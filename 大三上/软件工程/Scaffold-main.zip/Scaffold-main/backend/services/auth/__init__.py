"""
认证服务模块
"""
from .UserService import UserService

__all__ = ['UserService']

