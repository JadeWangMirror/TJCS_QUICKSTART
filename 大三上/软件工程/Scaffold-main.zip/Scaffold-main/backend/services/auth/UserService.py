"""
用户认证服务
处理用户注册、登录、密码验证等业务逻辑
"""
import bcrypt
import jwt
from datetime import datetime, timedelta
from typing import Optional, Dict

from backend.storage.DBManager import DBManager, get_db_manager
from backend.storage.models import User
from backend.utils.CCBLog import CCBLog


class UserService:
    """用户认证服务类"""
    
    # JWT 密钥（实际项目应该放在环境变量中）
    JWT_SECRET = "your-secret-key-change-this-in-production-scaffold-2025"
    JWT_ALGORITHM = "HS256"
    JWT_EXPIRATION_DAYS = 30  # token 有效期 30 天
    
    def __init__(self):
        self.log = CCBLog("UserService")
    
    def hash_password(self, password: str) -> str:
        """
        密码哈希加密
        
        Args:
            password: 明文密码
            
        Returns:
            str: 哈希后的密码
        """
        # bcrypt 会自动生成 salt
        hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        return hashed.decode('utf-8')
    
    def verify_password(self, password: str, hashed_password: str) -> bool:
        """
        验证密码
        
        Args:
            password: 明文密码
            hashed_password: 哈希后的密码
            
        Returns:
            bool: 密码是否正确
        """
        try:
            return bcrypt.checkpw(
                password.encode('utf-8'),
                hashed_password.encode('utf-8')
            )
        except Exception as e:
            self.log.error(f"密码验证失败: {e}")
            return False
    
    def generate_token(self, user_id: int) -> str:
        """
        生成 JWT token
        
        Args:
            user_id: 用户ID
            
        Returns:
            str: JWT token
        """
        payload = {
            'user_id': user_id,
            'exp': datetime.utcnow() + timedelta(days=self.JWT_EXPIRATION_DAYS),
            'iat': datetime.utcnow()
        }
        token = jwt.encode(payload, self.JWT_SECRET, algorithm=self.JWT_ALGORITHM)
        
        return token
    
    def verify_token(self, token: str) -> Optional[Dict]:
        """
        验证 JWT token
        
        Args:
            token: JWT token
            
        Returns:
            dict: 解码后的 payload，验证失败返回 None
        """
        try:
            payload = jwt.decode(token, self.JWT_SECRET, algorithms=[self.JWT_ALGORITHM])
            return payload
        except jwt.ExpiredSignatureError:
            self.log.warning("Token 已过期")
            return None
        except jwt.InvalidTokenError as e:
            self.log.warning(f"Token 无效: {e}")
            return None
    
    def _map_level_to_role(self, level: int) -> str:
        """
        将数据库的 level 映射为前端的 role
        
        Args:
            level: 用户权限等级
            
        Returns:
            str: role ('user', 'moderator', 'admin')
        """
        if level >= 10:
            return 'admin'
        elif level >= 5:
            return 'moderator'
        else:
            return 'user'
    
    def _format_user_response(self, user: User) -> Dict:
        """
        格式化用户信息，匹配前端 UserSummary 接口
        
        Args:
            user: User ORM 对象
            
        Returns:
            dict: 格式化后的用户信息
        """
        return {
            'id': str(user.id),  # 转为字符串
            'email': user.name,  # 数据库的 name 对应前端的 email
            'nickname': user.introduce or user.name,  # introduce 作为 nickname
            'avatarUrl': None,  # 暂无头像功能
            'bio': user.introduce,
            'role': self._map_level_to_role(user.level),
            'status': 'active',  # 默认 active，后续可扩展
            'followers': 0,  # 暂无关注功能
            'following': 0,
            'joinedAt': user.created_at.isoformat() + 'Z' if user.created_at else None
        }
    
    def register(self, name: str, password: str, email: str, introduce: str = '', tag: list = None) -> int:
        """
        用户注册
        
        Args:
            name: 用户名
            password: 明文密码
            email: 邮箱（必填）
            introduce: 个人简介
            tag: 标签列表
            
        Returns:
            int: 新创建用户的 user_id
            
        Raises:
            ValueError: 用户名已存在或参数无效
        """
        # 参数验证
        if not name or not password or not email:
            raise ValueError("用户名、密码和邮箱不能为空")
        
        if len(password) < 8:
            raise ValueError("密码长度至少 8 位")
        
        with get_db_manager().get_db_session() as session:
            # 检查用户名是否已存在
            existing_user = session.query(User).filter(User.name == name).first()
            if existing_user:
                raise ValueError("用户名已存在")
            
            # 检查邮箱是否已存在
            existing_email = session.query(User).filter(User.email == email).first()
            if existing_email:
                raise ValueError("该邮箱已被注册")
            
            # 密码哈希
            hashed_password = self.hash_password(password)
            
            # 处理 tag 格式：将列表转换为字典 {tag: count}
            tag_dict = {}
            if tag:
                for t in tag:
                    tag_dict[t] = tag_dict.get(t, 0) + 1
            
            # 创建用户
            new_user = User(
                name=name,
                email=email,
                password=hashed_password,
                level=1,  # 默认普通用户
                introduce=introduce if introduce else '',
                tag=tag_dict if tag_dict else None
            )
            
            session.add(new_user)
            session.flush()  # 获取自动生成的ID
            
            user_id = new_user.id
        
        self.log.info(f"用户注册成功: {name} (ID: {user_id})")
        
        return user_id
    
    def login(self, name: str, password: str) -> Dict:
        """
        用户登录
        
        Args:
            name: 用户名
            password: 明文密码
            
        Returns:
            dict: 包含 user_id, token, expires_in
            
        Raises:
            ValueError: 用户名不存在或密码错误
        """
        with get_db_manager().get_db_session() as session:
            # 查询用户
            user = session.query(User).filter(User.name == name).first()
            
            if not user:
                raise ValueError("用户名或密码错误")
            
            # 验证密码
            if not self.verify_password(password, user.password):
                raise ValueError("用户名或密码错误")
            
            # 生成 token
            token = self.generate_token(user.id)
            
            user_id = user.id
        
        self.log.info(f"用户登录成功: {name} (ID: {user_id})")
        
        return {
            'user_id': user_id,
            'token': token,
            'expires_in': self.JWT_EXPIRATION_DAYS * 24 * 3600  # 转换为秒
        }
    
    def get_user_by_id(self, user_id: int) -> Optional[Dict]:
        """
        根据 ID 获取用户信息
        
        Args:
            user_id: 用户ID
            
        Returns:
            dict: 用户信息，不存在返回 None
        """
        with get_db_manager().get_db_session() as session:
            user = session.query(User).filter(User.id == user_id).first()
            
            if not user:
                return None
            
            return self._format_user_response(user)
    
    def reset_password(self, email: str, new_password: str) -> bool:
        """
        重置用户密码
        
        Args:
            email: 用户邮箱
            new_password: 新密码（明文）
            
        Returns:
            bool: 是否重置成功
            
        Raises:
            ValueError: 邮箱不存在、新密码格式不符等错误
        """
        # 参数验证
        if not email or not new_password:
            raise ValueError("邮箱和新密码不能为空")
        
        if len(new_password) < 8:
            raise ValueError("密码长度至少 8 位")
        
        with get_db_manager().get_db_session() as session:
            # 查询用户
            user = session.query(User).filter(User.email == email).first()
            
            if not user:
                raise ValueError("该邮箱未注册")
            
            # 哈希新密码
            hashed_password = self.hash_password(new_password)
            
            # 更新密码
            user.password = hashed_password
            session.flush()
            
            user_id = user.id
            user_name = user.name
        
        self.log.info(f"用户密码重置成功: {user_name} (ID: {user_id})")
        
        return True

