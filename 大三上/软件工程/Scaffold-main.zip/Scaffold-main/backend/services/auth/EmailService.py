"""
邮箱验证服务
处理验证码生成、发送和验证
"""
import random
import string
import smtplib
import json
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta
from typing import Optional, Dict

from backend.services.api_client.AlibabaEmailAPI import AlibabaEmailAPI
from backend.utils.CCBLog import CCBLog
from backend.cache.cache import get_redis_client


class EmailService:
    """邮箱验证服务类"""
    
    # Redis key 前缀
    VERIFICATION_CODE_PREFIX = "email_verification:"
    
    def __init__(self):
        self.log = CCBLog("EmailService")
        self.code_expiry_minutes = 10  # 验证码有效期10分钟
        self.max_attempts = 5  # 最大验证尝试次数

    def _get_redis_key(self, email: str) -> str:
        """获取 Redis key"""
        return f"{self.VERIFICATION_CODE_PREFIX}{email}"
    
    def generate_code(self, length: int = 6) -> str:
        """
        生成随机验证码
        
        Args:
            length: 验证码长度，默认6位
            
        Returns:
            str: 验证码
        """
        return ''.join(random.choices(string.digits, k=length))
    
    def send_verification_code(self, email: str) -> bool:
        """
        发送验证码到指定邮箱
        
        Args:
            email: 目标邮箱地址
            
        Returns:
            bool: 是否发送成功
        """
        # 生成验证码
        code = self.generate_code()
        
        try:
            redis_client = get_redis_client()
            key = self._get_redis_key(email)
            
            # 保存验证码到 Redis
            code_info = {
                'code': code,
                'created_at': datetime.now().isoformat(),
                'attempts': 0
            }
            # 设置过期时间
            redis_client.setex(
                key,
                timedelta(minutes=self.code_expiry_minutes),
                json.dumps(code_info)
            )
            
            # 发送邮件
            text = f"您的验证码为: {code} ，十分钟内有效，请及时注册"
            AlibabaEmailAPI.sendEmail(to_address=email, text_body=text)
            self.log.info(f"验证码已发送到 {email}: {code} (有效期{self.code_expiry_minutes}分钟)")
            return True
            
        except Exception as e:
            self.log.error(f"发送验证码失败 {email}: {e}")
            return False
    
    def verify_code(self, email: str, code: str) -> tuple[bool, str]:
        """
        验证邮箱验证码
        
        Args:
            email: 邮箱地址
            code: 用户输入的验证码
            
        Returns:
            tuple: (是否验证成功, 错误消息)
        """
        try:
            redis_client = get_redis_client()
            key = self._get_redis_key(email)
            
            # 获取验证码信息
            data = redis_client.get(key)
            if not data:
                return False, "验证码不存在或已过期"
            
            code_info = json.loads(data)
            
            # 检查尝试次数
            if code_info['attempts'] >= self.max_attempts:
                redis_client.delete(key)
                return False, "验证码尝试次数过多，请重新发送"
            
            # 更新尝试次数
            code_info['attempts'] += 1
            
            # 验证码匹配
            if code_info['code'] == code:
                # 验证成功，删除验证码
                redis_client.delete(key)
                self.log.info(f"邮箱验证成功: {email}")
                return True, ""
            else:
                # 更新尝试次数到 Redis，保持原有过期时间
                remaining_ttl = redis_client.ttl(key)
                if remaining_ttl > 0:
                    redis_client.setex(key, remaining_ttl, json.dumps(code_info))
                
                remaining = self.max_attempts - code_info['attempts']
                return False, f"验证码错误，还可尝试 {remaining} 次"
                
        except Exception as e:
            self.log.error(f"验证码验证异常: {e}")
            return False, "验证服务异常，请稍后重试"
    
    def clear_expired_codes(self):
        """
        清理过期的验证码
        注意：使用 Redis 后，过期验证码会自动被 Redis 清理，此方法保留仅为接口兼容
        """
        self.log.info("使用 Redis 存储，过期验证码由 Redis 自动清理")
    
    def can_send_code(self, email: str, cooldown_seconds: int = 60) -> tuple[bool, str]:
        """
        检查是否可以发送验证码（防止频繁发送）
        
        Args:
            email: 邮箱地址
            cooldown_seconds: 冷却时间（秒）
            
        Returns:
            tuple: (是否可以发送, 提示消息)
        """
        try:
            redis_client = get_redis_client()
            key = self._get_redis_key(email)
            
            data = redis_client.get(key)
            if data:
                code_info = json.loads(data)
                created_at = datetime.fromisoformat(code_info['created_at'])
                time_passed = (datetime.now() - created_at).total_seconds()
                
                if time_passed < cooldown_seconds:
                    remaining = int(cooldown_seconds - time_passed)
                    return False, f"请 {remaining} 秒后再试"
            
            return True, ""
            
        except Exception as e:
            self.log.error(f"检查发送冷却异常: {e}")
            # 出错时允许发送，避免阻塞用户
            return True, ""
