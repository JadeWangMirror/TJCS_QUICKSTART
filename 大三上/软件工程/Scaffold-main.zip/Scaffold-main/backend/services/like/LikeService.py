# Service 层 - 点赞业务逻辑

from flask import jsonify
from typing import Tuple
from backend.storage.LikeDB import LikeDB
from backend.cache.PostRedis import check_and_trigger_hot_refresh, update_post_detail_count
from backend.cache.tasks import update_user_profile_task
from backend.utils.CCBLog import CCBLog

def toggle_like_post_comment(user_id: int, post_id: int) -> Tuple[dict, int]:
    """
    切换点赞状态：如果用户已点赞则取消点赞，否则执行点赞
    
    业务逻辑流程：
    1. 检查用户是否已经点赞过该帖子/评论
    2. 如果已点赞：
       - 删除点赞记录（从 likes 表）
       - 更新点赞计数 -1（在 posts_comments 表）
       - 返回 is_liked=False
    3. 如果未点赞：
       - 创建点赞记录（插入 likes 表）
       - 更新点赞计数 +1（在 posts_comments 表）
       - 返回 is_liked=True
    4. 在两种情况下都返回最新的点赞总数
    
    :param user_id: 点赞用户的ID
    :param post_id: 被点赞的帖子/评论ID
    :return: (JSON响应, HTTP状态码)
    """
    try:
        db_manager = LikeDB()
        
        # 1. 检查用户是否已经点赞过该帖子/评论
        is_already_liked = db_manager.check_user_liked(user_id=user_id, post_id=post_id)
        
        if is_already_liked:
            # 2a. 如果已点赞，执行取消点赞操作
            deleted_count = db_manager.delete_like(user_id=user_id, post_id=post_id)
            
            if deleted_count > 0:
                # 2b. 删除成功，更新点赞计数 -1
                db_manager.decrement_post_like_count(post_id=post_id)
                update_post_detail_count(post_id=post_id, count_type='like', increment=-1)
                update_user_profile_task.delay(user_id=user_id, post_id=post_id, increment=-2.0)
                
                # 2c. 获取更新后的点赞总数并返回
                like_count = db_manager.get_post_like_count(post_id=post_id)
                
                return jsonify({
                    "status": "success",
                    "message": "已取消点赞",
                    "post_id": post_id,
                    "is_liked": False,
                    "like_count": like_count
                }), 200
            else:
                # 删除失败
                return jsonify({"error": "取消点赞失败"}), 400
        
        else:
            # 3a. 如果未点赞，执行点赞操作
            insert_success = db_manager.insert_like(user_id=user_id, post_id=post_id)
            
            if insert_success:
                # 3b. 插入成功，更新点赞计数 +1
                db_manager.increment_post_like_count(post_id=post_id)
                update_post_detail_count(post_id=post_id, count_type='like', increment=1)
                update_user_profile_task.delay(user_id=user_id, post_id=post_id, increment=3.0)
                check_and_trigger_hot_refresh(3)
                
                # 3c. 获取更新后的点赞总数并返回
                like_count = db_manager.get_post_like_count(post_id=post_id)
                
                return jsonify({
                    "status": "success",
                    "message": "点赞成功",
                    "post_id": post_id,
                    "is_liked": True,
                    "like_count": like_count
                }), 200
            else:
                # 插入失败（通常因为重复点赞）
                return jsonify({"error": "点赞失败"}), 400
    
    except Exception as e:
        CCBLog('toggle_like_post_comment').error(f"切换点赞状态失败: {e}")
        raise


def check_user_liked(user_id: int, post_id: int) -> bool:
    """
    检查用户是否已经点赞了某个帖子/评论
    
    :param user_id: 用户ID
    :param post_id: 帖子/评论ID
    :return: True 表示已点赞，False 表示未点赞
    """
    try:
        db_manager = LikeDB()
        is_liked = db_manager.check_user_liked(user_id=user_id, post_id=post_id)
        return is_liked
    
    except Exception as e:
        CCBLog('check_user_liked').error(f"检查点赞状态失败: {e}")
        raise


def get_post_like_count(post_id: int) -> int:
    """
    获取帖子/评论的点赞总数
    
    :param post_id: 帖子/评论ID
    :return: 点赞总数
    """
    try:
        db_manager = LikeDB()
        like_count = db_manager.get_post_like_count(post_id=post_id)
        return like_count
    
    except Exception as e:
        CCBLog('get_post_like_count').error(f"获取点赞数失败: {e}")
        raise
