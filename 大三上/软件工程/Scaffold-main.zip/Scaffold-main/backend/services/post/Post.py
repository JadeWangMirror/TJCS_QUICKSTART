import math
import time
from datetime import datetime, timezone
from flask import request, jsonify, url_for
from typing import List, Dict, Any, Optional
from collections import deque
from backend.storage.PostDB import PostDB
from backend.utils.CCBLog import CCBLog
from backend.utils.HandleFileURL import save_files, delete_url_list
from backend.cache.PostRedis import get_cached_posts_by_key
from backend.cache.tasks import cache_recommendation_post_ids_task, push_new_post_task, update_user_profile_task, cache_posts_task
from backend.cache.cache import get_global_key_map
from backend.cache.PostRedis import check_and_trigger_hot_refresh, update_post_detail_count, update_post_cache_by_id, delete_post_cache, get_or_create_tag_indices, cache_item_profile, get_cached_user_profile, get_candidate_post_ids, get_cached_item_profiles

# 定义批量查询的大小，用于优化数据库I/O
RECOMMEND_MIN_BATCH_SIZE = 5 
RECOMMEND_MAX_BATCH_SIZE = 30

def get_post_list(order: str, limit: int, page_num: int):
    offset = (page_num - 1) * limit
    key = order
    key_map = get_global_key_map()
    max_len = key_map[key]['MAX_LEN']
    try:
        posts_data, total_count = get_cached_posts_by_key(key=key, start=offset, end=offset + limit - 1)
        if not posts_data:
            db_manager = PostDB()
            posts_data, total_count = db_manager.get_posts_by_args_ordered_by_arg(
                    order=order, limit=limit, offset=offset
                )
        page_count = math.ceil(total_count / limit)
        return jsonify({
            "status": "success",
            "count": len(posts_data),
            "limit": limit,
            "page_num": page_num,
            "page_count": page_count,
            "posts": posts_data
        }), 200
    
    except Exception as e:
        # 捕获数据库连接或查询错误
        CCBLog("Post").error(f"获取帖子列表失败: {e}")
        return jsonify({"error": "服务器内部错误，无法获取帖子列表"}), 500

def get_posts(tags: List[str] = None, author_name: str = '', context_snippet: str = '', time_limit_seconds: Optional[int] = None, order: str = 'time', limit: int = 10, page_num: int = 1):    
    offset = (page_num - 1) * limit
    # 1. 调用 PostDB 方法获取数据
    try:
        db_manager = PostDB()
        posts_data, post_count = db_manager.get_posts_by_args_ordered_by_arg(tags=tags, author_name=author_name, context_snippet=context_snippet, time_limit_seconds=time_limit_seconds, order=order, limit=limit, offset=offset)
        page_count = post_count // limit + 1 if post_count % limit != 0 else 0

        # 2. 返回 JSON 响应
        return jsonify({
            "status": "success",
            "count": len(posts_data),
            "limit": limit,
            "page_num": page_num,
            "page_count": page_count,
            "posts": posts_data
        }), 200
        
    except Exception as e:
        # 捕获数据库连接或查询错误
        CCBLog("Post").error(f"获取帖子列表失败: {e}")
        return jsonify({"error": "服务器内部错误，无法获取帖子列表"}), 500

def get_recommend_posts(user_id, limit, page_num):
    offset = (page_num - 1) * limit
    # 2. 获取用户标签并处理无标签回退
    db_manager = PostDB()
    tags_count = db_manager.get_tags_by_user_id(user_id=user_id)
    if not tags_count:
        # 如果用户无标签，回退到全局热门（按浏览数）并应用全局 offset/limit
        return get_posts(order='browse', limit=limit, page_num=page_num)

    # --- 解决全局 OFFSET 的核心逻辑 ---
    
    # 3. 初始化采样变量
    total_needed = limit + offset
    remain_to_collect = total_needed
    
    sorted_tags_desc_list = sorted(tags_count.items(), key=lambda item: item[1], reverse=True)
    l = min(4, len(sorted_tags_desc_list)) 
    
    # 记录每个标签已从数据库加载的帖子的总数（用于数据库 offset）
    db_offset_map = {tag: 0 for tag, _ in sorted_tags_desc_list[:l]}
    
    # 缓冲区：存储已加载但未使用的帖子，使用 deque 方便快速移除
    tag_buffers = {tag: deque() for tag, _ in sorted_tags_desc_list[:l]}
    
    posts_data_full = []
    post_id_set = set()
    
    tag_index = 0
    tags_exhausted_count = 0
    
    # 4. 辅助函数：尝试为缓冲区填充数据
    def fill_buffer(tag_name):
        nonlocal tags_exhausted_count
        
        current_db_offset = db_offset_map[tag_name]

        # 1. 计算我们还需要收集多少帖子 (总计)
        remaining_overall = total_needed - len(posts_data_full)
        
        # 2. 动态计算批量大小 (Dynamic Batch Size Calculation)
        # 目标：尝试将剩余的帖子均摊到每个标签的未来查询中，但受限于 MAX/MIN 限制
        
        # 计算每个标签理论上还需要贡献的平均数量
        # 如果 remaining_overall 很大，这个值也会很大
        average_per_tag_needed = remaining_overall // l
        
        # 动态 batch_size：
        # - 不能超过 MAX_BATCH_SIZE (内存安全)
        # - 不能低于 MIN_BATCH_SIZE (效率保证)
        # - 不能超过平均值 (避免收尾阶段浪费过多数据)
        dynamic_batch_size = min(RECOMMEND_MAX_BATCH_SIZE, average_per_tag_needed)
        dynamic_batch_size = max(RECOMMEND_MIN_BATCH_SIZE, dynamic_batch_size)
        
        # 从数据库批量查询
        post_list_from_db, post_count = db_manager.get_posts_by_args_ordered_by_arg(
            tags=[tag_name], 
            limit=dynamic_batch_size, 
            offset=current_db_offset,
            order='browse'
        )
        page_count = post_count // limit + 1 if post_count % limit != 0 else 0
        
        if post_list_from_db:
            # 更新数据库偏移量
            db_offset_map[tag_name] += len(post_list_from_db)
            # 将查询结果添加到缓冲区
            tag_buffers[tag_name].extend(post_list_from_db)
            return True
        else:
            # 如果数据库查询结果为空，标记该标签已采尽 (使用 None 标记)
            if db_offset_map[tag_name] != -1:
                db_offset_map[tag_name] = -1
                tags_exhausted_count += 1
            return False

    # 5. 模拟轮询采样过程
    while remain_to_collect > 0 and tags_exhausted_count < l:
        
        current_tag_index = tag_index % l
        tag, _ = sorted_tags_desc_list[current_tag_index]
        
        # 5.1 如果缓冲区为空且未采尽，尝试填充缓冲区
        if not tag_buffers[tag] and db_offset_map[tag] != -1:
             fill_buffer(tag)

        # 5.2 从缓冲区中取出帖子
        if tag_buffers[tag]:
            post = tag_buffers[tag].popleft()
            
            # 5.3 检查是否重复
            if post['id'] not in post_id_set:
                posts_data_full.append(post)
                post_id_set.add(post['id'])
                remain_to_collect -= 1
        
        # 移到下一个标签
        tag_index += 1
    
    # 6. 提取最终结果 (应用全局 offset)
    final_posts = posts_data_full[offset : total_needed]

    return jsonify({
        "status": "success",
        "count": len(final_posts),
        "limit": limit,
        "page_num": page_num,
        #"page_count": page_count,
        "posts": final_posts
    }), 200

def create_insert_post(title, author_name, context, user_id, tags_list, url_list):
    #url_list = save_files(files=files)
    try:
        db_manager = PostDB()
        current_datetime_utc = datetime.now()
        db_insert_time = current_datetime_utc.strftime('%Y-%m-%d %H:%M:%S')
        cache_timestamp_float = current_datetime_utc.timestamp()
        post_id = db_manager.insert_post(
            timestamp=db_insert_time, # 插入数据库
            title=title, 
            context=context, 
            author_id= user_id,
            tags=tags_list,      # 传递 tags 列表
            url_list=url_list    # 传递 URL 列表
        )

        post = {
            'id': post_id,
            'title': title,
            'context': context,
            'author_id': user_id,
            'author': author_name,
            'timestamp': cache_timestamp_float, # 传给redis
            'cover_image': url_list[0] if len(url_list) > 0 else None,
            'tags': tags_list,
            'browse_count': 0,
            'like_count': 0,
            'comment_count': 0,
        }

        push_new_post_task.delay(post=post)

        update_post_profiles_on_creation(post_id=post_id, tags_list=tags_list)

        return jsonify({
            "message": "帖子创建成功",
            "post_id": post_id,
            "image_urls": url_list
        }), 201 # 201 Created
        
    except Exception as e:
        # 打印或记录详细错误信息
        CCBLog("Post").error(f"数据库插入失败: {e}")
        # 如果是数据库错误（如 foreign key constraint），应该回滚
        return jsonify({"error": "数据库操作失败", "details": str(e)}), 500

def post_update(post_id, title, context, user_id, tags_list, new_files:list[str]):
    try:
        db_manager = PostDB()
        old_url_list = db_manager.get_url_list_by_post_id(post_id=post_id)

        # ↓ 如果在旧文件而不在新文件，就是删除状态
        delete_files = [file for file in old_url_list if file not in new_files]
        res = delete_url_list(url_list=delete_files)
        CCBLog("PostUpdate").info(f"删除文件：{res}个")
        rowcount = db_manager.update_post(
            post_id=post_id,
            title=title, 
            context=context, 
            author_id= int(user_id),
            tags=tags_list,      # 传递 tags 列表
            url_list=new_files  # 传递 URL 列表
        )

        if rowcount > 0:
            update_post_cache_by_id(post_id=post_id)
            return jsonify({
                "message": "帖子编辑成功"
            }), 200 # OK
        else:
            return jsonify({
                "error": "无此帖/权限不足/要修改的是评论"
            }), 400
    
    except Exception as e:
        # 打印或记录详细错误信息
        CCBLog("Post").error(f"数据库编辑失败: {e}")
        # 如果是数据库错误（如 foreign key constraint），应该回滚
        return jsonify({"error": "数据库操作失败", "details": str(e)}), 500

def post_comment_delete(user_id, id):
    id = int(id)
    db_manager = PostDB()
    root_post_id, delete_count = db_manager.delete_post_comment(user_id=user_id, id=id)
    if delete_count > 0 and root_post_id != id:
        update_post_detail_count(post_id=root_post_id, count_type='comment', increment=-delete_count)
        update_user_profile_task.delay(user_id=user_id, post_id=root_post_id, increment=-3.0)
    elif delete_count > 0 and root_post_id == id:
        result = delete_post_cache(post_id=id)
    return delete_count

def create_insert_comment(point_id, context, user_id, url_list):
    #url_list = save_files(files=files)
    try:
        db_manager = PostDB()
        comment_id = db_manager.insert_comment(
            point_id=point_id,
            context=context,
            author_id=user_id,
            url_list=url_list    # 传递 URL 列表
        )
        update_post_detail_count(post_id=point_id, count_type='comment', increment=1)
        check_and_trigger_hot_refresh(5)
        update_user_profile_task.delay(user_id=user_id, post_id=db_manager._get_root_post_id(comment_id), increment=5.0)

        return jsonify({
            "message": "帖子创建成功",
            "comment_id": comment_id,
            "image_urls": url_list
        }), 201 # 201 Created
        
    except Exception as e:
        # 打印或记录详细错误信息
        CCBLog("Post").error(f"数据库插入失败: {e}")
        # 如果是数据库错误（如 foreign key constraint），应该回滚
        return jsonify({"error": "数据库操作失败", "details": str(e)}), 500


def get_post_detail(user_id: int, post_id: int):
    db_manager = PostDB()
    post_detail = db_manager.get_post_detail(user_id=user_id, post_id=post_id)
    if post_detail:
        return jsonify({
            "status": "success",
            "post": post_detail
        }), 200
    else:
        return jsonify({"error": "帖子不存在或无访问权限"}), 404
    
#更新:新增帖子详情和浏览历史相关函数
def get_post_detail_with_browse(user_id: Optional[int], post_id: int):
    """
    获取帖子详情并处理浏览相关逻辑。
    
    - 无论用户是否登录，都增加帖子浏览数
    - 若用户已登录（user_id 为有效数字），记录浏览历史
    
    :param user_id: 用户ID，若未登录则为 None
    :param post_id: 帖子ID
    :return: JSON 响应
    """
    try:
        db_manager = PostDB()
        
        # 1. 增加帖子浏览数
        success = db_manager.increase_post_browse_count(post_id)
        if not success:
            return jsonify({"error": "帖子不存在"}), 404
        update_post_detail_count(post_id=post_id, count_type='browse', increment=1)
        CCBLog("browse").info(f"updating user {user_id} profile")
        update_user_profile_task.delay(user_id=user_id, post_id=post_id, increment=1.0)
        check_and_trigger_hot_refresh(1)
        
        # 2. 如果用户已登录，记录浏览历史并更新推荐标签
        browse_logger = CCBLog("BrowseHistory")
        if user_id is not None and isinstance(user_id, int) and user_id > 0:
            
            browse_logger.info(f"尝试记录浏览历史 user_id={user_id}, post_id={post_id}")

            browse_success = db_manager.record_user_browse(user_id, post_id)
            if browse_success:
                browse_logger.info(f"记录浏览历史成功 user_id={user_id}, post_id={post_id}")
            else:
                browse_logger.warning(f"记录浏览历史失败(未插入/未更新行) user_id={user_id}, post_id={post_id}")

            # 同时更新用户的推荐标签
            recommend_success = db_manager.update_user_recommend_tags(user_id, post_id)
            if recommend_success:
                browse_logger.info(f"更新推荐标签成功 user_id={user_id}, post_id={post_id}")
            else:
                browse_logger.warning(f"更新推荐标签失败 user_id={user_id}, post_id={post_id}")
        else:
            browse_logger.info(f"未记录浏览历史，用户未登录或无效 user_id={user_id}, post_id={post_id}")
        # 3. 获取帖子详情
        post_detail = db_manager.get_post_detail(post_id)
        get_user_browse_history_list
        if post_detail:
            return jsonify({
                "status": "success",
                "post": post_detail
            }), 200
        else:
            return jsonify({"error": "帖子不存在"}), 404
    
    except Exception as e:
        CCBLog("Post").error(f"获取帖子详情失败: {e}")
        return jsonify({"error": "服务器内部错误"}), 500


def get_user_browse_history_list(user_id: int, limit: int = 10, page_num: int = 1):
    """获取用户的浏览历史记录列表（分页：第几页）。

    :param user_id: 用户ID
    :param limit: 每页数量
    :param page_num: 第几页（从 1 开始）
    :return: JSON 响应
    """
    if limit < 1 or page_num < 1:
        return jsonify({"error": "Limit 必须大于 0 且 PageNum 必须为正"}), 400

    # 计算偏移量
    offset = (page_num - 1) * limit

    try:
        db_manager = PostDB()

        # 获取浏览历史总数
        total_count = db_manager.get_user_browse_history_count(user_id)

        # 获取浏览历史记录
        history_list = db_manager.get_user_browse_history(user_id, limit, offset)

        page_count = 0
        if limit > 0:
            page_count = math.ceil(total_count / limit)

        return jsonify({
            "status": "success",
            "count": len(history_list),
            "total_count": total_count,
            "limit": limit,
            "page_num": page_num,
            "page_count": page_count,
            "records": history_list
        }), 200

    except Exception as e:
        CCBLog("Post").error(f"获取浏览历史失败: {e}")
        return jsonify({"error": "服务器内部错误"}), 500


def delete_user_browse_record(user_id: int, record_id: int):
    """
    删除用户的某条浏览历史记录。
    
    :param user_id: 用户ID（用于验证所有权）
    :param record_id: 浏览历史记录ID
    :return: JSON 响应
    """
    try:
        db_manager = PostDB()
        
        # 删除浏览历史记录（会验证所有权）
        success = db_manager.delete_user_browse_history_record(user_id, record_id)
        
        if success:
            return jsonify({"status": "success", "message": "浏览历史删除成功"}), 200
        else:
            return jsonify({"error": "记录不存在或无权限删除"}), 404
    
    except Exception as e:
        CCBLog("Post").error(f"删除浏览历史失败: {e}")
        return jsonify({"error": "服务器内部错误"}), 500


def clear_user_browse_history(user_id: int):
    """
    清空用户的所有浏览历史记录。
    
    :param user_id: 用户ID
    :return: JSON 响应
    """
    try:
        db_manager = PostDB()
        
        # 直接执行 DELETE 查询清空该用户所有历史
        sql = "DELETE FROM user_browse_history WHERE user_id = :user_id"
        params = {"user_id": user_id}
        result = db_manager.execute_dml(sql, params)
        
        return jsonify({
            "status": "success",
            "message": "浏览历史已清空",
            "deleted_count": result.rowcount
        }), 200
    
    except Exception as e:
        CCBLog("Post").error(f"清空浏览历史失败: {e}")
        return jsonify({"error": "服务器内部错误"}), 500


def get_user_posts(user_id: int, limit: int = 10, page_num: int = 1):
    """获取指定用户发布的主贴列表（用户主页“我的帖子”）。

    :param user_id: 用户ID
    :param limit: 每页数量
    :param page_num: 页码（从1开始）
    :return: JSON 响应
    """
    if page_num < 1 or limit < 1:
        return jsonify({"error": "Limit 必须大于 0 且 PageNum 必须为正"}), 400

    offset = (page_num - 1) * limit

    try:
        db_manager = PostDB()
        posts, total_count = db_manager.get_posts_by_user_id(user_id=user_id, limit=limit, offset=offset)

        page_count = 0
        if limit > 0:
            page_count = math.ceil(total_count / limit)

        return jsonify({
            "status": "success",
            "count": len(posts),
            "limit": limit,
            "page_num": page_num,
            "page_count": page_count,
            "total_count": total_count,
            "posts": posts
        }), 200

    except Exception as e:
        CCBLog('get_user_posts').error(f"获取用户帖子失败: {e}")
        return jsonify({"error": "服务器内部错误"}), 500


def get_user_posts(user_id: int, limit: int = 10, page_num: int = 1):
    """获取指定用户发布的主贴列表（用户主页“我的帖子”）。

    :param user_id: 用户ID
    :param limit: 每页数量
    :param page_num: 页码（从1开始）
    :return: JSON 响应
    """
    if page_num < 1 or limit < 1:
        return jsonify({"error": "Limit 必须大于 0 且 PageNum 必须为正"}), 400

    offset = (page_num - 1) * limit

    try:
        db_manager = PostDB()
        posts, total_count = db_manager.get_posts_by_user_id(user_id=user_id, limit=limit, offset=offset)

        page_count = 0
        if limit > 0:
            page_count = math.ceil(total_count / limit)

        return jsonify({
            "status": "success",
            "count": len(posts),
            "limit": limit,
            "page_num": page_num,
            "page_count": page_count,
            "total_count": total_count,
            "posts": posts
        }), 200

    except Exception as e:
        CCBLog('get_user_posts').error(f"获取用户帖子失败: {e}")
        return jsonify({"error": "服务器内部错误"}), 500



def calculate_cosine_similarity(profile_a: Dict[int, float], profile_b: Dict[int, float]) -> float:
    """
    计算两个稀疏画像字典之间的余弦相似度。
    
    Args:
        profile_a: 第一个画像字典 {tag_index: score}。
        profile_b: 第二个画像字典 {tag_index: score}。
        
    Returns:
        余弦相似度分数 (0.0 到 1.0)。
    """
    if not profile_a or not profile_b:
        return 0.0
    
    dot_product = 0.0
    for tag_index, socre_a in profile_a.items():
        if tag_index in profile_b:
            socre_b = profile_b[tag_index]
            dot_product += socre_a * socre_b
    
    if dot_product == 0.0:
        return 0.0
    
    magnitude_a = math.sqrt(sum(score_a ** 2 for score_a in profile_a.values()))
    magnitude_b = math.sqrt(sum(score_b ** 2 for score_b in profile_b.values()))
    if magnitude_a == 0.0 or magnitude_b == 0.0:
        return 0.0
    
    return dot_product / (magnitude_a * magnitude_b)

def update_post_profiles_on_creation(post_id: int, tags_list: List[str]):
    """
    发布新帖子时，同步更新标签表和创建 Item Profile。
    
    Args:
        post_id: 新发布的帖子 ID。
        tags_list: 帖子包含的标签列表 (如 ['Python', 'AI'])。
    """
    if not tags_list:
        return
    
    item_profiles_data = []
    
    try:
        # 1. 批量获取或创建标签索引
        tag_indices_map = get_or_create_tag_indices(tags_list)

        # 2. 构造 Item Profile 数据结构
        for tag_name in tags_list:
            tag_index = tag_indices_map.get(tag_name)

            if tag_index and tag_index > 0:
                item_profiles_data.append({
                    'post_id': post_id,
                    'tag_index': tag_index,
                    'tag_value': 1 
                })
            else:
                # 如果某个标签索引获取失败，记录警告并继续
                CCBLog("item_profile").warning(f"Could not retrieve index for tag: {tag_name} during post {post_id} creation.")
                

        # 3. 批量插入和缓存
        if item_profiles_data:
            from backend.storage.PostDB import PostDB
            db_manager = PostDB()

            # 插入 DB
            db_manager.batch_insert_item_profiles(item_profiles_data)
            
            # 缓存
            cache_item_profile(post_id=post_id, item_profiles_data=item_profiles_data)
            
    except Exception as e:
        # 确保任何数据库或批量标签操作失败时，都向上抛出以回滚帖子发布事务
        CCBLog("item_profile").error(f"Failed to update profiles for post {post_id} due to underlying error. Error: {e}")
        raise

def get_recall_post_ids(user_id: int, recall_limit: int = 100) -> List[tuple[int, float]]:
    """
    执行基于内容的召回，计算用户与候选帖子的相似度。

    Args:
        user_id: 目标用户 ID。
        recall_limit: 召回结果的数量限制。

    Returns:
        [(post_id, similarity_score), ...] 的列表，按分数降序排列。
    """
    # 1. 获取目标用户画像 U
    user_profile = get_cached_user_profile(user_id=user_id)
    if not user_profile:
        return []

    # 2. 获取候选帖子 ID
    CANDIDATE_POOL_SIZE = 500
    candidate_post_ids = get_candidate_post_ids(limit=CANDIDATE_POOL_SIZE)
    #CCBLog("get_recall_post_ids").info(f"candidate posts {candidate_post_ids[:recall_limit]} for user {user_id}")
    
    # 3. 批量获取候选帖子的画像
    # CCBLog('get_recall_post_ids').info(f'candidate_post_ids: {candidate_post_ids}')
    item_profiles_map = get_cached_item_profiles(candidate_post_ids)

    recall_results = []

    db_manager = PostDB()
    history_list = db_manager.get_user_browse_history(user_id=user_id, limit=CANDIDATE_POOL_SIZE)
    user_read_post_ids = [history["post_id"] for history in history_list]

    # 4. 批量计算相似度
    #CCBLog("get_recall_post_ids").info(f"{user_profile}")
    for post_id, item_profile in item_profiles_map.items():
        if post_id in user_read_post_ids:
            continue
        score = calculate_cosine_similarity(user_profile, item_profile)
        #CCBLog("get_recall_post_ids").info(f"{post_id}: {score}\n{item_profile}")
        if score > 0.0: # 只保留有共同兴趣标签的帖子
            recall_results.append((post_id, score))
    
    # 5. 排序并返回 Top K 结果
    recall_results.sort(key=lambda x: x[1], reverse=True)
    # CCBLog("get_recall_post_ids").info(f"recommend posts {recall_results[:recall_limit]} for user {user_id}")
    return recall_results[:recall_limit]

def get_recommendation_list(user_id: int, limit: int, page_num: int):
    offset = (page_num - 1) * limit
    key = "recommendation"
    key_map = get_global_key_map()
    max_len = key_map[key]['MAX_LEN']
    try:
        posts_data, total_count = get_cached_posts_by_key(key=key, start=offset, end=offset + limit - 1, user_id=user_id)
        if not posts_data:
            recommend_post_ids = get_recall_post_ids(user_id=user_id, recall_limit=max_len)
            if recommend_post_ids:
                cache_recommendation_post_ids_task.delay(key=key, post_ids=recommend_post_ids, user_id=user_id)
                post_ids = [post_id[0] for post_id in recommend_post_ids]
                db_manager = PostDB()
                posts_data, total_count = db_manager.get_posts_by_ids(post_ids)
                cache_posts_task.delay(posts=posts_data)
                posts_data = posts_data[offset:offset + limit - 1]
        else:
            CCBLog("get_recommendation_list").info(f"get {total_count} post(s) from cache")
        if total_count < limit:
            return get_post_list(order='hot', limit=limit, page_num=page_num)
        page_count = math.ceil(total_count / limit)
        return jsonify({
            "status": "success",
            "count": len(posts_data),
            "limit": limit,
            "page_num": page_num,
            "page_count": page_count,
            "posts": posts_data
        }), 200
    
    except Exception as e:
        # 捕获数据库连接或查询错误
        CCBLog("Post").error(f"获取帖子列表失败: {e}")
        return jsonify({"error": "服务器内部错误，无法获取帖子列表"}), 500
