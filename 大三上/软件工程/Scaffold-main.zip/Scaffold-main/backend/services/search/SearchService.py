from flask import jsonify
from typing import Optional
from backend.storage.SearchDB import SearchDB
from backend.utils.CCBLog import CCBLog

def search_posts(user_id: Optional[int], search_query: str, search_type: str, limit: int = 10, page_num: int = 1):
    """搜索帖子并记录搜索历史（分页：第几页）。"""

    if not search_query or not search_query.strip():
        return jsonify({"error": "搜索关键词不能为空"}), 400

    if search_type not in ['title', 'content', 'tag']:
        return jsonify({"error": "搜索类型必须是 title、content 或 tag 之一"}), 400

    if limit < 1 or page_num < 1:
        return jsonify({"error": "Limit 必须大于 0 且 PageNum 必须为正"}), 400

    normalized_query = search_query.strip()
    offset = (page_num - 1) * limit

    try:
        db_manager = SearchDB()

        results, total_count = db_manager.search_posts(
            search_query=normalized_query,
            search_type=search_type,
            limit=limit,
            offset=offset
        )

        if user_id is not None and isinstance(user_id, int) and user_id > 0:
            db_manager.record_search_history(
                user_id=user_id,
                search_query=normalized_query,
                search_type=search_type
            )

        page_count = 0
        if limit > 0:
            page_count = (total_count + limit - 1) // limit

        return jsonify({
            "status": "success",
            "query": normalized_query,
            "search_type": search_type,
            "count": len(results),
            "limit": limit,
            "page_num": page_num,
            "page_count": page_count,
            "posts": results
        }), 200

    except ValueError as ve:
        return jsonify({"error": str(ve)}), 400
    except Exception as e:
        CCBLog('search_posts').error(f"搜索失败: {e}")
        return jsonify({"error": "服务器内部错误，搜索失败"}), 500


def get_search_history(user_id: int, limit: int = 10, page_num: int = 1):
    """获取用户搜索历史记录列表（分页：第几页）。

    :param user_id: 用户ID
    :param limit: 每页数量
    :param page_num: 第几页（从1开始）
    :return: JSON响应
    """
    if limit < 1 or page_num < 1:
        return jsonify({"error": "Limit 必须大于 0 且 PageNum 必须为正"}), 400

    # 计算偏移量
    offset = (page_num - 1) * limit

    try:
        db_manager = SearchDB()

        # 获取搜索历史总数
        total_count = db_manager.get_search_history_count(user_id)

        # 获取搜索历史记录
        history_list = db_manager.get_search_history(user_id, limit, offset)

        page_count = 0
        if limit > 0:
            page_count = (total_count + limit - 1) // limit

        return jsonify({
            "status": "success",
            "count": len(history_list),
            "total_count": total_count,
            "limit": limit,
            "page_num": page_num,
            "page_count": page_count,
            "records": history_list
        }), 200

    except Exception as e:
        CCBLog('get_search_history').error(f"获取搜索历史失败: {e}")
        return jsonify({"error": "服务器内部错误"}), 500


def delete_search_history_record(user_id: int, record_id: int):
    """
    删除用户的某条搜索历史记录。

    :param user_id: 用户ID（用于验证所有权）
    :param record_id: 搜索历史记录ID
    :return: JSON响应
    """
    try:
        db_manager = SearchDB()

        # 删除搜索历史记录（会验证所有权）
        success = db_manager.delete_search_history_record(user_id, record_id)

        if success:
            return jsonify({"status": "success", "message": "搜索历史删除成功"}), 200
        else:
            return jsonify({"error": "记录不存在或无权限删除"}), 404

    except Exception as e:
        CCBLog('delete_search_history_record').error(f"删除搜索历史失败: {e}")
        return jsonify({"error": "服务器内部错误"}), 500


def clear_search_history(user_id: int):
    """
    清空用户的所有搜索历史记录。

    :param user_id: 用户ID
    :return: JSON响应
    """
    try:
        db_manager = SearchDB()

        # 执行清空操作
        deleted_count = db_manager.clear_search_history(user_id)

        return jsonify({
            "status": "success",
            "message": "搜索历史已清空",
            "deleted_count": deleted_count
        }), 200

    except Exception as e:
        CCBLog('clear_search_history').error(f"清空搜索历史失败: {e}")
        return jsonify({"error": "服务器内部错误"}), 500