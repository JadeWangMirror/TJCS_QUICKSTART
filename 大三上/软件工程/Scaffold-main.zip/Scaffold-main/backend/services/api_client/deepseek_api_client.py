"""
DeepSeek API
"""

import requests
from backend.config.ConfigReader import *
from backend.utils.CCBLog import CCBLog

class DeepSeekClient:
    def __init__(self):
        deepseek_config = ConfigReader("./backend/config/api_config.json").read_config()["DEEPSEEK_CONFIG"]
        self.api_key = deepseek_config["api_key"]
        self.base_url = deepseek_config["base_url"]
        self.model = deepseek_config["model"]
        self.temperature = deepseek_config["temperature"]
        self.max_tokens = deepseek_config["max_tokens"]
        # CCBLog('DeepSeekClient').info(self.api_key,self.base_url)
    
    def call_api(self, messages):
        """调用DeepSeek API"""
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "stream": False
        }
        
        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=headers,
                json=payload,
                timeout=60
            )
            # CCBLog('call_api').info(response.json())
            response.raise_for_status()
            result = response.json()
            return result["choices"][0]["message"]["content"]
        except Exception as e:
            CCBLog('call_api').error(f"API调用错误: {e}")
            return None