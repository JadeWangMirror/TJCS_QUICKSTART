import sys

from typing import List

from aiofiles.os import access
from alibabacloud_dm20151123.client import Client as Dm20151123Client
from alibabacloud_tea_openapi import models as open_api_models
from alibabacloud_dm20151123 import models as dm_20151123_models
from alibabacloud_tea_util import models as util_models
from alibabacloud_tea_util.client import Client as UtilClient

from backend.config import ConfigReader
from backend.utils.CCBLog import CCBLog

RANDOM_ACCOUNT = 0
SAME_ACCOUNT = 1

class AlibabaEmailAPI:
    def __init__(self):
        pass

    @staticmethod
    def create_client() -> Dm20151123Client:
        """
        使用凭据初始化账号Client
        @return: Client
        @throws Exception
        """
        APIConfig = ConfigReader("./backend/config/api_config.json").read_config()["EMAIL_CONFIG"]
        # 工程代码建议使用更安全的无AK方式，凭据配置方式请参见：https://help.aliyun.com/document_detail/378659.html。
        config = open_api_models.Config(
            access_key_id=APIConfig["ack_id"],
            access_key_secret=APIConfig["ack"],
            region_id=APIConfig["region_id"],
            endpoint=APIConfig["url"]
        )
        return Dm20151123Client(config)

    @staticmethod
    def sendEmail(to_address: str, text_body: str) -> None:

        client = AlibabaEmailAPI.create_client()
        single_send_mail_request = dm_20151123_models.SingleSendMailRequest(
            to_address= to_address,
            address_type= RANDOM_ACCOUNT,
            account_name=  ConfigReader("./backend/config/api_config.json").read_config()["EMAIL_CONFIG"]["account_name"],
            subject="【注册验证码】10分钟内有效",
            reply_to_address=False,
            text_body=text_body
        )
        runtime = util_models.RuntimeOptions()
        try:
            response = client.single_send_mail_with_options(single_send_mail_request, runtime)
            CCBLog("EmailAPI").info(f"邮件发送成功: {response.body}")
        except Exception as error:
            # 此处仅做打印展示，请谨慎对待异常处理，在工程项目中切勿直接忽略异常。
            # 错误 message
            CCBLog("EmailAPI").warning(error.message + error.data.get("Recommend"))
            UtilClient.assert_as_string(error.message)

