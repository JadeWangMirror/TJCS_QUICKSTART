"""
图像生成处理模块 - 使用阿里云百炼API进行图像生成
"""

import os
from http import HTTPStatus
from urllib.parse import urlparse, unquote
from pathlib import PurePosixPath
import requests
from flask import jsonify
from dashscope import ImageSynthesis
import dashscope

from backend.utils.CCBLog import CCBLog
from backend.config.ConfigReader import ConfigReader
from backend.services.ai_history.ImageHistoryService import save_image_histories

class ImageGenDeal:
    def __init__(self):
        self.config = ConfigReader("./backend/config/image_gen_config.json").read_config()
        self.log = CCBLog(name="ImageGenDeal")
        
        # 设置API基础URL（北京地域）
        dashscope.base_http_api_url = 'https://dashscope.aliyuncs.com/api/v1'
        
        # 设置API Key
        self._setup_api_key()
    
    def _setup_api_key(self):
        """设置API Key - 按照官方示例代码风格"""
        api_key = self.config.get("api_key", "")
        if not api_key:
            self.log.warning("配置文件中未找到API Key，尝试从环境变量获取")
            api_key = os.getenv("DASHSCOPE_API_KEY", "")
        
        self.api_key = api_key
        self.log.info("API Key设置成功")
        return True
    
    def process_image_generation(self, request_id, original_prompt, user_id=None):
        """处理图像生成请求"""
        
        self.log.info(f"开始处理图像生成请求 {request_id}")
        self.log.info(f"原始提示词: {original_prompt}")
        
        try:
            # 检查API Key是否已设置
            if not hasattr(self, 'api_key') or not self.api_key:
                return self._create_error_response("API Key未配置", request_id)
            
            # 生成图像
            image_result = self._generate_image(original_prompt, request_id)
            if not image_result:
                return self._create_error_response("图像生成失败", request_id)
            
            # 如果返回的是错误信息
            if "error" in image_result:
                return self._create_error_response(image_result["error"], request_id)
            
            # 保存图片生成历史记录到数据库（如果提供了user_id）
            if user_id and user_id > 0:
                try:
                    # 提取所有图片URL
                    image_urls = []
                    if "image_urls" in image_result:
                        image_urls = [item.get("image_url", "") for item in image_result["image_urls"] if item.get("image_url")]
                    
                    if image_urls:
                        save_image_histories(
                            user_id=user_id,
                            prompt=original_prompt,
                            urls=image_urls
                        )
                        self.log.info(f"图片生成历史记录已保存到数据库: user_id={user_id}, count={len(image_urls)}")
                except Exception as e:
                    self.log.error(f"保存图片生成历史记录到数据库失败: {e}")
            
            # 返回成功结果
            return self._create_success_response(
                request_id=request_id,
                prompt=original_prompt,
                image_data=image_result
            )
            
        except Exception as e:
            self.log.error(f"图像生成处理异常: {str(e)}")
            return self._create_error_response(f"处理过程中发生异常: {str(e)}", request_id)
    
    def _generate_image(self, prompt, request_id):
        """调用阿里云百炼图像生成API - 严格按照官方示例代码风格"""
        self.log.info("开始调用阿里云百炼图像生成API")
        
        try:
            # 获取图像生成配置
            image_generation_config = self.config.get("image_generation", {})
            
            self.log.info('----同步调用，请等待任务执行----')
            
            # 严格按照官方示例代码风格调用API
            rsp = ImageSynthesis.call(
                api_key=self.api_key,
                model="qwen-image-plus",
                prompt=prompt,
                n=1,
                size='1328*1328',
                prompt_extend=image_generation_config.get("prompt_extend", True),
                watermark=image_generation_config.get("watermark", True)
            )
            
            self.log.info(f'API响应状态码: {rsp.status_code}')
            
            if rsp.status_code == HTTPStatus.OK:
                self.log.info("图像生成成功")
                
                # 直接返回图片URL给前端，前端可以直接下载
                image_urls = []
                for i, result in enumerate(rsp.output.results):
                    file_name = PurePosixPath(unquote(urlparse(result.url).path)).parts[-1]
                    image_urls.append({
                        "index": i,
                        "file_name": file_name,
                        "image_url": result.url,  # 直接返回URL
                        "mime_type": self._get_mime_type(file_name)
                    })
                    self.log.info(f"第 {i+1} 张图像URL: {result.url}")
                
                if not image_urls:
                    return {"error": "未生成任何图像"}
                
                # 构建返回数据
                result_data = {
                    "image_urls": image_urls,
                    "image_count": len(image_urls),
                    "task_id": getattr(rsp.output, 'task_id', ''),
                    "task_status": getattr(rsp.output, 'task_status', 'SUCCEEDED')
                }
                
                self.log.info(f"成功生成 {len(image_urls)} 张图像，返回URL给前端")
                return result_data
                
            else:
                # 按照官方示例代码的错误处理方式
                error_msg = f'同步调用失败, status_code: {rsp.status_code}, code: {rsp.code}, message: {rsp.message}'
                self.log.error(error_msg)
                return {"error": error_msg}
                
        except Exception as e:
            error_msg = f"图像生成API调用异常: {str(e)}"
            self.log.error(error_msg)
            return {"error": error_msg}
    
    def _get_mime_type(self, filename):
        """根据文件名获取MIME类型"""
        if filename.lower().endswith(('.png')):
            return 'image/png'
        elif filename.lower().endswith(('.jpg', '.jpeg')):
            return 'image/jpeg'
        elif filename.lower().endswith('.webp'):
            return 'image/webp'
        else:
            return 'image/png'
    
    def _create_success_response(self, request_id, prompt, image_data):
        """创建成功响应"""
        response_data = {
            'request_id': request_id,
            'status': 'success',
            'prompt': prompt,
            'data': image_data,
            'message': '图像生成成功'
        }
        
        self.log.info(f"图像生成请求完成: {request_id}")
        return jsonify(response_data), 200
    
    def _create_error_response(self, error_message, request_id):
        """创建错误响应"""
        response_data = {
            'request_id': request_id,
            'status': 'error',
            'error': error_message
        }
        
        self.log.error(f"图像生成失败: {error_message}")
        return jsonify(response_data), 500


# 创建全局实例
image_gen_processor = ImageGenDeal()

def image_gen_deal(request_id, original_prompt, user_id=None):
    """图像生成处理入口函数"""
    return image_gen_processor.process_image_generation(request_id, original_prompt, user_id)