"""
角色管理器 - 协调各个角色的工作
"""

from backend.utils.CCBLog import CCBLog
from backend.services.api_client.deepseek_api_client import DeepSeekClient
from backend.config.ConfigReader import ConfigReader

class RolesManager:
    def __init__(self):
        self.roles = ConfigReader("./backend/config/role.json").read_config()
        self.api_client = DeepSeekClient()
        self.workflow_history = []
        self.log = CCBLog(name="RolesManager")
    
    def execute_role_task(self, role_key, prompt, context=None):
        """执行特定角色的任务"""

        role_config = self.roles[role_key]
        messages = [
            {"role": "system", "content": "\n".join(role_config["system_prompt"])},
            {"role": "user", "content": self.build_task_prompt(prompt, context)}
        ]
        self.log.info(message=f"{role_config['name']} 正在处理任务: {role_config['description']}")
        self.log.info(message=f"任务: {role_config['description']}")
        
        result = self.api_client.call_api(messages)
        
        if result:
            self.workflow_history.append({
                "role": role_key,
                "role_name": role_config["name"],
                "input": prompt,
                "output": result,
                "context": context
            })
        
        return result
    
    def build_task_prompt(self, prompt, context):
        """构建任务提示词"""
        task_prompt = f"需要处理的提示词：\n{prompt}\n\n"
        
        if context:
            task_prompt += f"上文信息：\n{context}\n\n"
        
        task_prompt += "请根据您的角色职责进行处理，并给出优化结果："
        return task_prompt
    
    def get_workflow_history(self):
        """获取工作流历史"""
        return self.workflow_history