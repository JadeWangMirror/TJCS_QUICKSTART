"""
提示词处理器 - 管理整个优化工作流
"""
from .RolesManager import RolesManager


class PromptProcessor:
    def __init__(self):
        self.roles_manager = RolesManager()
        self.optimization_stages = []

    def optimize_prompt(self, original_prompt):
        """执行完整的提示词优化工作流"""


        # 阶段1: 分析原始提示词
        analysis_result = self.roles_manager.execute_role_task(
            "analyzer",
            original_prompt
        )
        self.optimization_stages.append({
            "stage": "analysis",
            "result": analysis_result
        })



        # 阶段4: 最终润色
        final_result = self.roles_manager.execute_role_task(
            "refiner",
            analysis_result,
            f"原始提示词: {original_prompt}\n扩展结果: {analysis_result}"
        )
        self.optimization_stages.append({
            "stage": "refinement",
            "result": final_result
        })

        return final_result