from datetime import datetime

from flask import jsonify
from backend.utils.CCBLog import CCBLog
from .PromptProcessor import PromptProcessor
from backend.storage.JSONManager import JSONManager
from backend.services.ai_history.AIHistoryService import save_ai_history
json_manager = JSONManager("./results/prompt_results.json")

Log = CCBLog("history_routes")
def prompt_deal(request_id, original_prompt, user_id=None):

    try:
        processor = PromptProcessor()
        stages_data = []
        Log.info(message=f"开始处理请求: {request_id} 原提示词：{original_prompt}")

        # 阶段1: 分析
        analysis_result = processor.roles_manager.execute_role_task(
            "analyzer", original_prompt
        )
        stages_data.append({
            'stage': 'analysis',
            'role_name': '提示词分析专家',
            'result': analysis_result,
            'status': 'completed',
            'timestamp': datetime.now().isoformat()
        })

        

        # 阶段4: 最终润色
        final_result = processor.roles_manager.execute_role_task(
            "refiner", analysis_result,
            f"原始提示词: {original_prompt}\n扩展结果: {analysis_result}"
        )
        stages_data.append({
            'stage': 'refinement',
            'role_name': '最终润色专家',
            'result': final_result,
            'status': 'completed',
            'timestamp': datetime.now().isoformat()
        })

        # 保存结果
        workflow_history = processor.roles_manager.get_workflow_history()
        
        # 保存到JSON文件
        #json_manager.save_optimization_result(
        #    original_prompt, final_result, workflow_history
        #)
        
        # 保存到数据库（如果提供了user_id）
        if user_id and user_id > 0:
            try:
                save_ai_history(
                    user_id=user_id,
                    original_prompt=original_prompt,
                    optimized_prompt=final_result,
                    workflow_history=workflow_history
                )
                Log.info(f"AI历史记录已保存到数据库: user_id={user_id}")
            except Exception as e:
                Log.error(f"保存AI历史记录到数据库失败: {e}")

        response_data = {
            'request_id': request_id,
            'original_prompt': original_prompt,
            'optimized_prompt': final_result,
            'stages': stages_data,
            'status': 'completed',
            'total_stages': len(stages_data),
            'completed_at': datetime.now().isoformat()
        }

        return jsonify(response_data)

    except Exception as e:
        return jsonify({
            'request_id': request_id,
            'error': str(e),
            'status': 'error'
        }), 500
