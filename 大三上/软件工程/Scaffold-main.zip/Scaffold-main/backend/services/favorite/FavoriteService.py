# Service 层 - 收藏业务逻辑

from flask import jsonify
from typing import Tuple, Dict, Any, List
import json
from backend.storage.FavoriteDB import FavoriteDB
from backend.cache.PostRedis import check_and_trigger_hot_refresh, update_post_detail_count
from backend.cache.tasks import update_user_profile_task
from backend.utils import CCBLog

def toggle_favorite_post_comment(user_id: int, post_id: int) -> Tuple[dict, int]:
    """
    切换收藏状态：如果用户已收藏则取消收藏，否则执行收藏
    
    业务逻辑流程：
    1. 检查用户是否已经收藏过该帖子/评论
    2. 如果已收藏：
       - 删除收藏记录（从 favorites 表）
       - 更新收藏计数 -1（在 posts_comments 表）
       - 返回 is_favorited=False
    3. 如果未收藏：
       - 创建收藏记录（插入 favorites 表）
       - 更新收藏计数 +1（在 posts_comments 表）
       - 返回 is_favorited=True
    4. 在两种情况下都返回最新的收藏总数
    
    :param user_id: 收藏用户的ID
    :param post_id: 被收藏的帖子/评论ID
    :return: (JSON响应, HTTP状态码)
    """
    try:
        db_manager = FavoriteDB()
        
        # 1. 检查用户是否已经收藏过该帖子/评论
        is_already_favorited = db_manager.check_user_favorited(user_id=user_id, post_id=post_id)
        
        if is_already_favorited:
            # 2a. 如果已收藏，执行取消收藏操作
            deleted_count = db_manager.delete_favorite(user_id=user_id, post_id=post_id)
            
            if deleted_count > 0:
                # 2b. 删除成功，更新收藏计数 -1
                db_manager.decrement_post_favorite_count(post_id=post_id)
                update_post_detail_count(post_id=post_id, count_type='favorite', increment=-1)
                update_user_profile_task.delay(user_id=user_id, post_id=post_id, increment=-4.0)
                
                # 2c. 获取更新后的收藏总数并返回
                favorite_count = db_manager.get_post_favorite_count(post_id=post_id)
                
                return jsonify({
                    "status": "success",
                    "message": "已取消收藏",
                    "post_id": post_id,
                    "is_favorited": False,
                    "favorite_count": favorite_count
                }), 200
            else:
                # 删除失败
                return jsonify({"error": "取消收藏失败"}), 400
        
        else:
            # 3a. 如果未收藏，执行收藏操作
            insert_success = db_manager.insert_favorite(user_id=user_id, post_id=post_id)
            
            if insert_success:
                # 3b. 插入成功，更新收藏计数 +1
                db_manager.increment_post_favorite_count(post_id=post_id)
                update_post_detail_count(post_id=post_id, count_type='favorite', increment=1)
                update_user_profile_task.delay(user_id=user_id, post_id=post_id, increment=4.0)
                check_and_trigger_hot_refresh(4) # 假设收藏权重比点赞高
                
                # 3c. 获取更新后的收藏总数并返回
                favorite_count = db_manager.get_post_favorite_count(post_id=post_id)
                
                return jsonify({
                    "status": "success",
                    "message": "收藏成功",
                    "post_id": post_id,
                    "is_favorited": True,
                    "favorite_count": favorite_count
                }), 200
            else:
                # 插入失败（通常因为重复收藏）
                return jsonify({"error": "收藏失败"}), 400
    
    except Exception as e:
        CCBLog('toggle_favorite_post_comment').error(f"切换收藏状态失败: {e}")
        raise


def check_user_favorited(user_id: int, post_id: int) -> bool:
    """
    检查用户是否已经收藏了某个帖子/评论
    
    :param user_id: 用户ID
    :param post_id: 帖子/评论ID
    :return: True 表示已收藏，False 表示未收藏
    """
    try:
        db_manager = FavoriteDB()
        is_favorited = db_manager.check_user_favorited(user_id=user_id, post_id=post_id)
        return is_favorited
    
    except Exception as e:
        CCBLog('check_user_favorited').error(f"检查收藏状态失败: {e}")
        raise


def get_post_favorite_count(post_id: int) -> int:
    """
    获取帖子/评论的收藏总数
    
    :param post_id: 帖子/评论ID
    :return: 收藏总数
    """
    try:
        db_manager = FavoriteDB()
        favorite_count = db_manager.get_post_favorite_count(post_id=post_id)
        return favorite_count
    
    except Exception as e:
        CCBLog('get_post_favorite_count').error(f"获取收藏数失败: {e}")
        raise


def get_user_favorite_posts_service(user_id: int, limit: int = 10, page_num: int = 1) -> Tuple[Dict[str, Any], int]:
    """获取用户收藏的帖子列表（分页：第几页）。"""
    if user_id is None or user_id <= 0:
        return jsonify({"error": "无效的用户ID"}), 400
    if limit < 1:
        return jsonify({"error": "Limit 必须大于 0"}), 400
    if page_num < 1:
        page_num = 1

    offset = (page_num - 1) * limit
    db = FavoriteDB()

    try:
        raw_posts: List[Dict[str, Any]] = db.get_user_favorite_posts(user_id=user_id, limit=limit, offset=offset)
        total_count = db.count_user_favorite_posts(user_id=user_id)
    except Exception as e:
        CCBLog('get_user_favorite_posts_service').error(f"获取用户收藏列表失败: {e}")
        return jsonify({"error": "服务器内部错误"}), 500

    def parse_json_field(value, default):
        try:
            return json.loads(value) if isinstance(value, str) else (value or default)
        except Exception:
            return default

    posts: List[Dict[str, Any]] = []
    for p in raw_posts:
        posts.append({
            "id": p.get("id"),
            "title": p.get("title"),
            "context": p.get("context"),
            "author": p.get("author"),
            "author_id": p.get("author_id"),
            "timestamp": p.get("timestamp"),
            "url_list": parse_json_field(p.get("url_list"), []),
            "tags": parse_json_field(p.get("tag"), []),
            "browse_count": p.get("browse_count", 0),
            "like_count": p.get("like_count", 0),
            "comment_count": p.get("comment_count", 0),
            "favorite_count": p.get("favorite_count", 0),
        })

    page_count = (total_count + limit - 1) // limit if limit > 0 else 0

    return jsonify({
        "status": "success",
        "count": len(posts),
        "total_count": total_count,
        "limit": limit,
        "page_num": page_num,
        "page_count": page_count,
        "posts": posts,
    }), 200

