# Service 层 - 图片生成历史记录业务逻辑

from flask import jsonify
from typing import Tuple, Dict, Any, Optional, List
from backend.storage.ImageHistoryDB import ImageHistoryDB
from backend.utils.CCBLog import CCBLog

def save_image_history(
    user_id: int,
    prompt: str,
    url: str
) -> Optional[int]:
    """
    保存图片生成的历史记录（单条）。
    
    :param user_id: 用户ID
    :param prompt: 生成图片的提示词
    :param url: 生成的图片URL
    :return: 保存的记录ID，失败返回None
    """
    try:
        # 参数验证
        if not user_id or user_id <= 0:
            return None
        if not prompt or not prompt.strip():
            return None
        if not url or not url.strip():
            return None
        
        # 调用storage层
        db_manager = ImageHistoryDB()
        history_id = db_manager.insert_image_history(
            user_id=user_id,
            prompt=prompt.strip(),
            url=url.strip()
        )
        
        return history_id
    except Exception as e:
        CCBLog('save_image_history').error(f"保存图片生成历史记录失败: {e}")
        return None


def save_image_histories(
    user_id: int,
    prompt: str,
    urls: List[str]
) -> List[int]:
    """
    批量保存图片生成的历史记录。
    
    :param user_id: 用户ID
    :param prompt: 生成图片的提示词
    :param urls: 生成的图片URL列表
    :return: 保存的记录ID列表
    """
    try:
        # 参数验证
        if not user_id or user_id <= 0:
            return []
        if not prompt or not prompt.strip():
            return []
        if not urls:
            return []
        
        # 调用storage层
        db_manager = ImageHistoryDB()
        history_ids = db_manager.insert_image_histories(
            user_id=user_id,
            prompt=prompt.strip(),
            urls=urls
        )
        
        return history_ids
    except Exception as e:
        CCBLog('save_image_histories').error(f"批量保存图片生成历史记录失败: {e}")
        return []


def get_image_history_list(
    user_id: int,
    limit: int = 20,
    page_num: int = 1
) -> Tuple[dict, int]:
    """获取用户的图片生成历史记录列表（分页：第几页）。

    :param user_id: 用户ID
    :param limit: 每页数量
    :param page_num: 第几页（从1开始）
    :return: (JSON响应, HTTP状态码)
    """
    try:
        # 参数验证
        if not user_id or user_id <= 0:
            return jsonify({"error": "无效的用户ID"}), 400
        if limit < 1 or limit > 100:
            limit = 20
        if page_num < 1:
            page_num = 1

        offset = (page_num - 1) * limit
        
        # 调用storage层
        db_manager = ImageHistoryDB()
        records = db_manager.get_image_history_by_user_id(
            user_id=user_id,
            limit=limit,
            offset=offset
        )
        total_count = db_manager.count_image_history_by_user_id(user_id=user_id)
        
        # 格式化返回数据
        formatted_records = []
        for record in records:
            prompt = record.get('prompt', '') or ''
            formatted_records.append({
                'id': record['id'],
                'timestamp': record['timestamp'].isoformat() if hasattr(record['timestamp'], 'isoformat') else str(record['timestamp']),
                'prompt': prompt,
                'prompt_preview': prompt[:100] + ('...' if len(prompt) > 100 else ''),
                'url': record.get('url', ''),
                'user_id': record.get('user_id')
            })
        
        page_count = 0
        if limit > 0:
            page_count = (total_count + limit - 1) // limit

        return jsonify({
            "status": "success",
            "count": len(formatted_records),
            "total": total_count,
            "limit": limit,
            "page_num": page_num,
            "page_count": page_count,
            "records": formatted_records
        }), 200
        
    except Exception as e:
        CCBLog('get_image_history_list').error(f"获取图片生成历史记录列表失败: {e}")
        return jsonify({"error": "服务器内部错误"}), 500


def get_image_history_detail(history_id: int, user_id: Optional[int] = None) -> Tuple[dict, int]:
    """
    获取图片生成历史记录详情。
    
    :param history_id: 历史记录ID
    :param user_id: 用户ID（可选，用于验证权限）
    :return: (JSON响应, HTTP状态码)
    """
    try:
        # 参数验证
        if not history_id or history_id <= 0:
            return jsonify({"error": "无效的历史记录ID"}), 400
        
        # 调用storage层
        db_manager = ImageHistoryDB()
        record = db_manager.get_image_history_by_id(history_id)
        
        if not record:
            return jsonify({"error": "历史记录未找到"}), 404
        
        # 验证权限（如果提供了user_id）
        if user_id is not None and record.get('user_id') != user_id:
            return jsonify({"error": "无权访问此记录"}), 403
        
        # 格式化时间戳
        timestamp = record.get('timestamp')
        if hasattr(timestamp, 'isoformat'):
            timestamp = timestamp.isoformat()
        else:
            timestamp = str(timestamp)
        
        return jsonify({
            "status": "success",
            "record": {
                'id': record['id'],
                'timestamp': timestamp,
                'prompt': record.get('prompt', ''),
                'url': record.get('url', ''),
                'user_id': record.get('user_id')
            }
        }), 200
        
    except Exception as e:
        CCBLog('get_image_history_detail').error(f"获取图片生成历史记录详情失败: {e}")
        return jsonify({"error": "服务器内部错误"}), 500


def delete_image_history(history_id: int, user_id: int) -> Tuple[dict, int]:
    """
    删除图片生成历史记录。
    
    :param history_id: 历史记录ID
    :param user_id: 用户ID（用于验证权限）
    :return: (JSON响应, HTTP状态码)
    """
    try:
        # 参数验证
        if not history_id or history_id <= 0:
            return jsonify({"error": "无效的历史记录ID"}), 400
        if not user_id or user_id <= 0:
            return jsonify({"error": "无效的用户ID"}), 400
        
        # 调用storage层
        db_manager = ImageHistoryDB()
        success = db_manager.delete_image_history(history_id, user_id)
        
        if success:
            return jsonify({
                "status": "success",
                "message": "删除成功"
            }), 200
        else:
            return jsonify({"error": "删除失败，记录不存在或无权删除"}), 404
        
    except Exception as e:
        CCBLog('delete_image_history').error(f"删除图片生成历史记录失败: {e}")
        return jsonify({"error": "服务器内部错误"}), 500


def clear_all_image_history(user_id: int) -> Tuple[dict, int]:
    """
    清空用户的所有图片生成历史记录。
    
    :param user_id: 用户ID
    :return: (JSON响应, HTTP状态码)
    """
    try:
        # 参数验证
        if not user_id or user_id <= 0:
            return jsonify({"error": "无效的用户ID"}), 400
        
        # 调用storage层
        db_manager = ImageHistoryDB()
        deleted_count = db_manager.delete_all_image_history_by_user_id(user_id)
        
        return jsonify({
            "status": "success",
            "message": "清空成功",
            "deleted_count": deleted_count
        }), 200
        
    except Exception as e:
        CCBLog('clear_all_image_history').error(f"清空图片生成历史记录失败: {e}")
        return jsonify({"error": "服务器内部错误"}), 500

