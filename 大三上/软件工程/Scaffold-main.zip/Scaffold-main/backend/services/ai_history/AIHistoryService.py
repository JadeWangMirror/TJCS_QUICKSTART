# Service 层 - AI历史记录业务逻辑

from flask import jsonify
from typing import Tuple, Dict, Any, Optional, List
from backend.storage.AIHistoryDB import AIHistoryDB
from backend.utils.CCBLog import CCBLog

def save_ai_history(
    user_id: int,
    original_prompt: str,
    optimized_prompt: Optional[str] = None,
    workflow_history: Optional[Dict[str, Any]] = None
) -> Optional[int]:
    """
    保存AI提示词优化的历史记录。
    
    业务逻辑：
    1. 验证参数
    2. 调用storage层保存到数据库
    3. 返回记录ID
    
    :param user_id: 用户ID
    :param original_prompt: 原始提示词
    :param optimized_prompt: 优化后的提示词（可选）
    :param workflow_history: 工作流历史记录（可选）
    :return: 保存的记录ID，失败返回None
    """
    try:
        # 参数验证
        if not user_id or user_id <= 0:
            return None
        if not original_prompt or not original_prompt.strip():
            return None
        
        # 调用storage层
        db_manager = AIHistoryDB()
        history_id = db_manager.insert_ai_history(
            user_id=user_id,
            original_prompt=original_prompt.strip(),
            optimized_prompt=optimized_prompt.strip() if optimized_prompt else None,
            workflow_history=workflow_history
        )
        
        return history_id
    except Exception as e:
        CCBLog('save_ai_history').error(f"保存AI历史记录失败: {e}")
        return None


def get_ai_history_list(
    user_id: int,
    limit: int = 20,
    page_num: int = 1
) -> Tuple[dict, int]:
    """获取用户的AI历史记录列表（分页：第几页）。

    :param user_id: 用户ID
    :param limit: 每页数量
    :param page_num: 第几页（从1开始）
    :return: (JSON响应, HTTP状态码)
    """
    try:
        # 参数验证
        if not user_id or user_id <= 0:
            return jsonify({"error": "无效的用户ID"}), 400
        if limit < 1 or limit > 100:
            limit = 20
        if page_num < 1:
            page_num = 1

        offset = (page_num - 1) * limit
        
        # 调用storage层
        db_manager = AIHistoryDB()
        records = db_manager.get_ai_history_by_user_id(
            user_id=user_id,
            limit=limit,
            offset=offset
        )
        total_count = db_manager.count_ai_history_by_user_id(user_id=user_id)
        
        # 格式化返回数据
        formatted_records = []
        for record in records:
            original_prompt = record.get('original_prompt', '') or ''
            optimized_prompt = record.get('optimized_prompt', '') or ''
            formatted_records.append({
                'id': record['id'],
                'timestamp': record['timestamp'].isoformat() if hasattr(record['timestamp'], 'isoformat') else str(record['timestamp']),
                'original_prompt': original_prompt,
                'optimized_prompt': optimized_prompt,
                'original_preview': original_prompt[:100] + ('...' if len(original_prompt) > 100 else ''),
                'optimized_preview': optimized_prompt[:100] + ('...' if len(optimized_prompt) > 100 else ''),
                'workflow_history': record.get('workflow_history'),
                'workflow_stages': len(record.get('workflow_history', [])) if isinstance(record.get('workflow_history'), list) else 0
            })
        
        page_count = 0
        if limit > 0:
            page_count = (total_count + limit - 1) // limit

        return jsonify({
            "status": "success",
            "count": len(formatted_records),
            "total": total_count,
            "limit": limit,
            "page_num": page_num,
            "page_count": page_count,
            "records": formatted_records
        }), 200
        
    except Exception as e:
        CCBLog('get_ai_history_list').error(f"获取AI历史记录列表失败: {e}")
        return jsonify({"error": "服务器内部错误"}), 500


def get_ai_history_detail(history_id: int, user_id: Optional[int] = None) -> Tuple[dict, int]:
    """
    获取AI历史记录详情。
    
    :param history_id: 历史记录ID
    :param user_id: 用户ID（可选，用于验证权限）
    :return: (JSON响应, HTTP状态码)
    """
    try:
        # 参数验证
        if not history_id or history_id <= 0:
            return jsonify({"error": "无效的历史记录ID"}), 400
        
        # 调用storage层
        db_manager = AIHistoryDB()
        record = db_manager.get_ai_history_by_id(history_id)
        
        if not record:
            return jsonify({"error": "历史记录未找到"}), 404
        
        # 验证权限（如果提供了user_id）
        if user_id is not None and record.get('user_id') != user_id:
            return jsonify({"error": "无权访问此记录"}), 403
        
        # 格式化时间戳
        timestamp = record.get('timestamp')
        if hasattr(timestamp, 'isoformat'):
            timestamp = timestamp.isoformat()
        else:
            timestamp = str(timestamp)
        
        return jsonify({
            "status": "success",
            "record": {
                'id': record['id'],
                'timestamp': timestamp,
                'original_prompt': record.get('original_prompt', ''),
                'optimized_prompt': record.get('optimized_prompt', ''),
                'workflow_history': record.get('workflow_history'),
                'user_id': record.get('user_id')
            }
        }), 200
        
    except Exception as e:
        CCBLog('get_ai_history_detail').error(f"获取AI历史记录详情失败: {e}")
        return jsonify({"error": "服务器内部错误"}), 500


def delete_ai_history(history_id: int, user_id: int) -> Tuple[dict, int]:
    """
    删除AI历史记录。
    
    :param history_id: 历史记录ID
    :param user_id: 用户ID（用于验证权限）
    :return: (JSON响应, HTTP状态码)
    """
    try:
        # 参数验证
        if not history_id or history_id <= 0:
            return jsonify({"error": "无效的历史记录ID"}), 400
        if not user_id or user_id <= 0:
            return jsonify({"error": "无效的用户ID"}), 400
        
        # 调用storage层
        db_manager = AIHistoryDB()
        success = db_manager.delete_ai_history(history_id, user_id)
        
        if success:
            return jsonify({
                "status": "success",
                "message": "删除成功"
            }), 200
        else:
            return jsonify({"error": "删除失败，记录不存在或无权删除"}), 404
        
    except Exception as e:
        CCBLog('delete_ai_history').error(f"删除AI历史记录失败: {e}")
        return jsonify({"error": "服务器内部错误"}), 500


def clear_all_ai_history(user_id: int) -> Tuple[dict, int]:
    """
    清空用户的所有AI提示词优化历史记录。
    
    :param user_id: 用户ID
    :return: (JSON响应, HTTP状态码)
    """
    try:
        # 参数验证
        if not user_id or user_id <= 0:
            return jsonify({"error": "无效的用户ID"}), 400
        
        # 调用storage层
        db_manager = AIHistoryDB()
        deleted_count = db_manager.delete_all_ai_history_by_user_id(user_id)
        
        return jsonify({
            "status": "success",
            "message": "清空成功",
            "deleted_count": deleted_count
        }), 200
        
    except Exception as e:
        CCBLog('clear_all_ai_history').error(f"清空AI历史记录失败: {e}")
        return jsonify({"error": "服务器内部错误"}), 500

