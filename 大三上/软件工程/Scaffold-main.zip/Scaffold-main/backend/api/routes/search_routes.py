from flask import request, jsonify
from typing import Optional
from backend.services.search.SearchService import (
    search_posts,
    get_search_history,
    delete_search_history_record,
    clear_search_history
)

def search_posts_handler(user_id: Optional[int] = None):
    """
    根据搜索关键词和搜索类型搜索帖子。

    URL: GET /api/user/<user_id>/search
    Query params: q, type, limit, page_num
    ---
    tags:
      - Search
    summary: 搜索帖子
    operationId: searchPosts
    parameters:
      - name: q
        in: query
        required: true
        description: 搜索关键词
        schema:
          type: string
          example: "Python"
      - name: type
        in: query
        required: true
        description: 搜索类型
        schema:
          type: string
          enum: [title, content, tag]
          example: "title"
      - name: user_id
        in: query
        required: false
        description: 用户ID（0或空表示未登录，不记录搜索历史）
        schema:
          type: integer
          default: 0
          example: 1
      - name: limit
        in: query
        required: false
        description: 每页数量（默认10）
        schema:
          type: integer
          default: 10
          example: 10
      - name: page_num
        in: query
        required: false
        description: 第几页（从1开始，默认1）
        schema:
          type: integer
          default: 1
          example: 1
    responses:
      200:
        description: 搜索成功
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                query:
                  type: string
                  description: 实际搜索的关键词
                  example: "Python"
                search_type:
                  type: string
                  description: 搜索类型
                  example: "title"
                count:
                  type: integer
                  description: 本次返回的帖子数量
                  example: 8
                limit:
                  type: integer
                  description: 每页数量
                  example: 10
                page_num:
                  type: integer
                  description: 当前页码（从1开始）
                  example: 1
                page_count:
                  type: integer
                  description: 总页数
                  example: 5
                posts:
                  type: array
                  description: 搜索结果列表
                  items:
                    type: object
                    properties:
                      id:
                        type: integer
                        description: 帖子ID
                        example: 123
                      title:
                        type: string
                        description: 帖子标题
                        example: "Python编程入门指南"
                      context:
                        type: string
                        description: 帖子内容摘要
                        example: "本文介绍了Python编程的基础知识..."
                      author:
                        type: string
                        description: 作者名
                        example: "author_name"
                      timestamp:
                        type: string
                        format: date-time
                        description: 发布时间戳
                        example: "2024-10-27T14:30:00"
                      cover_image:
                        type: string
                        format: url
                        description: 封面图片URL
                        example: "https://example.com/images/cover.jpg"
                      tags:
                        type: array
                        items:
                          type: string
                        description: 帖子标签列表
                        example: ["Python", "编程"]
                      browse_count:
                        type: integer
                        description: 浏览量
                        example: 150
                      like_count:
                        type: integer
                        description: 点赞数
                        example: 25
                      comment_count:
                        type: integer
                        description: 评论数
                        example: 8
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "搜索关键词不能为空"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "服务器内部错误，搜索失败"
    """
    # 获取查询参数
    search_query = request.args.get('q', '').strip()
    search_type = request.args.get('type', '').strip()

    # 处理 user_id：优先使用 path 中的 user_id（由路由传入），否则尝试从 query 参数读取（兼容性）
    if user_id is None:
        user_id_str = request.args.get('user_id', '0').strip()
        if user_id_str and user_id_str != '0':
            try:
                parsed = int(user_id_str)
                user_id = parsed if parsed > 0 else None
            except ValueError:
                user_id = None
    else:
        # 确保 path 提供的 user_id 为正整数，否则视作未登录
        if not isinstance(user_id, int) or user_id <= 0:
            user_id = None

    try:
      limit = int(request.args.get('limit', 10))
      page_num = int(request.args.get('page_num', 1))
    except ValueError:
      return jsonify({"error": "Limit 和 PageNum 必须是有效的整数"}), 400

    # 调用服务层方法
    return search_posts(
      user_id=user_id,
      search_query=search_query,
      search_type=search_type,
      limit=limit,
      page_num=page_num
    )


def get_search_history_handler(user_id: int):
    """
    获取用户的搜索历史记录列表。

    URL: GET /api/user/<user_id>/history/search
    Query params: limit, page_num
    ---
    tags:
      - Search History
    summary: 获取用户搜索历史列表
    operationId: getUserSearchHistory
    parameters:
      - name: user_id
        in: path
        required: true
        description: 用户ID
        schema:
          type: integer
          example: 1
      - name: limit
        in: query
        required: false
        description: 每页数量（默认10）
        schema:
          type: integer
          default: 10
          example: 10
      - name: page_num
        in: query
        required: false
        description: 第几页（从1开始，默认1）
        schema:
          type: integer
          default: 1
          example: 1
    responses:
      200:
        description: 成功获取搜索历史列表
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                count:
                  type: integer
                  description: 本次返回的记录数量
                  example: 10
                total_count:
                  type: integer
                  description: 总记录数
                  example: 50
                limit:
                  type: integer
                  description: 每页数量
                  example: 10
                page_num:
                  type: integer
                  description: 当前页码（从1开始）
                  example: 1
                page_count:
                  type: integer
                  description: 总页数
                  example: 5
                records:
                  type: array
                  description: 搜索历史记录列表
                  items:
                    type: object
                    properties:
                      id:
                        type: integer
                        description: 搜索历史记录ID
                        example: 123
                      search_query:
                        type: string
                        description: 搜索关键词
                        example: "Python"
                      search_type:
                        type: string
                        description: 搜索类型
                        enum: [title, content, tag]
                        example: "title"
                      timestamp:
                        type: string
                        format: date-time
                        description: 搜索时间
                        example: "2024-10-27T14:30:00"
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "参数类型错误"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "服务器内部错误"
    """
    try:
      limit = int(request.args.get('limit', 10))
      page_num = int(request.args.get('page_num', 1))
    except ValueError:
      return jsonify({"error": "Limit 和 PageNum 必须是有效的整数"}), 400

    return get_search_history(user_id=user_id, limit=limit, page_num=page_num)


def delete_search_history_record_handler(user_id: int, record_id: int):
    """
    删除用户的单条搜索历史记录。

    URL: DELETE /api/user/<user_id>/history/search/<record_id>
    ---
    tags:
      - Search History
    summary: 删除单条搜索历史记录
    operationId: deleteUserSearchHistoryRecord
    parameters:
      - name: user_id
        in: path
        required: true
        description: 用户ID
        schema:
          type: integer
          example: 1
      - name: record_id
        in: path
        required: true
        description: 搜索历史记录ID
        schema:
          type: integer
          example: 123
    responses:
      200:
        description: 删除成功
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                message:
                  type: string
                  example: "搜索历史删除成功"
      404:
        description: 记录不存在
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "记录不存在或无权限删除"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "服务器内部错误"
    """
    return delete_search_history_record(user_id=user_id, record_id=record_id)


def clear_search_history_handler(user_id: int):
    """
    清空用户的所有搜索历史。

    URL: DELETE /api/user/<user_id>/history/search
    ---
    tags:
      - Search History
    summary: 清空用户所有搜索历史
    operationId: clearUserSearchHistory
    parameters:
      - name: user_id
        in: path
        required: true
        description: 用户ID
        schema:
          type: integer
          example: 1
    responses:
      200:
        description: 清空成功
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                message:
                  type: string
                  example: "搜索历史已清空"
                deleted_count:
                  type: integer
                  description: 删除的记录数量
                  example: 25
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "服务器内部错误"
    """
    return clear_search_history(user_id=user_id)