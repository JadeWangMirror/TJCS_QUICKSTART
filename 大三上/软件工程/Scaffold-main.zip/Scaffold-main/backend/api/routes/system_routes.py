from datetime import datetime
from flask import jsonify
from backend.storage.JSONManager import JSONManager

json_manager = JSONManager("./results/prompt_results.json")

def health_check():
    """
    健康检查
    ---
    tags:
      - System
    summary: 健康检查
    operationId: healthCheck
    responses:
      200:
        description: 服务健康状态
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "healthy"
    """

    return jsonify({'status': 'healthy'})


def api_statistics():
    """
    获取API统计信息
    ---
    tags:
      - System
    summary: 获取API统计信息
    operationId: getApiStatistics
    responses:
      200:
        description: API统计信息
        content:
          application/json:
            schema:
              type: object
              properties:
                total_optimizations:
                  type: integer
                  description: 总优化次数
                  example: 150
                last_optimization:
                  type: string
                  format: date-time
                  description: 最后一次优化的时间戳
                  example: "2024-10-27T14:30:00"
                average_stages:
                  type: integer
                  description: 平均阶段数（固定为4）
                  example: 4
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "服务器内部错误"
    """
    data = json_manager.load_all_records()
    records = data.get('optimization_records', [])

    return jsonify({
        'total_optimizations': len(records),
        'last_optimization': records[-1]['timestamp'] if records else 'None',
        'average_stages': 4  # 固定4个阶段
    })
