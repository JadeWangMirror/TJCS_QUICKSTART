from flask import request, jsonify
from backend.services.ai_history.AIHistoryService import (
    get_ai_history_list,
    get_ai_history_detail,
    delete_ai_history,
    clear_all_ai_history
)
from backend.services.ai_history.ImageHistoryService import (
    get_image_history_list,
    get_image_history_detail,
    delete_image_history,
    clear_all_image_history
)
from backend.utils.CCBLog import CCBLog

# ==================== 旧版JSON文件接口（已注释） ====================
# from backend.storage.JSONManager import JSONManager
# json_manager = JSONManager("./results/prompt_results.json")
# 
# def api_history_detail(record_id):
#     """获取历史记录详情"""
#     data = json_manager.load_all_records()
#     records = data.get('optimization_records', [])
# 
#     for record in records:
#         if record['timestamp'] == record_id:
#             return jsonify({
#                 'record': record
#             })
# 
#     return jsonify({'error': '记录未找到'}), 404
# 
# def api_history():
#     """获取历史记录"""
#     data = json_manager.load_all_records()
#     records = data.get('optimization_records', [])
# 
#     formatted_records = []
#     for record in records[-20:]:
#         original_prompt = record.get('original_prompt', '') or ''
#         optimized_prompt = record.get('optimized_prompt', '') or ''
#         workflow_history = record.get('workflow_history', []) or []
#         formatted_records.append({
#             'id': record['timestamp'],
#             'timestamp': record['timestamp'],
#             'original_prompt': original_prompt,
#             'optimized_prompt': optimized_prompt,
#             'original_preview': original_prompt[:100] + (
#                 '...' if len(original_prompt) > 100 else ''),
#             'optimized_preview': optimized_prompt[:100] + (
#                 '...' if len(optimized_prompt) > 100 else ''),
#             'workflow_stages': len(workflow_history)
#         })
#     CCBLog("history").info(message=f"获取历史记录: {len(formatted_records)}条")
#     return jsonify({
#         'records': formatted_records[::-1]
#     })

# ==================== AI提示词优化历史记录接口 ====================

def api_ai_history(user_id):
    """
    获取用户的AI提示词优化历史记录列表
    ---
    tags:
      - AI History
    summary: 获取AI提示词优化历史记录列表
    operationId: getAIHistoryList
    parameters:
      - name: user_id
        in: path
        required: true
        description: 用户ID
        schema:
          type: integer
          example: 1
      - name: limit
        in: query
        required: false
        description: 每页数量（默认20，最大100）
        schema:
          type: integer
          default: 20
          example: 20
      - name: page_num
        in: query
        required: false
        description: 第几页（从1开始，默认1）
        schema:
          type: integer
          default: 1
          example: 1
    responses:
      200:
        description: 成功获取历史记录列表
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                count:
                  type: integer
                  description: 本次返回的记录数量
                  example: 20
                total:
                  type: integer
                  description: 总记录数
                  example: 100
                limit:
                  type: integer
                  description: 每页数量
                  example: 20
                page_num:
                  type: integer
                  description: 当前页码（从1开始）
                  example: 1
                page_count:
                  type: integer
                  description: 总页数
                  example: 5
                records:
                  type: array
                  description: 历史记录列表
                  items:
                    type: object
                    properties:
                      id:
                        type: integer
                        description: 记录ID
                        example: 1
                      timestamp:
                        type: string
                        format: date-time
                        description: 时间戳
                        example: "2024-10-27T14:30:00"
                      original_prompt:
                        type: string
                        description: 原始提示词
                        example: "画一只可爱的小猫"
                      optimized_prompt:
                        type: string
                        description: 优化后的提示词
                        example: "请绘制一只可爱的猫咪，要求细节丰富，风格温馨，背景简洁，高清质量。"
                      original_preview:
                        type: string
                        description: 原始提示词预览
                        example: "画一只可爱的小猫"
                      optimized_preview:
                        type: string
                        description: 优化后提示词预览
                        example: "请绘制一只可爱的猫咪，要求细节丰富..."
                      workflow_history:
                        type: object
                        description: 工作流历史记录
                        example: {}
                      workflow_stages:
                        type: integer
                        description: 工作流阶段数
                        example: 4
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "无效的用户ID"
      500:
        description: 服务器内部错误
    """
    try:
        user_id = int(user_id)
    except (ValueError, TypeError):
        return jsonify({"error": "无效的用户ID"}), 400
    
    # 获取查询参数
    try:
        limit = request.args.get('limit', 20, type=int)
        page_num = request.args.get('page_num', 1, type=int)
    except (ValueError, TypeError):
        limit = 20
        page_num = 1
    
    return get_ai_history_list(user_id=user_id, limit=limit, page_num=page_num)


def api_ai_history_detail(user_id, history_id):
    """
    获取AI提示词优化历史记录详情
    ---
    tags:
      - AI History
    summary: 获取AI提示词优化历史记录详情
    operationId: getAIHistoryDetail
    parameters:
      - name: user_id
        in: path
        required: true
        description: 用户ID
        schema:
          type: integer
          example: 1
      - name: history_id
        in: path
        required: true
        description: 历史记录ID
        schema:
          type: integer
          example: 1
    responses:
      200:
        description: 成功获取历史记录详情
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                record:
                  type: object
                  properties:
                    id:
                      type: integer
                      description: 记录ID
                      example: 1
                    timestamp:
                      type: string
                      format: date-time
                      description: 时间戳
                      example: "2024-10-27T14:30:00"
                    original_prompt:
                      type: string
                      description: 原始提示词
                      example: "画一只可爱的小猫"
                    optimized_prompt:
                      type: string
                      description: 优化后的提示词
                      example: "请绘制一只可爱的猫咪，要求细节丰富，风格温馨，背景简洁，高清质量。"
                    workflow_history:
                      type: object
                      description: 工作流历史记录
                      example: {}
                    user_id:
                      type: integer
                      description: 用户ID
                      example: 1
      400:
        description: 请求参数错误
      403:
        description: 无权访问此记录
      404:
        description: 历史记录未找到
      500:
        description: 服务器内部错误
    """
    try:
        user_id = int(user_id)
        history_id = int(history_id)
    except (ValueError, TypeError):
        return jsonify({"error": "无效的参数"}), 400
    
    return get_ai_history_detail(history_id=history_id, user_id=user_id)


def api_delete_ai_history(user_id, history_id):
    """
    删除AI提示词优化历史记录
    ---
    tags:
      - AI History
    summary: 删除AI提示词优化历史记录
    operationId: deleteAIHistory
    parameters:
      - name: user_id
        in: path
        required: true
        description: 用户ID
        schema:
          type: integer
          example: 1
      - name: history_id
        in: path
        required: true
        description: 历史记录ID
        schema:
          type: integer
          example: 1
    responses:
      200:
        description: 删除成功
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                message:
                  type: string
                  example: "删除成功"
      400:
        description: 请求参数错误
      404:
        description: 记录不存在或无权删除
      500:
        description: 服务器内部错误
    """
    try:
        user_id = int(user_id)
        history_id = int(history_id)
    except (ValueError, TypeError):
        return jsonify({"error": "无效的参数"}), 400
    
    return delete_ai_history(history_id=history_id, user_id=user_id)


# ==================== 图片生成历史记录接口 ====================

def api_image_history(user_id):
    """
    获取用户的图片生成历史记录列表
    ---
    tags:
      - Image History
    summary: 获取图片生成历史记录列表
    operationId: getImageHistoryList
    parameters:
      - name: user_id
        in: path
        required: true
        description: 用户ID
        schema:
          type: integer
          example: 1
      - name: limit
        in: query
        required: false
        description: 每页数量（默认20，最大100）
        schema:
          type: integer
          default: 20
          example: 20
      - name: page_num
        in: query
        required: false
        description: 第几页（从1开始，默认1）
        schema:
          type: integer
          default: 1
          example: 1
    responses:
      200:
        description: 成功获取历史记录列表
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                count:
                  type: integer
                  description: 本次返回的记录数量
                  example: 20
                total:
                  type: integer
                  description: 总记录数
                  example: 100
                limit:
                  type: integer
                  description: 每页数量
                  example: 20
                page_num:
                  type: integer
                  description: 当前页码（从1开始）
                  example: 1
                page_count:
                  type: integer
                  description: 总页数
                  example: 5
                records:
                  type: array
                  description: 历史记录列表
                  items:
                    type: object
                    properties:
                      id:
                        type: integer
                        description: 记录ID
                        example: 1
                      timestamp:
                        type: string
                        format: date-time
                        description: 时间戳
                        example: "2024-10-27T14:30:00"
                      prompt:
                        type: string
                        description: 提示词
                        example: "一只可爱的小猫，卡通风格，高清"
                      prompt_preview:
                        type: string
                        description: 提示词预览
                        example: "一只可爱的小猫，卡通风格，高清"
                      url:
                        type: string
                        format: url
                        description: 图片URL
                        example: "https://example.com/images/image_123456.png"
                      user_id:
                        type: integer
                        description: 用户ID
                        example: 1
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "无效的用户ID"
      500:
        description: 服务器内部错误
    """
    try:
        user_id = int(user_id)
    except (ValueError, TypeError):
        return jsonify({"error": "无效的用户ID"}), 400
    
    # 获取查询参数
    try:
        limit = request.args.get('limit', 20, type=int)
        page_num = request.args.get('page_num', 1, type=int)
    except (ValueError, TypeError):
        limit = 20
        page_num = 1
    
    return get_image_history_list(user_id=user_id, limit=limit, page_num=page_num)


def api_image_history_detail(user_id, history_id):
    """
    获取图片生成历史记录详情
    ---
    tags:
      - Image History
    summary: 获取图片生成历史记录详情
    operationId: getImageHistoryDetail
    parameters:
      - name: user_id
        in: path
        required: true
        description: 用户ID
        schema:
          type: integer
          example: 1
      - name: history_id
        in: path
        required: true
        description: 历史记录ID
        schema:
          type: integer
          example: 1
    responses:
      200:
        description: 成功获取历史记录详情
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                record:
                  type: object
                  properties:
                    id:
                      type: integer
                      description: 记录ID
                      example: 1
                    timestamp:
                      type: string
                      format: date-time
                      description: 时间戳
                      example: "2024-10-27T14:30:00"
                    prompt:
                      type: string
                      description: 提示词
                      example: "一只可爱的小猫，卡通风格，高清"
                    url:
                      type: string
                      format: url
                      description: 图片URL
                      example: "https://example.com/images/image_123456.png"
                    user_id:
                      type: integer
                      description: 用户ID
                      example: 1
      400:
        description: 请求参数错误
      403:
        description: 无权访问此记录
      404:
        description: 历史记录未找到
      500:
        description: 服务器内部错误
    """
    try:
        user_id = int(user_id)
        history_id = int(history_id)
    except (ValueError, TypeError):
        return jsonify({"error": "无效的参数"}), 400
    
    return get_image_history_detail(history_id=history_id, user_id=user_id)


def api_delete_image_history(user_id, history_id):
    """
    删除图片生成历史记录
    ---
    tags:
      - Image History
    summary: 删除图片生成历史记录
    operationId: deleteImageHistory
    parameters:
      - name: user_id
        in: path
        required: true
        description: 用户ID
        schema:
          type: integer
          example: 1
      - name: history_id
        in: path
        required: true
        description: 历史记录ID
        schema:
          type: integer
          example: 1
    responses:
      200:
        description: 删除成功
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                message:
                  type: string
                  example: "删除成功"
      400:
        description: 请求参数错误
      404:
        description: 记录不存在或无权删除
      500:
        description: 服务器内部错误
    """
    try:
        user_id = int(user_id)
        history_id = int(history_id)
    except (ValueError, TypeError):
        return jsonify({"error": "无效的参数"}), 400
    
    return delete_image_history(history_id=history_id, user_id=user_id)


def api_clear_all_ai_history(user_id):
    """
    清空用户的所有AI提示词优化历史记录
    ---
    tags:
      - AI History
    summary: 清空用户的所有AI提示词优化历史记录
    operationId: clearAllAIHistory
    parameters:
      - name: user_id
        in: path
        required: true
        description: 用户ID
        schema:
          type: integer
    responses:
      200:
        description: 清空成功
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                message:
                  type: string
                  example: "清空成功"
                deleted_count:
                  type: integer
                  description: 删除的记录数量
                  example: 25
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "无效的用户ID"
      500:
        description: 服务器内部错误
    """
    try:
        user_id = int(user_id)
    except (ValueError, TypeError):
        return jsonify({"error": "无效的用户ID"}), 400
    
    return clear_all_ai_history(user_id=user_id)


def api_clear_all_image_history(user_id):
    """
    清空用户的所有图片生成历史记录
    ---
    tags:
      - Image History
    summary: 清空用户的所有图片生成历史记录
    operationId: clearAllImageHistory
    parameters:
      - name: user_id
        in: path
        required: true
        description: 用户ID
        schema:
          type: integer
    responses:
      200:
        description: 清空成功
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                message:
                  type: string
                  example: "清空成功"
                deleted_count:
                  type: integer
                  description: 删除的记录数量
                  example: 15
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "无效的用户ID"
      500:
        description: 服务器内部错误
    """
    try:
        user_id = int(user_id)
    except (ValueError, TypeError):
        return jsonify({"error": "无效的用户ID"}), 400
    
    return clear_all_image_history(user_id=user_id)
