import uuid

from flask import request, jsonify

from backend.services.api_client.prompt_deal import prompt_deal

# def api_optimize():
#     """优化提示词 API"""
#     data = request.get_json()
#     if data is None:
#         print(111)
#         return jsonify({'error': '请求体必须是有效的 JSON 格式'}), 400
#     original_prompt = data.get('prompt', '').strip()

#     if not original_prompt:
#         return jsonify({'error': '提示词不能为空'}), 400

#     # 生成请求ID
#     request_id = str(uuid.uuid4())

#     return prompt_deal(request_id, original_prompt)

def api_optimize():
    """
    优化提示词 API
    ---
    tags:
      - AI Prompt
    summary: 优化提示词
    operationId: optimizePrompt
    requestBody:
      required: true
      content:
        application/json:
          schema:
            type: object
            required:
              - prompt
            properties:
              prompt:
                type: string
                description: 原始提示词
                example: "画一只可爱的小猫"
              user_id:
                type: integer
                description: 用户ID（可选，如果提供则保存历史记录）
                example: 1
    responses:
      200:
        description: 成功优化提示词
        content:
          application/json:
            schema:
              type: object
              properties:
                request_id:
                  type: string
                  description: 请求ID
                  example: "550e8400-e29b-41d4-a716-446655440000"
                original_prompt:
                  type: string
                  description: 原始提示词
                  example: "画一只可爱的小猫"
                optimized_prompt:
                  type: string
                  description: 优化后的提示词
                  example: "请绘制一只可爱的猫咪，要求细节丰富，风格温馨，背景简洁，高清质量，适合用于插画或卡通风格。"
                stages:
                  type: array
                  description: 优化阶段详情
                  items:
                    type: object
                    properties:
                      stage:
                        type: string
                        description: 阶段名称
                        example: "analysis"
                      role_name:
                        type: string
                        description: 角色名称
                        example: "提示词分析专家"
                      result:
                        type: string
                        description: 阶段结果
                        example: "分析完成，识别出需要优化的关键点..."
                      status:
                        type: string
                        description: 状态
                        example: "completed"
                      timestamp:
                        type: string
                        format: date-time
                        description: 时间戳
                        example: "2024-10-27T14:30:00"
                status:
                  type: string
                  example: "completed"
                total_stages:
                  type: integer
                  description: 总阶段数
                  example: 4
                completed_at:
                  type: string
                  format: date-time
                  description: 完成时间
                  example: "2024-10-27T14:30:05"
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "提示词不能为空"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                request_id:
                  type: string
                  example: "550e8400-e29b-41d4-a716-446655440000"
                error:
                  type: string
                  example: "服务器内部错误"
                status:
                  type: string
                  example: "error"
    """
    data = request.get_json()
    if data is None:
        return jsonify({'error': '请求体必须是有效的 JSON 格式'}), 400
    
    original_prompt = data.get('prompt', '').strip()
    user_id = data.get('user_id')

    if not original_prompt:
        return jsonify({'error': '提示词不能为空'}), 400

    # 处理user_id（转换为整数或None）
    if user_id is not None:
        try:
            user_id = int(user_id)
            if user_id <= 0:
                user_id = None
        except (ValueError, TypeError):
            user_id = None

    # 生成请求ID
    request_id = str(uuid.uuid4())

    return prompt_deal(request_id, original_prompt, user_id=user_id)


