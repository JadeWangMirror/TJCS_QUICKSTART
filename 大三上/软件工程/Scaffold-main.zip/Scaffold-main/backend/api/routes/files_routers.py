from flask import jsonify, request

from backend.utils.HandleFileURL import save_files,delete_url_list


def files_add_router():
    """
    Upload multiple files and return their URLs

    ---
    tags:
      - Files
    summary: Upload files
    description: Upload one or more files and get their access URLs
    consumes:
      - multipart/form-data
    produces:
      - application/json
    parameters:
      - name: files
        in: formData
        description: Files to upload
        required: true
        type: file
        multiple: true
    responses:
      200:
        description: Successful operation
        schema:
          type: object
          properties:
            status:
              type: string
              example: "success"
            data:
              type: array
              items:
                type: string
              example:
                - "http://example.com/uploads/file1.jpg"
                - "http://example.com/uploads/file2.png"
      400:
        description: Bad request
      500:
        description: Internal server error
    """

    files = []
    if 'files' in request.files:
        files = request.files.getlist('files')
    url_list:list[str] = save_files( files)
    return jsonify({
        "status": "success",
        "data": url_list
    })

# def files_delete_router():
#     res = 0
#     if 'files' in request.files:
#         res = delete_url_list(request.files.getlist('files'))
#     return jsonify({
#         "status": "success",
#         "data": f"删除文件：{res}个"
#     })


