# API 层 - 点赞路由处理

from flask import request, jsonify
from typing import Tuple
from backend.services.like.LikeService import toggle_like_post_comment, check_user_liked
from backend.utils.CCBLog import CCBLog

def toggle_like(user_id: int, post_id: int) -> Tuple[dict, int]:
    """
    切换点赞状态（点赞/取消点赞）
    
    业务流程：
    1. 检查用户是否已点赞
    2. 如果已点赞 → 删除点赞记录 → like_count - 1
    3. 如果未点赞 → 创建点赞记录 → like_count + 1
    4. 返回当前点赞状态和更新后的点赞总数
    ---
    tags:
      - Likes
    summary: 切换点赞状态
    operationId: toggleLike
    parameters:
      - name: user_id
        in: path
        required: true
        description: 当前用户ID
        schema:
          type: integer
          example: 1
      - name: post_id
        in: path
        required: true
        description: 帖子/评论ID
        schema:
          type: integer
          example: 1
    responses:
      200:
        description: 点赞状态切换成功
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                message:
                  type: string
                  description: 操作消息（"点赞成功" 或 "已取消点赞"）
                  example: "点赞成功"
                post_id:
                  type: integer
                  description: 帖子/评论ID
                is_liked:
                  type: boolean
                  description: 当前点赞状态（true表示已点赞，false表示未点赞）
                  example: true
                like_count:
                  type: integer
                  description: 更新后的点赞总数
                  example: 42
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "用户ID和帖子ID不能为空"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "服务器内部错误，点赞操作失败"
    """
    try:
        # 参数验证
        if not user_id or not post_id:
            return jsonify({"error": "用户ID和帖子ID不能为空"}), 400
        
        # 调用 service 层处理业务逻辑
        result = toggle_like_post_comment(user_id=user_id, post_id=post_id)
        
        return result
    
    except ValueError as e:
        # 业务逻辑错误
        return jsonify({"error": str(e)}), 400
    
    except Exception as e:
        # 系统错误
        CCBLog('toggle_like').error(f"点赞操作失败: {e}")
        return jsonify({"error": "服务器内部错误，点赞操作失败"}), 500


def get_like_status(user_id: int, post_id: int) -> Tuple[dict, int]:
    """
    获取当前用户是否点赞了某个帖子/评论
    ---
    tags:
      - Likes
    summary: 查询点赞状态
    operationId: getLikeStatus
    parameters:
      - name: user_id
        in: path
        required: true
        description: 当前用户ID
        schema:
          type: integer
          example: 1
      - name: post_id
        in: path
        required: true
        description: 帖子/评论ID
        schema:
          type: integer
          example: 1
    responses:
      200:
        description: 成功获取点赞状态
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                post_id:
                  type: integer
                  description: 帖子/评论ID
                  example: 1
                is_liked:
                  type: boolean
                  description: 是否已点赞（true表示已点赞，false表示未点赞）
                  example: true
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "用户ID和帖子ID不能为空"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "服务器内部错误，无法查询点赞状态"
    """
    try:
        # 参数验证
        if not user_id or not post_id:
            return jsonify({"error": "用户ID和帖子ID不能为空"}), 400
        
        # 调用 service 层检查点赞状态
        is_liked = check_user_liked(user_id=user_id, post_id=post_id)
        
        return jsonify({
            "status": "success",
            "post_id": post_id,
            "is_liked": is_liked
        }), 200
    
    except Exception as e:
        CCBLog('get_like_status').error(f"查询点赞状态失败: {e}")
        return jsonify({"error": "服务器内部错误，无法查询点赞状态"}), 500
