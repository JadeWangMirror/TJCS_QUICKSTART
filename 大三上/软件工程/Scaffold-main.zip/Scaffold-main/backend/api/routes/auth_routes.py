"""
用户认证相关路由
处理注册、登录、登出等请求
"""
from flask import request, jsonify
from backend.services.auth.UserService import UserService
from backend.services.auth.EmailService import EmailService
from backend.utils.CCBLog import CCBLog
from backend.storage.DBManager import get_db_manager

# 初始化服务
user_service = UserService()
email_service = EmailService()
log = CCBLog("AuthRoutes")


def send_verification_code():
    """
    发送邮箱验证码
    ---
    tags:
      - Authentication
    summary: 发送邮箱验证码
    operationId: sendVerificationCode
    requestBody:
      required: true
      content:
        application/json:
          schema:
            type: object
            required:
              - email
            properties:
              email:
                type: string
                format: email
                description: 用户邮箱地址
                example: "user@example.com"
    responses:
      200:
        description: 验证码发送成功
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "success"
                message:
                  type: string
                  example: "验证码已发送，请查收邮件"
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "error"
                message:
                  type: string
                  example: "邮箱不能为空"
      429:
        description: 请求过于频繁
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "error"
                message:
                  type: string
                  example: "请稍后再试，验证码发送过于频繁"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "error"
                message:
                  type: string
                  example: "验证码发送失败，请稍后重试"
    """
    try:
        data = request.get_json()
        email = data.get('email')

        if not email:
            return jsonify({
                'status': 'error',
                'message': '邮箱不能为空'
            }), 400

        # 检查发送冷却
        can_send, message = email_service.can_send_code(email, cooldown_seconds=60)
        if not can_send:
            return jsonify({
                'status': 'error',
                'message': message
            }), 429  # Too Many Requests

        # 发送验证码
        success = email_service.send_verification_code(email)

        if success:
            return jsonify({
                'status': 'success',
                'message': '验证码已发送，请查收邮件'
            }), 200
        else:
            return jsonify({
                'status': 'error',
                'message': '验证码发送失败，请稍后重试'
            }), 500

    except Exception as e:
        log.error(f"发送验证码异常: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'status': 'error',
            'message': '服务器内部错误'
        }), 500


def register():
    """
    用户注册
    ---
    tags:
      - Authentication
    summary: 用户注册
    operationId: register
    requestBody:
      required: true
      content:
        application/json:
          schema:
            type: object
            required:
              - name
              - email
              - verification_code
              - password
            properties:
              name:
                type: string
                description: 用户名
                example: "new_user"
              email:
                type: string
                format: email
                description: 用户邮箱地址
                example: "user@example.com"
              verification_code:
                type: string
                description: 邮箱验证码
                example: "123456"
              password:
                type: string
                format: password
                description: 用户密码（至少6位）
                example: "secure_password123"
              introduce:
                type: string
                description: 个人简介（可选）
                example: "个人简介"
              tag:
                type: array
                items:
                  type: string
                description: 用户标签列表（可选）
                example: ["Python", "JavaScript"]
    responses:
      201:
        description: 注册成功
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "success"
                message:
                  type: string
                  example: "注册成功"
                user_id:
                  type: integer
                  description: 新注册用户的ID
                  example: 1001
      400:
        description: 请求参数错误或验证码错误
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "error"
                message:
                  type: string
                  example: "请输入验证码"
      409:
        description: 用户名或邮箱已存在
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "error"
                message:
                  type: string
                  example: "用户名已存在"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "error"
                message:
                  type: string
                  example: "服务器内部错误"
    """
    try:
        data = request.get_json()
        
        name = data.get('name')
        email = data.get('email')
        verification_code = data.get('verification_code')
        password = data.get('password')
        introduce = data.get('introduce', '')
        tag = data.get('tag', [])

        # 验证验证码
        if not verification_code:
            return jsonify({
                'status': 'error',
                'message': '请输入验证码'
            }), 400

        is_valid, error_msg = email_service.verify_code(email, verification_code)
        if not is_valid:
            return jsonify({
                'status': 'error',
                'message': error_msg
            }), 400

        # 参数验证在 service 层完成
        user_id = user_service.register(
            name=name,
            password=password,
            email=email,
            introduce=introduce,
            tag=tag
        )
        
        return jsonify({
            'status': 'success',
            'message': '注册成功',
            'user_id': user_id
        }), 201
        
    except ValueError as e:
        log.warning(f"注册失败: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 400 if '不能为空' in str(e) or '至少' in str(e) else 409
        
    except Exception as e:
        log.error(f"注册异常: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'status': 'error',
            'message': '服务器内部错误'
        }), 500


def login():
    """
    用户登录
    ---
    tags:
      - Authentication
    summary: 用户登录
    operationId: login
    requestBody:
      required: true
      content:
        application/json:
          schema:
            type: object
            required:
              - name
              - password
            properties:
              name:
                type: string
                description: 用户名
                example: "existing_user"
              password:
                type: string
                format: password
                description: 用户密码
                example: "user_password123"
    responses:
      200:
        description: 登录成功
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "success"
                message:
                  type: string
                  example: "登录成功"
                user_id:
                  type: integer
                  description: 用户ID
                  example: 1
                token:
                  type: string
                  description: JWT访问令牌
                  example: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoxLCJuYW1lIjoiZXhpc3RpbmdfdXNlciIsImV4cCI6MTcwOTU2NzIwMH0.example"
                expires_in:
                  type: integer
                  description: Token过期时间（秒）
                  example: 3600
      401:
        description: 用户名或密码错误
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "error"
                message:
                  type: string
                  example: "用户名或密码错误"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "error"
                message:
                  type: string
                  example: "服务器内部错误"
    """
    try:
        data = request.get_json()
        
        name = data.get('name')
        password = data.get('password')
        
        # 调用服务层登录
        result = user_service.login(name=name, password=password)

        return jsonify({
            'status': 'success',
            'message': '登录成功',
            'user_id': result['user_id'],
            'token': result['token'],
            'expires_in': result['expires_in']
        }), 200
        
    except ValueError as e:
        log.warning(f"登录失败: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 401  # Unauthorized
        
    except Exception as e:
        log.error(f"登录异常: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'status': 'error',
            'message': '服务器内部错误'
        }), 500


def logout():
    """
    用户登出
    ---
    tags:
      - Authentication
    summary: 用户登出
    operationId: logout
    security:
      - BearerAuth: []
    responses:
      200:
        description: 登出成功
        content:
          application/json:
            schema:
              type: object
              properties:
                success:
                  type: boolean
                  example: true
                data:
                  type: boolean
                  example: true
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                success:
                  type: boolean
                  example: false
                message:
                  type: string
                  example: "服务器内部错误"
    """
    try:
        from flask import g
        user_id = g.current_user_id
        log.info(f"用户 {user_id} 登出")
        
        return jsonify({
            'success': True,
            'data': True
        }), 200
        
    except Exception as e:
        log.error(f"登出异常: {e}")
        return jsonify({
            'success': False,
            'message': '服务器内部错误'
        }), 500


def get_current_user():
    """
    获取当前登录用户信息
    ---
    tags:
      - Authentication
    summary: 获取当前登录用户信息
    operationId: getCurrentUser
    security:
      - BearerAuth: []
    responses:
      200:
        description: 成功获取用户信息
        content:
          application/json:
            schema:
              type: object
              properties:
                success:
                  type: boolean
                  example: true
                data:
                  type: object
                  properties:
                    user:
                      type: object
                      description: 用户信息
                      properties:
                        id:
                          type: integer
                          example: 1
                        name:
                          type: string
                          example: "existing_user"
                        email:
                          type: string
                          example: "user@example.com"
                        level:
                          type: integer
                          example: 1
                        introduce:
                          type: string
                          example: "个人简介"
      401:
        description: 未提供认证信息或Token无效
        content:
          application/json:
            schema:
              type: object
              properties:
                success:
                  type: boolean
                  example: false
                message:
                  type: string
                  example: "未提供认证信息"
      404:
        description: 用户不存在
        content:
          application/json:
            schema:
              type: object
              properties:
                success:
                  type: boolean
                  example: false
                message:
                  type: string
                  example: "用户不存在"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                success:
                  type: boolean
                  example: false
                message:
                  type: string
                  example: "服务器内部错误"
    """
    try:
        from flask import g
        user_id = g.current_user_id
        
        # 获取用户信息
        user_info = user_service.get_user_by_id(user_id)
        
        if not user_info:
            return jsonify({
                'success': False,
                'message': '用户不存在'
            }), 404
        
        return jsonify({
            'success': True,
            'data': {
                'user': user_info
            }
        }), 200
        
    except Exception as e:
        log.error(f"获取用户信息异常: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': '服务器内部错误'
        }), 500


def reset_password():
    """
    重置密码（忘记密码/修改密码）
    ---
    tags:
      - Authentication
    summary: 重置密码（需要邮箱验证码）
    operationId: resetPassword
    requestBody:
      required: true
      content:
        application/json:
          schema:
            type: object
            required:
              - email
              - verification_code
              - new_password
            properties:
              email:
                type: string
                format: email
                description: 用户邮箱地址
                example: "user@example.com"
              verification_code:
                type: string
                description: 邮箱验证码
                example: "123456"
              new_password:
                type: string
                format: password
                description: 新密码（至少8位）
                example: "new_secure_password123"
    responses:
      200:
        description: 密码重置成功
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "success"
                message:
                  type: string
                  example: "密码重置成功，请使用新密码登录"
      400:
        description: 请求参数错误或验证码错误
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "error"
                message:
                  type: string
                  example: "验证码错误"
      404:
        description: 邮箱未注册
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "error"
                message:
                  type: string
                  example: "该邮箱未注册"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "error"
                message:
                  type: string
                  example: "服务器内部错误"
    """
    try:
        data = request.get_json()
        email = data.get('email')
        verification_code = data.get('verification_code')
        new_password = data.get('new_password')
        
        # 参数验证
        if not email:
            return jsonify({
                'status': 'error',
                'message': '邮箱不能为空'
            }), 400
        
        if not verification_code:
            return jsonify({
                'status': 'error',
                'message': '请输入验证码'
            }), 400
        
        if not new_password:
            return jsonify({
                'status': 'error',
                'message': '新密码不能为空'
            }), 400
        
        # 验证邮箱验证码
        is_valid, error_msg = email_service.verify_code(email, verification_code)
        if not is_valid:
            return jsonify({
                'status': 'error',
                'message': error_msg
            }), 400
        
        # 重置密码
        user_service.reset_password(email, new_password)
        
        log.info(f"密码重置成功: {email}")
        
        return jsonify({
            'status': 'success',
            'message': '密码重置成功，请使用新密码登录'
        }), 200
        
    except ValueError as e:
        log.warning(f"密码重置失败: {e}")
        error_message = str(e)
        
        # 根据错误信息返回适当的状态码
        if '未注册' in error_message:
            status_code = 404
        else:
            status_code = 400
        
        return jsonify({
            'status': 'error',
            'message': error_message
        }), status_code
        
    except Exception as e:
        log.error(f"密码重置异常: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'status': 'error',
            'message': '服务器内部错误'
        }), 500


def get_user_info(user_id):
    """
    获取指定用户的公开信息
    ---
    tags:
      - User
    summary: 获取指定用户的公开信息
    operationId: getUserInfo
    parameters:
      - name: user_id
        in: path
        required: true
        description: 用户ID
        schema:
          type: integer
          example: 1
    responses:
      200:
        description: 成功获取用户信息
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "success"
                user:
                  type: object
                  description: 用户公开信息
                  properties:
                    id:
                      type: integer
                      example: 1
                    name:
                      type: string
                      example: "user_name"
                    introduce:
                      type: string
                      example: "个人简介"
                    tag:
                      type: array
                      items:
                        type: string
                      example: ["Python", "Java"]
                    created_at:
                      type: string
                      format: date-time
                      example: "2024-10-27T14:30:00"
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "error"
                message:
                  type: string
                  example: "无效的用户ID"
      404:
        description: 用户不存在
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "error"
                message:
                  type: string
                  example: "用户不存在"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: "error"
                message:
                  type: string
                  example: "服务器内部错误"
    """
    try:
        # 验证user_id是否为有效数字
        try:
            user_id = int(user_id)
        except (ValueError, TypeError):
            return jsonify({
                'status': 'error',
                'message': '无效的用户ID'
            }), 400

        # 从数据库获取用户信息
        from backend.storage.models import User



        with get_db_manager().get_db_session() as session:
            user = session.query(User).filter(User.id == user_id).first()

            if not user:
                return jsonify({
                    'status': 'error',
                    'message': '用户不存在'
                }), 404

            # 格式化tag字段：从 {tag: count} 转换为 [tag1, tag2, ...]
            tag_list = []
            if user.tag and isinstance(user.tag, dict):
                tag_list = list(user.tag.keys())

            # 格式化created_at字段
            created_at_str = user.created_at.strftime('%Y-%m-%dT%H:%M:%S') if user.created_at else None

            # 按照API文档格式返回
            return jsonify({
                'status': 'success',
                'user': {
                    'id': user.id,
                    'name': user.name,
                    'introduce': user.introduce or '',
                    'tag': tag_list,
                    'created_at': created_at_str
                }
            }), 200

    except Exception as e:
        log.error(f"获取用户信息异常: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'status': 'error',
            'message': '服务器内部错误'
        }), 500
