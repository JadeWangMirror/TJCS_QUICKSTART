from .files_routers import files_add_router
from .history_routes import (
    api_ai_history, 
    api_ai_history_detail, 
    api_delete_ai_history,
    api_clear_all_ai_history,
    api_image_history,
    api_image_history_detail,
    api_delete_image_history,
    api_clear_all_image_history
)
# 旧版JSON接口已注释
# from .history_routes import api_history_detail, api_history
from .system_routes import health_check, api_statistics
from .prompt_routes import api_optimize
from .post_comment_routes import recommend_posts, hotest_posts, newest_posts, create_post, delete_post, create_comment, delete_comment, get_user_posts_route
from .auth_routes import register, login, logout, get_current_user, reset_password, send_verification_code, get_user_info
from .like_routes import toggle_like, get_like_status
from .favorite_routes import toggle_favorite, get_favorite_status, get_user_favorite_posts
from .post_comment_routes import post_detail, get_user_browse_history, delete_user_single_browse_record,clear_all_user_browse_history, update_post
from .search_routes import (
    search_posts_handler,
    get_search_history_handler,
    delete_search_history_record_handler,
    clear_search_history_handler
)
from .image_gen_route import api_imagegen

def register_routes(app):
    """注册路由"""
    
    # ==================== 认证相关路由 ====================
    app.add_url_rule('/api/user/send-code', view_func=send_verification_code, methods=['POST'])
    app.add_url_rule('/api/user/register', view_func=register, methods=['POST'])
    app.add_url_rule('/api/user/login', view_func=login, methods=['POST'])
    app.add_url_rule('/api/user/logout', view_func=logout, methods=['POST'])
    app.add_url_rule('/api/user/me', view_func=get_current_user, methods=['GET'])
    app.add_url_rule('/api/user/reset-password', view_func=reset_password, methods=['POST'])
    app.add_url_rule('/api/user/<int:user_id>', view_func=get_user_info, methods=['GET'])
    
    # ==================== AI 历史记录 ====================
    # 旧版JSON接口（已注释）
    # app.add_url_rule('/api/history', view_func=api_history, methods=['GET'])
    # app.add_url_rule('/api/history/<record_id>', view_func=api_history_detail, methods=['GET'])
    
    # 新版数据库接口 - AI提示词优化历史记录
    app.add_url_rule('/api/user/<int:user_id>/history/ai', view_func=api_ai_history, methods=['GET'])
    app.add_url_rule('/api/user/<int:user_id>/history/ai/<int:history_id>', view_func=api_ai_history_detail, methods=['GET'])
    app.add_url_rule('/api/user/<int:user_id>/history/ai/<int:history_id>', view_func=api_delete_ai_history, methods=['DELETE'])
    app.add_url_rule('/api/user/<int:user_id>/history/ai', view_func=api_clear_all_ai_history, methods=['DELETE'])
    
    # 新版数据库接口 - 图片生成历史记录
    app.add_url_rule('/api/user/<int:user_id>/history/image', view_func=api_image_history, methods=['GET'])
    app.add_url_rule('/api/user/<int:user_id>/history/image/<int:history_id>', view_func=api_image_history_detail, methods=['GET'])
    app.add_url_rule('/api/user/<int:user_id>/history/image/<int:history_id>', view_func=api_delete_image_history, methods=['DELETE'])
    app.add_url_rule('/api/user/<int:user_id>/history/image', view_func=api_clear_all_image_history, methods=['DELETE'])
    
    # ==================== 系统接口 ====================
    app.add_url_rule('/api/health', view_func=health_check, methods=['GET'])
    app.add_url_rule('/api/statistics', view_func=api_statistics, methods=['GET'])
    
    # ==================== Prompt 优化 ====================
    app.add_url_rule('/api/optimize', view_func=api_optimize, methods=['POST'])

    # ==================== 文件 ====================
    app.add_url_rule('/api/file/upload', view_func=files_add_router, methods=['POST'])
    # ==================== 帖子相关 ====================
    app.add_url_rule('/api/user/<user_id>/recommend', view_func=recommend_posts, methods=['GET'])
    app.add_url_rule('/api/user/hotest', view_func=hotest_posts, methods=['GET'])
    app.add_url_rule('/api/user/newest', view_func=newest_posts, methods=['GET'])
    app.add_url_rule('/api/user/<user_id>/posts', view_func=get_user_posts_route, methods=['GET'])
    app.add_url_rule('/api/user/<user_id>/create_post', view_func=create_post, methods=['POST'])
    app.add_url_rule('/api/user/<user_id>/<post_id>/update_post', view_func=update_post, methods=['PUT'])
    app.add_url_rule('/api/user/<user_id>/<post_id>/delete_post', view_func=delete_post, methods=['DELETE'])
    app.add_url_rule('/api/user/<user_id>/<post_id>/create_comment', view_func=create_comment, methods=['POST'])
    app.add_url_rule('/api/user/<user_id>/<comment_id>/delete_comment', view_func=delete_comment, methods=['DELETE'])

    # ==================== 点赞相关 ====================
    app.add_url_rule('/api/user/<int:user_id>/<int:post_id>/like', view_func=toggle_like, methods=['POST'])
    app.add_url_rule('/api/user/<int:user_id>/<int:post_id>/like/status', view_func=get_like_status, methods=['GET'])

    # ==================== 收藏相关 ====================
    app.add_url_rule('/api/user/<int:user_id>/<int:post_id>/favorite', view_func=toggle_favorite, methods=['POST'])
    app.add_url_rule('/api/user/<int:user_id>/<int:post_id>/favorite/status', view_func=get_favorite_status, methods=['GET'])
    app.add_url_rule('/api/user/<int:user_id>/favorites', view_func=get_user_favorite_posts, methods=['GET'])

     # ==================== 帖子详情 (新增) ====================

    app.add_url_rule('/api/user/post/<int:post_id>', view_func=post_detail, methods=['GET'])
    
    # ==================== 浏览历史相关====================
    app.add_url_rule('/api/user/<int:user_id>/history/browse', view_func=get_user_browse_history, methods=['GET'])
    app.add_url_rule('/api/user/<int:user_id>/history/browse/<int:record_id>', view_func=delete_user_single_browse_record, methods=['DELETE'])
    app.add_url_rule('/api/user/<int:user_id>/history/browse', view_func=clear_all_user_browse_history, methods=['DELETE'])

    # ==================== 搜索相关 ====================

    # 用户搜索接口（记录搜索历史）
    app.add_url_rule('/api/user/<int:user_id>/search', view_func=search_posts_handler, methods=['GET'])
    # 搜索历史相关
    app.add_url_rule('/api/user/<int:user_id>/history/search', view_func=get_search_history_handler, methods=['GET'])
    app.add_url_rule('/api/user/<int:user_id>/history/search/<int:record_id>', view_func=delete_search_history_record_handler, methods=['DELETE'])
    app.add_url_rule('/api/user/<int:user_id>/history/search', view_func=clear_search_history_handler, methods=['DELETE'])

    # ==================== AI图片生成 ====================
    app.add_url_rule('/api/generate_image', view_func=api_imagegen, methods=['POST'])
