from flask import request, jsonify
from backend.services.post.Post import get_posts, get_recommendation_list, create_insert_post, post_comment_delete, create_insert_comment, post_update, get_post_list, get_user_posts
from backend.services.post.Post import (
    get_post_detail_with_browse,
    get_user_browse_history_list,
    delete_user_browse_record,
    clear_user_browse_history
)
from backend.utils.CCBLog import CCBLog
from backend.utils.CCBLog import CCBLog
def recommend_posts(user_id: int):
    """
    根据用户的兴趣标签（tags_count）进行轮询采样推荐，并支持全局分页。
    ---
    tags:
      - Recommendations
    summary: 获取用户推荐帖子
    operationId: recommendPosts
    parameters:
      - name: user_id
        in: path
        required: true
        description: 要获取推荐的用户ID
        schema:
          type: integer
          example: 1
      - name: limit
        in: query
        required: false
        description: 每页返回的帖子数量 (默认 10)
        schema:
          type: integer
          default: 10
          example: 10
      - name: page_num
        in: query
        required: false
        description: 第几页 (默认 1)
        schema:
          type: integer
          default: 0
          example: 0
    responses:
      200:
        description: 成功获取推荐帖子列表
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                count:
                  type: integer
                  description: 本次返回的帖子数量
                  example: 10
                limit:
                  type: integer
                  description: 请求的限制数量
                  example: 10
                offset:
                  type: integer
                  description: 请求的偏移量
                  example: 0
                posts:
                  type: array
                  description: 推荐的帖子列表
                  items:
                    type: object
                    properties:
                      id:
                        type: integer
                        description: 帖子ID
                        example: 123
                      title:
                        type: string
                        description: 帖子标题
                        example: "Python编程入门指南"
                      context:
                        type: string
                        description: 帖子内容摘要
                        example: "本文介绍了Python编程的基础知识..."
                      author:
                        type: string
                        description: 作者名
                        example: "author_name"
                      timestamp:
                        type: string
                        format: date-time
                        description: 发布时间戳
                        example: "2024-10-27T14:30:00"
                      cover_image:
                        type: string
                        format: url
                        description: 封面图片URL
                        example: "https://example.com/images/cover.jpg"
                      tags:
                        type: array
                        items:
                          type: string
                        description: 帖子标签列表
                        example: ["Python", "编程"]
                      browse_count:
                        type: integer
                        description: 浏览量
                        example: 150
                      like_count:
                        type: integer
                        description: 点赞数
                        example: 25
                      comment_count:
                        type: integer
                        description: 评论数
                        example: 8
      400:
        description: 请求参数错误 (Limit 或 Offset 格式/范围错误)
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "Limit 必须大于 0 且 Offset 不能为负"
    """
    if user_id is None or user_id == 0:
        return jsonify({"error": "user_id必须为有效值(>0)"}), 401
    # 从请求查询参数中获取 limit 和 offset
    try:
        limit = request.args.get('limit', 10, type=int)
        page_num = request.args.get('page_num', 1, type=int)
        
        if limit < 1 or page_num < 1:
            return jsonify({"error": "Limit 必须大于 0 且 PageNum 必须为正"}), 400
        
    except ValueError:
        return jsonify({"error": "Limit 和 PageNum 必须是有效的整数"}), 400

    # 返回 JSON
    return get_recommendation_list(user_id=user_id, limit=limit, page_num=page_num)

def hotest_posts():
    """
    获取按浏览量（热门程度）排序的帖子列表，支持分页。
    ---
    tags:
      - Posts
    summary: 获取最热门的帖子
    operationId: getHotestPosts
    parameters:
      - name: limit
        in: query
        required: false
        description: 每页返回的帖子数量 (默认 10)
        schema:
          type: integer
          default: 10
          example: 10
      - name: page_num
        in: query
        required: false
        description: 第几页 (默认 1)
        schema:
          type: integer
          default: 0
          example: 0
    responses:
      200:
        description: 成功获取热门帖子列表
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                count:
                  type: integer
                  description: 本次返回的帖子数量
                limit:
                  type: integer
                  description: 请求的限制数量
                page_num:
                  type: integer
                  description: 请求的页号
                page_count:
                  type: integer
                  description: 列表总长度(页数)
                posts:
                  type: array
                  description: 热门帖子列表 (按浏览量排序)
                  items:
                    type: object
                    properties:
                      id:
                        type: integer
                        description: 帖子ID
                      title:
                        type: string
                        description: 帖子标题
                      context:
                        type: string
                        description: 帖子内容摘要
                      author:
                        type: string
                        description: 作者名
                      timestamp:
                        type: string
                        format: date-time
                        description: 发布时间戳
                      cover_image:
                        type: string
                        format: url
                        description: 封面图片URL
                      tags:
                        type: array
                        items:
                          type: string
                        description: 帖子标签列表
                      browse_count:
                        type: integer
                        description: 浏览量
                      like_count:
                        type: integer
                        description: 点赞数
                      comment_count:
                        type: integer
                        description: 评论数
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "Limit 和 Offset 必须是有效的整数"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "服务器内部错误，无法获取帖子列表"
    """
    # 从请求查询参数中获取 limit 和 offset
    try:
        limit = request.args.get('limit', 10, type=int)
        page_num = request.args.get('page_num', 1, type=int)
        
        if limit < 1 or page_num < 1:
            return jsonify({"error": "Limit 必须大于 0 且 PageNum 必须为正"}), 400
         
    except ValueError:
        return jsonify({"error": "Limit 和 PageNum 必须是有效的整数"}), 400
    
    return get_post_list(order='hot', limit=limit, page_num=page_num)

def newest_posts():
    """
    获取按时间（最新）排序的帖子列表，支持分页。
    ---
    tags:
      - Posts
    summary: 获取最新的帖子
    operationId: getNewestPosts
    parameters:
      - name: limit
        in: query
        required: false
        description: 每页返回的帖子数量 (默认 10)
        schema:
          type: integer
          default: 10
          example: 10
      - name: page_num
        in: query
        required: false
        description: 第几页 (默认 1)
        schema:
          type: integer
          default: 0
          example: 0
    responses:
      200:
        description: 成功获取最新帖子列表
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                count:
                  type: integer
                  description: 本次返回的帖子数量
                limit:
                  type: integer
                  description: 请求的限制数量
                page_num:
                  type: integer
                  description: 请求的页号
                page_count:
                  type: integer
                  description: 列表总长度(页数)
                posts:
                  type: array
                  description: 最新帖子列表 (按时间排序)
                  items:
                    type: object
                    properties:
                      id:
                        type: integer
                        description: 帖子ID
                      title:
                        type: string
                        description: 帖子标题
                      context:
                        type: string
                        description: 帖子内容摘要
                      author:
                        type: string
                        description: 作者名
                      timestamp:
                        type: string
                        format: date-time
                        description: 发布时间戳
                      cover_image:
                        type: string
                        format: url
                        description: 封面图片URL
                      tags:
                        type: array
                        items:
                          type: string
                        description: 帖子标签列表
                      browse_count:
                        type: integer
                        description: 浏览量
                      like_count:
                        type: integer
                        description: 点赞数
                      comment_count:
                        type: integer
                        description: 评论数
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "Limit 和 Offset 必须是有效的整数"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "服务器内部错误，无法获取帖子列表"
    """
    # 从请求查询参数中获取 limit 和 offset
    try:
        limit = request.args.get('limit', 10, type=int)
        page_num = request.args.get('page_num', 1, type=int)
        
        if limit < 1 or page_num < 1:
            return jsonify({"error": "Limit 必须大于 0 且 PageNum 必须为正"}), 400
        
    except ValueError:
        return jsonify({"error": "Limit 和 PageNum 必须是有效的整数"}), 400
    
    return get_post_list(order="time", limit=limit, page_num=page_num)

def create_post(user_id):
    """
    创建新的帖子，包括标题、内容、可选的标签和上传的图片文件。
    ---
    tags:
      - Posts
    summary: 创建一个新帖子
    operationId: createPost
    parameters:
      - name: user_id
        in: path
        required: true
        description: 创建帖子的用户ID
        schema:
          type: integer
          example: 1
    requestBody:
      required: true
      content:
        multipart/form-data:
          schema:
            type: object
            properties:
              title:
                type: string
                description: 帖子的标题
                example: "我的第一个帖子"
              author_name:
                type: string
                description: 作者名
                example: "author_name"
              context:
                type: string
                description: 帖子的内容
                example: "这是帖子的详细内容..."
              tags:
                type: array
                items:
                  type: string
                description: 帖子关联的标签列表 (可重复字段)
                example: ["Python", "编程"]
              files:
                type: array
                items:
                  type: string
                description: 上传的图片URL列表
    responses:
      201:
        description: 帖子创建成功
        content:
          application/json:
            schema:
              type: object
              properties:
                message:
                  type: string
                  example: "帖子创建成功"
                post_id:
                  type: integer
                  description: 新创建帖子的ID
                  example: 1
                image_urls:
                  type: array
                  items:
                    type: string
                  description: 上传图片的最终访问URL列表
                  example: ["https://example.com/uploads/image1.jpg"]
      400:
        description: 输入数据不完整或缺失 (标题/内容为空)
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "标题和内容不能为空"
      500:
        description: 内部服务器错误（例如数据库插入失败）
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "数据库操作失败"
                details:
                  type: string
                  description: 具体的错误信息，用于调试
    """
    if user_id is None or user_id == 0:
        return jsonify({"error": "user_id必须为有效值(>0)"}), 401
    title = request.form.get('title')
    context = request.form.get('context')
    author_name = request.form.get('author_name')
    if not title or not context:
        return jsonify({"error": "标题和内容不能为空"}), 400
    
    tags_list = []
    if 'tags' in request.form:
        tags_list = request.form.getlist('tags')
    
    url_list = []
    if 'files' in request.form:
        url_list = request.form.getlist('files')
    return create_insert_post(title=title, author_name=author_name, context=context, user_id=user_id, tags_list=tags_list, url_list=url_list)

def update_post(user_id, post_id):
    """
    更新指定帖子（post_id）的内容，包括标题、内容、标签，并支持重新上传图片。
    **注意：此操作会删除帖子原有的所有图片并替换为新上传的文件。**
    ---
    tags:
      - Posts
    summary: 更新现有帖子
    operationId: updatePost
    parameters:
      - name: user_id
        in: path
        required: true
        description: 执行更新操作的用户ID (用于权限验证)
        schema:
          type: integer
      - name: post_id
        in: path
        required: true
        description: 要更新的帖子ID
        schema:
          type: integer
    requestBody:
      required: true
      content:
        multipart/form-data:
          schema:
            type: object
            properties:
              title:
                type: string
                description: 帖子的新标题
              context:
                type: string
                description: 帖子的新内容
              tags:
                type: array
                items:
                  type: string
                description: 帖子关联的新标签列表 (可重复字段)
              files:
                type: array
                items:
                  type: string
                description: 新上传的图片URL列表。
            required:
              - title
              - context
    responses:
      200:
        description: 帖子编辑成功
        content:
          application/json:
            schema:
              type: object
              properties:
                message:
                  type: string
                  example: "帖子编辑成功"
      400:
        description: 输入数据不完整或权限/对象错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  enum:
                    - "标题和内容不能为空"
                    - "无此帖/权限不足/要修改的是评论"
                  description: 错误详情
      500:
        description: 内部服务器错误（例如数据库操作失败）
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "数据库操作失败"
                details:
                  type: string
                  description: 具体的错误信息，用于调试
    """
    if user_id is None or user_id == 0:
        return jsonify({"error": "user_id必须为有效值(>0)"}), 401
    title = request.form.get('title')
    context = request.form.get('context')
    if not title or not context:
        return jsonify({"error": "标题和内容不能为空"}), 400
    
    tags_list = []
    if 'tags' in request.form:
        tags_list = request.form.getlist('tags')
    
    files = []
    if 'files' in request.form:
        files = request.form.getlist('files')
    return post_update(post_id=post_id, title=title, context=context, user_id=user_id, tags_list=tags_list, new_files=files)

def delete_post(user_id, post_id):
    """
    根据用户ID和帖子ID删除指定的帖子（同时删除相关评论）。
    ---
    tags:
      - Posts
    summary: 删除帖子
    operationId: deletePost
    parameters:
      - name: user_id
        in: path
        required: true
        description: 执行删除操作的用户ID (用于权限验证)
        schema:
          type: integer
          example: 1
      - name: post_id
        in: path
        required: true
        description: 要删除的帖子ID
        schema:
          type: integer
          example: 1
    responses:
      200:
        description: 帖子成功删除
        content:
          application/json:
            schema:
              type: object
              properties:
                message:
                  type: string
                  example: "帖子删除成功"
      404:
        description: 帖子不存在或用户无权删除
        content:
          application/json:
            schema:
              type: object
              properties:
                message:
                  type: string
                  example: "无此帖或无权限删除此帖"
      500:
        description: 服务器内部错误（例如数据库操作失败）
        content:
          application/json:
            schema:
              type: object
              properties:
                message:
                  type: string
                  example: "内部服务器错误"
    """
    if user_id is None or user_id == 0:
        return jsonify({"error": "user_id必须为有效值(>0)"}), 401
    rowcount = post_comment_delete(user_id=user_id, id=post_id)
    if rowcount:
        return jsonify({
            "message": "帖子删除成功"
        }), 200
    else:
        return jsonify({
            "message": "无此帖或无权限删除此帖"
        }), 404

def create_comment(user_id, post_id):
    """
    在指定帖子下创建新的评论。如果提供 point_id，则创建的是对该评论的回复。
    ---
    tags:
      - Comments
    summary: 创建帖子评论或回复
    operationId: createComment
    parameters:
      - name: user_id
        in: path
        required: true
        description: 发表评论的用户ID
        schema:
          type: integer
          example: 1
      - name: post_id
        in: path
        required: true
        description: 评论所属的主帖子ID
        schema:
          type: integer
          example: 1
    requestBody:
      required: true
      content:
        multipart/form-data:
          schema:
            type: object
            properties:
              context:
                type: string
                description: 评论的内容
                example: "这是一条评论内容"
              point_id:
                type: integer
                description: |
                  可选。如果此评论是对另一个评论的回复，则为该**评论**的ID。
                  如果未提供，则默认为 **post_id**，表示是对主帖子的评论。
                example: 1
              files:
                type: array
                items:
                  type: string
                  format: binary
                description: 可选的评论图片文件列表
            required:
              - context
    responses:
      201:
        description: 评论创建成功
        content:
          application/json:
            schema:
              type: object
              properties:
                message:
                  type: string
                  example: "帖子创建成功"
                comment_id:
                  type: integer
                  description: 新创建评论的ID
                  example: 1
                image_urls:
                  type: array
                  items:
                    type: string
                  description: 上传图片的最终访问URL列表
                  example: ["https://example.com/uploads/comment_image.jpg"]
      400:
        description: 输入数据不完整（内容为空）
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "内容不能为空"
      500:
        description: 内部服务器错误（例如数据库插入失败或外键约束失败）
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "数据库操作失败"
                details:
                  type: string
                  description: 具体的错误信息，用于调试
    """
    if user_id is None or user_id == 0:
        return jsonify({"error": "user_id必须为有效值(>0)"}), 401
    context = request.form.get('context')
    if not context:
        return jsonify({"error": "内容不能为空"}), 400
    
    point_id = post_id
    if 'point_id' in request.form:
        point_id = request.form.get('point_id')
    
    url_list = []
    if 'files' in request.form:
        url_list = request.form.getlist('files')
    return create_insert_comment(point_id=point_id, context=context, user_id=user_id, url_list=url_list)

def delete_comment(user_id, comment_id):
    """
    根据用户ID和评论ID删除指定的评论。
    ---
    tags:
      - Comments
    summary: 删除评论
    operationId: deleteComment
    parameters:
      - name: user_id
        in: path
        required: true
        description: 执行删除操作的用户ID (用于权限验证)
        schema:
          type: integer
          example: 1
      - name: comment_id
        in: path
        required: true
        description: 要删除的评论ID
        schema:
          type: integer
          example: 456
    responses:
      200:
        description: 评论成功删除
        content:
          application/json:
            schema:
              type: object
              properties:
                message:
                  type: string
                  example: "评论删除成功"
      404:
        description: 评论不存在或用户无权删除
        content:
          application/json:
            schema:
              type: object
              properties:
                message:
                  type: string
                  example: "无此帖或无权限删除此评论"
      500:
        description: 服务器内部错误（例如数据库操作失败）
        content:
          application/json:
            schema:
              type: object
              properties:
                message:
                  type: string
                  example: "内部服务器错误"
    """
    if user_id is None or user_id == 0:
        return jsonify({"error": "user_id必须为有效值(>0)"}), 401
    rowcount = post_comment_delete(user_id=user_id, id=comment_id)
    if rowcount:
        return jsonify({
            "message": "评论删除成功"
        }), 200
    else:
        return jsonify({
            "message": "无此帖或无权限删除此评论"
        }), 404
    
# ==================== 帖子详情相关路由 ====================
def post_detail(post_id):
    """
        查看帖子详情。

        URL:  GET /api/user/post/<post_id>

        - 参数中的 user_id 可为 0（未登录）或有效的数字ID
        - 无论登录与否都增加浏览数
        - 已登录用户记录浏览历史
        ---
        tags:
          - Posts
        summary: 获取帖子详情
        operationId: getPostDetail
        parameters:
          - name: post_id
            in: path
            required: true
            description: 帖子ID
            schema:
              type: integer
              example: 123
          - name: user_id
            in: query
            required: false
            description: 用户ID（可选，0或有效数字ID，用于记录浏览历史）
            schema:
              type: integer
              example: 1
        responses:
          200:
            description: 成功获取帖子详情
            content:
              application/json:
                schema:
                  type: object
                  properties:
                    status:
                      type: string
                      example: success
                    post:
                      type: object
                      description: 帖子详情
                      properties:
                        id:
                          type: integer
                          description: 帖子ID
                          example: 123
                        title:
                          type: string
                          description: 帖子标题
                          example: "Python编程入门指南"
                        context:
                          type: string
                          description: 帖子内容
                          example: "本文详细介绍了Python编程的基础知识..."
                        author:
                          type: string
                          description: 作者名称
                          example: "user_name"
                        author_id:
                          type: integer
                          description: 作者ID
                          example: 1
                        timestamp:
                          type: string
                          format: date-time
                          description: 发布时间戳
                          example: "2024-10-27T14:30:00"
                        url_list:
                          type: array
                          items:
                            type: string
                            format: url
                          description: 图片/资源URL列表
                          example: ["https://example.com/uploads/image1.jpg"]
                        browse_count:
                          type: integer
                          description: 浏览量
                          example: 150
                        like_count:
                          type: integer
                          description: 点赞数
                          example: 25
                        favorite_count:
                          type: integer
                          description: 收藏数
                          example: 12
                        comment_count:
                          type: integer
                          description: 评论数
                          example: 8
                        tags:
                          type: array
                          items:
                            type: string
                          description: 标签列表
                          example: ["Python", "编程"]
                        comments:
                          type: array
                          description: 评论树结构
                          items:
                            type: object
                            properties:
                              id:
                                type: integer
                                description: 评论ID
                                example: 456
                              context:
                                type: string
                                description: 评论内容
                                example: "这是一条评论内容"
                              author:
                                type: string
                                description: 评论作者名
                                example: "commenter_name"
                              author_id:
                                type: integer
                                description: 评论作者ID
                                example: 2
                              timestamp:
                                type: string
                                format: date-time
                                description: 评论时间
                                example: "2024-10-27T15:30:00"
                              url_list:
                                type: array
                                items:
                                  type: string
                                  format: url
                                description: 评论图片URL列表
                                example: []
                              browse_count:
                                type: integer
                                description: 评论浏览量
                                example: 3
                              like_count:
                                type: integer
                                description: 评论点赞数
                                example: 0
                              favorite_count:
                                type: integer
                                description: 评论收藏数
                                example: 0
                              comment_count:
                                type: integer
                                description: 评论的回复数
                                example: 1
                              tags:
                                type: array
                                items:
                                  type: string
                                description: 评论标签列表
                                example: []
                              title:
                                type: string
                                description: 评论标题
                                example: "回复标题"
                              comments:
                                type: array
                                description: 子评论列表（递归结构）
                                example: []

          400:
            description: 请求参数错误
            content:
              application/json:
                schema:
                  type: object
                  properties:
                    error:
                      type: string
                      example: "参数类型错误"
          404:
            description: 帖子不存在
            content:
              application/json:
                schema:
                  type: object
                  properties:
                    error:
                      type: string
                      example: "帖子不存在"
          500:
            description: 服务器内部错误
            content:
              application/json:
                schema:
                  type: object
                  properties:
                    error:
                      type: string
                      example: "服务器内部错误"
    """

    try:
        user_id=request.args.get('user_id')
        # 将 user_id 转换为整数或 None
        if user_id is None or user_id == 0 or user_id == '':
            user_id = None
        else:
            try:
                user_id = int(user_id)
            except (ValueError, TypeError):
                user_id = None
        if user_id is None or user_id == 0:
          return jsonify({"error": "user_id必须为有效值(>0)"}), 401
        post_id = int(post_id)
        
        CCBLog("post_detail").info(f"user {user_id} is browsing on post {post_id}")

        return get_post_detail_with_browse(user_id, post_id)
    
    except ValueError:
        return jsonify({"error": "参数类型错误"}), 400


# ==================== 浏览历史相关路由 ====================

def get_user_browse_history(user_id):
    """
    获取用户的浏览历史列表。
    
    URL: GET /api/user/<user_id>/history/browse
    Query params: limit, page_num
    ---
    tags:
      - Browse History
    summary: 获取用户浏览历史列表
    operationId: getUserBrowseHistory
    parameters:
      - name: user_id
        in: path
        required: true
        description: 用户ID
        schema:
          type: integer
          example: 1
          example: 1
      - name: limit
        in: query
        required: false
        description: 每页数量（默认10）
        schema:
          type: integer
          default: 10
          example: 10
      - name: page_num
        in: query
        required: false
        description: 第几页（默认1）
        schema:
          type: integer
          default: 1
          example: 1
    responses:
      200:
        description: 成功获取浏览历史列表
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                count:
                  type: integer
                  description: 本次返回的记录数量
                  example: 10
                total_count:
                  type: integer
                  description: 总记录数
                  example: 50
                limit:
                  type: integer
                  description: 每页数量
                  example: 10
                page_num:
                  type: integer
                  description: 当前页码
                  example: 1
                page_count:
                  type: integer
                  description: 总页数
                  example: 5
                records:
                  type: array
                  description: 浏览历史记录列表
                  items:
                    type: object
                    properties:
                      id:
                        type: integer
                        description: 浏览记录ID
                        example: 1
                      post_id:
                        type: integer
                        description: 帖子ID
                        example: 123
                      title:
                        type: string
                        description: 帖子标题
                        example: "Python编程入门指南"
                      author:
                        type: string
                        description: 帖子作者名称
                        example: "author_name"
                      browse_count:
                        type: integer
                        description: 帖子当前浏览量
                        example: 150
                      like_count:
                        type: integer
                        description: 帖子当前点赞数
                        example: 25
                      comment_count:
                        type: integer
                        description: 帖子当前评论数
                        example: 8
                      timestamp:
                        type: string
                        format: date-time
                        description: 浏览时间
                        example: "2024-10-27T14:30:00"
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "参数类型错误"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "服务器内部错误"
    """
    try:
      user_id = int(user_id)
      if user_id is None or user_id == 0:
        return jsonify({"error": "user_id必须为有效值(>0)"}), 401
      limit = request.args.get('limit', 10, type=int)
      page_num = request.args.get('page_num', 1, type=int)

      return get_user_browse_history_list(user_id, limit, page_num)
    
    except ValueError:
        return jsonify({"error": "参数类型错误"}), 400


def delete_user_single_browse_record(user_id, record_id):
    """
    删除用户的单条浏览历史记录。
    
    URL: DELETE /api/user/<user_id>/history/browse/<record_id>
    ---
    tags:
      - Browse History
    summary: 删除单条浏览历史记录
    operationId: deleteUserSingleBrowseRecord
    parameters:
      - name: user_id
        in: path
        required: true
        description: 用户ID
        schema:
          type: integer
          example: 1
          example: 1
      - name: record_id
        in: path
        required: true
        description: 浏览历史记录ID（即帖子ID）
        schema:
          type: integer
          example: 123
    responses:
      200:
        description: 删除成功
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                message:
                  type: string
                  example: "删除成功"
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "参数类型错误"
      404:
        description: 记录不存在
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "记录不存在"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "服务器内部错误"
    """
    try:
        user_id = int(user_id)
        if user_id is None or user_id == 0:
          return jsonify({"error": "user_id必须为有效值(>0)"}), 401
        record_id = int(record_id)
        
        return delete_user_browse_record(user_id, record_id)
    
    except ValueError:
        return jsonify({"error": "参数类型错误"}), 400


def clear_all_user_browse_history(user_id):
    """
    清空用户的所有浏览历史。
    
    URL: DELETE /api/user/<user_id>/history/browse
    ---
    tags:
      - Browse History
    summary: 清空用户所有浏览历史
    operationId: clearAllUserBrowseHistory
    parameters:
      - name: user_id
        in: path
        required: true
        description: 用户ID
        schema:
          type: integer
          example: 1
    responses:
      200:
        description: 清空成功
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                message:
                  type: string
                  example: "清空成功"
                deleted_count:
                  type: integer
                  description: 删除的记录数量
                  example: 25
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "参数类型错误"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "服务器内部错误"
    """
    try:
        user_id = int(user_id)
        if user_id is None or user_id == 0:
          return jsonify({"error": "user_id必须为有效值(>0)"}), 401
        
        return clear_user_browse_history(user_id)
    
    except ValueError:
        return jsonify({"error": "参数类型错误"}), 400


def get_user_posts_route(user_id):
    """
    获取指定用户发布的所有主贴（用户主页“我的帖子”），支持分页。

    URL: GET /api/user/<user_id>/posts
    Query params: limit, page_num
    ---
    tags:
      - Posts
    summary: 获取用户发布的帖子列表
    operationId: getUserPosts
    parameters:
      - name: user_id
        in: path
        required: true
        description: 用户ID
        schema:
          type: integer
          example: 1
      - name: limit
        in: query
        required: false
        description: 每页返回的帖子数量 (默认 10)
        schema:
          type: integer
          default: 10
          example: 10
      - name: page_num
        in: query
        required: false
        description: 第几页 (默认 1)
        schema:
          type: integer
          default: 1
          example: 1
    responses:
      200:
        description: 成功获取用户帖子列表
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                count:
                  type: integer
                  description: 本次返回的帖子数量
                limit:
                  type: integer
                  description: 每页数量
                page_num:
                  type: integer
                  description: 当前页码
                page_count:
                  type: integer
                  description: 总页数
                total_count:
                  type: integer
                  description: 帖子总数
                posts:
                  type: array
                  description: 用户发布的帖子列表
                  items:
                    type: object
                    properties:
                      id:
                        type: integer
                        description: 帖子ID
                      title:
                        type: string
                        description: 帖子标题
                      context:
                        type: string
                        description: 帖子内容摘要
                      author:
                        type: string
                        description: 作者名称
                      author_id:
                        type: integer
                        description: 作者ID
                      timestamp:
                        type: string
                        format: date-time
                        description: 发布时间戳
                      cover_image:
                        type: string
                        format: url
                        description: 封面图片URL（若有）
                      tags:
                        type: array
                        items:
                          type: string
                        description: 标签列表
                      browse_count:
                        type: integer
                        description: 浏览量
                      like_count:
                        type: integer
                        description: 点赞数
                      comment_count:
                        type: integer
                        description: 评论数
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "Limit 必须大于 0 且 PageNum 必须为正"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "服务器内部错误"
    """
    try:
        user_id = int(user_id)
        limit = request.args.get('limit', 10, type=int)
        page_num = request.args.get('page_num', 1, type=int)

        return get_user_posts(user_id=user_id, limit=limit, page_num=page_num)

    except ValueError:
        return jsonify({"error": "参数类型错误"}), 400
