# API 层 - 收藏路由处理

from flask import request, jsonify
from typing import Tuple
from backend.services.favorite.FavoriteService import (
  toggle_favorite_post_comment,
  check_user_favorited,
  get_user_favorite_posts_service,
)
from backend.utils.CCBLog import CCBLog


def toggle_favorite(user_id: int, post_id: int) -> Tuple[dict, int]:
    """
    切换收藏状态（收藏/取消收藏）
    
    业务流程：
    1. 检查用户是否已收藏
    2. 如果已收藏 → 删除收藏记录 → favorite_count - 1
    3. 如果未收藏 → 创建收藏记录 → favorite_count + 1
    4. 返回当前收藏状态和更新后的收藏总数
    ---
    tags:
      - Favorites
    summary: 切换收藏状态
    operationId: toggleFavorite
    parameters:
      - name: user_id
        in: path
        required: true
        description: 当前用户ID
        schema:
          type: integer
          example: 1
      - name: post_id
        in: path
        required: true
        description: 帖子/评论ID
        schema:
          type: integer
          example: 1
    responses:
      200:
        description: 收藏状态切换成功
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                message:
                  type: string
                  description: 操作消息（"收藏成功" 或 "已取消收藏"）
                  example: "收藏成功"
                post_id:
                  type: integer
                  description: 帖子/评论ID
                is_favorited:
                  type: boolean
                  description: 当前收藏状态（true表示已收藏，false表示未收藏）
                  example: true
                favorite_count:
                  type: integer
                  description: 更新后的收藏总数
                  example: 15
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "用户ID和帖子ID不能为空"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "服务器内部错误，收藏操作失败"
    """
    try:
        # 参数验证
        if not user_id or not post_id:
            return jsonify({"error": "用户ID和帖子ID不能为空"}), 400
        
        # 调用 service 层处理业务逻辑
        result = toggle_favorite_post_comment(user_id=user_id, post_id=post_id)
        
        return result
    
    except ValueError as e:
        # 业务逻辑错误
        return jsonify({"error": str(e)}), 400
    
    except Exception as e:
        # 系统错误
        CCBLog('toggle_favorite').error(f"收藏操作失败: {e}")
        return jsonify({"error": "服务器内部错误，收藏操作失败"}), 500


def get_favorite_status(user_id: int, post_id: int) -> Tuple[dict, int]:
    """
    获取当前用户是否收藏了某个帖子/评论
    ---
    tags:
      - Favorites
    summary: 查询收藏状态
    operationId: getFavoriteStatus
    parameters:
      - name: user_id
        in: path
        required: true
        description: 当前用户ID
        schema:
          type: integer
          example: 1
      - name: post_id
        in: path
        required: true
        description: 帖子/评论ID
        schema:
          type: integer
          example: 1
    responses:
      200:
        description: 成功获取收藏状态
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                post_id:
                  type: integer
                  description: 帖子/评论ID
                  example: 1
                is_favorited:
                  type: boolean
                  description: 是否已收藏（true表示已收藏，false表示未收藏）
                  example: true
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "用户ID和帖子ID不能为空"
      500:
        description: 服务器内部错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "服务器内部错误，无法查询收藏状态"
    """
    try:
        # 参数验证
        if not user_id or not post_id:
            return jsonify({"error": "用户ID和帖子ID不能为空"}), 400
        
        # 调用 service 层检查收藏状态
        is_favorited = check_user_favorited(user_id=user_id, post_id=post_id)
        
        return jsonify({
            "status": "success",
            "post_id": post_id,
            "is_favorited": is_favorited
        }), 200
    
    except Exception as e:
        CCBLog('get_favorite_status').error(f"查询收藏状态失败: {e}")
        return jsonify({"error": "服务器内部错误，无法查询收藏状态"}), 500


def get_user_favorite_posts(user_id: int):
    """
    获取用户收藏的帖子列表（分页）。
    ---
    tags:
      - Favorites
    summary: 获取用户收藏的帖子列表
    operationId: getUserFavoritePosts
    parameters:
      - name: user_id
        in: path
        required: true
        description: 用户ID
        schema:
          type: integer
          example: 1
      - name: limit
        in: query
        required: false
        description: 每页数量（默认10）
        schema:
          type: integer
          default: 10
          example: 10
      - name: page_num
        in: query
        required: false
        description: 第几页（从1开始，默认1）
        schema:
          type: integer
          default: 1
          example: 1
    responses:
      200:
        description: 成功获取收藏列表
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  example: success
                count:
                  type: integer
                  description: 本次返回的记录数量
                  example: 10
                total_count:
                  type: integer
                  description: 收藏总数
                  example: 42
                limit:
                  type: integer
                  description: 每页数量
                  example: 10
                page_num:
                  type: integer
                  description: 当前页码（从1开始）
                  example: 1
                page_count:
                  type: integer
                  description: 总页数
                  example: 5
                posts:
                  type: array
                  items:
                    type: object
                    properties:
                      id:
                        type: integer
                        description: 帖子ID
                        example: 123
                      title:
                        type: string
                        description: 帖子标题
                        example: "示例标题"
                      context:
                        type: string
                        description: 帖子内容
                        example: "正文..."
                      author:
                        type: string
                        description: 作者昵称
                        example: "user1"
                      author_id:
                        type: integer
                        description: 作者ID
                        example: 9
                      timestamp:
                        type: string
                        format: date-time
                        description: 发布时间
                        example: "2024-10-27T14:30:00"
                      url_list:
                        type: array
                        items:
                          type: string
                        description: 图片/资源URL列表
                      tags:
                        type: array
                        items:
                          type: string
                        description: 标签列表
                      browse_count:
                        type: integer
                        description: 浏览量
                      like_count:
                        type: integer
                        description: 点赞数
                      comment_count:
                        type: integer
                        description: 评论数
                      favorite_count:
                        type: integer
                        description: 收藏数
      400:
        description: 参数错误
      500:
        description: 服务器内部错误
    """
    try:
        limit = request.args.get('limit', 10, type=int)
        page_num = request.args.get('page_num', 1, type=int)
    except (ValueError, TypeError):
        return jsonify({"error": "参数格式错误"}), 400

    return get_user_favorite_posts_service(user_id=user_id, limit=limit, page_num=page_num)

