import uuid

from flask import request, jsonify

from backend.services.api_client.image_gen_deal import image_gen_deal

# def api_imagegen():
#     """优化提示词 API"""
#     data = request.get_json()
#     if data is None:
#         print(111)
#         return jsonify({'error': '请求体必须是有效的 JSON 格式'}), 400
#     original_prompt = data.get('prompt', '').strip()

#     if not original_prompt:
#         return jsonify({'error': '提示词不能为空'}), 400

#     # 生成请求ID
#     request_id = str(uuid.uuid4())

#     return image_gen_deal(request_id, original_prompt)

def api_imagegen():
    """
    图像生成 API
    ---
    tags:
      - AI Image Generation
    summary: 生成图像
    operationId: generateImage
    requestBody:
      required: true
      content:
        application/json:
          schema:
            type: object
            required:
              - prompt
            properties:
              prompt:
                type: string
                description: 生成图像的提示词
                example: "一只可爱的小猫，卡通风格，高清"
              user_id:
                type: integer
                description: 用户ID（可选，如果提供则保存历史记录）
                example: 1
    responses:
      200:
        description: 成功生成图像
        content:
          application/json:
            schema:
              type: object
              properties:
                request_id:
                  type: string
                  description: 请求ID
                  example: "550e8400-e29b-41d4-a716-446655440000"
                status:
                  type: string
                  example: "success"
                prompt:
                  type: string
                  description: 提示词
                  example: "一只可爱的小猫，卡通风格，高清"
                data:
                  type: object
                  description: 图像生成数据
                  properties:
                    image_urls:
                      type: array
                      description: 图像URL列表
                      items:
                        type: object
                        properties:
                          index:
                            type: integer
                            description: 图像索引
                            example: 0
                          file_name:
                            type: string
                            description: 文件名
                            example: "image_123456.png"
                          image_url:
                            type: string
                            format: url
                            description: 图像URL
                            example: "https://example.com/images/image_123456.png"
                          mime_type:
                            type: string
                            description: MIME类型
                            example: "image/png"
                    image_count:
                      type: integer
                      description: 图像数量
                      example: 1
                    task_id:
                      type: string
                      description: 任务ID
                      example: "task_123456"
                    task_status:
                      type: string
                      description: 任务状态
                      example: "SUCCEEDED"
                message:
                  type: string
                  example: "图像生成成功"
      400:
        description: 请求参数错误
        content:
          application/json:
            schema:
              type: object
              properties:
                error:
                  type: string
                  example: "提示词不能为空"
      500:
        description: 服务器内部错误或图像生成失败
        content:
          application/json:
            schema:
              type: object
              properties:
                request_id:
                  type: string
                  example: "550e8400-e29b-41d4-a716-446655440000"
                status:
                  type: string
                  example: "error"
                error:
                  type: string
                  description: 错误信息
                  example: "API Key未配置"
    """
    data = request.get_json()
    if data is None:
        return jsonify({'error': '请求体必须是有效的 JSON 格式'}), 400
    
    original_prompt = data.get('prompt', '').strip()
    user_id = data.get('user_id')

    if not original_prompt:
        return jsonify({'error': '提示词不能为空'}), 400

    # 处理user_id（转换为整数或None）
    if user_id is not None:
        try:
            user_id = int(user_id)
            if user_id <= 0:
                user_id = None
        except (ValueError, TypeError):
            user_id = None

    # 生成请求ID
    request_id = str(uuid.uuid4())

    return image_gen_deal(request_id, original_prompt, user_id=user_id)


