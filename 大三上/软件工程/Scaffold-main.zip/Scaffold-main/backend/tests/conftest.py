import pytest
from backend.app import app as flask_app

@pytest.fixture
def app():
    """Create and configure a new app instance for each test."""
    # 进一步的配置，例如使用测试数据库
    flask_app.config.update({
        "TESTING": True,
        # 在这里可以覆盖数据库配置，使用一个单独的测试数据库
        # "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:", 
    })

    # 其他设置，例如创建测试数据库和表
    # with flask_app.app_context():
    #     from backend.storage.db import db
    #     db.create_all()

    yield flask_app

    # 清理工作，例如删除测试数据库的表
    # with flask_app.app_context():
    #     db.drop_all()


@pytest.fixture
def client(app):
    """A test client for the app."""
    return app.test_client()
