import json
import pytest
from unittest.mock import patch, MagicMock

# 使用 conftest.py 中定义的 client fixture
def test_register_success(client):
    """测试成功注册"""
    # 模拟 UserService 和 EmailService
    with patch('backend.api.routes.auth_routes.user_service') as mock_user_service, \
         patch('backend.api.routes.auth_routes.email_service') as mock_email_service:

        # 配置模拟对象的返回值
        mock_email_service.verify_code.return_value = (True, "")
        mock_user_service.register.return_value = 1 # 返回新用户ID

        # 准备测试数据
        data = {
            "name": "testuser",
            "email": "test@example.com",
            "password": "password123",
            "verification_code": "123456"
        }

        # 发送 POST 请求
        response = client.post('/api/auth/register', data=json.dumps(data), content_type='application/json')

        # 断言
        assert response.status_code == 201
        response_data = json.loads(response.data)
        assert response_data['status'] == 'success'
        assert response_data['message'] == '注册成功'
        assert response_data['user_id'] == 1
        
        # 验证服务是否被正确调用
        mock_email_service.verify_code.assert_called_once_with("test@example.com", "123456")
        mock_user_service.register.assert_called_once()

def test_register_existing_user(client):
    """测试用户名已存在的情况"""
    with patch('backend.api.routes.auth_routes.user_service') as mock_user_service, \
         patch('backend.api.routes.auth_routes.email_service') as mock_email_service:

        mock_email_service.verify_code.return_value = (True, "")
        # 模拟 register 方法抛出 ValueError，因为用户名已存在
        mock_user_service.register.side_effect = ValueError("用户名已存在")

        data = {
            "name": "existinguser",
            "email": "test@example.com",
            "password": "password123",
            "verification_code": "123456"
        }

        response = client.post('/api/auth/register', data=json.dumps(data), content_type='application/json')

        assert response.status_code == 409 # Conflict
        response_data = json.loads(response.data)
        assert response_data['status'] == 'error'
        assert response_data['message'] == '用户名已存在'

def test_login_success(client):
    """测试成功登录"""
    with patch('backend.api.routes.auth_routes.user_service') as mock_user_service:
        # 模拟 login 方法的返回值
        mock_user_service.login.return_value = {
            'user_id': 1,
            'token': 'fake_jwt_token',
            'expires_in': 3600
        }

        data = {
            "name": "testuser",
            "password": "password123"
        }

        response = client.post('/api/auth/login', data=json.dumps(data), content_type='application/json')

        assert response.status_code == 200
        response_data = json.loads(response.data)
        assert response_data['status'] == 'success'
        assert response_data['message'] == '登录成功'
        assert response_data['token'] == 'fake_jwt_token'
        mock_user_service.login.assert_called_once_with(name="testuser", password="password123")

def test_login_failure(client):
    """测试登录失败（密码错误）"""
    with patch('backend.api.routes.auth_routes.user_service') as mock_user_service:
        # 模拟 login 方法抛出 ValueError
        mock_user_service.login.side_effect = ValueError("用户名或密码错误")

        data = {
            "name": "testuser",
            "password": "wrongpassword"
        }

        response = client.post('/api/auth/login', data=json.dumps(data), content_type='application/json')

        assert response.status_code == 401 # Unauthorized
        response_data = json.loads(response.data)
        assert response_data['status'] == 'error'
        assert response_data['message'] == '用户名或密码错误'
