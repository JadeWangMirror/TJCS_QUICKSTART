# file: D:\zs\软工\code\Scaffold\Code\backend\utils\logger.py
import datetime


class CCBLog:
    # 定义颜色码
    COLORS = {
        'INFO': '\033[92m',  # 绿色
        'WARNING': '\033[93m',  # 黄色
        'ERROR': '\033[91m',  # 红色
        'DEBUG': '\033[96m',  # 青色
        'RESET': '\033[0m'  # 重置颜色
    }

    def __init__(self, name="app"):
        self.name = name

    def _log(self, level, message):
        """基础日志方法"""
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        color = self.COLORS.get(level, '')
        reset = self.COLORS['RESET']

        log_message = f"{color}[{timestamp}] {self.name} - {level} - {message}{reset}"
        print(log_message)

    def info(self, message):
        """信息级别日志"""
        self._log('INFO', message)

    def warning(self, message):
        """警告级别日志"""
        self._log('WARNING', message)

    def error(self, message):
        """错误级别日志"""
        self._log('ERROR', message)

    def debug(self, message):
        """调试级别日志"""
        self._log('DEBUG', message)
