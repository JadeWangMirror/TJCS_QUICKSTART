import os
import uuid
from flask import url_for
from backend.config.ConfigReader import ConfigReader
from backend.utils.CCBLog import CCBLog

UPLOAD_FOLDER = ConfigReader("./backend/config/app_config.json").read_config()['UPLOAD_FOLDER']

def save_files(files):
    url_list = []
    for file in files:
        if not file or file.filename == '':
            continue
        # 1. 获取原始文件的扩展名
        _, file_ext = os.path.splitext(file.filename)
        # 2. 生成基于 UUID 的唯一文件名
        filename = str(uuid.uuid4()) + file_ext

        file_path = os.path.join(UPLOAD_FOLDER, filename)
        file.save(file_path)
        parts = UPLOAD_FOLDER.split('/', 1)
        image_url = url_for(parts[0], filename=f'{parts[1]}/{filename}', _external=True)
        url_list.append(image_url)
    return url_list

def delete_url_list(url_list:list)->int:
    num = 0
    for url in url_list:
        filename = url.split('/')[-1]
        file_path = os.path.join(UPLOAD_FOLDER, filename)
        log = CCBLog("FileDelete")
        try:
            # 检查文件是否存在，然后删除
            if os.path.exists(file_path):
                os.remove(file_path)
                log.info(f"成功删除文件: {file_path}")
            else:
                log.warning(f"文件不存在，跳过删除: {file_path}")
            num += 1
        except OSError as e:
            # 捕获删除失败的异常，例如权限不足等
            log.error(f"删除文件失败 {file_path}: {e}")
    return num