"""
SQLAlchemy ORM 模型定义

⚠️ 重要说明：
- 本文件是数据库表结构的**权威定义**
- 初始化数据库请使用: python -m backend.storage.init_db
- 如需修改表结构，请修改本文件并重新运行 init_db
"""
from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Text, TIMESTAMP, 
    BigInteger, JSON, Index
)
from sqlalchemy.dialects.mysql import INTEGER, BIGINT
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, foreign
from sqlalchemy.sql import func
from sqlalchemy.sql import text

# 创建基类
Base = declarative_base()


class User(Base):
    """用户表"""
    __tablename__ = 'users'
    __table_args__ = {'comment': '用户表'}

    id = Column(
        INTEGER(unsigned=True),
        primary_key=True,
        autoincrement=True,
        comment='用户ID'
    )
    name = Column(
        String(100),
        nullable=False,
        unique=True,
        comment='用户名'
    )
    email = Column(
        String(100),
        nullable=False,
        unique=True,
        comment='邮箱（唯一，必填）'
    )
    password = Column(
        String(255),
        nullable=False,
        comment='哈希加密后的密码'
    )
    level = Column(
        Integer,
        nullable=False,
        default=1,
        server_default=text('1'),
        comment='权限等级'
    )
    introduce = Column(
        String(500),
        nullable=True,
        comment='自我介绍'
    )
    tag = Column(
        JSON,
        nullable=True,
        comment='标签及计数 (map{tag:count})'
    )
    recommend_tag_list = Column(
        JSON,
        nullable=True,
        comment='标签及计数 (map{tag:count})'
    )
    created_at = Column(
        TIMESTAMP,
        server_default=func.current_timestamp(),
        nullable=False
    )

    # 关系定义
    posts_comments = relationship(
        "PostComment",
        back_populates="author_user",
        primaryjoin="User.id==foreign(PostComment.author)",
        cascade="all, delete-orphan"
    )
    likes = relationship(
        "Like",
        back_populates="user",
        primaryjoin="User.id==foreign(Like.user_id)",
        cascade="all, delete-orphan"
    )
    favorites = relationship(
        "Favorite",
        back_populates="user",
        primaryjoin="User.id==foreign(Favorite.user_id)",
        cascade="all, delete-orphan"
    )
    browse_history = relationship(
        "UserBrowseHistory",
        back_populates="user",
        primaryjoin="User.id==foreign(UserBrowseHistory.user_id)",
        cascade="all, delete-orphan"
    )
    ai_history = relationship(
        "AIHistory",
        back_populates="user",
        primaryjoin="User.id==foreign(AIHistory.user_id)",
        cascade="all, delete-orphan"
    )
    image_history = relationship(
        "ImageHistory",
        back_populates="user",
        primaryjoin="User.id==foreign(ImageHistory.user_id)",
        cascade="all, delete-orphan"
    )
    search_history = relationship(
        "SearchHistory",
        back_populates="user",
        primaryjoin="User.id==foreign(SearchHistory.user_id)",
        cascade="all, delete-orphan"
    )
    user_profiles = relationship(
        "UserProfile",
        back_populates="user",
        primaryjoin="User.id==foreign(UserProfile.user_id)",
        cascade="all, delete-orphan"
    )

    def __repr__(self):
        return f"<User(id={self.id}, name='{self.name}', level={self.level})>"


class PostComment(Base):
    """帖子/评论表"""
    __tablename__ = 'posts_comments'
    __table_args__ = (
        Index('idx_point_id', 'point_id'),
        {'comment': '帖子和评论表'}
    )

    id = Column(
        BIGINT(unsigned=True),
        primary_key=True,
        autoincrement=True,
        comment='ID'
    )
    title = Column(
        String(255),
        nullable=True,
        comment='帖子标题 (仅主贴使用，评论可空)'
    )
    timestamp = Column(
        TIMESTAMP,
        server_default=func.current_timestamp(),
        nullable=False,
        comment='发布时间'
    )
    context = Column(
        Text,
        nullable=False,
        comment='内容'
    )
    author = Column(
        INTEGER(unsigned=True),
        nullable=False,
        comment='作者用户ID'
    )
    url_list = Column(
        JSON,
        nullable=True,
        comment='图片/资源 URL 列表 (JSON 列表)'
    )
    point_id = Column(
        BIGINT(unsigned=True),
        nullable=True,
        comment='指向的父帖子/评论ID (用于评论的递归关系)'
    )
    browse_count = Column(
        BIGINT(unsigned=True),
        nullable=False,
        default=0,
        server_default=text('0'),
        comment='浏览数'
    )
    like_count = Column(
        BIGINT(unsigned=True),
        nullable=False,
        default=0,
        server_default=text('0'),
        comment='点赞数'
    )
    favorite_count = Column(
        BIGINT(unsigned=True),
        nullable=False,
        default=0,
        server_default=text('0'),
        comment='收藏数'
    )
    comment_count = Column(
        INTEGER(unsigned=True),
        nullable=False,
        default=0,
        server_default=text('0'),
        comment='评论数'
    )
    tag = Column(
        JSON,
        nullable=True,
        comment='标签信息 (JSON 格式)'
    )

    # 关系定义
    author_user = relationship(
        "User",
        back_populates="posts_comments",
        primaryjoin="foreign(PostComment.author)==User.id"
    )
    
    # 自引用关系 - 父评论和子评论
    parent_post = relationship(
        "PostComment",
        remote_side=[id],
        back_populates="child_comments",
        primaryjoin="foreign(PostComment.point_id)==PostComment.id"
    )
    child_comments = relationship(
        "PostComment",
        back_populates="parent_post",
        primaryjoin="foreign(PostComment.point_id)==PostComment.id",
        cascade="all, delete-orphan"
    )
    
    likes = relationship(
        "Like",
        back_populates="post_comment",
        primaryjoin="PostComment.id==foreign(Like.point_id)",
        cascade="all, delete-orphan"
    )
    favorites = relationship(
        "Favorite",
        back_populates="post_comment",
        primaryjoin="PostComment.id==foreign(Favorite.point_id)",
        cascade="all, delete-orphan"
    )
    browse_history = relationship(
        "UserBrowseHistory",
        back_populates="post",
        primaryjoin="PostComment.id==foreign(UserBrowseHistory.post_id)",
        cascade="all, delete-orphan"
    )
    item_profiles = relationship(
        "ItemProfile",
        back_populates="post",
        primaryjoin="PostComment.id==foreign(ItemProfile.post_id)",
        cascade="all, delete-orphan"
    )

    def __repr__(self):
        return f"<PostComment(id={self.id}, title='{self.title}', author={self.author})>"


class Like(Base):
    """点赞表"""
    __tablename__ = 'likes'
    __table_args__ = {'comment': '点赞记录表'}

    point_id = Column(
        BIGINT(unsigned=True),
        primary_key=True,
        nullable=False,
        comment='被点赞的帖子/评论ID'
    )
    user_id = Column(
        INTEGER(unsigned=True),
        primary_key=True,
        nullable=False,
        comment='点赞人ID'
    )
    timestamp = Column(
        TIMESTAMP,
        server_default=func.current_timestamp(),
        nullable=False,
        comment='点赞时间'
    )

    # 关系定义
    post_comment = relationship(
        "PostComment",
        back_populates="likes",
        primaryjoin="foreign(Like.point_id)==PostComment.id"
    )
    user = relationship(
        "User",
        back_populates="likes",
        primaryjoin="foreign(Like.user_id)==User.id"
    )

    def __repr__(self):
        return f"<Like(point_id={self.point_id}, user_id={self.user_id})>"


class Favorite(Base):
    """收藏表"""
    __tablename__ = 'favorites'
    __table_args__ = {'comment': '收藏记录表'}

    point_id = Column(
        BIGINT(unsigned=True),
        primary_key=True,
        nullable=False,
        comment='被收藏的帖子/评论ID'
    )
    user_id = Column(
        INTEGER(unsigned=True),
        primary_key=True,
        nullable=False,
        comment='收藏人ID'
    )
    timestamp = Column(
        TIMESTAMP,
        server_default=func.current_timestamp(),
        nullable=False,
        comment='收藏时间'
    )

    # 关系定义
    post_comment = relationship(
        "PostComment",
        back_populates="favorites",
        primaryjoin="foreign(Favorite.point_id)==PostComment.id"
    )
    user = relationship(
        "User",
        back_populates="favorites",
        primaryjoin="foreign(Favorite.user_id)==User.id"
    )

    def __repr__(self):
        return f"<Favorite(point_id={self.point_id}, user_id={self.user_id})>"


class UserBrowseHistory(Base):
    """用户浏览历史记录表"""
    __tablename__ = 'user_browse_history'
    __table_args__ = {'comment': '用户浏览历史记录表'}

    id = Column(
        INTEGER(unsigned=True),
        primary_key=True,
        nullable=False,
        autoincrement=True,
        comment='历史记录ID'
    )
    user_id = Column(
        INTEGER(unsigned=True),
        nullable=False,
        comment='用户ID'
    )
    post_id = Column(
        BIGINT(unsigned=True),
        nullable=False,
        comment='被浏览的帖子/评论ID'
    )
    timestamp = Column(
        TIMESTAMP,
        server_default=func.current_timestamp(),
        nullable=False,
        comment='浏览时间'
    )

    # 关系定义
    user = relationship(
        "User",
        back_populates="browse_history",
        primaryjoin="foreign(UserBrowseHistory.user_id)==User.id"
    )
    post = relationship(
        "PostComment",
        back_populates="browse_history",
        primaryjoin="foreign(UserBrowseHistory.post_id)==PostComment.id"
    )

    def __repr__(self):
        return f"<UserBrowseHistory(user_id={self.user_id}, post_id={self.post_id})>"


class AIHistory(Base):
    """AI 历史记录表"""
    __tablename__ = 'ai_history'
    __table_args__ = (
        Index('idx_original_prompt_prefix', 'original_prompt', mysql_length=30),
        Index('idx_timestamp', 'timestamp'),
        {'comment': 'AI 历史记录表'}
    )

    id = Column(
        BIGINT(unsigned=True),
        primary_key=True,
        autoincrement=True,
        comment='主键ID'
    )
    timestamp = Column(
        TIMESTAMP,
        server_default=func.current_timestamp(),
        nullable=False,
        comment='记录时间'
    )
    original_prompt = Column(
        Text,
        nullable=False,
        comment='用户的原始输入文本'
    )
    optimized_prompt = Column(
        Text,
        nullable=True,
        comment='经过优化的 Prompt 文本'
    )
    workflow_history = Column(
        JSON,
        nullable=True,
        comment='工作流历史记录（JSON 格式）'
    )
    user_id = Column(
        INTEGER(unsigned=True),
        nullable=False,
        comment='所属用户ID'
    )

    # 关系定义
    user = relationship(
        "User",
        back_populates="ai_history",
        primaryjoin="foreign(AIHistory.user_id)==User.id"
    )

    def __repr__(self):
        return f"<AIHistory(id={self.id}, user_id={self.user_id})>"


class ImageHistory(Base):
    """图片生成历史记录表"""
    __tablename__ = 'image_history'
    __table_args__ = (
        Index('idx_user_id', 'user_id'),
        Index('idx_timestamp', 'timestamp'),
        {'comment': '图片生成历史记录表'}
    )

    id = Column(
        BIGINT(unsigned=True),
        primary_key=True,
        autoincrement=True,
        comment='主键ID'
    )
    timestamp = Column(
        TIMESTAMP,
        server_default=func.current_timestamp(),
        nullable=False,
        comment='记录时间'
    )
    prompt = Column(
        Text,
        nullable=False,
        comment='生成图片的提示词'
    )
    user_id = Column(
        INTEGER(unsigned=True),
        nullable=False,
        comment='所属用户ID'
    )
    url = Column(
        Text,
        nullable=False,
        comment='生成的图片URL'
    )

    # 关系定义
    user = relationship(
        "User",
        back_populates="image_history",
        primaryjoin="foreign(ImageHistory.user_id)==User.id"
    )

    def __repr__(self):
        return f"<ImageHistory(id={self.id}, user_id={self.user_id}, prompt='{self.prompt[:50]}...')>"


class SearchHistory(Base):
    """搜索历史记录表"""
    __tablename__ = 'search_history'
    __table_args__ = (
        Index('idx_user_id', 'user_id'),
        Index('idx_timestamp', 'timestamp'),
        Index('idx_search_type', 'search_type'),
        {'comment': '搜索历史记录表'}
    )

    id = Column(
        INTEGER(unsigned=True),
        primary_key=True,
        nullable=False,
        autoincrement=True,
        comment='搜索历史记录ID'
    )
    user_id = Column(
        INTEGER(unsigned=True),
        nullable=False,
        comment='用户ID'
    )
    search_query = Column(
        Text,
        nullable=False,
        comment='搜索关键词'
    )
    search_type = Column(
        String(20),
        nullable=False,
        comment='搜索类型：title, content, tag'
    )
    timestamp = Column(
        TIMESTAMP,
        server_default=func.current_timestamp(),
        nullable=False,
        comment='搜索时间'
    )

    # 关系定义
    user = relationship(
        "User",
        back_populates="search_history",
        primaryjoin="foreign(SearchHistory.user_id)==User.id"
    )

    def __repr__(self):
        return f"<SearchHistory(id={self.id}, user_id={self.user_id}, query='{self.search_query[:20]}...', type='{self.search_type}')>"
    
class GlobalTagMap(Base):
    """全局标签库表：存储所有唯一标签及其索引"""
    __tablename__ = 'global_tag_map'
    __table_args__ = (
        Index('uq_tag_name', 'tag_name', unique=True),
        {'comment': '推荐系统全局标签库'}
    )

    id = Column(
        INTEGER(unsigned=True),
        primary_key=True,
        autoincrement=True,
        comment='标签的全局唯一索引 (维度ID)'
    )
    tag_name = Column(
        String(100),
        nullable=False,
        unique=True,
        comment='标签名称 (如 Python, AI)'
    )
    created_at = Column(
        TIMESTAMP,
        server_default=func.current_timestamp(),
        nullable=False
    )

    # 关系定义
    item_profiles = relationship(
        "ItemProfile",
        back_populates="tag_map", # 指向 ItemProfile.tag_map
        primaryjoin="GlobalTagMap.id==foreign(ItemProfile.tag_index)"
    )
    user_profiles = relationship(
        "UserProfile",
        back_populates="tag_map", # 指向 UserProfile.tag_map
        primaryjoin="GlobalTagMap.id==foreign(UserProfile.tag_index)"
    )

    def __repr__(self):
        return f"<GlobalTagMap(id={self.id}, tag_name='{self.tag_name}')>"


class ItemProfile(Base):
    """帖子画像表：存储帖子的标签特征稀疏表示"""
    __tablename__ = 'item_profiles'
    __table_args__ = (
        # 联合主键/唯一索引，保证一个帖子的一个标签只有一个值
        Index('pk_item_profile', 'post_id', 'tag_index', unique=True),
        {'comment': '帖子画像 (Item Profile) 稀疏存储'}
    )

    # 使用复合主键，因此不需要单独的自增ID
    post_id = Column(
        BIGINT(unsigned=True),
        primary_key=True,
        comment='帖子的ID'
    )
    tag_index = Column(
        INTEGER(unsigned=True),
        primary_key=True,
        comment='标签的全局索引 (维度)'
    )
    tag_value = Column(
        Integer,
        nullable=False,
        default=1,
        server_default=text('1'),
        comment='标签的权重/值 (基础版为 1)'
    )
    
    # 关系定义
    post = relationship(
        "PostComment",
        back_populates="item_profiles", # 指向 PostComment.item_profiles
        primaryjoin="foreign(ItemProfile.post_id)==PostComment.id"
    )
    tag_map = relationship(
        "GlobalTagMap",
        back_populates="item_profiles", # 指向 GlobalTagMap.item_profiles
        primaryjoin="foreign(ItemProfile.tag_index)==GlobalTagMap.id"
    )

    def __repr__(self):
        return f"<ItemProfile(post_id={self.post_id}, tag_index={self.tag_index}, value={self.tag_value})>"


class UserProfile(Base):
    """用户画像表：存储用户对标签的兴趣稀疏表示"""
    __tablename__ = 'user_profiles'
    __table_args__ = (
        # 联合主键/唯一索引，保证一个用户的一个标签只有一个兴趣分数
        Index('pk_user_profile', 'user_id', 'tag_index', unique=True),
        Index('idx_user_updated', 'user_id', 'last_updated'),
        {'comment': '用户画像 (User Profile) 稀疏存储'}
    )

    # 使用复合主键，因此不需要单独的自增ID
    user_id = Column(
        INTEGER(unsigned=True),
        primary_key=True,
        comment='用户的ID'
    )
    tag_index = Column(
        INTEGER(unsigned=True),
        primary_key=True,
        comment='标签的全局索引 (维度)'
    )
    score = Column(
        String(20),
        nullable=False,
        default=0.0,
        server_default=text('0.0'),
        comment='用户对该标签的总兴趣分数'
    )
    last_updated = Column(
        TIMESTAMP,
        server_default=func.current_timestamp(),
        onupdate=func.current_timestamp(),
        nullable=False,
        comment='兴趣分数最后更新时间'
    )
    
    # 关系定义
    user = relationship(
        "User",
        back_populates="user_profiles", # 指向 User.user_profiles
        primaryjoin="foreign(UserProfile.user_id)==User.id"
    )
    tag_map = relationship(
        "GlobalTagMap",
        back_populates="user_profiles", # 指向 GlobalTagMap.user_profiles
        primaryjoin="foreign(UserProfile.tag_index)==GlobalTagMap.id"
    )

    def __repr__(self):
        return f"<UserProfile(user_id={self.user_id}, tag_index={self.tag_index}, score={self.score})>"
