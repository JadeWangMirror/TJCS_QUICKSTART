# Storage 层 - 收藏数据库操作

from sqlalchemy import create_engine, text
from .DBManager import DBManager, get_db_manager
from typing import List, Dict, Any, Optional
from backend.utils.CCBLog import CCBLog


class FavoriteDB:
    """
    收藏功能的数据库操作类，使用 SQLAlchemy Core 封装连接和基本 CRUD 操作。
    
    职责说明：
    1. 在 favorites 表中管理收藏记录（记录用户的收藏行为）
    2. 在 posts_comments 表中维护 favorite_count 计数器（存储收藏总数）
    3. 提供收藏状态查询接口
    
    数据库表设计：
    - favorites 表：记录"谁收藏了哪个帖子/评论"，联合主键 (point_id, user_id) 防止重复收藏
    - posts_comments 表：存储帖子/评论的详细信息，favorite_count 字段存储该条目的收藏总数
    """

    def __init__(self):
        #db_manager = DBManager()
        self.engine = get_db_manager().get_engine()
        self.log = CCBLog("FavoriteDB")

    def execute_dml(self, sql_query: str, params: Optional[Dict[str, Any]] = None, commit: bool = True):
        """
        执行 DML 操作 (INSERT, UPDATE, DELETE)。
        
        :param sql_query: 原始 SQL 字符串
        :param params: 绑定参数字典
        :param commit: 是否在执行后提交事务
        :return: 执行结果对象 (CursorResult)，包含 rowcount 等信息
        """
        with self.engine.begin() as conn:
            result = conn.execute(text(sql_query), params or {})
            if not commit:
                conn.rollback()
            return result

    def execute_read_query(self, sql_query: str, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        执行查询操作 (SELECT)。
        
        :param sql_query: 原始 SQL 字符串
        :param params: 绑定参数字典
        :return: 查询结果列表（字典格式）
        """
        with self.engine.connect() as conn:
            result = conn.execute(text(sql_query), params or {})
            return [dict(row) for row in result.mappings().all()]

    # ==================== favorites 表操作 ====================

    def insert_favorite(self, user_id: int, post_id: int) -> bool:
        """
        插入一条收藏记录到 favorites 表。
        
        联合主键 (point_id, user_id) 防止同一用户重复收藏同一帖子/评论。
        
        :param user_id: 收藏用户的ID
        :param post_id: 被收藏的帖子/评论ID
        :return: True 表示插入成功，False 表示插入失败（如重复收藏）
        """
        sql_query = """
        INSERT INTO favorites (point_id, user_id, timestamp)
        VALUES (:point_id, :user_id, NOW())
        """
        
        params = {
            "point_id": post_id,
            "user_id": user_id
        }
        
        try:
            result = self.execute_dml(sql_query=sql_query, params=params)
            return result.rowcount > 0
        except Exception as e:
            # 捕获重复键错误
            if "Duplicate entry" in str(e) or "PRIMARY" in str(e):
                self.log.warning(f"用户 {user_id} 已收藏帖子 {post_id}")
                return False
            else:
                self.log.error(f"插入收藏记录失败: {e}")
                raise

    def delete_favorite(self, user_id: int, post_id: int) -> int:
        """
        删除一条收藏记录。
        
        :param user_id: 收藏用户的ID
        :param post_id: 被收藏的帖子/评论ID
        :return: 删除的行数
        """
        sql_query = """
        DELETE FROM favorites
        WHERE point_id = :point_id AND user_id = :user_id
        """
        
        params = {
            "point_id": post_id,
            "user_id": user_id
        }
        
        try:
            result = self.execute_dml(sql_query=sql_query, params=params)
            return result.rowcount
        except Exception as e:
            self.log.error(f"删除收藏记录失败: {e}")
            raise

    def check_user_favorited(self, user_id: int, post_id: int) -> bool:
        """
        检查用户是否已经收藏了某个帖子/评论。
        
        通过查询 favorites 表判断是否存在该用户对该帖子的收藏记录。
        
        :param user_id: 用户ID
        :param post_id: 帖子/评论ID
        :return: True 表示已收藏，False 表示未收藏
        """
        sql_query = """
        SELECT COUNT(*) as count FROM favorites
        WHERE point_id = :point_id AND user_id = :user_id
        """
        
        params = {
            "point_id": post_id,
            "user_id": user_id
        }
        
        try:
            result = self.execute_read_query(sql_query=sql_query, params=params)
            if result and result[0]['count'] > 0:
                return True
            return False
        except Exception as e:
            self.log.error(f"检查收藏状态失败: {e}")
            raise

    # ==================== posts_comments 表的 favorite_count 字段操作 ====================

    def increment_post_favorite_count(self, post_id: int) -> bool:
        """
        增加帖子/评论的收藏计数器。
        
        当用户收藏时，更新 posts_comments 表中该帖子/评论的 favorite_count 字段 +1。
        这是一个原子操作，MySQL 保证线程安全。
        
        :param post_id: 帖子/评论ID
        :return: True 表示操作成功，False 表示帖子不存在
        """
        sql_query = """
        UPDATE posts_comments
        SET favorite_count = favorite_count + 1
        WHERE id = :post_id
        """
        
        params = {
            "post_id": post_id
        }
        
        try:
            result = self.execute_dml(sql_query=sql_query, params=params)
            if result.rowcount > 0:
                self.log.info(f"帖子 {post_id} 收藏数 +1")
                return True
            else:
                self.log.warning(f"帖子 {post_id} 不存在，无法增加收藏数")
                return False
        except Exception as e:
            self.log.error(f"增加收藏计数失败: {e}")
            raise

    def decrement_post_favorite_count(self, post_id: int) -> bool:
        """
        减少帖子/评论的收藏计数器。
        
        当用户取消收藏时，更新 posts_comments 表中该帖子/评论的 favorite_count 字段 -1。
        使用 CASE 语句防止计数小于 0。
        
        :param post_id: 帖子/评论ID
        :return: True 表示操作成功，False 表示帖子不存在
        """
        sql_query = """
        UPDATE posts_comments
        SET favorite_count = CASE 
            WHEN favorite_count > 0 THEN favorite_count - 1 
            ELSE 0 
        END
        WHERE id = :post_id
        """
        
        params = {
            "post_id": post_id
        }
        
        try:
            result = self.execute_dml(sql_query=sql_query, params=params)
            if result.rowcount > 0:
                self.log.info(f"帖子 {post_id} 收藏数 -1")
                return True
            else:
                self.log.warning(f"帖子 {post_id} 不存在，无法减少收藏数")
                return False
        except Exception as e:
            self.log.error(f"减少收藏计数失败: {e}")
            raise

    def get_post_favorite_count(self, post_id: int) -> int:
        """
        获取帖子/评论的收藏总数。
        
        从 posts_comments 表中读取 favorite_count 字段。
        
        :param post_id: 帖子/评论ID
        :return: 收藏总数，如果帖子不存在则返回 0
        """
        sql_query = """
        SELECT favorite_count FROM posts_comments
        WHERE id = :post_id
        """
        
        params = {
            "post_id": post_id
        }
        
        try:
            result = self.execute_read_query(sql_query=sql_query, params=params)
            if result:
                return result[0]['favorite_count'] or 0
            return 0
        except Exception as e:
            self.log.error(f"获取收藏总数失败: {e}")
            raise

    # ==================== 查询操作 ====================

    def get_favorites_for_post(self, post_id: int, limit: int = 10, offset: int = 0) -> List[Dict[str, Any]]:
        """
        获取某个帖子/评论的收藏用户列表（分页）。
        
        从 favorites 表联接 users 表，返回收藏了该帖子的用户信息和收藏时间。
        
        :param post_id: 帖子/评论ID
        :param limit: 返回的最大收藏用户数
        :param offset: 分页偏移量
        :return: 收藏用户列表，包含用户ID、用户名和收藏时间
        """
        sql_query = """
        SELECT 
            f.user_id,
            u.name as user_name,
            f.timestamp as favorited_at
        FROM favorites f
        JOIN users u ON f.user_id = u.id
        WHERE f.point_id = :point_id
        ORDER BY f.timestamp DESC
        LIMIT :limit OFFSET :offset
        """
        
        params = {
            "point_id": post_id,
            "limit": limit,
            "offset": offset
        }
        
        try:
            result = self.execute_read_query(sql_query=sql_query, params=params)
            return result
        except Exception as e:
            self.log.error(f"获取收藏列表失败: {e}")
            raise

    # ==================== 用户收藏的帖子列表 ====================

    def get_user_favorite_posts(self, user_id: int, limit: int = 10, offset: int = 0) -> List[Dict[str, Any]]:
        """获取指定用户收藏的帖子列表（含帖子基础字段）。"""
        sql_query = """
        SELECT 
            p.id,
            p.title,
            p.context,
            p.timestamp,
            p.url_list,
            p.tag,
            p.browse_count,
            p.like_count,
            p.comment_count,
            p.favorite_count,
            u.name AS author,
            u.id AS author_id
        FROM favorites f
        JOIN posts_comments p ON f.point_id = p.id
        JOIN users u ON p.author = u.id
        WHERE f.user_id = :user_id
        ORDER BY f.timestamp DESC
        LIMIT :limit OFFSET :offset
        """
        params = {"user_id": user_id, "limit": limit, "offset": offset}
        try:
            return self.execute_read_query(sql_query, params)
        except Exception as e:
            self.log.error(f"获取用户收藏帖子列表失败: {e}")
            raise

    def count_user_favorite_posts(self, user_id: int) -> int:
        """统计指定用户收藏的帖子总数。"""
        sql_query = """
        SELECT COUNT(*) AS total
        FROM favorites
        WHERE user_id = :user_id
        """
        params = {"user_id": user_id}
        try:
            result = self.execute_read_query(sql_query, params)
            return result[0]["total"] if result else 0
        except Exception as e:
            self.log.error(f"统计用户收藏帖子总数失败: {e}")
            raise

