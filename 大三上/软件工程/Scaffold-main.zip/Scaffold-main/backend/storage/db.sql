--
-- SQL 初始化文件：根据 SQLAlchemy ORM 模型生成
--
-- ⚠️ 重要说明：
-- - 本文件将先删除后创建所有表。
-- - 所有外键约束（FOREIGN KEY）均被移除，只保留字段类型、主键、非空约束和默认值。
-- - 适用于 MySQL 数据库，使用了 INTEGER(unsigned) 和 BIGINT(unsigned) 等 MySQL 特定类型。
--

-- --- 删除表 ---

DROP TABLE IF EXISTS `image_history`;
DROP TABLE IF EXISTS `ai_history`;
DROP TABLE IF EXISTS `user_browse_history`;
DROP TABLE IF EXISTS `favorites`;
DROP TABLE IF EXISTS `likes`;
DROP TABLE IF EXISTS `search_history`;
DROP TABLE IF EXISTS `item_profiles`;
DROP TABLE IF EXISTS `user_profiles`;
-- global_tag_map 必须在 item_profiles 和 user_profiles 之后删除
DROP TABLE IF EXISTS `global_tag_map`;
-- posts_comments 必须在 item_profiles、user_profiles、likes, favorites 和 user_browse_history 之后删除
DROP TABLE IF EXISTS `posts_comments`;
-- users 必须在 posts_comments, likes, favorites, user_browse_history, ai_history, image_history 之后删除
DROP TABLE IF EXISTS `users`;


-- --- 创建表 ---

-- 用户表 (users)
CREATE TABLE `users` (
    `id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '用户ID',
    `name` VARCHAR(100) NOT NULL COMMENT '用户名',
    `email` VARCHAR(100) NOT NULL COMMENT '邮箱（唯一，必填）',
    `password` VARCHAR(255) NOT NULL COMMENT '哈希加密后的密码',
    `level` INTEGER NOT NULL DEFAULT 1 COMMENT '权限等级',
    `introduce` VARCHAR(500) NULL COMMENT '自我介绍',
    `tag` JSON NULL COMMENT '标签及计数 (map{tag:count})',
    `recommend_tag_list` JSON NULL COMMENT '标签及计数 (map{tag:count})',
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `name` (`name`),
    UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户表';


-- 帖子/评论表 (posts_comments)
CREATE TABLE `posts_comments` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
    `title` VARCHAR(255) NULL COMMENT '帖子标题 (仅主贴使用，评论可空)',
    `timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
    `context` TEXT NOT NULL COMMENT '内容',
    `author` INTEGER UNSIGNED NOT NULL COMMENT '作者用户ID', -- 移除 FOREIGN KEY
    `url_list` JSON NULL COMMENT '图片/资源 URL 列表 (JSON 列表)',
    `point_id` BIGINT UNSIGNED NULL COMMENT '指向的父帖子/评论ID (用于评论的递归关系)', -- 移除 FOREIGN KEY
    `browse_count` BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '浏览数',
    `like_count` BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '点赞数',
    `favorite_count` BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '收藏数',
    `comment_count` INTEGER UNSIGNED NOT NULL DEFAULT 0 COMMENT '评论数',
    `tag` JSON NULL COMMENT '标签信息 (JSON 格式)',
    PRIMARY KEY (`id`),
    KEY `idx_point_id` (`point_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='帖子和评论表';


-- 点赞表 (likes)
CREATE TABLE `likes` (
    `point_id` BIGINT UNSIGNED NOT NULL COMMENT '被点赞的帖子/评论ID', -- 移除 FOREIGN KEY
    `user_id` INTEGER UNSIGNED NOT NULL COMMENT '点赞人ID', -- 移除 FOREIGN KEY
    `timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '点赞时间',
    PRIMARY KEY (`point_id`, `user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='点赞记录表';


-- 收藏表 (favorites)
CREATE TABLE `favorites` (
    `point_id` BIGINT UNSIGNED NOT NULL COMMENT '被收藏的帖子/评论ID', -- 移除 FOREIGN KEY
    `user_id` INTEGER UNSIGNED NOT NULL COMMENT '收藏人ID', -- 移除 FOREIGN KEY
    `timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '收藏时间',
    PRIMARY KEY (`point_id`, `user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='收藏记录表';


-- 用户浏览历史记录表 (user_browse_history)
CREATE TABLE `user_browse_history` (
    `id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '历史记录ID',
    `user_id` INTEGER UNSIGNED NOT NULL COMMENT '用户ID', -- 移除 FOREIGN KEY
    `post_id` BIGINT UNSIGNED NOT NULL COMMENT '被浏览的帖子/评论ID', -- 移除 FOREIGN KEY
    `timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '浏览时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户浏览历史记录表';


-- AI 历史记录表 (ai_history)
CREATE TABLE `ai_history` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    `timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '记录时间',
    `original_prompt` TEXT NOT NULL COMMENT '用户的原始输入文本',
    `optimized_prompt` TEXT NULL COMMENT '经过优化的 Prompt 文本',
    `workflow_history` JSON NULL COMMENT '工作流历史记录（JSON 格式）',
    `user_id` INTEGER UNSIGNED NOT NULL COMMENT '所属用户ID', -- 移除 FOREIGN KEY
    PRIMARY KEY (`id`),
    KEY `idx_original_prompt_prefix` (`original_prompt`(30)),
    KEY `idx_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='AI 历史记录表';


-- 图片生成历史记录表 (image_history)
CREATE TABLE `image_history` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    `timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '记录时间',
    `prompt` TEXT NOT NULL COMMENT '生成图片的提示词',
    `user_id` INTEGER UNSIGNED NOT NULL COMMENT '所属用户ID', -- 移除 FOREIGN KEY
    `url` TEXT NOT NULL COMMENT '生成的图片URL',
    PRIMARY KEY (`id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='图片生成历史记录表';


-- 搜索历史记录表 (search_history)
CREATE TABLE `search_history` (
    `id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '搜索历史记录ID',
    `user_id` INTEGER UNSIGNED NOT NULL COMMENT '用户ID', -- 移除 FOREIGN KEY
    `search_query` TEXT NOT NULL COMMENT '搜索关键词',
    `search_type` VARCHAR(20) NOT NULL COMMENT '搜索类型：title, content, tag',
    `timestamp` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '搜索时间',
    PRIMARY KEY (`id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_timestamp` (`timestamp`),
    KEY `idx_search_type` (`search_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='搜索历史记录表';

-- 全局标签库表 (global_tag_map)
CREATE TABLE `global_tag_map` (
    `id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '标签的全局唯一索引 (维度ID)',
    `tag_name` VARCHAR(100) NOT NULL COMMENT '标签名称 (如 Python, AI)',
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_tag_name` (`tag_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='推荐系统全局标签库';


-- 帖子画像表 (item_profiles)
CREATE TABLE `item_profiles` (
    `post_id` BIGINT UNSIGNED NOT NULL COMMENT '帖子的ID', -- 移除 FOREIGN KEY
    `tag_index` INTEGER UNSIGNED NOT NULL COMMENT '标签的全局索引 (维度)', -- 移除 FOREIGN KEY
    `tag_value` INTEGER NOT NULL DEFAULT 1 COMMENT '标签的权重/值 (基础版为 1)',
    PRIMARY KEY (`post_id`, `tag_index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='帖子画像 (Item Profile) 稀疏存储';


-- 用户画像表 (user_profiles)
CREATE TABLE `user_profiles` (
    `user_id` INTEGER UNSIGNED NOT NULL COMMENT '用户的ID', -- 移除 FOREIGN KEY
    `tag_index` INTEGER UNSIGNED NOT NULL COMMENT '标签的全局索引 (维度)', -- 移除 FOREIGN KEY
    `score` VARCHAR(20) NOT NULL DEFAULT '0.0' COMMENT '用户对该标签的总兴趣分数', -- 存储FLOAT分数
    `last_updated` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '兴趣分数最后更新时间',
    PRIMARY KEY (`user_id`, `tag_index`),
    KEY `idx_user_updated` (`user_id`, `last_updated`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户画像 (User Profile) 稀疏存储';
