"""
数据库初始化脚本
用于创建所有表结构和初始数据

使用方式：
    python -m backend.storage.init_db          # 创建表结构
    python -m backend.storage.init_db --drop   # 删除并重建所有表

⚠️ 重要说明：
- backend/storage/models.py 是数据库表结构的权威定义
- 本脚本使用 SQLAlchemy ORM 自动创建表结构
- 如需修改表结构，请修改 models.py 并重新运行本脚本
"""
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

from backend.config import ConfigReader
from backend.storage.models import Base, User, PostComment, Like, UserBrowseHistory, AIHistory, ImageHistory, SearchHistory
from backend.utils.CCBLog import CCBLog


class DatabaseInitializer:
    """数据库初始化类"""
    
    def __init__(self):
        """初始化数据库连接"""
        self.log = CCBLog("DatabaseInitializer")
        
        # 读取数据库配置
        config = ConfigReader("backend/config/db.json").read_config().get('mysql')
        user = config.get('user')
        password = config.get('password')
        database = config.get('database')
        host = config.get('host')
        port = config.get('port')
        
        # 构建数据库连接 URL
        self.DATABASE_URL = (
            f"mysql+pymysql://{user}:{password}@{host}:{port}/{database}"
        )
        
        try:
            # 创建引擎
            self.engine = create_engine(
                self.DATABASE_URL,
                echo=True,  # 打印SQL语句
                pool_pre_ping=True
            )
            
            # 创建会话工厂
            self.SessionLocal = sessionmaker(
                autocommit=False,
                autoflush=False,
                bind=self.engine
            )
            
            self.log.info("数据库连接初始化成功")
        except Exception as e:
            self.log.error(f"数据库连接初始化失败: {e}")
            raise
    
    def drop_all_tables(self):
        """
        删除所有表（按照正确的顺序，避免外键约束问题）
        """
        self.log.info("开始删除所有表...")
        
        try:
            with self.engine.connect() as conn:
                # 按照依赖关系的逆序删除表
                drop_statements = [
                    "DROP TABLE IF EXISTS likes;",
                    "DROP TABLE IF EXISTS user_browse_history;",
                    "DROP TABLE IF EXISTS ai_history;",
                    "DROP TABLE IF EXISTS image_history;",
                    "DROP TABLE IF EXISTS search_history;",
                    "DROP TABLE IF EXISTS item_profiles;",
                    "DROP TABLE IF EXISTS user_profiles;",
                    "DROP TABLE IF EXISTS global_tag_map;",
                    "DROP TABLE IF EXISTS posts_comments;",
                    "DROP TABLE IF EXISTS users;"
                ]
                
                for statement in drop_statements:
                    conn.execute(text(statement))
                    self.log.info(f"执行: {statement}")
                
                conn.commit()
                self.log.info("所有表删除成功")
        except Exception as e:
            self.log.error(f"删除表失败: {e}")
            raise
    
    def create_all_tables(self):
        """
        使用 SQLAlchemy ORM 创建所有表
        """
        self.log.info("开始创建所有表...")
        
        try:
            # 使用 Base.metadata.create_all() 创建所有表
            Base.metadata.create_all(bind=self.engine)
            self.log.info("所有表创建成功")
        except Exception as e:
            self.log.error(f"创建表失败: {e}")
            raise
    
    def init_database(self, drop_existing=False):
        """
        初始化数据库
        
        Args:
            drop_existing: 是否删除已存在的表（默认False）
        """
        try:
            if drop_existing:
                self.log.warning("将删除所有现有表！")
                self.drop_all_tables()
            
            self.create_all_tables()
            self.log.info("数据库初始化完成")
            
        except Exception as e:
            self.log.error(f"数据库初始化失败: {e}")
            raise
    
    def get_session(self):
        """
        获取数据库会话
        
        Returns:
            Session: SQLAlchemy 会话对象
        """
        return self.SessionLocal()


def main():
    """
    主函数：用于命令行执行数据库初始化
    """
    import sys
    
    initializer = DatabaseInitializer()
    
    # 检查命令行参数
    drop_existing = '--drop' in sys.argv or '-d' in sys.argv
    
    if drop_existing:
        confirm = input("⚠️  警告：将删除所有现有表！是否继续？(yes/no): ")
        if confirm.lower() != 'yes':
            CCBLog('init_db').warning("操作已取消")
            return
    
    # 执行初始化
    initializer.init_database(drop_existing=drop_existing)
    CCBLog('init_db').info("\n✅ 数据库初始化成功！")


if __name__ == '__main__':
    main()

