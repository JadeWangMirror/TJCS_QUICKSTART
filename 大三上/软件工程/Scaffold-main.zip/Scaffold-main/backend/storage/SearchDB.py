from sqlalchemy import create_engine, text
from .DBManager import DBManager, get_db_manager
from typing import List, Dict, Any, Optional, Tuple
import json

from backend.config import ConfigReader
from backend.utils.CCBLog import CCBLog

class SearchDB:
    """
    搜索相关的数据库类，使用 SQLAlchemy Core 封装连接和基本 CRUD 操作。
    """

    def __init__(self):
        #dbmanager = DBManager()
        self.engine = get_db_manager().get_engine()

    def execute_dml(self, sql_query: str, params: Optional[Dict[str, Any]] = None, commit: bool = True):
        """
        执行 DML 操作 (INSERT, UPDATE, DELETE)。
        :param sql_query: 原始 SQL 字符串。
        :param params: 绑定参数字典。
        :param commit: 是否在执行后提交事务。
        :return: 执行结果对象 (CursorResult)，其中包含 rowcount, lastrowid 等信息。
        """
        with self.engine.begin() as conn:
            result = conn.execute(text(sql_query), params)
            if not commit:
                conn.rollback()
            return result

    def execute_read_query(self, sql_query: str, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        执行查询操作 (SELECT)。
        :param sql_query: 原始 SQL 字符串。
        :param params: 绑定参数字典。
        :return: 查询结果列表 (DictCursor 类似地返回字典列表)
        """
        with self.engine.connect() as conn:
            result = conn.execute(text(sql_query), params)
            return [dict(row) for row in result.mappings().all()]

    def search_posts(self, search_query: str, search_type: str, limit: int = 10, offset: int = 0) -> Tuple[List[Dict[str, Any]], int]:
        """
        根据搜索关键词和搜索类型搜索帖子。

        :param search_query: 搜索关键词
        :param search_type: 搜索类型 ('title', 'content', 'tag')
        :param limit: 限制返回的帖子数量
        :param offset: 偏移量
        :return: 搜索结果列表
        """
        if search_type not in ['title', 'content', 'tag']:
            raise ValueError("search_type must be one of: 'title', 'content', 'tag'")

        base_condition = "WHERE p.point_id IS NULL"
        params = {"limit": limit, "offset": offset}
        count_params = {}

        if search_type == 'title':
            base_condition += " AND p.title LIKE :search_pattern"
            params["search_pattern"] = f"%{search_query}%"
            count_params["search_pattern"] = params["search_pattern"]
        elif search_type == 'content':
            base_condition += " AND p.context LIKE :search_pattern"
            params["search_pattern"] = f"%{search_query}%"
            count_params["search_pattern"] = params["search_pattern"]
        elif search_type == 'tag':
            base_condition += " AND JSON_CONTAINS(p.tag, :tag_pattern)"
            params["tag_pattern"] = json.dumps([search_query])
            count_params["tag_pattern"] = params["tag_pattern"]

        query_sql = f"""
        SELECT
            p.id,
            p.title,
            p.context,
            p.timestamp,
            p.url_list,
            p.tag,
            p.browse_count,
            p.like_count,
            p.comment_count,
            u.name AS author_name
        FROM posts_comments p
        JOIN users u ON p.author = u.id
        {base_condition}
        ORDER BY p.timestamp DESC
        LIMIT :limit OFFSET :offset
        """

        count_sql = f"""
        SELECT COUNT(*) AS total
        FROM posts_comments p
        {base_condition}
        """

        # 执行查询
        raw_posts = self.execute_read_query(query_sql, params)
        count_result = self.execute_read_query(count_sql, count_params)
        total_count = count_result[0]["total"] if count_result else 0

        processed_posts = []

        # 处理结果
        for post in raw_posts:
            # 解析 url_list (JSON)
            cover_image_url = None
            try:
                url_list = json.loads(post.get('url_list') or '[]')
                if url_list and isinstance(url_list, list):
                    cover_image_url = url_list[0]
            except (json.JSONDecodeError, TypeError):
                url_list = []

            # 解析 tags (JSON)
            tags_list = []
            try:
                tags_list = json.loads(post.get('tag') or '[]')
                if not isinstance(tags_list, list):
                    tags_list = []
            except (json.JSONDecodeError, TypeError):
                tags_list = []

            # 构造最终返回的结构
            processed_posts.append({
                'id': post['id'],
                'title': post['title'],
                'context': post['context'],
                'author': post['author_name'],
                'timestamp': post['timestamp'],
                'cover_image': cover_image_url,
                'tags': tags_list,
                'browse_count': post['browse_count'],
                'like_count': post['like_count'],
                'comment_count': post['comment_count'],
            })

        return processed_posts, total_count

    def record_search_history(self, user_id: int, search_query: str, search_type: str) -> bool:
        """
        记录用户搜索历史。

        :param user_id: 用户ID
        :param search_query: 搜索关键词
        :param search_type: 搜索类型
        :return: 操作是否成功
        """
        sql_query = """
        INSERT INTO search_history (user_id, search_query, search_type)
        VALUES (:user_id, :search_query, :search_type)
        """
        params = {
            "user_id": user_id,
            "search_query": search_query,
            "search_type": search_type
        }

        result = self.execute_dml(sql_query, params)
        return result.rowcount > 0

    def get_search_history(self, user_id: int, limit: int = 10, offset: int = 0) -> List[Dict[str, Any]]:
        """
        获取用户搜索历史记录。

        :param user_id: 用户ID
        :param limit: 限制返回的记录数
        :param offset: 偏移量
        :return: 搜索历史记录列表
        """
        sql_query = """
        SELECT id, search_query, search_type, timestamp
        FROM search_history
        WHERE user_id = :user_id
        ORDER BY timestamp DESC
        LIMIT :limit OFFSET :offset
        """
        params = {"user_id": user_id, "limit": limit, "offset": offset}

        result = self.execute_read_query(sql_query, params)
        return result

    def get_search_history_count(self, user_id: int) -> int:
        """
        获取用户搜索历史记录总数。

        :param user_id: 用户ID
        :return: 记录数
        """
        sql_query = """
        SELECT COUNT(*) as count
        FROM search_history
        WHERE user_id = :user_id
        """
        params = {"user_id": user_id}

        result = self.execute_read_query(sql_query, params)
        if result:
            return result[0]['count']
        return 0

    def delete_search_history_record(self, user_id: int, record_id: int) -> bool:
        """
        删除用户的某条搜索历史记录。

        :param user_id: 用户ID
        :param record_id: 搜索历史记录ID
        :return: 操作是否成功
        """
        sql_query = """
        DELETE FROM search_history
        WHERE user_id = :user_id AND id = :record_id
        """
        params = {"user_id": user_id, "record_id": record_id}

        result = self.execute_dml(sql_query, params)
        return result.rowcount > 0

    def clear_search_history(self, user_id: int) -> int:
        """
        清空用户的所有搜索历史记录。

        :param user_id: 用户ID
        :return: 删除的记录数量
        """
        sql_query = """
        DELETE FROM search_history
        WHERE user_id = :user_id
        """
        params = {"user_id": user_id}

        result = self.execute_dml(sql_query, params)
        return result.rowcount