from sqlalchemy import create_engine, text, Engine
from sqlalchemy.engine import Connection
from sqlalchemy.orm import sessionmaker, Session
from contextlib import contextmanager
from typing import Generator

from backend.config import ConfigReader
from backend.utils.CCBLog import CCBLog


class DBManager:
    """
    数据库管理类，使用 SQLAlchemy Core 和 ORM 封装连接和基本 CRUD 操作。
    支持两种方式：
    1. Core API: 直接执行 SQL 语句（适用于复杂查询）
    2. ORM API: 使用模型对象进行操作（适用于标准 CRUD）
    """

    ORDER_MAP = {
        'time': 'p.timestamp DESC',
        'browse': 'p.browse_count DESC',
        'like': 'p.like_count DESC',
        'comment': 'p.comment_count DESC'
    }

    def __init__(self):
        # 1. 构建数据库连接 URL
        config = ConfigReader("backend/config/db.json").read_config().get('mysql')
        user = config.get('user')
        password = config.get('password')
        database = config.get('database')
        host = config.get('host')
        port = config.get('port')
        self.log = CCBLog("DBManager")

        # 格式: 'mysql+pymysql://user:password@host:port/database'
        self.DATABASE_URL = (
            f"mysql+pymysql://{user}:{password}@{host}:{port}/{database}"
        )

        # Engine 是与数据库通信的中心，它负责连接池和方言处理。
        try:
            self.engine = create_engine(
                self.DATABASE_URL, 
                echo=False, # 设为 True 会打印所有执行的 SQL 语句
                pool_pre_ping=True  # 确保连接在被使用前是活动的
            )
            # 尝试连接一次，以验证配置是否正确
            with self.engine.connect():
                self.log.info("SQLAlchemy Engine 初始化成功。")
            
            # 创建 Session 工厂（用于 ORM 操作）
            self.SessionLocal = sessionmaker(
                autocommit=False,
                autoflush=False,
                bind=self.engine
            )
            self.log.info("SQLAlchemy ORM Session 工厂创建成功。")
            
        except Exception as e:
            self.log.error(f"【错误】SQLAlchemy 引擎创建或连接验证失败: {e}")
            raise

    # SQLAlchemy Core 直接管理连接池，不需要 _get_connection 或 close 方法
    # 我们使用 with self.engine.connect() as conn: 来获取连接

    def get_engine(self) -> Engine:
        """
        获取数据库引擎（用于 Core API）。
        :return: 数据库引擎对象 engine。
        """
        return self.engine
    
    def get_session(self) -> Session:
        """
        获取一个新的 ORM 会话对象。
        注意：使用完毕后需要手动关闭会话。
        
        推荐使用 get_db_session() 上下文管理器。
        
        :return: SQLAlchemy Session 对象
        """
        return self.SessionLocal()
    
    @contextmanager
    def get_db_session(self) -> Generator[Session, None, None]:
        """
        上下文管理器：获取数据库会话，自动处理提交和回滚。
        
        使用示例：
            with db_manager.get_db_session() as session:
                user = session.query(User).filter_by(id=1).first()
                # 操作完成后自动提交
        
        :yield: SQLAlchemy Session 对象
        """
        session = self.SessionLocal()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            self.log.error(f"数据库会话操作失败，已回滚: {e}")
            raise
        finally:
            session.close()

db_manager: DBManager = None

def init_db_manager() -> DBManager:
    global db_manager
    if db_manager is None:
        db_manager = DBManager()
    return db_manager

def get_db_manager() -> DBManager:
    """
    获取数据库管理器实例。
    :return: 数据库管理器实例。
    """
    if db_manager is None:
        init_db_manager()
    return db_manager