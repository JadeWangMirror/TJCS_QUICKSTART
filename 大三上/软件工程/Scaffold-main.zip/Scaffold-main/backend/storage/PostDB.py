from sqlalchemy import create_engine, text
from sqlalchemy.exc import IntegrityError
from .DBManager import DBManager, get_db_manager
from typing import List, Dict, Any, Optional, Tuple
import json
from datetime import datetime, timedelta

from backend.config import ConfigReader
from backend.utils.CCBLog import CCBLog

class PostDB:
    """
    帖子的数据库类，使用 SQLAlchemy Core 封装连接和基本 CRUD 操作。
    它使用 Engine 和 Connection Pool 管理数据库连接。
    """

    ORDER_MAP = {
        'time': 'p.timestamp DESC',
        'hot': 'score DESC',
        'browse': 'p.browse_count DESC',
        'like': 'p.like_count DESC',
        'comment': 'p.comment_count DESC'
    }

    def __init__(self):
        # dbmanager = DBManager()
        self.engine = get_db_manager().get_engine()

    # SQLAlchemy Core 直接管理连接池，不需要 _get_connection 或 close 方法
    # 我们使用 with self.engine.connect() as conn: 来获取连接

    def execute_dml(self, sql_query: str, params: Optional[Dict[str, Any]] = None, commit: bool = True):
        """
        执行 DML 操作 (INSERT, UPDATE, DELETE)。
        :param sql_query: 原始 SQL 字符串。
        :param params: 绑定参数字典。
        :param commit: 是否在执行后提交事务。
        :return: 执行结果对象 (CursorResult)，其中包含 rowcount, lastrowid 等信息。
        """
        # 使用 begin() 块来管理事务
        with self.engine.begin() as conn:
            # text() 函数将字符串转换为 SQLAlchemy 可识别的 SQL 表达式
            result = conn.execute(text(sql_query), params)

            # 如果 commit=True，begin() 块结束时会自动提交 (这是 with self.engine.begin() 的特性)
            # 如果 commit=False，则需要手动回滚或使用原始连接
            if not commit:
                conn.rollback()
                # 注意: 这里使用 begin() 会自动提交，如果需要手动控制，
                # 应该使用 conn = self.engine.connect() 并在 try/except 块中手动 conn.commit()/conn.rollback()。

            return result

    def execute_read_query(self, sql_query: str, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        执行查询操作 (SELECT)。
        :param sql_query: 原始 SQL 字符串。
        :param params: 绑定参数字典。
        :return: 查询结果列表 (DictCursor 类似地返回字典列表)
        """
        # 使用 connect() 块来获取连接，查询操作不需要 begin()
        with self.engine.connect() as conn:
            result = conn.execute(text(sql_query), params)

            # 使用 result.mappings().all() 可以返回一个类似于字典的映射列表
            return [dict(row) for row in result.mappings().all()]

    def _get_root_post_id(self, initial_id: int) -> Optional[int]:
        """
        【辅助方法】向上递归查询，找到评论链中最顶层的主帖ID (point_id IS NULL)。
        
        :param initial_id: 当前评论所回复的帖子或评论ID。
        :return: 最顶层主帖的ID，如果找不到则返回 None。
        """
        # 使用 Recursive CTE 实现向上追溯
        sql_query = """
        WITH RECURSIVE Ancestors AS (
            -- 锚点成员 (Anchor member): 从直接父级开始
            SELECT id, point_id
            FROM posts_comments
            WHERE id = :initial_id
            
            UNION ALL
            
            -- 递归成员 (Recursive member): 找到当前祖先的父级
            SELECT pc.id, pc.point_id
            FROM posts_comments pc
            JOIN Ancestors a ON pc.id = a.point_id
            -- 停止条件隐含在 JOIN 语句中，当 pc.id 找不到匹配时递归结束
            -- 显式 WHERE pc.point_id IS NOT NULL 可以优化
        )
        -- 最终结果：从所有祖先中选择 point_id IS NULL 的那个（即主贴）
        SELECT id
        FROM Ancestors
        WHERE point_id IS NULL
        LIMIT 1;
        """
        params = {"initial_id": initial_id}
        
        # 假设 execute_read_query 返回一个包含字典的列表
        # 示例: [{'id': 100}]
        raw_result = self.execute_read_query(sql_query, params)
        
        if raw_result and 'id' in raw_result[0]:
            return raw_result[0]['id']
        return None
    
    def insert_post(self, timestamp, title: str, context: str, author_id: int, tags: List[str], url_list: List[str]) -> int:
        """
        插入新的帖子数据到 posts_comments 表。

        :param title: 帖子标题。
        :param context: 帖子内容。
        :param author_id: 作者用户ID (author)。
        :param tags: 标签列表。
        :param url_list: 图片 URL 列表（可选）。
        :return: 插入的帖子 ID (posts_comments.id)。
        """
        db_url_list_json = json.dumps(url_list) if url_list else '[]'
        db_tags_json = json.dumps(tags) if tags else '[]'

        sql_query = """
        INSERT INTO posts_comments 
            (timestamp, title, context, author, url_list, tag, point_id)
        VALUES 
            (:timestamp, :title, :context, :author, :url_list, :tag, :point_id)
        """

        params = {
            "timestamp": timestamp,
            "title": title,
            "context": context,
            "author": author_id,
            "url_list": db_url_list_json,  # JSON 字符串
            "tag": db_tags_json,  # JSON 字符串
            "point_id": None  # 主贴 point_id 默认为 NULL
        }

        result = self.execute_dml(sql_query=sql_query, params=params)
        post_id = result.lastrowid

        return post_id

    def get_url_list_by_post_id(self, post_id: int) -> List[str]:
        """
        根据帖子id获取该帖子的url_list

        :param post_id: 要获取url_list的帖子ID
        :return: 该帖子的url_list
        """
        sql_query = """
        SELECT url_list
        FROM posts_comments
        WHERE id = :post_id
        """

        params = {
            "post_id": post_id
        }

        # 1. 执行查询，result 是一个列表 (e.g., [{'url_list': ['url1', 'url2']}])
        result = self.execute_read_query(sql_query, params)
        if not result:
            return {}  # 如果用户不存在，返回空字典

        url_json_str = result[0].get('url_list')

        url_list = []
        if url_json_str:
            try:
                parsed_data = json.loads(url_json_str)
                if isinstance(parsed_data, list):
                    url_list = parsed_data

            except json.JSONDecodeError:
                url_list = []

        return url_list

    def update_post(self, post_id: int, title: str, context: str, author_id: int, tags: List[str], url_list: List[str]) -> int:
        """
        编辑现有帖子数据到 posts_comments 表。

        此操作必须确保 point_id 为 NULL (即只允许编辑主贴)，并且 author 匹配。

        :param post_id: 要编辑的帖子ID。
        :param title: 新的帖子标题。
        :param context: 新的帖子内容。
        :param author_id: 作者用户ID (author)，用于权限检查。
        :param tags: 新的标签列表。
        :param url_list: 新的图片 URL 列表（可选）。
        :return: 受影响的行数(0/1，用于判断是否成功)。
        """
        db_url_list_json = json.dumps(url_list) if url_list else '[]'
        db_tags_json = json.dumps(tags) if tags else '[]'

        sql_query = """
        UPDATE posts_comments 
        SET 
            title = :title, 
            context = :context, 
            url_list = :url_list,
            tag = :tag
        WHERE 
            id = :post_id 
            AND author = :author_id 
            AND point_id IS NULL; -- 确保只修改主贴，防止修改评论
        """

        params = {
            "post_id": post_id,
            "author_id": author_id,
            "title": title,
            "context": context,
            "url_list": db_url_list_json,  # JSON 字符串
            "tag": db_tags_json,          # JSON 字符串
        }

        result = self.execute_dml(sql_query=sql_query, params=params)

        return result.rowcount
    
    def delete_post_comment(self, user_id, id):
        """
        :return: root_post_id, delete_count
        """
        params = {
            "user_id": user_id,
            "id": id
        }

        cte_query = """
            WITH RECURSIVE CommentHierarchy AS (
                -- 锚定成员 (Anchor Member): 父评论本身
                SELECT id
                FROM posts_comments
                WHERE id = :id AND author = :user_id
                
                UNION ALL
                
                -- 递归成员 (Recursive Member): 查找子评论
                SELECT c.id
                FROM posts_comments c
                JOIN CommentHierarchy ch ON c.point_id = ch.id
            )
            SELECT count(id) AS total_count FROM CommentHierarchy;
        """

        delete_count = self.execute_read_query(cte_query, params)[0].get('total_count', 0)

        if delete_count > 0:
            root_post_id = self._get_root_post_id(id)
            sql_query = """
            DELETE FROM posts_comments
            WHERE author = :user_id
            AND id = :id
            """

            self.execute_dml(sql_query, params)
            if root_post_id != id:
                update_sql = """
                UPDATE posts_comments
                SET comment_count = comment_count - :delete_count
                WHERE id = :root_post_id;
                """
                update_params = {
                    "root_post_id": root_post_id,
                    "delete_count": delete_count
                }
                
                # 使用 DML 方法执行更新
                self.execute_dml(sql_query=update_sql, params=update_params)
        
            return root_post_id, delete_count
        else:
            return 0, 0

    def get_posts_by_args_ordered_by_arg(self, tags: List[str] = None, author_name: str = '', context_snippet: str = '',
                                         time_limit_seconds: Optional[int] = None, order: str = 'time', limit: int = 10,
                                         offset: int = 0) -> List[Dict[str, Any]]:
        """
        Retrieves a list of main posts (point_id IS NULL), filtered by various arguments (optional) and
        ordered by the specified argument.

        获取按某个标准排序的帖子列表，仅查询主贴，支持多项筛选。

        :param tags: 标签名列表，用于筛选 (可选，帖子必须包含所有标签)。
        :param author_name: 作者名，用于模糊匹配 (可选)。
        :param context_snippet: 内容片段，用于模糊匹配 (可选)。
        :param time_limit_seconds: 距离当前时间的秒数限制 (可选)。
        :param order: 排序标准 ('time', 'browse', 'like', 'comment')。
        :param limit: 限制获取的帖子数量。
        :param offset: 偏移量。
        :return: A list of processed post dictionaries.
        """

        # 1. 验证排序参数
        order_clause = self.ORDER_MAP.get(order, self.ORDER_MAP['time'])

        # 2. 构建基础 SQL 查询和参数字典
        sql_query = """
        SELECT
            p.id,
            p.title,
            p.author,
            p.context,
            p.timestamp,
            p.url_list,
            p.tag,
            p.browse_count,
            p.like_count,
            p.comment_count,
            u.name AS author_name,
            COUNT(*) OVER() AS total_count,
            p.browse_count + p.like_count * 3 + p.comment_count * 5 AS score
        FROM posts_comments p
        JOIN users u ON p.author = u.id
        WHERE p.point_id IS NULL 
        """

        params = {"limit": limit, "offset": offset}

        # 3. 添加标签筛选条件 (多标签 AND 逻辑)
        tags = tags if tags is not None else []
        tag_conditions = []
        for i, tag_item in enumerate(tags):
            # 为每个标签创建唯一的参数名
            param_key = f"tag_candidate_{i}"
            tag_conditions.append(f"JSON_CONTAINS(p.tag, :{param_key})")
            # 必须将标签名转换为 JSON 字符串格式用于 JSON_CONTAINS
            params[param_key] = json.dumps([tag_item])

        if tag_conditions:
            sql_query += " AND " + " AND ".join(tag_conditions)

        # 4. 添加作者名筛选条件 (模糊匹配)
        if author_name:
            sql_query += " AND u.name LIKE :author_name_pattern"
            params["author_name_pattern"] = f"%{author_name}%"

        # 5. 添加内容片段筛选条件 (模糊匹配)
        if context_snippet:
            sql_query += " AND p.context LIKE :context_pattern"
            params["context_pattern"] = f"%{context_snippet}%"

        # 6. 添加发布时间限制条件 (MySQL DATE_SUB 逻辑)
        if time_limit_seconds is not None and time_limit_seconds > 0:
            # 假设 MySQL 支持 DATE_SUB(NOW(), INTERVAL X SECOND)
            sql_query += " AND p.timestamp >= DATE_SUB(NOW(), INTERVAL :time_limit_seconds SECOND)"
            params["time_limit_seconds"] = time_limit_seconds

        # 7. 添加排序和分页
        sql_query += f' ORDER BY {order_clause} LIMIT :limit OFFSET :offset;'

        # 8. 执行原始查询
        raw_posts = self.execute_read_query(sql_query, params)

        total_count = raw_posts[0]['total_count']

        processed_posts = []

        # 9. 对结果进行 Python 层面的处理 (JSON 解析和封面图提取)
        for post in raw_posts:
            # 解析 url_list (JSON)
            cover_image_url = None
            try:
                url_list = json.loads(post.get('url_list') or '[]')
                if url_list and isinstance(url_list, list):
                    cover_image_url = url_list[0]
            except (json.JSONDecodeError, TypeError):
                url_list = []

            # 解析 tags (JSON)
            tags_list = []
            try:
                tags_list = json.loads(post.get('tag') or '[]')
                if not isinstance(tags_list, list):
                    tags_list = []
            except (json.JSONDecodeError, TypeError):
                tags_list = []

            # 10. 构造最终返回的结构
            processed_posts.append({
                'id': post['id'],
                'title': post['title'],
                'context': post['context'],
                'author_id': post['author'],
                'author': post['author_name'],
                'timestamp': post['timestamp'],
                'cover_image': cover_image_url,
                'tags': tags_list,
                'browse_count': post['browse_count'],
                'like_count': post['like_count'],
                'comment_count': post['comment_count'],
            })

        return processed_posts, total_count
    
    def get_posts_by_ids(self, post_ids: List[int]):
        """
        根据帖子 ID 列表批量获取主帖详细信息。
        只返回主帖 (point_id IS NULL)。

        :param post_ids: 帖子 ID 列表。
        :return: 帖子详情字典列表和列表长度
        """
        if not post_ids:
            return [], 0
        
        post_id_str = ', '.join(map(str, post_ids))

        sql_query = f"""
        SELECT
            p.id,
            p.title,
            p.author,
            p.context,
            p.timestamp,
            p.url_list,
            p.tag,
            p.browse_count,
            p.like_count,
            p.comment_count,
            u.name AS author_name,
            COUNT(*) OVER() AS total_count
        FROM posts_comments p
        JOIN users u ON p.author = u.id
        WHERE p.point_id IS NULL
        AND p.id IN ({post_id_str})
        ORDER BY FIELD(p.id, {post_id_str})
        """

        params = []

        raw_posts = self.execute_read_query(sql_query, params)

        total_count = raw_posts[0].get('total_count')

        processed_posts = []

        # 对结果进行 Python 层面的处理 (JSON 解析和封面图提取)
        for post in raw_posts:
            # 解析 url_list (JSON)
            cover_image_url = None
            try:
                url_list = json.loads(post.get('url_list') or '[]')
                if url_list and isinstance(url_list, list):
                    cover_image_url = url_list[0]
            except (json.JSONDecodeError, TypeError):
                url_list = []

            # 解析 tags (JSON)
            tags_list = []
            try:
                tags_list = json.loads(post.get('tag') or '[]')
                if not isinstance(tags_list, list):
                    tags_list = []
            except (json.JSONDecodeError, TypeError):
                tags_list = []

            processed_posts.append({
                'id': post['id'],
                'title': post['title'],
                'context': post['context'],
                'author_id': post['author'],
                'author': post['author_name'],
                'timestamp': post['timestamp'],
                'cover_image': cover_image_url,
                'tags': tags_list,
                'browse_count': post['browse_count'],
                'like_count': post['like_count'],
                'comment_count': post['comment_count'],
            })

        return processed_posts, total_count

    def get_post_ids_by_args_ordered_by_arg(self, tags: List[str] = None, author_name: str = '', context_snippet: str = '',
                                         time_limit_seconds: Optional[int] = None, order: str = 'time', limit: int = 10,
                                         offset: int = 0) -> List[Tuple[int, float]]:
        """
        Retrieves a list of main post_ids (point_id IS NULL), filtered by various arguments (optional) and
        ordered by the specified argument.

        获取按某个标准排序的帖子id列表，仅查询主贴，支持多项筛选。

        :param tags: 标签名列表，用于筛选 (可选，帖子必须包含所有标签)。
        :param author_name: 作者名，用于模糊匹配 (可选)。
        :param context_snippet: 内容片段，用于模糊匹配 (可选)。
        :param time_limit_seconds: 距离当前时间的秒数限制 (可选)。
        :param order: 排序标准 ('time', 'browse', 'like', 'comment')。
        :param limit: 限制获取的帖子数量。
        :param offset: 偏移量。
        :return: A list of post ids.
        """

        # 1. 验证排序参数
        order_clause = self.ORDER_MAP.get(order, self.ORDER_MAP['time'])

        # 2. 构建基础 SQL 查询和参数字典
        sql_query = """
        SELECT
            p.id,
            p.timestamp,
            p.browse_count + p.like_count * 3 + p.comment_count * 5 AS score
        FROM posts_comments p
        JOIN users u ON p.author = u.id
        WHERE p.point_id IS NULL 
        """

        params = {"limit": limit, "offset": offset}

        # 3. 添加标签筛选条件 (多标签 AND 逻辑)
        tags = tags if tags is not None else []
        tag_conditions = []
        for i, tag_item in enumerate(tags):
            # 为每个标签创建唯一的参数名
            param_key = f"tag_candidate_{i}"
            tag_conditions.append(f"JSON_CONTAINS(p.tag, :{param_key})")
            # 必须将标签名转换为 JSON 字符串格式用于 JSON_CONTAINS
            params[param_key] = json.dumps([tag_item])

        if tag_conditions:
            sql_query += " AND " + " AND ".join(tag_conditions)

        # 4. 添加作者名筛选条件 (模糊匹配)
        if author_name:
            sql_query += " AND u.name LIKE :author_name_pattern"
            params["author_name_pattern"] = f"%{author_name}%"

        # 5. 添加内容片段筛选条件 (模糊匹配)
        if context_snippet:
            sql_query += " AND p.context LIKE :context_pattern"
            params["context_pattern"] = f"%{context_snippet}%"

        # 6. 添加发布时间限制条件 (MySQL DATE_SUB 逻辑)
        if time_limit_seconds is not None and time_limit_seconds > 0:
            # 假设 MySQL 支持 DATE_SUB(NOW(), INTERVAL X SECOND)
            sql_query += " AND p.timestamp >= DATE_SUB(NOW(), INTERVAL :time_limit_seconds SECOND)"
            params["time_limit_seconds"] = time_limit_seconds

        # 7. 添加排序和分页
        sql_query += f' ORDER BY {order_clause} LIMIT :limit OFFSET :offset;'

        # 8. 执行原始查询
        raw_post_ids = self.execute_read_query(sql_query, params)

        post_ids = []

        # 9. 对结果进行 Python 层面的处理 (JSON 解析和封面图提取)
        for post_id in raw_post_ids:
            if order == 'time':
                post_ids.append((post_id['id'], post_id['timestamp'].timestamp() * 1000))
            else:
                post_ids.append((post_id['id'], float(post_id['score'])))

        return post_ids

    def get_tags_by_user_id(self, user_id: int) -> Dict[str, int]:
        """
        根据用户ID获取该用户的推荐标签及计数信息。

        :param user_id: 作者用户ID。
        :return: 推荐标签及计数信息，格式为 {'tagA': count, 'tagB': count}，若无则返回空字典。
        """
        params = {"user_id": user_id}

        sql_query = """
        SELECT recommend_tag_list
        FROM users
        WHERE id = :user_id
        """

        # 1. 执行查询，result 是一个列表 (e.g., [{'recommend_tag_list': '{"tagA": 10}'}])
        result = self.execute_read_query(sql_query, params)
        if not result:
            return {}  # 如果用户不存在，返回空字典

        recommend_tag_json_str = result[0].get('recommend_tag_list')

        tags_count = {}
        if recommend_tag_json_str:
            try:
                parsed_data = json.loads(recommend_tag_json_str)
                if isinstance(parsed_data, dict):
                    tags_count = parsed_data

            except json.JSONDecodeError:
                tags_count = {}

        return tags_count

    def update_user_recommend_tags(self, user_id: int, post_id: int) -> bool:
        """
        根据用户浏览的帖子更新用户的个性化推荐标签(recommend_tag_list)。

        :param user_id: 用户ID
        :param post_id: 浏览的帖子ID
        :return: 操作是否成功
        """
        try:
            # 1. 获取帖子的标签信息
            post_tag_sql = """
            SELECT tag FROM posts_comments WHERE id = :post_id
            """
            post_params = {"post_id": post_id}
            post_result = self.execute_read_query(post_tag_sql, post_params)

            if not post_result:
                return False  # 帖子不存在

            post_tag_json = post_result[0].get('tag')
            if not post_tag_json:
                return True  # 帖子没有标签，直接返回成功

            # 解析帖子标签
            try:
                post_tags = json.loads(post_tag_json)
                if not isinstance(post_tags, list):
                    post_tags = []
            except json.JSONDecodeError:
                post_tags = []

            if not post_tags:
                return True  # 帖子标签为空，直接返回成功

            # 2. 获取用户当前的推荐标签
            user_tags_sql = """
            SELECT recommend_tag_list FROM users WHERE id = :user_id
            """
            user_params = {"user_id": user_id}
            user_result = self.execute_read_query(user_tags_sql, user_params)

            if not user_result:
                return False  # 用户不存在

            recommend_tags = {}
            recommend_tag_json = user_result[0].get('recommend_tag_list')
            if recommend_tag_json:
                try:
                    recommend_tags = json.loads(recommend_tag_json)
                    if not isinstance(recommend_tags, dict):
                        recommend_tags = {}
                except json.JSONDecodeError:
                    recommend_tags = {}

            # 3. 更新推荐标签计数
            for tag in post_tags:
                if tag in recommend_tags:
                    recommend_tags[tag] += 1
                else:
                    recommend_tags[tag] = 1

            # 4. 保存更新后的推荐标签
            updated_tags_json = json.dumps(recommend_tags)
            update_sql = """
            UPDATE users SET recommend_tag_list = :recommend_tags WHERE id = :user_id
            """
            update_params = {
                "recommend_tags": updated_tags_json,
                "user_id": user_id
            }

            result = self.execute_dml(update_sql, update_params)
            return result.rowcount > 0

        except Exception as e:
            print(f"更新用户推荐标签失败: {e}")
            return False

    def insert_comment(self, point_id: int, context: str, author_id: int, url_list: List[str]) -> int:
        """
        插入新的评论数据到 posts_comments 表。

        :param point_id: 主帖/父评论id。
        :param context: 帖子内容。
        :param author_id: 作者用户ID (author)。
        :param url_list: 图片 URL 列表（可选）。
        :return: 插入的评论 ID (posts_comments.id)。
        """
        db_url_list_json = json.dumps(url_list) if url_list else '[]'

        sql_query = """
        INSERT INTO posts_comments 
            (point_id, context, author, url_list)
        VALUES 
            (:point_id, :context, :author, :url_list)
        """

        params = {
            "point_id": point_id,
            "context": context,
            "author": author_id,
            "url_list": db_url_list_json,  # JSON 字符串
        }

        result = self.execute_dml(sql_query=sql_query, params=params)
        comment_id = result.lastrowid

        root_post_id = self._get_root_post_id(point_id)
        if root_post_id is not None:
            update_sql = """
            UPDATE posts_comments
            SET comment_count = comment_count + 1
            WHERE id = :root_post_id;
            """
            update_params = {"root_post_id": root_post_id}
            
            # 使用 DML 方法执行更新
            self.execute_dml(sql_query=update_sql, params=update_params)

        return comment_id
    
    #更新:完成历史记录以及帖子详情
        
    def get_post_detail(self, post_id: int) -> Optional[Dict[str, Any]]:
        """
        获取帖子详情（主贴）。
        
        :param post_id: 帖子ID
        :return: 帖子详情字典，若无则返回 None
        """
        sql = """
        SELECT 
            p.id, p.title, p.context, p.timestamp, p.url_list, p.tag, 
            p.browse_count, p.like_count, p.comment_count, p.favorite_count,
            u.name AS author_name, u.id AS author_id
        FROM posts_comments p
        JOIN users u ON p.author = u.id
        WHERE p.id = :post_id # AND p.point_id IS NULL
        """
        params = {"post_id": post_id}
        result = self.execute_read_query(sql, params)
        
        if not result:
            return None
        
        post = result[0]
        
        # 解析 url_list JSON 字符串为列表
        try:
            url_list = json.loads(post.get('url_list') or '[]')
        except (json.JSONDecodeError, TypeError):
            url_list = []
        
        # 解析 tag JSON 字符串为列表
        try:
            tags = json.loads(post.get('tag') or '[]')
        except (json.JSONDecodeError, TypeError):
            tags = []
        
        # 获取评论列表
        comments_sql = """
        SELECT c.id
        FROM posts_comments c
        JOIN users u ON c.author = u.id
        WHERE c.point_id = :post_id
        ORDER BY c.timestamp DESC
        """
        comments_params = {"post_id": post_id}
        comments_id_result = self.execute_read_query(comments_sql, comments_params)
        
        comments_list = []
        for comment_id in comments_id_result:
            comment = self.get_post_detail(post_id=comment_id['id'])

            comments_list.append(comment)
        
        post_detail = {
            "id": post['id'],
            "title": post['title'],
            "context": post['context'],
            "author": post['author_name'],
            "author_id": post['author_id'],
            "timestamp": post['timestamp'],
            "url_list": url_list,
            "tags": tags,
            "browse_count": post['browse_count'],
            "like_count": post['like_count'],
            "comment_count": post['comment_count'],
            "favorite_count": post.get('favorite_count', 0),
            "comments": comments_list
        }
        
        return post_detail


    def increase_post_browse_count(self, post_id: int) -> bool:
        """
        增加帖子的浏览数。
        
        :param post_id: 帖子ID
        :return: 操作是否成功
        """
        sql = """
        UPDATE posts_comments 
        SET browse_count = browse_count + 1 
        WHERE id = :post_id
        """
        params = {"post_id": post_id}
        result = self.execute_dml(sql, params)
        return result.rowcount > 0


    def record_user_browse(self, user_id: int, post_id: int) -> bool:
        """
        记录用户浏览历史。如果用户已浏览过该帖子，则更新时间戳。
        
        :param user_id: 用户ID
        :param post_id: 帖子ID
        :return: 操作是否成功
        """
        log = CCBLog("BrowseHistoryDB")

        # 首先检查是否已存在该记录
        check_sql = """
        SELECT id FROM user_browse_history 
        WHERE user_id = :user_id AND post_id = :post_id
        """
        check_params = {"user_id": user_id, "post_id": post_id}
        log.info(f"检查浏览记录是否存在 user_id={user_id}, post_id={post_id}")
        check_result = self.execute_read_query(check_sql, check_params)
        
        if check_result:
            existing_id = check_result[0].get("id")
            log.info(f"浏览记录已存在 id={existing_id}，准备更新时间戳 user_id={user_id}, post_id={post_id}")
            # 更新时间戳
            update_sql = """
            UPDATE user_browse_history 
            SET timestamp = NOW() 
            WHERE user_id = :user_id AND post_id = :post_id
            """
            update_params = {"user_id": user_id, "post_id": post_id}
            result = self.execute_dml(update_sql, update_params)
            if result.rowcount > 0:
                log.info(f"更新浏览记录时间成功 rows={result.rowcount} user_id={user_id}, post_id={post_id}")
                return True
            else:
                log.warning(f"更新浏览记录时间失败 rows={result.rowcount} user_id={user_id}, post_id={post_id}")
                return False
        else:
            log.info(f"未找到浏览记录，准备插入新记录 user_id={user_id}, post_id={post_id}")
            # 插入新记录
            insert_sql = """
            INSERT INTO user_browse_history (user_id, post_id, timestamp) 
            VALUES (:user_id, :post_id, NOW())
            """
            insert_params = {"user_id": user_id, "post_id": post_id}
            result = self.execute_dml(insert_sql, insert_params)
            if result.rowcount > 0:
                log.info(f"插入浏览记录成功 rows={result.rowcount}, lastrowid={getattr(result, 'lastrowid', None)} user_id={user_id}, post_id={post_id}")
                return True
            else:
                log.warning(f"插入浏览记录失败 rows={result.rowcount} user_id={user_id}, post_id={post_id}")
                return False


    def get_user_browse_history(self, user_id: int, limit: int = 10, offset: int = 0) -> List[Dict[str, Any]]:
        """
        获取用户的浏览历史记录。
        
        :param user_id: 用户ID
        :param limit: 限制返回的记录数
        :param offset: 偏移量
        :return: 浏览历史记录列表
        """
        sql = """
        SELECT 
            h.id, h.post_id, h.timestamp,
            p.title, p.browse_count, p.like_count, p.comment_count,
            u.name AS author_name
        FROM user_browse_history h
        JOIN posts_comments p ON h.post_id = p.id
        JOIN users u ON p.author = u.id
        WHERE h.user_id = :user_id
        ORDER BY h.timestamp DESC
        LIMIT :limit OFFSET :offset
        """
        params = {"user_id": user_id, "limit": limit, "offset": offset}
        result = self.execute_read_query(sql, params)
        
        history_list = []
        for record in result:
            history_list.append({
                "id": record['id'],
                "post_id": record['post_id'],
                "title": record['title'],
                "author": record['author_name'],
                "timestamp": record['timestamp'],
                "browse_count": record['browse_count'],
                "like_count": record['like_count'],
                "comment_count": record['comment_count']
            })
        
        return history_list


    def delete_user_browse_history_record(self, user_id: int, record_id: int) -> bool:
        """
        删除用户的某条浏览历史记录。需要验证所有权。
        
        :param user_id: 用户ID
        :param record_id: 浏览历史记录ID
        :return: 操作是否成功
        """
        sql = """
        DELETE FROM user_browse_history 
        WHERE user_id = :user_id AND id = :id
        """
        params = {"user_id": user_id, "id": record_id}
        result = self.execute_dml(sql, params)
        return result.rowcount > 0


    def get_user_browse_history_count(self, user_id: int) -> int:
        """
        获取用户的浏览历史记录总数。
        
        :param user_id: 用户ID
        :return: 记录数
        """
        sql = """
        SELECT COUNT(*) as count FROM user_browse_history 
        WHERE user_id = :user_id
        """
        params = {"user_id": user_id}
        result = self.execute_read_query(sql, params)
        
        if result:
            return result[0]['count']
        return 0

    def get_posts_by_user_id(self, user_id: int, limit: int = 10, offset: int = 0):
        """根据用户ID获取该用户发布的主帖列表（point_id IS NULL）。

        :param user_id: 用户ID
        :param limit: 每页数量
        :param offset: 偏移量
        :return: (posts_list, total_count)
        """

        sql = """
        SELECT
            p.id,
            p.title,
            p.author,
            p.context,
            p.timestamp,
            p.url_list,
            p.tag,
            p.browse_count,
            p.like_count,
            p.comment_count,
            u.name AS author_name,
            COUNT(*) OVER() AS total_count
        FROM posts_comments p
        JOIN users u ON p.author = u.id
        WHERE p.point_id IS NULL AND p.author = :user_id
        ORDER BY p.timestamp DESC
        LIMIT :limit OFFSET :offset
        """

        params = {"user_id": user_id, "limit": limit, "offset": offset}

        raw_posts = self.execute_read_query(sql, params)

        if not raw_posts:
            return [], 0

        total_count = raw_posts[0].get('total_count', 0)

        posts = []
        for post in raw_posts:
            try:
                url_list = json.loads(post.get('url_list') or '[]')
            except (json.JSONDecodeError, TypeError):
                url_list = []

            try:
                tags_list = json.loads(post.get('tag') or '[]')
            except (json.JSONDecodeError, TypeError):
                tags_list = []

            cover_image_url = None
            if isinstance(url_list, list) and url_list:
                cover_image_url = url_list[0]

            posts.append({
                'id': post['id'],
                'title': post['title'],
                'context': post['context'],
                'author_id': post['author'],
                'author': post['author_name'],
                'timestamp': post['timestamp'],
                'cover_image': cover_image_url,
                'tags': tags_list if isinstance(tags_list, list) else [],
                'browse_count': post['browse_count'],
                'like_count': post['like_count'],
                'comment_count': post['comment_count'],
            })

        return posts, total_count

        
    def get_tag_index(self, tag_name: str) -> int:
        """
        查询某个tag在全局标签表中的index

        :param tag_name: 标签名
        :return: tag的id，不存在则返回0
        """
        sql = """
        SELECT id FROM global_tag_map
        WHERE tag_name = :tag_name
        """
        params = {"tag_name": tag_name}
        result = self.execute_read_query(sql, params)

        if result:
            return result[0]['id']
        return 0
    
    def batch_get_tag_indices(self, tag_names: List[str]) -> Dict[str, int]:
        """
        根据 tag_name 列表，批量查询 global_tag_map 表中已存在的标签索引。

        :param tag_names: 标签名列表。
        :return: {tag_name: index} 的字典，只包含找到的标签。
        """
        if not tag_names:
            return {}

        sql = f"""
        SELECT tag_name, id
        FROM global_tag_map
        WHERE tag_name IN :tag_names
        """
        params = {"tag_names": tag_names}

        results = self.execute_read_query(sql, params)

        # 转换为 {tag_name: id} 字典
        indices = {row['tag_name']: row['id'] for row in results}
        
        return indices
    
    def create_new_tag(self, tag_name: str) -> int:
        """
        向全局标签表中插入一个新tag并返回它的id

        :param tag_name: 标签名
        :return: 新生成的id，插入失败则返回0
        """
        insert_sql = """
        INSERT INTO global_tag_map (tag_name) 
        VALUES (:tag_name)
        """
        insert_params = {"tag_name": tag_name}
        try:
            result = self.execute_dml(insert_sql, insert_params)
            if result.rowcount > 0:
                return result.lastrowid
        except IntegrityError:
            CCBLog("PostDB").warning("fConcurrent tag creation detected for '{tag_name}'. Retrieving existing index.")
            return self.get_tag_index(tag_name)
        except Exception as e:
            CCBLog("PostDB").error(f"Error during create_new_tag for '{tag_name}': {e}")

        return 0
        
    def batch_get_item_profiles(self, post_ids: List[int]) -> Dict[int, List[Dict[str, Any]]]:
        """
        根据 post_id 列表，批量查询 item_profiles 表中的画像数据。

        :param post_ids: 帖子 ID 列表。
        :return: {post_id: List[{'tag_index': 1, 'tag_value': 1}], ...}
        """
        if not post_ids:
            return {}
        
        sql = f"""
        SELECT post_id, tag_index, tag_value
        FROM item_profiles
        WHERE post_id IN :post_ids
        """
        params = {"post_ids": post_ids}

        results = self.execute_read_query(sql, params)

        # 将平铺的结果列表转换为 {post_id: List[Rows]} 的字典结构
        profiles_by_id = {}

        for row in results:
            pid = row['post_id']
            if pid not in profiles_by_id:
                profiles_by_id[pid] = []
            profiles_by_id[pid].append(row)
            
        return profiles_by_id
    
    def batch_insert_item_profiles(self, profiles: List[Dict[str, Any]]):
        sql_query = """
            INSERT INTO item_profiles (post_id, tag_index, tag_value)
            VALUES (:post_id, :tag_index, :tag_value)
            ON DUPLICATE KEY UPDATE tag_value = VALUES(tag_value);
        """
        result = self.execute_dml(sql_query, params=profiles)
        return result.rowcount
    
    def get_user_profile(self, user_id: int) -> Dict[int, float]:
        sql = """
        SELECT tag_index, score
        FROM user_profiles
        WHERE user_id = :user_id
        """
        params = {"user_id": user_id}
        
        # 假设 execute_read_query 返回一个字典列表
        result = self.execute_read_query(sql, params)

        profile_dict = {}
        for row in result:
            try:
                profile_dict[int(row['tag_index'])] = float(row['score'])
            except (ValueError, TypeError) as e:
                CCBLog("PostDB").error(f"DB profile data format error: {e}")
                continue
        return profile_dict
    
    def batch_update_user_profiles(self, user_id: int, user_profile_new: Dict[int, float]):
        """
        批量更新/插入用户画像到 user_profiles 表（Upsert 操作）。

        :param user_id: 用户的ID。
        :param user_profile_new: 格式为 {tag_index: score} 的新画像字典。
        :return: 受影响的行数。
        """
        if not user_profile_new:
            return 0

        # 1. 将 {tag_index: score} 字典转换为 List[Dict] 格式
        # 这一步是为了适应 execute_dml 批量执行所需的参数格式
        profiles_to_update = []
        # 当前时间戳（精确到秒）
        current_time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        for tag_index, score in user_profile_new.items():
            profiles_to_update.append({
                "user_id": user_id,
                "tag_index": tag_index,
                # 注意：score 必须转换成字符串，以匹配数据库中的 VARCHAR(20) 类型
                "score": str(round(score, 4)), 
                "last_updated": current_time_str
            })

        # 2. 定义 Upsert SQL 语句
        # 使用 ON DUPLICATE KEY UPDATE 来实现：如果 (user_id, tag_index) 组合已存在，则更新分数和时间。
        sql_query = """
            INSERT INTO user_profiles (user_id, tag_index, score, last_updated)
            VALUES (:user_id, :tag_index, :score, :last_updated)
            ON DUPLICATE KEY UPDATE
                score = VALUES(score),
                last_updated = VALUES(last_updated);
        """

        try:
            # 3. 批量执行 DML
            # execute_dml 传入 List[Dict] 实现批量 Upsert
            result = self.execute_dml(sql_query, params=profiles_to_update)
            
            CCBLog("PostDB").info(f"User {user_id} profile DB updated. Rows affected: {result.rowcount}")
            return result.rowcount

        except Exception as e:
            CCBLog("PostDB").error(f"Failed to batch update user profiles for user {user_id}: {e}")
            # 异步任务中，如果数据库更新失败，通常只记录错误，但如果设计要求强一致性，
            # 这里可能需要触发重试或警报。
            raise # 抛出异常以便任务队列捕获和处理重试

    def get_active_user_ids(self, time_delta: timedelta) -> List[int]:
        """
        查询在最近 time_delta 时间内有浏览记录的用户的唯一 ID 列表。

        Args:
            time_delta: 一个 datetime.timedelta 对象，定义了活跃时间窗口。

        Returns:
            活跃用户的唯一 ID 列表 (List[int])。
        """
        time_threshold = datetime.now() - time_delta

        sql_query = """
            SELECT DISTINCT user_id
            FROM user_browse_history
            WHERE timestamp >= :time_threshold;
        """
        params = {"time_threshold": time_threshold}

        result = self.execute_dml(sql_query, params=params)

        return [row[0] for row in result]