"""
JSON数据管理器
"""

import json
from backend.utils.CCBLog import CCBLog
import os
from datetime import datetime

class JSONManager:
    def __init__(self, storage_path=""):
        self.storage_path = storage_path
        self.ensure_directory()
        self.log = CCBLog("JSONManager")
    
    def ensure_directory(self):
        """确保存储目录存在"""
        directory = os.path.dirname(self.storage_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)
    
    def save_optimization_result(self, original_prompt, optimized_prompt, workflow_history):
        """保存优化结果到JSON文件"""
        try:
            # 读取现有数据
            existing_data = self.load_existing_data()
            
            # 创建新记录
            new_record = {
                "timestamp": datetime.now().isoformat(),
                "original_prompt": original_prompt,
                "optimized_prompt": optimized_prompt,
                "workflow_history": workflow_history
            }
            
            # 添加到数据中
            existing_data["optimization_records"].append(new_record)
            
            # 保存到文件
            with open(self.storage_path, 'w', encoding='utf-8') as f:
                json.dump(existing_data, f, ensure_ascii=False, indent=2)

            self.log.info(f"保存结果成功: {self.storage_path}")
            return True
            
        except Exception as e:
            self.log.error(f"保存结果时出错: {e}")
            return False
    
    def load_existing_data(self):
        """加载现有数据或创建新结构"""
        CCBLog('load_existing_data').info(self.storage_path)
        if os.path.exists(self.storage_path):
            try:
                with open(self.storage_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                self.log.error(f"加载数据时出错: {e}")
        
        # 创建新的数据结构
        return {
            "metadata": {
                "created_at": datetime.now().isoformat(),
                "version": "1.0",
                "description": "提示词优化结果存储"
            },
            "optimization_records": []
        }
    
    def load_all_records(self):
        """加载所有记录"""
        return self.load_existing_data()