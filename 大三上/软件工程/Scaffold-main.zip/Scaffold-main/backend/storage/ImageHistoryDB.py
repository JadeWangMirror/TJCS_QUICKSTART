# Storage 层 - 图片生成历史记录数据库操作

from sqlalchemy import text
from .DBManager import DBManager, get_db_manager
from typing import List, Dict, Any, Optional
from backend.utils.CCBLog import CCBLog


class ImageHistoryDB:
    """
    图片生成历史记录功能的数据库操作类，使用 SQLAlchemy Core 封装连接和基本 CRUD 操作。
    
    职责说明：
    1. 在 image_history 表中管理图片生成的历史记录
    2. 提供历史记录的增删改查接口
    """

    def __init__(self):
        #db_manager = DBManager()
        self.engine = get_db_manager().get_engine()
        self.log = CCBLog("ImageHistoryDB")

    def execute_dml(self, sql_query: str, params: Optional[Dict[str, Any]] = None, commit: bool = True):
        """
        执行 DML 操作 (INSERT, UPDATE, DELETE)。
        
        :param sql_query: 原始 SQL 字符串
        :param params: 绑定参数字典
        :param commit: 是否在执行后提交事务
        :return: 执行结果对象 (CursorResult)，包含 rowcount 等信息
        """
        with self.engine.begin() as conn:
            result = conn.execute(text(sql_query), params or {})
            if not commit:
                conn.rollback()
            return result

    def execute_read_query(self, sql_query: str, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        执行查询操作 (SELECT)。
        
        :param sql_query: 原始 SQL 字符串
        :param params: 绑定参数字典
        :return: 查询结果列表（字典格式）
        """
        with self.engine.connect() as conn:
            result = conn.execute(text(sql_query), params or {})
            return [dict(row) for row in result.mappings().all()]

    def insert_image_history(
        self,
        user_id: int,
        prompt: str,
        url: str
    ) -> Optional[int]:
        """
        插入一条图片生成历史记录到 image_history 表。
        
        :param user_id: 用户ID
        :param prompt: 生成图片的提示词
        :param url: 生成的图片URL
        :return: 插入的记录ID，失败返回None
        """
        sql_query = """
        INSERT INTO image_history (user_id, prompt, url, timestamp)
        VALUES (:user_id, :prompt, :url, NOW())
        """
        
        params = {
            "user_id": user_id,
            "prompt": prompt,
            "url": url
        }
        
        try:
            result = self.execute_dml(sql_query=sql_query, params=params)
            if result.rowcount > 0:
                # 获取插入的记录ID
                last_id_result = self.execute_read_query("SELECT LAST_INSERT_ID() as id")
                if last_id_result:
                    return last_id_result[0]['id']
            return None
        except Exception as e:
            self.log.error(f"插入图片生成历史记录失败: {e}")
            return None

    def insert_image_histories(
        self,
        user_id: int,
        prompt: str,
        urls: List[str]
    ) -> List[int]:
        """
        批量插入图片生成历史记录。
        
        :param user_id: 用户ID
        :param prompt: 生成图片的提示词
        :param urls: 生成的图片URL列表
        :return: 插入的记录ID列表
        """
        inserted_ids = []
        for url in urls:
            history_id = self.insert_image_history(user_id, prompt, url)
            if history_id:
                inserted_ids.append(history_id)
        return inserted_ids

    def get_image_history_by_id(self, history_id: int) -> Optional[Dict[str, Any]]:
        """
        根据ID获取图片生成历史记录。
        
        :param history_id: 历史记录ID
        :return: 历史记录字典，不存在返回None
        """
        sql_query = """
        SELECT id, timestamp, prompt, user_id, url
        FROM image_history
        WHERE id = :history_id
        """
        
        params = {"history_id": history_id}
        
        try:
            results = self.execute_read_query(sql_query, params)
            if results:
                return results[0]
            return None
        except Exception as e:
            self.log.error(f"获取图片生成历史记录失败: {e}")
            return None

    def get_image_history_by_user_id(
        self,
        user_id: int,
        limit: int = 20,
        offset: int = 0
    ) -> List[Dict[str, Any]]:
        """
        根据用户ID获取图片生成历史记录列表（分页）。
        
        :param user_id: 用户ID
        :param limit: 每页数量
        :param offset: 偏移量
        :return: 历史记录列表
        """
        sql_query = """
        SELECT id, timestamp, prompt, user_id, url
        FROM image_history
        WHERE user_id = :user_id
        ORDER BY timestamp DESC
        LIMIT :limit OFFSET :offset
        """
        
        params = {
            "user_id": user_id,
            "limit": limit,
            "offset": offset
        }
        
        try:
            return self.execute_read_query(sql_query, params)
        except Exception as e:
            self.log.error(f"获取用户图片生成历史记录列表失败: {e}")
            return []

    def delete_image_history(self, history_id: int, user_id: Optional[int] = None) -> bool:
        """
        删除图片生成历史记录。
        
        :param history_id: 历史记录ID
        :param user_id: 用户ID（可选，用于验证权限）
        :return: True表示删除成功，False表示删除失败
        """
        if user_id is not None:
            sql_query = """
            DELETE FROM image_history
            WHERE id = :history_id AND user_id = :user_id
            """
            params = {"history_id": history_id, "user_id": user_id}
        else:
            sql_query = """
            DELETE FROM image_history
            WHERE id = :history_id
            """
            params = {"history_id": history_id}
        
        try:
            result = self.execute_dml(sql_query=sql_query, params=params)
            return result.rowcount > 0
        except Exception as e:
            self.log.error(f"删除图片生成历史记录失败: {e}")
            return False

    def delete_all_image_history_by_user_id(self, user_id: int) -> int:
        """
        删除用户的所有图片生成历史记录。
        
        :param user_id: 用户ID
        :return: 删除的记录数量，失败返回0
        """
        sql_query = """
        DELETE FROM image_history
        WHERE user_id = :user_id
        """
        
        params = {"user_id": user_id}
        
        try:
            # 执行删除
            result = self.execute_dml(sql_query=sql_query, params=params)
            
            if result.rowcount >= 0:
                self.log.info(f"成功删除用户 {user_id} 的 {result.rowcount} 条图片生成历史记录")
                return result.rowcount
            return 0
        except Exception as e:
            self.log.error(f"清空用户图片生成历史记录失败: {e}")
            return 0

    def count_image_history_by_user_id(self, user_id: int) -> int:
        """
        统计用户的图片生成历史记录总数。
        
        :param user_id: 用户ID
        :return: 记录总数
        """
        sql_query = """
        SELECT COUNT(*) as count
        FROM image_history
        WHERE user_id = :user_id
        """
        
        params = {"user_id": user_id}
        
        try:
            results = self.execute_read_query(sql_query, params)
            if results:
                return results[0]['count']
            return 0
        except Exception as e:
            self.log.error(f"统计图片生成历史记录总数失败: {e}")
            return 0

