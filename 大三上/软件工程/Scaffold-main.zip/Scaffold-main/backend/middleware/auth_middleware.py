"""
认证中间件
处理全局 JWT 鉴权
"""
from flask import request, jsonify, g
from backend.services.auth.UserService import UserService
from backend.utils.CCBLog import CCBLog

user_service = UserService()
log = CCBLog("AuthMiddleware")

# 白名单：不需要鉴权的路由
PUBLIC_ROUTES = [
    # 认证相关
    '/api/user/send-code',
    '/api/user/register',
    '/api/user/login',
    '/api/user/reset-password',
    '/apispec_1.json',
]

# 支持动态路由的白名单（使用前缀匹配）
PUBLIC_ROUTE_PREFIXES = [
    '/static/uploads/'
]


def is_public_route(path: str) -> bool:
    """
    判断是否是公开路由
    
    Args:
        path: 请求路径
        
    Returns:
        bool: 是否是公开路由
    """
    # 精确匹配
    if path in PUBLIC_ROUTES:
        return True
    
    # 前缀匹配
    for prefix in PUBLIC_ROUTE_PREFIXES:
        if path.startswith(prefix):
            return True
    
    return False


def verify_token_middleware():
    """
    Token 验证中间件
    在每个请求前执行，验证 JWT token
    """
    if not request.path.startswith('/api/'):
        return None
    # 跳过公开路由
    if is_public_route(request.path):
        return None
    
    # 获取 token
    auth_header = request.headers.get('Authorization')
    
    if not auth_header:
        log.warning(f"未提供认证信息: {request.path}")
        return jsonify({
            'success': False,
            'message': '未提供认证信息，请先登录'
        }), 401
    
    if not auth_header.startswith('Bearer '):
        log.warning(f"认证格式错误: {request.path}")
        return jsonify({
            'success': False,
            'message': '认证格式错误，应为 Bearer <token>'
        }), 401
    
    try:
        token = auth_header.split(' ')[1]
    except IndexError:
        log.warning(f"Token 格式错误: {request.path}")
        return jsonify({
            'success': False,
            'message': 'Token 格式错误'
        }), 401
    
    # 验证 token
    payload = user_service.verify_token(token)
    
    if not payload:
        log.warning(f"Token 无效或已过期: {request.path}")
        return jsonify({
            'success': False,
            'message': 'Token 无效或已过期，请重新登录'
        }), 401
    
    # 将用户信息存储到 Flask g 对象中，供后续使用
    g.current_user_id = payload.get('user_id')
    g.token_payload = payload
    
    log.info(f"用户 {g.current_user_id} 访问: {request.path}")
    
    return None  # 继续执行请求

