import os

from flask import Flask
from flask_cors import CORS
import logging
from backend.api.routes import register_routes
from backend.cache.cache import get_redis_client, init_celery, init_redis_client
from backend.config import ConfigReader
from backend.middleware.auth_middleware import verify_token_middleware
from backend.storage.DBManager import init_db_manager
from backend.utils.CCBLog import CCBLog

def create_app():
    init_db_manager()
    app = Flask(__name__, static_folder='../static', static_url_path='/static')


    UPLOAD_FOLDER = ConfigReader("./backend/config/app_config.json").read_config()['UPLOAD_FOLDER']
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)

    redis_config = ConfigReader("./backend/config/redis.json").read_config()['redis']
    try:
        init_redis_client(redis_config=redis_config)
        get_redis_client().ping()
        CCBLog('create_app').info("Redis 客户端连接成功!")

    except Exception as e:
        CCBLog('create_app').error(f"Redis 连接失败: {e}")

    init_celery(redis_config=redis_config)
    CORS(app)  # 允许跨域请求
    app.before_request(verify_token_middleware)

    register_routes(app)  # 注册路由
    logging.basicConfig(level=logging.INFO)
    return  app
