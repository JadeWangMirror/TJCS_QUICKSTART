from backend.cache.cache import get_celery_app
from typing import List, Dict, Any, Tuple
from datetime import timedelta

celery_app = get_celery_app()

from backend.cache.PostRedis import cache_post_ids_by_key, cache_new_post, update_user_profile, cache_posts, refresh_recommendations
from backend.utils.CCBLog import CCBLog

@celery_app.task(name='cache_post_ids_task')
def cache_post_ids_task(key: str, max_len: int):
    """
    异步任务：获取并缓存完整的帖子列表
    """
    from backend.storage.PostDB import PostDB
    db_manager = PostDB()

    post_ids = db_manager.get_post_ids_by_args_ordered_by_arg(
        order=key, limit=max_len, offset=0
    )

    cache_post_ids_by_key(key=key, post_ids=post_ids)

    CCBLog("task").info(f"异步任务完成: 列表 {key} 已缓存 {len(post_ids)} 条数据。")

@celery_app.task(name='push_new_post_task') 
def push_new_post_task(post: Dict[str, Any]):
    """
    异步任务：将新帖子增量推送到最新列表的队头，并裁剪id列表。
    """
    cache_new_post(post=post)
    
    CCBLog("task").info(f"异步更新完成: 最新列表已推送新帖 {post['id']}。")

@celery_app.task(name='update_user_profile_task')
def update_user_profile_task(user_id: int, post_id: int, increment: float):
    CCBLog("task").info(f"updating user {user_id} profile")
    update_user_profile(user_id, post_id, increment)

@celery_app.task(name="cache_recommendation_post_ids_task")
def cache_recommendation_post_ids_task(key: str, post_ids: List[Tuple[int, float]], user_id: int):
    cache_post_ids_by_key(key=key, post_ids=post_ids, user_id=user_id)

@celery_app.task(name="cache_posts_task")
def cache_posts_task(posts: List[Dict[str, Any]]):
    cache_posts(posts=posts)

@celery_app.task(name="refresh_recommendations_task")
def refresh_recommendations_task(user_id: int):
    """
    异步计算目标用户的推荐列表，并将结果写入 Redis 缓存。

    Args:
        user_id: 目标用户 ID。
    """
    refresh_recommendations(user_id=user_id)

@celery_app.task(name="proactive_recommendations_refresh")
def proactive_recommendations_refresh():
    """
    主动刷新所有活跃用户的推荐列表缓存。此任务应由调度器定时执行。
    """
    CCBLog("proactive").info("Starting proactive refresh of recommendation caches.")
    
    try:
        from backend.storage.PostDB import PostDB
        db_manager = PostDB()
        time_delta = timedelta(days=2)
        active_users = db_manager.get_active_user_ids(time_delta=time_delta)
        user_count = len(active_users)
        
        if not active_users:
            CCBLog("proactive").info("No active users found to refresh.")
            return

        CCBLog("proactive").info(f"Found {user_count} active users. Triggering async refresh tasks.")
        
        # 批量触发异步计算任务
        for user_id in active_users:
            # 调用之前定义好的异步计算任务
            # 注意：这里调用的是 .delay()，确保计算在后台执行
            refresh_recommendations_task.delay(user_id=user_id) 
            
        CCBLog("proactive").info(f"Successfully triggered refresh tasks for {user_count} users.")

    except Exception as e:
        CCBLog("proactive").error(f"Error during proactive refresh process: {e}")
        # 任务失败，记录错误
        pass