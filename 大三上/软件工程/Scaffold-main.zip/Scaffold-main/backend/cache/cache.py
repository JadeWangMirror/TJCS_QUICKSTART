from redis import Redis
from celery import Celery
from typing import Optional, Dict, Any
from datetime import timedelta
from backend.config.ConfigReader import ConfigReader
from backend.utils.CCBLog import CCBLog

redis_client: Optional[Redis] = None
celery_app = Celery('scaffold')
GLOBAL_KEY_MAP: Optional[Dict] = None

def init_global_config():
    """在应用启动时加载配置，供所有模块访问"""
    global GLOBAL_KEY_MAP
    if GLOBAL_KEY_MAP is not None:
        return
        
    try:
        config = ConfigReader("./backend/config/redis.json").read_config()
        GLOBAL_KEY_MAP = config.get('key_map')
    except Exception as e:
        # 允许应用启动，但在需要配置时失败
        CCBLog('init_global_config').warning(f"警告: 无法加载 GLOBAL_KEY_MAP: {e}")

def get_global_key_map() -> Dict:
    """获取已加载的 Key Map 配置"""
    global GLOBAL_KEY_MAP
    if GLOBAL_KEY_MAP is None:
        # 尝试快速加载，防止在 Celery 任务中失败
        init_global_config() 
        if GLOBAL_KEY_MAP is None:
             raise Exception("GLOBAL_KEY_MAP 尚未初始化或加载失败。")
             
    return GLOBAL_KEY_MAP

def init_redis_client(redis_config: dict):
    """
    初始化全局 Redis 客户端。
    应在应用工厂中调用。
    """
    global redis_client
    
    # 确保只初始化一次
    if redis_client is not None:
        return

    redis_client = Redis(
        host=redis_config.get('host', 'localhost'),
        port=redis_config.get('port', 6379),
        db=redis_config.get('db', 0),
        password=redis_config.get('password'),
        decode_responses=True
    )

def get_redis_client() -> Redis:
    """
    获取已初始化的 Redis 客户端实例。
    """
    global redis_client
    if redis_client is None:
        # 抛出异常，提醒开发者客户端尚未初始化
        raise Exception("Redis 客户端尚未初始化。请确保已在应用启动时调用 init_redis_client()")
    return redis_client

CELERY_BEAT_SCHEDULE = {
    'proactive-recos-refresh-interval': {
        # 任务的完整路径 (确保 worker 能找到)
        'task': 'proactive_recommendations_refresh', 
        # 每隔 60 分钟运行一次 (您可以根据业务需求调整)
        'schedule': timedelta(minutes=1), 
        'args': (), # 任务的参数
    },
    # 您可能还有其他定时任务...
}

def make_celery(redis_config: Dict[str, Any]) -> Celery:
    """
    配置并创建 Celery 实例。
    """
    # 1. 构造 Redis 连接 URL
    # 使用 Redis 作为 Broker 和 Backend
    # 格式: redis://:password@host:port/db
    
    password = redis_config.get('password')
    auth_part = f":{password}@" if password else ""
    
    redis_url = (
        f"redis://{auth_part}"
        f"{redis_config.get('host', 'localhost')}:"
        f"{redis_config.get('port', 6379)}/"
        f"{redis_config.get('db', 0)}" # Broker 使用 DB 0
    )
    
    # 为了结果存储，Backend 最好使用不同的 DB (例如 DB 1)
    backend_url = f"{redis_url.rsplit('/', 1)[0]}/1" 

    # 2. 配置全局实例
    global celery_app

    # 3. 设置配置 
    celery_app.conf.update({
        'broker_url': redis_url,
        'result_backend': backend_url,
        'beat_schedule': CELERY_BEAT_SCHEDULE,
        'include': ['backend.cache.tasks'],
        'task_serializer': 'json',
        'result_serializer': 'json',
        'accept_content': ['json'],
        'timezone': 'Asia/Shanghai', # 设置时区
        'enable_utc': False,
        'broker_connection_retry_on_startup': True, # 启动时重试连接
        'broker_pool_limit': 10 # Broker 连接池大小
    })

def init_celery(redis_config: Dict[str, Any]):
    """初始化全局 Celery 实例"""
    global celery_app
    if celery_app.conf.get('broker_url'):
        return
    make_celery(redis_config)

def get_celery_app() -> Celery:
    """获取 Celery 实例"""
    global celery_app
    if celery_app is None:
        raise Exception("Celery 实例尚未初始化。")
    return celery_app


try:
    reader = ConfigReader("./backend/config/redis.json")
    full_config = reader.read_config()
    redis_config = full_config.get('redis')
    
    # 强制配置 Celery
    if redis_config:
        init_redis_client(redis_config=redis_config)
        make_celery(redis_config=redis_config)
        
    # 强制加载全局 KEY_MAP
    if full_config.get('key_map'):
        GLOBAL_KEY_MAP = full_config.get('key_map')

except FileNotFoundError:
    CCBLog('get_celery_app').error("错误: Celery Worker 启动时未找到 redis.json 配置文件。")
except Exception as e:
    CCBLog('get_celery_app').error(f"错误: Celery Worker 启动时配置加载失败: {e}")