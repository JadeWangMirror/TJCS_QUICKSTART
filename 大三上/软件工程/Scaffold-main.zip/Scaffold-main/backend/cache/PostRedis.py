from backend.cache.cache import get_redis_client, get_global_key_map
from backend.utils.CCBLog import CCBLog
from typing import List, Dict, Any, Tuple, Literal, Optional
from datetime import datetime
from redis.exceptions import WatchError
import json
import time

# 定义需要进行类型转换的字段
NUMERICAL_FIELDS = ['id', 'author_id', 'browse_count', 'like_count', 'comment_count', 'favorite_count']

def db_to_redis(post: Dict[str, Any]) -> Dict[str, str]:
    """
    将 DB/业务逻辑字典转换为 Redis Hash Map 存储所需的字符串字典。

    Args:
        post: 从 DB/ORM 获取或处理后的帖子字典，可能包含 datetime 和 list。

    Returns:
        post_redis: 键值均为字符串的字典，可以直接用于 redis.hmset()。
    """
    post_redis: Dict[str, str] = {}

    for k, v in post.items():
        if v is None:
            # 消除 None 值，Redis 不喜欢
            post_redis[k] = ""
        
        if k in NUMERICAL_FIELDS:
            # 整数/计数转换为字符串
            post_redis[k] = str(v)
        
        elif k == 'timestamp':
            if isinstance(v, datetime):
                # datetime 对象转换为 Unix 浮点时间戳
                post_redis[k] = str(v.timestamp())
            elif isinstance(v, (int, float)):
                # 如果已经是时间戳，直接转为字符串
                post_redis[k] = str(v)
            else:
                # 处理 DB 返回的字符串时间，尝试转换为时间戳或保留
                post_redis[k] = str(v)

        elif k == 'tags':
            # tags 列表转换为逗号分隔的字符串
            if isinstance(v, list):
                post_redis[k] = ','.join(map(str, v))
            elif isinstance(v, str):
                post_redis[k] = v # 如果已经是字符串，保留
                
        else:
            # 所有其他字段（如 title, context, author, cover_image）直接转为字符串
            post_redis[k] = str(v)
            
    return post_redis

def redis_to_response(details_dict: Dict[str, str]) -> Dict[str, Any]:
    """
    将 Redis Hash Map 取出的字符串字典转换为前端响应所需的 Python 字典。

    Args:
        details_dict: 从 redis.hgetall() 取出的键值均为字符串的字典。

    Returns:
        post: 转换后的字典，类型正确 (int, float, list)。
    """
    post: Dict[str, Any] = {}

    for k, v in details_dict.items():
        if k in NUMERICAL_FIELDS:
            # 字符串数字转换为整数
            try:
                post[k] = int(v) if v else 0
            except ValueError:
                post[k] = 0
                CCBLog('redis_to_response').warning(f"Redis字段 {k} 转换int失败，值: {v}")
                
        elif k == 'timestamp':
            # 字符串时间戳转换为浮点数
            try:
                post[k] = float(v) if v else None
            except ValueError:
                post[k] = None
                CCBLog('redis_to_response').warning(f"Redis字段 {k} 转换float失败，值: {v}")

        elif k == 'tags':
            # 逗号分隔字符串转换回列表
            if v:
                post[k] = v.split(',')
            else:
                post[k] = []
              
        else:
            # 其他字段（title, context, cover_image, author）直接赋值
            post[k] = v
            
    return post

def check_and_trigger_hot_refresh(increment: int = 1) -> bool:
    """
    原子性地增加全局操作计数器，如果达到阈值，则重置计数器
    并异步触发最热榜单的全量更新。
    
    Args:
        increment: 本次操作增加的数值（例如浏览+1，评论+2等）。
    
    Returns:
        如果任务被触发，返回 True；否则返回 False。
    """
    redis = get_redis_client()
    key_map = get_global_key_map()
    list_config = key_map.get("hot")
    ACTION_COUNTER_KEY = list_config["ACTION_COUNTER_KEY"]
    HOT_REFRESH_THRESHOLD = list_config["HOT_REFRESH_THRESHOLD"]
    max_len = list_config["MAX_LEN"]
    
    # 1. 原子性地增加计数器
    # 使用 INCRBY 确保多进程/多线程环境下计数的准确性
    new_count = redis.incrby(ACTION_COUNTER_KEY, increment)
    CCBLog('check_and_trigger_hot_refresh').info(f'increament{increment}, new_count{new_count}')
    
    # 2. 检测是否达到阈值
    if new_count >= HOT_REFRESH_THRESHOLD:
        CCBLog('check_and_trigger_hot_refresh').info(f"全局操作计数达到 {new_count}。正在触发最热榜单刷新。")
        
        # 3. 重置计数器
        # 注意：这里使用 SET 设置为 0，因为 INCRBY 已经返回了触发值。
        # 即使在重置和 INCRBY 之间有其他操作，新的操作数也会从 0 重新开始累加。
        redis.set(ACTION_COUNTER_KEY, 0)
        
        # 4. 异步触发最热榜单全量更新任务
        
        # 异步调用全量更新任务
        # ❗ 注意: 您的 cache_post_ids_task 内部需要实现按热度计算和排序的逻辑
        from backend.cache.tasks import cache_post_ids_task
        cache_post_ids_task.delay(key="hot", max_len=max_len)
        
        return True
    
    return False

def get_cached_posts_by_key(key: str, start: int, end: int, user_id: int = None) -> Tuple[List[Dict[str, Any]], int]:
    """
    根据缓存键和分页范围，从 Redis 中获取帖子 ID 列表和对应的帖子详情。

    Args:
        key: 缓存键的类型 (如 'time', 'hot').
        start: 列表范围的起始索引 (包含).
        end: 列表范围的结束索引 (包含).
    
    Returns:
        帖子的字典列表。
    """
    redis = get_redis_client()
    key_map = get_global_key_map()
    
    list_config = key_map.get(key)
    if not list_config:
        return [], 0

    LIST_KEY = list_config["NAME"]
    MAX_LEN = list_config["MAX_LEN"]
    POST_TTL_SECONDS = key_map.get('POST_TTL_SECONDS')
    if key == "recommendation" and user_id is not None:
        LIST_KEY = f"{LIST_KEY}{user_id}"
    
    CCBLog("get_cached_posts_by_key").info(f"trying to get {LIST_KEY} post from cache")
    # 1. 同步获取 ID 列表
    # raw_ids 包含了所有在 [start, end] 范围内的帖子 ID (字符串格式)
    pipe = redis.pipeline()
    # Command 1: 获取 ZSET 总长度
    pipe.zcard(LIST_KEY)
    # Command 2: 获取分页 ID (使用 ZREVRANGE 获取降序排列的元素)
    # 注意：ZREVRANGE 的 start 和 end 是基于排序秩 (Rank)
    pipe.zrevrange(LIST_KEY, start, end)
    results = pipe.execute()

    total_count: int = results[0] # 列表总长度
    raw_ids: List[str] = results[1]  # 分页 ID 列表

    if total_count == 0:
        CCBLog("get_cached_posts_by_key").warning(f"{LIST_KEY} cache out of date")
        if key != "recommendation":
            from backend.cache.tasks import cache_post_ids_task
            cache_post_ids_task.delay(key=key, max_len=MAX_LEN)
        return [], 0

    # 2. 批量获取帖子详情 (使用 Pipeline 优化性能)
    pipe = redis.pipeline()
    
    # 对获取到的每个 ID，构造 DETAIL_KEY 并添加到管道中
    for id_str in raw_ids:
        DETAIL_KEY = f"post:detail:{id_str}"
        pipe.hgetall(DETAIL_KEY) # 将批量获取操作放入管道
        
    # 批量执行管道中的所有 HGETALL 操作
    post_details: List[Dict[str, str]] = pipe.execute()

    # 识别未命中 ID，并追踪顺序
    posts_list: List[Dict[str, Any]] = []
    missing_ids: List[int] = []
    # 使用一个字典来临时存储所有结果，以保证在重建后能按原始顺序填充
    result_map: Dict[int, Dict[str, Any]] = {}

    # 结果处理和格式化
    for i, details_dict in enumerate(post_details):
        post_id = int(raw_ids[i])
        if not details_dict:
            missing_ids.append(post_id)
            result_map[post_id] = None
        else:
            try:
                post = redis_to_response(details_dict)
                result_map[post_id] = post

            except (ValueError, TypeError, KeyError) as e:
                # 如果转换失败（例如 'id' 不是有效的数字），跳过此条数据并打印警告
                # 这是一个重要的容错机制，防止脏数据导致整个应用崩溃
                CCBLog('check_and_trigger_hot_refresh').warning(f"警告: 转换帖子数据时出错: {e}. 原始数据: {details_dict}")
                continue
    
    # 缓存未命中处理：同步查询数据库并重建缓存
    if missing_ids:
        CCBLog('check_and_trigger_hot_refresh').info(f"DEBUG: 缓存未命中 {len(missing_ids)} 个帖子，同步查询数据库并重建缓存...")
        
        # 从数据库批量查询所有缺失的帖子完整数据 (必须是同步操作)
        from backend.storage.PostDB import PostDB
        db_manager = PostDB()
        posts, _ = db_manager.get_posts_by_ids(missing_ids)

        # 再次使用 Pipeline 批量写入重建的缓存，提高写入性能
        rebuild_pipe = redis.pipeline()

        for post in posts:
            post_id = post['id']

            # A. 立即填充结果列表，保持顺序
            result_map[post_id] = post

            # B. 准备写入缓存 (重建)
            redis_key = f"post:detail:{post_id}"

            redis_post = db_to_redis(post=post)

            rebuild_pipe.hmset(redis_key, redis_post)
            rebuild_pipe.expire(redis_key, POST_TTL_SECONDS)
        rebuild_pipe.execute()
    
    # 最终结果组装 (保证顺序)
    for id_str in raw_ids:
        post_id = int(id_str)
        post_detail = result_map.get(post_id)
        
        if post_detail is not None:
            # 确保只添加成功获取到的帖子
            posts_list.append(post_detail)
                
    return posts_list, total_count

def update_post_cache_by_id(post_id: int):
    from backend.storage.PostDB import PostDB
    db_manager = PostDB()
    post = db_manager.get_posts_by_ids(post_ids=[post_id])[0][0]
    if not post:
        CCBLog('update_post_cache_by_id').error(f"error: post{post_id} does not exist")
        return
    cache_posts(posts=[post])

def cache_posts(posts: List[Dict[str, Any]]):
    key_map = get_global_key_map()
    POST_TTL_SECONDS = key_map.get('POST_TTL_SECONDS')
    redis = get_redis_client()
    pipe = redis.pipeline()
    for post in posts:
        redis_post = db_to_redis(post=post)
        post_id = redis_post['id']
        
        # 定义帖子详情哈希键的格式
        DETAIL_KEY = f"post:detail:{post_id}"
        
        # 使用 HSET 命令设置帖子详情
        # 写入的是经过序列化处理的 serialized_post
        pipe.hset(DETAIL_KEY, mapping=redis_post) 
        
        # 为每个帖子详情哈希键设置 TTL 
        pipe.expire(DETAIL_KEY, POST_TTL_SECONDS)
        CCBLog("cache").info(f'成功缓存post{post_id}, TTL: {POST_TTL_SECONDS}')

    pipe.execute()

def cache_post_ids_by_key(key: str, post_ids: List[Tuple[int, float]], user_id: int = None):
    """
    异步任务：缓存帖子列表的 ID 和帖子的详细内容。
    
    Args:
        key: 缓存键的类型 (如 'time', 'hot').
        post_ids: 帖子id的列表.
    """
    redis = get_redis_client()
    key_map = get_global_key_map()

    # 获取列表键配置
    list_config = key_map.get(key)
    if not list_config:
        # 异常处理：配置未找到
        return

    LIST_KEY = list_config["NAME"]
    MAX_LEN = list_config["MAX_LEN"]
    TTL_SECONDS = list_config["TTL_SECONDS"]
    if key == "recommendation" and user_id is not None:
        LIST_KEY = f"{LIST_KEY}{user_id}"
    
    # ----------------------------------------
    # 1. 准备数据和管道
    # ----------------------------------------
    pipe = redis.pipeline()
    
    # 获取要缓存的 IDs (限制最大长度)
    zadd_params = {str(post_id): score for post_id, score in post_ids[:MAX_LEN]}

    # ----------------------------------------
    # 2. 处理列表键 (LIFO)
    # ----------------------------------------
    # a. 删除旧的 ZSET
    pipe.delete(LIST_KEY)

    # b. 写入新的 ZSET
    if zadd_params:
        # 使用 zadd 添加 Score 和 Member
        pipe.zadd(LIST_KEY, zadd_params)
    
    # c. 设置 ZSET 的 TTL
    pipe.expire(LIST_KEY, TTL_SECONDS)
    CCBLog('cache_post_ids_by_key').info(f'cache list {LIST_KEY} for {TTL_SECONDS}s')

    pipe.execute()

def cache_new_post(post: Dict[str, Any]):
    """
    异步任务：将最新的帖子数据增量推送到列表头部，裁剪列表，并缓存帖子详情。

    Args:
        key: 缓存键的类型 (如 'time').
        post: 包含帖子所有字段的字典（必须包含 'id'）。
    """
    key = 'time'
    redis = get_redis_client()
    key_map = get_global_key_map()
    
    list_config = key_map.get(key)
    if not list_config or 'id' not in post:
        # 配置缺失或帖子数据不完整
        return
    
    cache_posts(posts=[post])

    LIST_KEY = list_config["NAME"]
    MAX_LEN = list_config["MAX_LEN"]
    TTL_SECONDS = list_config["TTL_SECONDS"]
    if not redis.exists(LIST_KEY):
        from backend.cache.tasks import cache_post_ids_task
        CCBLog('cache_new_post').info(f"列表 {key} 对应的 Redis 键 {LIST_KEY} 已过期或不存在。触发全量更新。")
        cache_post_ids_task.delay(key=key, max_len=MAX_LEN)
        return
    
    post_id_str = str(post['id'])
    post_score = float(post['timestamp'])

    pipe = redis.pipeline()

    # 增量推送
    # ZADD 会自动根据 Score 更新或添加
    pipe.zadd(LIST_KEY, {post_id_str: post_score})
    
    # 裁剪列表，移除超出 MAX_LEN 的队尾 ID
    # ❗ 关键：这里只裁剪列表，不删除队尾 ID 对应的 DETAIL_KEY
    pipe.zremrangebyrank(LIST_KEY, MAX_LEN, -1)
    
    # 设置 ID 列表的 TTL
    pipe.expire(LIST_KEY, TTL_SECONDS)

    pipe.execute()

def update_post_detail_count(
    post_id: int, 
    count_type: Literal['like', 'comment', 'browse', 'favorite'], 
    increment: int = 1
) -> bool:
    """
    同步更新 Redis 中帖子详情 (post:detail:{post_id}) 的指定计数。

    Args:
        post_id: 帖子的唯一ID。
        count_type: 要更新的计数类型 ('like', 'comment', 'browse', 'favorite')。
        increment: 计数变化的数值，通常是 1 或 -1。

    Returns:
        如果缓存键存在且更新成功，返回 True；否则返回 False。
    """
    
    # 映射到 Redis Hash 中的字段名
    FIELD_MAP = {
        'like': 'like_count',
        'comment': 'comment_count',
        'browse': 'browse_count',
        'favorite': 'favorite_count'
    }
    
    if count_type not in FIELD_MAP:
        raise ValueError(f"无效的 count_type: {count_type}. 必须是 {list(FIELD_MAP.keys())} 之一。")

    redis = get_redis_client()
    redis_key = f"post:detail:{post_id}"
    field_name = FIELD_MAP[count_type]
    
    try:
        if not redis.exists(redis_key):
            update_post_cache_by_id(post_id=post_id)
            return True
        
        # 使用 HINCRBY 原子地增加 Hash 中的字段值
        # 即使字段不存在，Redis 也会将其视为 0 并加上 increment
        redis.hincrby(redis_key, field_name, increment)
        CCBLog('update_post_detail_count').info(f"成功更新帖子 {post_id} 的 {field_name} 计数: increment={increment}")
        
        return True 

    except Exception as e:
        CCBLog('update_post_detail_count').error(f"ERROR: 无法同步更新帖子 {post_id} 的 {field_name} 计数: {e}")
        # 如果 Redis 操作失败，记录错误，但通常不应中断主业务流程
        return False
    
def delete_post_cache(post_id: int) -> Dict[str, bool]:
    """
    主动删除 Redis 中单个帖子的详情缓存和相关的列表缓存。

    Args:
        post_id: 要删除缓存的帖子 ID。
    Returns:
        Dict: 包含操作结果的字典。
    """
    redis_client = get_redis_client()
    key_map = get_global_key_map()
    
    # 用于记录操作结果
    results = {}
    
    # 1. 帖子详情缓存 KEY
    DETAIL_KEY = f"post:detail:{post_id}"
    PROFILE_KEY = f"item:profile:{post_id}"

    # 使用 Pipeline 批量执行删除操作，提高效率
    pipe = redis_client.pipeline()

    # --- A. 删除帖子详情 Hash Map ---
    pipe.delete(DETAIL_KEY)
    pipe.delete(PROFILE_KEY)
    results['detail_deleted'] = True
    
    # --- B. 移除 ID 在指定列表中的记录 (LREM) ---
    list_keys_to_clean = ["time", "hot"]

    # 将 ID 转换为字符串，因为 Redis 列表中存储的是字符串 ID
    post_id_str = str(post_id)
    
    for key_type in list_keys_to_clean:
        list_config = key_map.get(key_type)
        
        if list_config:
            LIST_KEY = list_config["NAME"]
            
            # 使用 LREM 0 移除列表中所有匹配 post_id_str 的元素
            pipe.zrem(LIST_KEY, post_id_str)
            results[f'list_{key_type}_removed'] = True
        else:
            results[f'list_{key_type}_removed'] = False
            CCBLog('delete_post_cache').warning(f"尝试清理的列表键类型 '{key_type}' 未在 key_map 中配置。")

    # --- C. 清理列表缓存 (如果列表被视为缓存) ---
    # 通常，对于大型列表，我们只移除 ID (LREM)，不会删除整个列表。
    # 如果要实现更激进的列表缓存过期策略，可以在这里添加 expire/delete 逻辑。
    
    try:
        pipe.execute()
        pattern = key_map.get("recommendation")["NAME"] + "*"
        for user_recommendation_key in redis_client.scan_iter(match=pattern):
            redis_client.zrem(user_recommendation_key, post_id_str)
            results[f'list_{user_recommendation_key}_removed'] = True
    except Exception as e:
        results['error'] = str(e)
        CCBLog('delete_post_cache').error(f"Redis 缓存删除操作失败: {e}")
        return results

    return results

def get_or_create_tag_indices(tag_names: List[str]) -> Dict[str, int]:
    """
    同步获取标签的全局索引。如果标签不存在，则创建并更新数据库和缓存。

    :param tag_names: 标签名列表。
    :return: {tag_name: index} 的字典。
    """
    if not tag_names:
        return {}
    
    key_map = get_global_key_map()
    TAG_MAP_KEY = key_map["tag"]["TAG_MAP_KEY"]
    MAX_TAG_INDEX_KEY = key_map["tag"]["MAX_TAG_INDEX_KEY"]

    redis = get_redis_client()
    from backend.storage.PostDB import PostDB
    db_manager = PostDB()

    result_indices: Dict[str, int] = {}
    missing_tag_names: List[str] = []

    # --- 1. Redis 批量读取 (HMGET) ---
    try:
        # HMGET 一次性获取所有标签的值，返回一个列表，顺序与 tag_names 对应
        index_strs = redis.hmget(TAG_MAP_KEY, tag_names)
    except Exception as e:
        CCBLog("tag_index").error(f"Redis HMGET failed for tags: {tag_names}. Error: {e}")
        # 即使 Redis 失败，也必须继续尝试从 DB 获取
        index_strs = [None] * len(tag_names)
    
    # 2. 区分命中/未命中
    for i, tag_name in enumerate(tag_names):
        index_str = index_strs[i]
        if index_str is not None:
            try:
                # 缓存命中
                result_indices[tag_name] = int(index_str)
            except ValueError:
                CCBLog("tag_index").error(f"Redis value corrupted for tag: {tag_name}. Forced DB lookup.")
                missing_tag_names.append(tag_name)
        else:
            # 缓存未命中
            missing_tag_names.append(tag_name)

    # --- 3. 数据库处理未命中的标签 ---
    if missing_tag_names:
        
        # A. DB 批量查询 (获取 DB 中已存在的)
        db_existing_indices = db_manager.batch_get_tag_indices(missing_tag_names)

        tags_to_create = []

        for tag_name in missing_tag_names:
            if tag_name in db_existing_indices:
                # 标签已存在于 DB
                result_indices[tag_name] = db_existing_indices[tag_name]
            else:
                # 标签在 DB 和 Cache 中都不存在
                tags_to_create.append(tag_name)
        
        # B. 逐个同步创建（处理并发和自增ID）
        max_index = 0

        for tag_name in tags_to_create:
            # 必须逐个创建，以保证在并发场景下能正确处理唯一约束和获取自增 ID
            try:
                new_index = db_manager.create_new_tag(tag_name)
                
                if new_index > 0:
                    result_indices[tag_name] = new_index
                    max_index = max(max_index, new_index)
                else:
                    # 如果创建失败（如 create_new_tag 内部捕获了并发创建错误并回查失败）
                    CCBLog("tag_index").error(f"Final insertion into global_tag_map failed for tag: {tag_name}")
                    # 此时无法获取 index，推荐抛出错误终止事务，或用占位符 0
                    raise Exception(f"Final insertion into global_tag_map failed for tag: {tag_name}")
                    
            except Exception as e:
                CCBLog("tag_index").error(f"DB operation failed during tag creation for {tag_name}: {e}")
                raise
        
        # --- 4. Redis 批量回写 (Cache Warming) ---
        tags_to_cache = {
            tag_name: str(index)
            for tag_name, index in result_indices.items()
            if tag_name in missing_tag_names # 只回写从 DB 获取的这些
        }

        if tags_to_cache:
            # 批量 HSET 回写
            redis.hmset(TAG_MAP_KEY, tags_to_cache)

            # 更新 MAX_TAG_INDEX_KEY
            if max_index > 0:
                current_max_str = redis.get(MAX_TAG_INDEX_KEY)
                current_max = int(current_max_str) if current_max_str else 0
                
                if max_index > current_max:
                    # 简单的非原子 SET，因为数据库 ID 已经是最终真相
                    redis.set(MAX_TAG_INDEX_KEY, max_index)

    return result_indices

def cache_item_profile(post_id: int, item_profiles_data: List[Dict[str, Any]]):
    redis = get_redis_client()
    key_map = get_global_key_map()
    ITEM_PROFILE_PREFIX = key_map["item_profile"]["NAME"]
    TTL_SECONDS = key_map["item_profile"]["TTL_SECONDS"]

    redis_key = f"{ITEM_PROFILE_PREFIX}{post_id}"

    hash_data = {}
    for row in item_profiles_data:
        tag_index = str(row['tag_index'])
        tag_value = str(row['tag_value']) 
        
        hash_data[tag_index] = tag_value
    
    redis.hset(redis_key, mapping=hash_data)
    redis.expire(redis_key, TTL_SECONDS)

def get_cached_item_profiles(post_ids: List[int]) -> Dict[int, Dict[int, float]]:
    redis = get_redis_client()
    key_map = get_global_key_map()
    ITEM_PROFILE_PREFIX = key_map["item_profile"]["NAME"]

    # 1. 构造 Redis Key 列表
    redis_keys = [f"{ITEM_PROFILE_PREFIX}{pid}" for pid in post_ids]

    # 2. Redis 批量读取
    pipe = redis.pipeline()
    for key in redis_keys:
        pipe.hgetall(key)
    
    # 批量执行，一次网络往返
    redis_results_raw = pipe.execute()

    # 3. 解析 Redis 结果，并区分命中/未命中
    all_profiles = {}
    missing_post_ids = set()

    for i, raw_data in enumerate(redis_results_raw):
        post_id = post_ids[i]
        
        if raw_data:
            # 命中缓存：解码画像
            all_profiles[post_id] = decode_profile(raw_data)
        else:
            # 未命中：记录下来，准备从 DB 批量加载
            missing_post_ids.add(post_id)
    
    # --- 4. 批量从数据库加载未命中的画像 (Cache Miss) ---
    if missing_post_ids:
        from backend.storage.PostDB import PostDB
        db_manager = PostDB()

        db_profiles_raw = db_manager.batch_get_item_profiles(list(missing_post_ids))

        # 5. 处理 DB 结果，回写缓存
        pipe = redis.pipeline() # 使用新的 Pipeline 进行回写
        TTL_SECONDS = key_map["item_profile"]["TTL_SECONDS"]

        for post_id, db_rows in db_profiles_raw.items():
            if db_rows:
                # 转换格式并回写缓存 (Cache Warming)
                profile_dict = {}
                for row in db_rows:
                    profile_dict[int(row['tag_index'])] = float(row['tag_value'])
                
                all_profiles[post_id] = profile_dict

                # 编码并回写 Redis 缓存
                str_profile = encode_profile(profile_dict)
                
                redis_key = f"{ITEM_PROFILE_PREFIX}{post_id}"
                pipe.hset(redis_key, mapping=str_profile)
                pipe.expire(redis_key, TTL_SECONDS)
        pipe.execute() # 执行缓存回写操作
    
    return all_profiles

def decode_profile(raw_data: Dict[bytes, bytes]) -> Dict[int, float]:
    # 将字节串转换为 {int: float} 字典
    profile_dict = {}
    for tag_index_bytes, score_bytes in raw_data.items():
        try:
            # 索引是整数 (Hash Field)
            tag_index = int(tag_index_bytes)
            # 分数是浮点数 (Hash Value)
            score = float(score_bytes) 
            profile_dict[tag_index] = score
        except (ValueError, UnicodeDecodeError) as e:
            CCBLog("profile").error(f"Data conversion error in Redisprofile: {e}")
            continue
    
    return profile_dict

def encode_profile(profile_dict: Dict[int, float]) -> Dict[str, str]:
    """
    将 Python 字典格式的画像 {int: float} 编码为 Redis Hash Map 所需的 {str: str} 格式。

    Args:
        profile_dict: 画像字典，键为整数 tag_index，值为浮点数 score。

    Returns:
        Redis Hash Map 格式的字典，键和值均为字符串。
    """
    if not profile_dict:
        return {}

    redis_data = {}
    
    for tag_index, score in profile_dict.items():
        try:
            # 1. 键 (tag_index): 转换为字符串
            tag_index_str = str(tag_index)
            
            # 2. 值 (score): 转换为字符串，并保留一定的精度
            # round(score, 4) 是为了在存储时控制浮点数精度，避免不必要的冗余
            score_str = str(round(score, 4)) 
            
            redis_data[tag_index_str] = score_str
            
        except Exception as e:
            # 如果 tag_index 或 score 的类型意外错误，记录并跳过
            CCBLog("profile").error(f"Error encoding profile data: {e}, index={tag_index}, score={score}")
            continue
            
    return redis_data

def update_user_profile(user_id: int, post_id: int, increment: float):
    item_profiles_map = get_cached_item_profiles(post_ids=[post_id])
    item_profile = item_profiles_map.get(post_id)

    from backend.storage.PostDB import PostDB
    db_manager = PostDB()
    redis = get_redis_client()
    key_map = get_global_key_map()
    redis_key = f'{key_map["user_profile"]["NAME"]}{user_id}'
    TTL_SECONDS = key_map["user_profile"]["TTL_SECONDS"]


    MAX_RETRIES = 5 # 最大重试次数
    for attempt in range(MAX_RETRIES):
        try:
            # --- WATCH 事务开始 ---
            with redis.pipeline() as pipe:
                pipe.watch(redis_key) # 监视用户画像 Key，如果在 WATCH 期间 Key 被修改，EXEC 会失败

                # A. 读取用户画像 (从缓存)
                raw_data = redis.hgetall(redis_key)
            
            # B. 处理数据 (在事务块外处理 CPU 密集型计算)
            if not raw_data:
                user_profile = db_manager.get_user_profile(user_id) or {}
            else:
                user_profile = decode_profile(raw_data)

            # C. 计算新画像
            for tag_index, item_value in item_profile.items():
                # 获取旧分数，如果没有则为 0.0
                score = user_profile.get(tag_index, 0.0)
                user_profile[tag_index] = score + increment * item_value
            
            # D. 写入 Redis 缓存 (必须是原子性操作，将写入放在 MULTI/EXEC 块中)
            # 重启管道并开始事务
            with redis.pipeline() as pipe:
                pipe.multi()
                # 字典键和值必须是字符串！
                str_profile = encode_profile(user_profile)
                
                # 1. 缓存新画像
                pipe.hset(redis_key, mapping=str_profile)
                pipe.expire(redis_key, TTL_SECONDS)
                
                # 2. 尝试执行事务
                pipe.execute()

            # E. 写入 DB (非原子性，但持久化)
            CCBLog("user_profile").info(f"User {user_id} profile updating on db.")
            db_manager.batch_update_user_profiles(user_id=user_id, user_profile_new=user_profile)
            
            CCBLog("user_profile").info(f"User {user_id} profile updated successfully on attempt {attempt + 1}.")
            return # 成功，退出循环
        
        except WatchError:
            # 竞争失败：在 WATCH 和 EXEC 之间 Key 被其他进程修改了
            CCBLog("user_profile").warning(f"User {user_id} profile update conflict. Retrying... (Attempt {attempt + 1})")
            time.sleep(0.1 * (attempt + 1)) # 简单退避策略

        except Exception as e:
            CCBLog("user_profile").error(f"Fatal non-WatchError during user {user_id} update: {e}")
            raise # 抛出其他异常，交给 Celery 自动重试
    
    CCBLog("user_profile").error(f"User {user_id} profile update failed after {MAX_RETRIES} retries.")
    raise Exception("User profile update failed due to persistent concurrency conflicts.")

def get_cached_user_profile(user_id: int) -> Dict[int, float]:
    redis = get_redis_client()
    key_map = get_global_key_map()
    redis_key = f'{key_map["user_profile"]["NAME"]}{user_id}'
    TTL_SECONDS = key_map["user_profile"]["TTL_SECONDS"]

    user_profile = redis.hgetall(redis_key)
    if not user_profile:
        from backend.storage.PostDB import PostDB
        db_manager = PostDB()
        user_profile = db_manager.get_user_profile(user_id=user_id)
        if not user_profile:
            return user_profile
        str_profile = encode_profile(user_profile)
        pipe = redis.pipeline()
        pipe.hset(redis_key, mapping=str_profile)
        pipe.expire(redis_key, TTL_SECONDS)
        pipe.execute()
    else:
        user_profile = decode_profile(user_profile)
    return user_profile

def get_candidate_post_ids(limit: int) -> List[int]:
    from backend.storage.PostDB import PostDB
    db_manager = PostDB()
    redis = get_redis_client()
    key_map = get_global_key_map()
    
    LATEST_KEY = key_map["time"]["NAME"]
    HOT_KEY = key_map["hot"]["NAME"]

    keys_to_process = [
        {'key': LATEST_KEY, 'order': 'time'},
        {'key': HOT_KEY, 'order': 'hot'}
    ]
    
    candidate_set = set()
    pipe = redis.pipeline()
    for item in keys_to_process:
        pipe.zrevrange(item['key'], 0, limit - 1)
    redis_results = pipe.execute()
    # CCBLog('get_candidate_post_ids').info(f'redis_results: {redis_results}')

    for i, post_ids_raw in enumerate(redis_results):
        if post_ids_raw:
            for post_id_bytes in post_ids_raw:
                candidate_set.add(int(post_id_bytes))
        else:
            order = keys_to_process[i]['order']
            post_ids = db_manager.get_post_ids_by_args_ordered_by_arg(
                order=order, limit=limit, offset=0
            )
            cache_post_ids_by_key(key=order, post_ids=post_ids)
            for post_id in post_ids:
                candidate_set.add(post_id[0])
    # CCBLog('get_candidate_post_ids').info(f'candidate_set: {candidate_set}')
    return list(candidate_set)

def refresh_recommendations(user_id: int):
    redis = get_redis_client()
    key_map = get_global_key_map()
    key = "recommendation"
    MAX_LEN = key_map[key]["MAX_LEN"]

    from backend.services.post.Post import get_recall_post_ids
    recommend_post_ids = get_recall_post_ids(user_id=user_id, recall_limit=MAX_LEN)
    if recommend_post_ids:
        cache_post_ids_by_key(key=key, post_ids=recommend_post_ids, user_id=user_id)
