import json
# TODO: 给定文件名，读出来内容返回

class ConfigReader:
    def __init__(self, file_path):
        self.file_path = file_path

    def read_config(self):
        """
            读取配置文件
            return : 一个 JSON 对象
        """
        try:
            with open(self.file_path, 'r', encoding='utf-8') as file:
                content = file.read()
                return json.loads(content)
        except FileNotFoundError:
            raise Exception(f"配置文件 {self.file_path} 未找到")
        except json.JSONDecodeError as e:
            raise Exception(f"配置文件不是有效的 JSON 格式: {e}")
        except Exception as e:
            raise Exception(f"读取配置文件出错: {e}")