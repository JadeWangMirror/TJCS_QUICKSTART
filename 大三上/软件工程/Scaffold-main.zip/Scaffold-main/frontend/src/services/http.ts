/**
 * HTTP 客户端 - 基于 axios 的实际实现
 */
import axios, { type AxiosRequestConfig } from 'axios'

// 创建 axios 实例
const axiosInstance = axios.create({
  //  baseURL: 'http://bdh.aoinatsu.com:80',
  baseURL: 'http://ccb.aoinatsu.com',
   timeout: 95000,
    headers: { 'Content-Type': 'application/json', }, 
  })

// 请求拦截器 - 自动添加 token
axiosInstance.interceptors.request.use(
  (config) => {
    // 从 localStorage 获取 token
    const token = localStorage.getItem('access_token')
    
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`
    }
    
    return config
  },
  (error) => {
    return Promise.reject(error)
  },
)

// 响应拦截器 - 统一处理错误
axiosInstance.interceptors.response.use(
  (response) => {
    return response.data // 直接返回 data 部分
  },
  (error) => {
    if (error.response) {
      // 服务器返回错误
      const { status, data } = error.response
      
      if (status === 401) {
        // Token 过期或无效，清除本地存储并跳转到登录页
        localStorage.removeItem('access_token')
        localStorage.removeItem('refresh_token')
        
        // 如果不在登录页，跳转到登录页
        if (window.location.pathname !== '/auth/login') {
          window.location.href = '/auth/login'
        }
      }
      
      // 返回服务器的错误信息
      return Promise.reject({
        message: data?.message || '请求失败',
        status,
        data,
      })
    } else if (error.request) {
      // 请求已发出但没有收到响应
      return Promise.reject({
        message: '网络错误，请检查您的网络连接',
        status: 0,
      })
    } else {
      // 其他错误
      return Promise.reject({
        message: error.message || '未知错误',
        status: 0,
      })
    }
  },
)

export interface HttpRequestOptions<TBody = unknown> {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE'
  body?: TBody
  headers?: Record<string, string>
  auth?: boolean // 是否需要认证（默认 true）
}

export const httpClient = async <TResponse>(
  endpoint: string,
  { method = 'GET', body, headers, auth = true }: HttpRequestOptions = {},
): Promise<TResponse> => {
  const config: AxiosRequestConfig = {
    method,
    url: endpoint,
    data: body,
    headers: {
      ...headers,
    },
  }
  
  // 如果不需要认证，移除 Authorization header
  if (!auth && config.headers) {
    delete config.headers.Authorization
  }
  
  try {
    const response = await axiosInstance.request<unknown, TResponse>(config)
    return response
  } catch (error) {
    // 错误已经在拦截器中处理
    throw error
  }
}
