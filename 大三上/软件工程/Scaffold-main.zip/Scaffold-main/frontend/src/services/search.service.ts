import { searchApi } from "@/api/search.api";
import type { SearchPostResult } from "@/types/models";
import { type ApiResult } from "@/types/api";

export const searchService = {
  async searchPosts(
    user_id: number,
    query: string,
    type: string,
    limit: number = 10,
    offset: number = 0
  ): Promise<ApiResult<{ posts: SearchPostResult[]; count: number }>> {
    try {
      const apiResponse = await searchApi.searchPosts(user_id, query, type, limit, offset);
      return {
        success: true,
        message: "搜索成功",
        data: {
          posts: apiResponse.posts,
          count: apiResponse.count,
        },
      };
    } catch (error) {
      let errorMessage = "搜索失败，请检查网络或稍后重试。";
      if (typeof error === "object" && error !== null && "message" in error) {
        errorMessage = (error as { message: string }).message;
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }

      console.error("search posts failed:", error);
      return {
        success: false,
        message: errorMessage,
        data: null as any,
      };
    }
  },
};
