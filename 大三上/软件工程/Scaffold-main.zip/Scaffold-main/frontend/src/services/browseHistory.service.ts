import { browseHistoryApi } from "@/api/browseHistory";
import { type ApiResult, type SearchFilters } from "@/types/api";
import type { PostHistoryResponse } from "@/types/api-response";
export const browseHistoryService = {
  /**
   * 查看历史纪录
   */
  async FetchBrowseHistory(
    user_id: number,
    filters?: SearchFilters
  ): Promise<ApiResult<PostHistoryResponse>> {
    try {
      // 调用 API 层的方法
      // console.log(user_id)
      const apiResponse = await browseHistoryApi.FetchBrowseHistory(user_id,filters);
      return {
        success: true,
        data: apiResponse,
      };
    } catch (error) {
      let errorMessage = "查看失败，请检查网络或稍后重试。";
      if (typeof error === "object" && error !== null && "message" in error) {
        errorMessage = (error as { message: string }).message;
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }

      console.error("get browse history failed:", error);
      return {
        success: false,
        message: errorMessage,
        data: null as any,
      };
    }
  },
  async DeleteBrowseHistory(
    user_id: number,
    record_id: number
  ): Promise<ApiResult<{ data: null }>> {
    try {
      // console.log(`Service: Deleting comment ${record_id}`);
      const apiResponse = await browseHistoryApi.DeleteBrowseHistory(
        user_id,
        record_id
      );
      return {
        success: true,
        message: apiResponse.message || "成功删除浏览记录",
        data: null,
      };
    } catch (error) {
      let errorMessage = "删除浏览记录失败，请检查网络或稍后重试。";
      if (typeof error === "object" && error !== null && "message" in error) {
        errorMessage = (error as { message: string }).message;
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }

      console.error("delete post failed:", error);
      return {
        success: false,
        message: errorMessage,
        data: null,
      };
    }
  },
  async DeleteAllBrowseHistory(
    user_id: number
  ): Promise<ApiResult<{ data: null }>> {
    try {
      const apiResponse = await browseHistoryApi.DeleteAllBrowseHistory(
        user_id
      );
      return {
        success: true,
        message: apiResponse.message || "成功删除浏览记录",
        data: null,
      };
    } catch (error) {
      let errorMessage = "删除浏览记录失败，请检查网络或稍后重试。";
      if (typeof error === "object" && error !== null && "message" in error) {
        errorMessage = (error as { message: string }).message;
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }

      console.error("delete post failed:", error);
      return {
        success: false,
        message: errorMessage,
        data: null,
      };
    }
  },
};
