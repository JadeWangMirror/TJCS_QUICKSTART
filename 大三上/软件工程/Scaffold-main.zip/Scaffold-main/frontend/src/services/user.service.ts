import type { UserSummary } from '@/types/models'
import { userApi, type UpdateUserPayload, type UpdateUserResponse } from '@/api/user.api'
import axios from 'axios'

// -------------------------------------------------------------
// Service 层类型定义
// -------------------------------------------------------------
import { httpClient } from '@/utils/httpClients'

export interface RawUser {
  id?: number | string | null
  name?: string | null
  nickname?: string | null
  introduce?: string | null
  bio?: string | null
  tag?: string[] | null
  tags?: string[] | null
  created_at?: string | null
  createdAt?: string | null
  joined_at?: string | null
  joinedAt?: string | null
  avatarUrl?: string | null
  avatar_url?: string | null
  email?: string | null
  followers?: number | null
  following?: number | null
  role?: string | null
  status?: string | null
}

// 重新导出 API 层的类型以便外部使用
export type { UpdateUserPayload, UpdateUserResponse } from '@/api/user.api'

export interface UserProfileResult {
  success: boolean
  user: UserSummary | null
  message?: string
}

// -------------------------------------------------------------
// Service 层实现
// -------------------------------------------------------------

const normalizeUserSummary = (raw?: RawUser | null): UserSummary | null => {
  if (!raw) return null

  const numericId =
    typeof raw.id === 'string'
      ? Number.parseInt(raw.id, 10)
      : typeof raw.id === 'number'
        ? raw.id
        : NaN

  const tags =
    Array.isArray(raw.tag) && raw.tag.length > 0
      ? raw.tag
      : Array.isArray(raw.tags) && raw.tags.length > 0
        ? raw.tags
        : []

  const resolvedCreatedAt =
    raw.created_at ??
    raw.createdAt ??
    raw.joined_at ??
    raw.joinedAt ??
    null

  return {
    id: Number.isNaN(numericId) ? 0 : numericId,
    name: raw.name ?? raw.nickname ?? '',
    introduce: raw.introduce ?? raw.bio ?? '',
    tag: tags,
    created_at: resolvedCreatedAt ?? new Date().toISOString(),
    avatarUrl: raw.avatarUrl ?? raw.avatar_url ?? null,
    email: raw.email ?? null,
    followers: raw.followers ?? undefined,
    following: raw.following ?? undefined,
    role: raw.role ?? null,
    status: raw.status ?? null,
  }
}

const toResult = (user: RawUser | null | undefined, message?: string): UserProfileResult => {
  const normalized = normalizeUserSummary(user)
  return {
    success: Boolean(normalized),
    user: normalized,
    message,
  }
}

export const userService = {
  /**
   * 获取当前用户信息
   */
  async getCurrentUserProfile(): Promise<UserProfileResult> {
    try {
      const response = await userApi.getCurrentUserProfile()

      if (!response.success) {
        return {
          success: false,
          user: null,
          message: response.message || '获取用户信息失败',
        }
      }

      return toResult(response.data?.user, response.message)
    } catch (error) {
      let errorMessage = '获取用户信息失败'
      if (axios.isAxiosError(error)) {
        errorMessage =
          error.response?.data?.message ||
          `请求失败，状态码: ${error.response?.status || 'N/A'}`
      } else if (error instanceof Error) {
        errorMessage = error.message
      }

      console.error('获取当前用户信息失败:', error)
      return {
        success: false,
        user: null,
        message: errorMessage,
      }
    }
  },

  /**
   * 获取指定用户信息
   */
  async getUserProfile(userId: number | string): Promise<UserProfileResult> {
    try {
      const response = await userApi.getUserProfile(userId)

      if (response.status !== 'success') {
        return {
          success: false,
          user: null,
          message: response.message || '获取用户信息失败',
        }
      }

      return toResult(response.user, response.message)
    } catch (error) {
      let errorMessage = '获取用户信息失败'
      if (axios.isAxiosError(error)) {
        errorMessage =
          error.response?.data?.message ||
          `请求失败，状态码: ${error.response?.status || 'N/A'}`
      } else if (error instanceof Error) {
        errorMessage = error.message
      }

      console.error(`获取用户信息失败 (userId: ${userId}):`, error)
      return {
        success: false,
        user: null,
        message: errorMessage,
      }
    }
  },

  /**
   * 更新用户信息
   */
  async updateUserProfile(
    userId: number | string,
    payload: UpdateUserPayload
  ): Promise<UpdateUserResponse> {
    try {
      const response = await userApi.updateUserProfile(userId, payload)
      return response
    } catch (error) {
      let errorMessage = '更新用户信息失败'
      if (axios.isAxiosError(error)) {
        errorMessage =
          error.response?.data?.message ||
          `请求失败，状态码: ${error.response?.status || 'N/A'}`
      } else if (error instanceof Error) {
        errorMessage = error.message
      }

      console.error(`更新用户信息失败 (userId: ${userId}):`, error)
      return {
        success: false,
        message: errorMessage,
      }
    }
  },
}
