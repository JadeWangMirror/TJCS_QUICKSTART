import { httpClient } from '@/utils/httpClients'
import type {
  OptimizationDetailResponse,
  OptimizationHistoryResponse,
  OptimizePromptResponse
} from '@/types/ai'
import { useAuthStore } from "@/store/modules/auth"

export const promptAPI = {
  async optimize(prompt: string): Promise<OptimizePromptResponse> {
    const authStore = useAuthStore()
  
    const user_id = authStore.currentUser?.id
    if (!user_id) {
      throw new Error("User not authenticated.")
    }
    
    const response = await httpClient<OptimizePromptResponse>('/api/optimize', {
      method: 'POST',
      body: JSON.stringify({ 
        prompt,
        user_id
      }),
      headers: {
        'Content-Type': 'application/json',
      },
    })
    return response
  },

  async getHistory(): Promise<OptimizationHistoryResponse> {
    const authStore = useAuthStore()
    const user_id = authStore.currentUser?.id
    if (!user_id) {
      throw new Error("User not authenticated.")
    }
    
    const response = await httpClient<OptimizationHistoryResponse>(`/api/user/${user_id}/history/ai`, {
      method: 'GET',
    })
    return response
  },

  async getHistoryDetail(id: string | number): Promise<OptimizationDetailResponse> {
    const authStore = useAuthStore()
    const user_id = authStore.currentUser?.id
    if (!user_id) {
      throw new Error("User not authenticated.")
    }
    
    const response = await httpClient<OptimizationDetailResponse>(`/api/user/${user_id}/history/ai/${id}`, {
      method: 'GET',
    })
    return response
  },

  async getStatistics<T = unknown>(): Promise<T> {
    const response = await httpClient<T>('/api/statistics', {
      method: 'GET',
    })
    return response
  },

  async healthCheck<T = unknown>(): Promise<T> {
    const response = await httpClient<T>('/api/health', {
      method: 'GET',
    })
    return response
  }
}