import type { RawUser } from "./user.service";
import { recommendationsApi } from "@/api/recommendations.api";
import { userApi, type ApiUserResponse } from "@/api/user.api";
import axios from "axios";
import type { PostSummary, PostDetail, UserSummary } from "@/types/models";
import {
  type SearchFilters,
  type ApiResult,
  type PaginatedResponse,
} from "@/types/api";
import type { ApiPostsListResponse } from "@/types/api-response";
import { PostListApi } from "@/api/PostList.api";

export const recommendationService = {
  /**
   * 通用帖子列表获取函数（处理 N+1 查询问题和数据映射）
   */
  async fetchFeed(
    user_id: number | undefined,
    endpoint: "newest" | "hotest" | "recommend",
    filters?: SearchFilters
  ): Promise<ApiResult<ApiPostsListResponse>> {
    const pageSize = filters?.pageSize || 10;
    const page = filters?.page || 1;

    try {
      // 1. 获取帖子列表
      const apiResponse = await recommendationsApi.fetchPosts(
        user_id,
        endpoint,
        pageSize,
        page
      );
      return {
        success: true,
        message: `Successfully fetched ${endpoint} feed.`,
        data: apiResponse,
      };
    } catch (error) {
      let errorMessage = "An unknown error occurred.";
      if (axios.isAxiosError(error)) {
        errorMessage =
          error.response?.data?.message ||
          `Request failed with status ${error.response?.status || "N/A"}.`;
      } else {
        errorMessage = (error as Error).message;
      }

      console.error(`Fetch ${endpoint} feed failed:`, error);
      return {
        success: false,
        message: errorMessage,
        data: null as any,
      };
    }
  },

  // --- 接口封装 ---

  async fetchNewestFeed(
    user_id: number | undefined,
    filters?: SearchFilters
  ): Promise<ApiResult<ApiPostsListResponse>> {
    return this.fetchFeed(user_id, "newest", filters);
  },

  async fetchHottestFeed(
    user_id: number | undefined,
    filters?: SearchFilters
  ): Promise<ApiResult<ApiPostsListResponse>> {
    return this.fetchFeed(user_id, "hotest", filters);
  },

  async fetchRecommendedFeed(
    user_id: number,
    filters?: SearchFilters
  ): Promise<ApiResult<ApiPostsListResponse>> {
    return this.fetchFeed(user_id, "recommend", filters);
  },
  async fetchMyPosts(
    user_id: number,
    filters?: SearchFilters
  ): Promise<ApiResult<ApiPostsListResponse>> {
    const pageSize = filters?.pageSize || 10;
    const page = filters?.page || 1;

    try {
      // 1. 获取帖子列表
      const apiResponse = await PostListApi.fetchPosts(user_id, pageSize, page);
      return {
        success: true,
        message: `Successfully fetched feed.`,
        data: apiResponse,
      };
    } catch (error) {
      let errorMessage = "An unknown error occurred.";
      if (axios.isAxiosError(error)) {
        errorMessage =
          error.response?.data?.message ||
          `Request failed with status ${error.response?.status || "N/A"}.`;
      } else {
        errorMessage = (error as Error).message;
      }

      console.error(`Fetch My feed failed:`, error);
      return {
        success: false,
        message: errorMessage,
        data: null as any,
      };
    }
  },
  async fetchFavoritePosts(
    user_id: number,
    filters?: SearchFilters
  ): Promise<ApiResult<ApiPostsListResponse>> {
    const pageSize = filters?.pageSize || 10;
    const page = filters?.page || 1;

    try {
      // 1. 获取帖子列表
      const apiResponse = await PostListApi.fetchFavoritePosts(
        user_id,
        pageSize,
        page
      );
      return {
        success: true,
        message: `Successfully fetched feed.`,
        data: apiResponse,
      };
    } catch (error) {
      let errorMessage = "An unknown error occurred.";
      if (axios.isAxiosError(error)) {
        errorMessage =
          error.response?.data?.message ||
          `Request failed with status ${error.response?.status || "N/A"}.`;
      } else {
        errorMessage = (error as Error).message;
      }

      console.error(`Fetch My feed failed:`, error);
      return {
        success: false,
        message: errorMessage,
        data: null as any,
      };
    }
  },
};
