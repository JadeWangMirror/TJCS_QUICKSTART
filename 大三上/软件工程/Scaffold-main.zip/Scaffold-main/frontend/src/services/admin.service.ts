import type { ApiResult, PaginatedResponse } from '@/types/api'
import type { AdminStatistic, PostSummary, UserSummary } from '@/types/models'

import { httpClient } from '@/utils/httpClients'

export const adminService = {
  async fetchUsers(page = 1) {
    return httpClient<ApiResult<PaginatedResponse<UserSummary>>>('/api/admin/users', {
      method: 'GET',
      body: { page },
    })
  },

  async updateUserStatus(userId: string, status: 'active' | 'blocked') {
    return httpClient<ApiResult<UserSummary>>(`/api/admin/users/${userId}/status`, {
      method: 'PATCH',
      body: { status },
    })
  },

  async fetchPendingContent() {
    return httpClient<ApiResult<PostSummary[]>>('/api/admin/content/pending')
  },

  async reviewContent(contentId: string, action: 'approve' | 'reject') {
    return httpClient<ApiResult<boolean>>(`/api/admin/content/${contentId}`, {
      method: 'POST',
      body: { action },
    })
  },

  async fetchStatistics() {
    return httpClient<ApiResult<AdminStatistic[]>>('/api/admin/statistics')
  },
}
