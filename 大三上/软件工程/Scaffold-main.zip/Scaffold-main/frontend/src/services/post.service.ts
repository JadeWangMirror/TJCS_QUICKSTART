import { postApi } from "@/api/post.api";
import type { PostDetailWithStatus, PostFormPayload, SearchPostResult } from "@/types/models";
import { type ApiResult, type SearchFilters } from "@/types/api";
import { useAuthStore } from "@/store";
import { fileApi } from "@/api/file.api";
import type { ApiPostsListResponse } from "@/types/api-response";
import { PostListApi } from "@/api/PostList.api";
// -------------------------------------------------------------
// Service 层实现
// -------------------------------------------------------------

export const postService = {
  /**
   * 创建帖子
   */
  async createPost(
    user_id: number,
    payload: PostFormPayload
  ): Promise<ApiResult<{ postId: number; image_urls: string[] }>> {
    const formData = new FormData();
    formData.append("title", payload.title);
    formData.append("context", payload.context);
    formData.append("author_name",useAuthStore().currentUser!.name);
    if (payload.tags && payload.tags.length > 0) {
      payload.tags.forEach((tag) => {
        formData.append("tags", tag);
      });
    }
    if (payload.files && payload.files.length > 0) {
      try {
        const results = await fileApi.fileToUrl(payload.files);
        if (results.status=='success') {
          results.data.forEach((result) => {
            formData.append("files", result);
          });
        } else {
          console.error("API 未按预期返回数组:", results.data);
        }
      } catch (error) {
        console.error("处理文件时发生错误:", error);
      }
    }
    try {
      // 调用 API 层的方法
      const apiResponse = await postApi.createPost(user_id, formData);

      return {
        success: true,
        message: apiResponse.message || "成功创建帖子！",
        data: {
          postId: apiResponse.post_id,
          image_urls: apiResponse.image_urls,
        },
      };
    } catch (error) {
      // **关键优化点：简化错误捕获**
      let errorMessage = "创建帖子失败，请检查网络或稍后重试。";

      // 假设 httpClient 抛出的是包含 message 的对象
      if (typeof error === "object" && error !== null && "message" in error) {
        errorMessage = (error as { message: string }).message;
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }

      console.error("Create post failed:", error);
      return {
        success: false,
        message: errorMessage,
        data: null as any, // 保持与你代码一致的类型处理
      };
    }
  },
  async fetchPostDetailAndStatus(
    postId: number
  ): Promise<ApiResult<PostDetailWithStatus>> {
    try {
      let userId = useAuthStore().currentUser?.id;
      if(userId==undefined){
        userId=0;
      }
      // 协调两个 API 调用
      const detail = await postApi.fetchPostDetail(postId,userId); // 返回 PostDetail
      let statusResponse: { is_liked: boolean } = { is_liked: false };
      let favoriteStatusResponse:{is_favorited:boolean}={is_favorited:false};
      if (userId) {
        statusResponse = await postApi.getLikeStatus(userId, postId); // 返回 { is_liked: boolean }
        favoriteStatusResponse=await postApi.getfavoriteStatus(userId,postId);
      }
      // 整合数据
      const combinedData: PostDetailWithStatus = {
        ...detail.data,
        is_liked: statusResponse.is_liked,
        is_favorited:favoriteStatusResponse.is_favorited
      } as PostDetailWithStatus;
      return {
        success: true,
        message: "详情与状态获取成功",
        data: combinedData,
      };
    } catch (error) {
      console.error("fetchPostDetailAndStatus failed:", error);
      return { success: false, message: "获取帖子详情失败", data: null as any };
    }
  },

  /**
   * 更新帖子
   */
  async updatePost(
    user_id: number,
    post_id: number,
    payload: PostFormPayload
  ): Promise<ApiResult<{ data: null }>> {
    
    const formData = new FormData();
    formData.append("title", payload.title);
    formData.append("context", payload.context);
    if (payload.tags && payload.tags.length > 0) {
      payload.tags.forEach((tag) => {
        formData.append("tags", tag);
      });
    }
    if (payload.url_list && payload.url_list.length > 0) {
      payload.url_list.forEach((url) => {
        formData.append("files", url);
      });
    }
    if (payload.files && payload.files.length > 0) {
      try {
        const results = await fileApi.fileToUrl(payload.files);
        if (results.status=='success') {
          results.data.forEach((result) => {
            formData.append("files", result);
          });
        } else {
          console.error("API 未按预期返回数组:", results);
        }
      } catch (error) {
        console.error("处理文件时发生错误:", error);
      }
    }
    try {
      const apiResponse = await postApi.updatePost(user_id, post_id, formData);
      return {
        success: true,
        message: apiResponse.message || "成功更新帖子",
        data: null,
      };
    } catch (error) {
      let errorMessage = "更新帖子失败，请检查网络或稍后重试。";
      if (typeof error === "object" && error !== null && "message" in error) {
        errorMessage = (error as { message: string }).message;
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }

      console.error("delete post failed:", error);
      return {
        success: false,
        message: errorMessage,
        data: null,
      };
    }
  },
  /**
   * 删除帖子
   */
  async deletePost(
    user_id: number,
    post_id: number
  ): Promise<ApiResult<{ data: null }>> {
    try {
      // console.log(`Service: Deleting post ${post_id}`);
      const apiResponse = await postApi.deletePost(user_id, post_id);
      return {
        success: true,
        message: apiResponse.message || "成功删除帖子",
        data: null,
      };
    } catch (error) {
      let errorMessage = "删除帖子失败，请检查网络或稍后重试。";
      if (typeof error === "object" && error !== null && "message" in error) {
        errorMessage = (error as { message: string }).message;
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }

      console.error("delete post failed:", error);
      return {
        success: false,
        message: errorMessage,
        data: null,
      };
    }
  },
  async likePost(
    user_id: number,
    post_id: number
  ): Promise<
    ApiResult<{ postId: number; isLike: boolean; likeCount: number }>
  > {
    try {
      const apiResponse = await postApi.likePost(user_id, post_id);
      return {
        success: true,
        message: apiResponse.message || "成功点赞帖子",
        data: {
          postId: apiResponse.post_id,
          isLike: apiResponse.is_liked,
          likeCount: apiResponse.like_count,
        },
      };
    } catch (error) {
      let errorMessage = "点赞帖子失败，请检查网络或稍后重试。";
      if (typeof error === "object" && error !== null && "message" in error) {
        errorMessage = (error as { message: string }).message;
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }

      console.error("like post failed:", error);
      return {
        success: false,
        message: errorMessage,
        data: null as any,
      };
    }
  },
  async favoritePost(
    user_id: number,
    post_id: number
  ): Promise<
    ApiResult<{ postId: number; isFavorited: boolean; favorite_count: number }>
  > {
    try {
      const apiResponse = await postApi.favoritePost(user_id, post_id);
      return {
        success: true,
        message: apiResponse.message || "成功收藏帖子",
        data: {
          postId: apiResponse.post_id,
          isFavorited: apiResponse.is_favorited,
          favorite_count: apiResponse.favorite_count,
        },
      };
    } catch (error) {
      let errorMessage = "收藏帖子失败，请检查网络或稍后重试。";
      if (typeof error === "object" && error !== null && "message" in error) {
        errorMessage = (error as { message: string }).message;
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }

      console.error("favorite post failed:", error);
      return {
        success: false,
        message: errorMessage,
        data: null as any,
      };
    }
  },
};
