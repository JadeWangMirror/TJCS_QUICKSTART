import { commentApi } from "@/api/comment.api";
import type { CommentFormPayload } from "@/types/models";
import { type ApiResult } from "@/types/api";
import { fileApi } from "@/api/file.api";

export const commentService = {
  /**
   * 创建评论
   */
  async createComment(
    user_id: number,
    post_id: number,
    payload: CommentFormPayload,
  ): Promise<ApiResult<{ commentId: number; image_urls: string[] }>> {
    const formData = new FormData();
    formData.append("context", payload.context);
    if (payload.files && payload.files.length > 0) {
      try {
        const results = await fileApi.fileToUrl(payload.files);
        if (results.status == "success") {
          results.data.forEach((result) => {
            formData.append("files", result);
          });
        } else {
          console.error("API 未按预期返回数组:", results.data);
        }
      } catch (error) {
        console.error("处理文件时发生错误:", error);
      }
    }
    if (payload.point_id) {
      formData.append("point_id", payload.point_id.toString());
    }
    try {
      // 调用 API 层的方法
      const apiResponse = await commentApi.createComment(
        user_id,
        post_id,
        formData
      );

      return {
        success: true,
        message: apiResponse.message || "成功创建评论！",
        data: {
          commentId: apiResponse.comment_id,
          image_urls: apiResponse.url_list,
        },
      };
    } catch (error) {
      // **关键优化点：简化错误捕获**
      let errorMessage = "创建评论失败，请检查网络或稍后重试。";
      if (typeof error === "object" && error !== null && "message" in error) {
        errorMessage = (error as { message: string }).message;
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }

      console.error("Create post failed:", error);
      return {
        success: false,
        message: errorMessage,
        data: null as any,
      };
    }
  },
  async deleteComment(
      user_id: number,
      comment_id: number
    ): Promise<ApiResult<{ data: null }>> {
      try {
        // console.log(`Service: Deleting comment ${comment_id}`);
        const apiResponse = await commentApi.deleteComment(user_id, comment_id);
        return {
          success: true,
          message: apiResponse.message || "成功删除帖子",
          data: null,
        };
      } catch (error) {
        let errorMessage = "删除帖子失败，请检查网络或稍后重试。";
        if (typeof error === "object" && error !== null && "message" in error) {
          errorMessage = (error as { message: string }).message;
        } else if (error instanceof Error) {
          errorMessage = error.message;
        }
  
        console.error("delete post failed:", error);
        return {
          success: false,
          message: errorMessage,
          data: null,
        };
      }
    },
};
