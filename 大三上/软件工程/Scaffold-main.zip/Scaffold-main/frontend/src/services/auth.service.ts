import type { ApiResult, AuthTokens } from '@/types/api'
import type { UserSummary } from '@/types/models'

import { httpClient } from '@/utils/httpClients'

export interface LoginPayload {
  name: string
  password: string
}

export interface RegisterPayload {
  name: string
  email: string
  verification_code: string
  password: string
  introduce?: string
  tag?: string[]
}

// 后端登录返回格式
export interface LoginResponse {
  status: string
  message: string
  user_id: number
  token: string
  expires_in: number
}

// 后端注册返回格式
export interface RegisterResponse {
  status: string
  message: string
  user_id: number
}

export interface SendCodeResponse {
  status: string
  message: string
}

export interface ResetPasswordPayload {
  email: string
  new_password: string
  verification_code: string
}

export interface ResetPasswordResponse {
  status: string
  message: string
}

export const authService = {
  async sendVerificationCode(email: string) {
    return httpClient<SendCodeResponse>('/api/user/send-code', {
      method: 'POST',
      body: { email },
      auth: false,
    })
  },

  async login(payload: LoginPayload) {
    return httpClient<LoginResponse>('/api/user/login', {
      method: 'POST',
      body: payload,
      auth: false,
    })
  },

  async register(payload: RegisterPayload) {
    return httpClient<RegisterResponse>('/api/user/register', {
      method: 'POST',
      body: payload,
      auth: false,
    })
  },

  async logout() {
    return httpClient<ApiResult<boolean>>('/api/user/logout', { method: 'POST' })
  },

  async forgotPassword(email: string) {
    return httpClient<ApiResult<boolean>>('/api/user/forgot-password', {
      method: 'POST',
      body: { email },
      auth: false,
    })
  },

  async resetPassword(payload: ResetPasswordPayload) {
    // Authorization 是可选的，所以使用 auth: false
    // 即使已登录用户修改密码，也会通过邮箱验证码验证身份
    return httpClient<ResetPasswordResponse>('/api/user/reset-password', {
      method: 'POST',
      body: payload,
      auth: false, // Authorization 是可选的
    })
  },
}
