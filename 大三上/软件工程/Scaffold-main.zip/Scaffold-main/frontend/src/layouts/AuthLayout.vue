<template>
  <div class="auth-layout">
    <section class="auth-layout__panel">
      <header class="auth-layout__header">
        <h1 class="auth-layout__title">欢迎来到创享论坛</h1>
        <p class="auth-layout__subtitle">探索提示词灵感，分享你的生成作品</p>
      </header>
      <div class="auth-layout__form">
        <slot />
      </div>
    </section>
    <aside class="auth-layout__showcase">
      <div class="auth-layout__overlay">
        <h2>创意社区</h2>
        <p>沉浸式探索提示词、生成历史与热度榜单。</p>
      </div>
    </aside>
  </div>
</template>

<style scoped>
.auth-layout {
  min-height: 100vh;
  display: grid;
  grid-template-columns: minmax(320px, 540px) 1fr;
  background: linear-gradient(135deg, #0f172a 0%, #312e81 50%, #7c3aed 100%);
  color: #0f172a;
}

.auth-layout__panel {
  background: #ffffff;
  padding: 2.5rem 3rem;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  border-top-right-radius: 40px;
  border-bottom-right-radius: 40px;
}

.auth-layout__header {
  display: grid;
  gap: 0.5rem;
}

.auth-layout__title {
  font-size: 2rem;
  font-weight: 700;
}

.auth-layout__subtitle {
  font-size: 1rem;
  color: #475569;
}

.auth-layout__form {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.auth-layout__showcase {
  position: relative;
  background: radial-gradient(circle at top, rgba(255, 255, 255, 0.2), transparent 60%),
    url('https://images.unsplash.com/photo-1526498460520-4c246339dccb?auto=format&fit=crop&w=1600&q=80')
      center/cover no-repeat;
}

.auth-layout__overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(120deg, rgba(15, 23, 42, 0.85), rgba(76, 29, 149, 0.65));
  color: #f8fafc;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  padding: 4rem;
  text-shadow: 0 6px 18px rgba(15, 23, 42, 0.4);
  gap: 1rem;
}

@media (max-width: 960px) {
  .auth-layout {
    grid-template-columns: 1fr;
  }

  .auth-layout__panel {
    border-radius: 0;
  }

  .auth-layout__showcase {
    display: none;
  }
}
</style>
