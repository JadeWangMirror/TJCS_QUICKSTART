import type { Component } from 'vue'

import AdminLayout from './AdminLayout.vue'
import AuthLayout from './AuthLayout.vue'
import MainLayout from './MainLayout.vue'

export const layoutNames = ['main', 'auth', 'admin'] as const

export type LayoutKey = (typeof layoutNames)[number]

const layoutRegistry: Record<LayoutKey, Component> = {
  main: MainLayout,
  auth: AuthLayout,
  admin: AdminLayout,
}

export const getLayoutComponent = (layoutName?: LayoutKey): Component => {
  const name = layoutName && layoutRegistry[layoutName] ? layoutName : 'main'
  return layoutRegistry[name]
}
