<script setup lang="ts">
import AppHeader from '@/components/navigation/AppHeader.vue'
import MainSidebar from '@/components/navigation/MainSidebar.vue'
import AppFooter from '@/components/common/AppFooter.vue'
</script>

<template>
  <div class="main-layout">
    <AppHeader />
    <div class="main-layout__body">
      <MainSidebar class="main-layout__sidebar" />
      <main class="main-layout__content">
        <slot />
      </main>
    </div>
    <AppFooter />
  </div>
</template>

<!-- <style scoped>
.main-layout {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: #f5f7fa;
  color: #1f2933;
}

.main-layout__body {
  flex: 1;
  display: grid;
  gap: 1.5rem;
  grid-template-columns: 260px 1fr;
  align-items: start;
  padding: 1.5rem 2rem;
   overflow: visible;
}

.main-layout__sidebar {
  position: sticky;
  top: 1.5rem;
  align-self: start;
}

.main-layout__content {
  background: #ffffff;
  border-radius: 16px;
  box-shadow: 0 12px 32px rgba(15, 23, 42, 0.08);
  padding: 1.5rem 2rem;
  min-height: 60vh;
}

@media (max-width: 960px) {
  .main-layout__body {
    grid-template-columns: 1fr;
    padding: 1rem;
  }

  .main-layout__sidebar {
    position: static;
  }
}
</style> -->
<style scoped>
.main-layout {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: #f5f7fa;
  color: #1f2933;
  overflow: visible; 
}

.main-layout__body {
  flex: 1;
  display: grid;
  gap: 1.5rem;
  grid-template-columns: 260px 1fr;
  align-items: start;
  padding: 1.5rem 2rem;
  overflow: visible; 
}

.main-layout__sidebar {
  position: sticky;
  top: calc(4rem + 1.5rem); 
  align-self: start;
  height: fit-content;
}

.main-layout__content {
  background: #ffffff;
  border-radius: 16px;
  box-shadow: 0 12px 32px rgba(15, 23, 42, 0.08);
  padding: 1.5rem 2rem;
  min-height: 60vh;
}

@media (max-width: 960px) {
  .main-layout__body {
    grid-template-columns: 1fr;
    padding: 1rem;
  }

  .main-layout__sidebar {
    position: static;
  }
}
</style>
