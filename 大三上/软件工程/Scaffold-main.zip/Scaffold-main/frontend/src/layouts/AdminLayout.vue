<script setup lang="ts">
import AdminSidebar from '@/components/navigation/AdminSidebar.vue'
</script>

<template>
  <div class="admin-layout">
    <AdminSidebar class="admin-layout__sidebar" />
    <main class="admin-layout__content">
      <header class="admin-layout__header">
        <h1>管理控制台</h1>
        <p>监控平台运行数据，快速执行审核与维护操作。</p>
      </header>
      <section class="admin-layout__main">
        <slot />
      </section>
    </main>
  </div>
</template>

<style scoped>
.admin-layout {
  min-height: 100vh;
  display: grid;
  grid-template-columns: 280px 1fr;
  background-color: #0f172a;
  color: #0f172a;
}

.admin-layout__sidebar {
  border-right: 1px solid rgba(148, 163, 184, 0.16);
}

.admin-layout__content {
  background: linear-gradient(180deg, #0f172a 0%, #1e293b 45%, #f8fafc 45%, #f8fafc 100%);
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  padding: 2rem 2.5rem 3rem;
}

.admin-layout__header h1 {
  font-size: 2rem;
  color: #f8fafc;
  margin: 0;
}

.admin-layout__header p {
  margin: 0.5rem 0 0;
  color: rgba(226, 232, 240, 0.78);
}

.admin-layout__main {
  background: #ffffff;
  border-radius: 18px;
  box-shadow: 0 20px 48px rgba(15, 23, 42, 0.18);
  padding: 2rem;
  flex: 1;
}

@media (max-width: 1080px) {
  .admin-layout {
    grid-template-columns: 1fr;
  }

  .admin-layout__sidebar {
    position: sticky;
    top: 0;
    z-index: 10;
  }
}
</style>
