export interface PaginatedResponse<T> {
  items: T[]
  totalPages: number
  page: number
  pageSize: number
}

export interface ApiResult<T> {
  success: boolean
  message?: string
  data: T|null
}

export interface AuthTokens {
  accessToken: string
  refreshToken: string
  expiredAt: string
}

export interface SearchFilters {
  page: number
  pageSize: number
}
