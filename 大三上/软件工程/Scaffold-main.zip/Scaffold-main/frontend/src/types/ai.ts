// 已有的优化相关类型
export interface OptimizationStage {
  role: string
  role_name?: string
  content?: string
  summary?: string
  output?: string
  timestamp?: string | number | Date
  metadata?: Record<string, unknown>
  [key: string]: unknown
}

export interface OptimizationRecord {
  id?: string | number
  timestamp?: string | number | Date
  original_prompt?: string
  optimized_prompt?: string
  original_preview?: string
  optimized_preview?: string
  workflow_history?: OptimizationStage[]
  workflow_summary?: string
  stage_notes?: string[]
  metrics?: Record<string, number>
  metadata?: Record<string, unknown>
  [key: string]: unknown
}

export interface OptimizationHistoryResponse {
  records: OptimizationRecord[]
}

export interface OptimizationDetailResponse {
  record: OptimizationRecord
}

export interface OptimizePromptResponse extends OptimizationRecord {
  completed_at?: string
}

// 新增的图片生成相关类型
export interface GeneratedImage {
  image_url: string
  file_name?: string
  size?: string
  model?: string
  metadata?: Record<string, unknown>
}

export interface ImageGenerationData {
  status: 'success' | 'error' | 'processing'
  image_urls?: GeneratedImage[]
  output?: GeneratedImage[]
  image_url?: string
  file_name?: string
  error?: string
  message?: string
  [key: string]: unknown
}

export interface GenerationRecord {
  id?: string | number
  timestamp?: string | number | Date
  prompt: string
  size?: string
  model?: string
  user_id?: string | number
  data: ImageGenerationData
  completed_at?: string
  metadata?: Record<string, unknown>
  [key: string]: unknown
}

export interface ImageGenerationResponse {
  status: 'success' | 'error'
  data: ImageGenerationData
  message?: string
  error?: string
  timestamp?: string
  completed_at?: string
  [key: string]: unknown
}

export interface GenerationHistoryResponse {
  records: GenerationRecord[]
}

export interface GenerationDetailResponse {
  record: GenerationRecord
}