// export interface UserSummary {
//   id: string
//   email: string
//   nickname: string
//   avatarUrl?: string
//   bio?: string
//   role: 'user' | 'admin' | 'moderator'
//   status: 'active' | 'blocked' | 'pending'
//   followers: number
//   following: number
//   joinedAt: string
// }
// 后端 API 返回的用户信息结构,原则上应该有什么管理员之类的字段
export interface UserSummary {
  id: number;
  name: string;
  introduce: string;
  tag: string[];
  created_at: string;
  avatarUrl?: string | null;
  email?: string | null;
  followers?: number;
  following?: number;
  role?: string | null;
  status?: string | null;
}

export interface PostSummary {
  id: number;
  author: string;
  title: string;
  // prompt: string
  tags: string[];
  like_count: number;
  favoriteCount: number;
  commentCount: number;
  timestamp: string;
  status: "published" | "draft" | "deleted";
}
// 评论信息
export interface Comment {
  id: number;
  author: string;
  author_id: number;
  timestamp: string;
  like_count: number;
  context: string;
  browse_count: number; 
  comment_count: number; 
  tags: string[];
  url_list: string[];
  comments: Comment[]; // 用于递归的子评论列表
}

// 完整的帖子详情结构 (PostDetail)
export interface PostDetail {
  id: number;
  title: string;
  context: string; // 帖子内容
  author: string;
  author_id: number;
  timestamp: string; // 发布时间
  url_list: string[]; // 图片或其他媒体的 URL 列表
  tags: string[];
  browse_count: number; // 浏览数
  like_count: number; // 点赞数
  comment_count: number; // 评论总数
  comments: Comment[]; // 评论列表
  favorite_count:number;
}
export interface PostDetailWithStatus extends PostDetail {
  is_liked: boolean; // 新增字段
  is_favorited:boolean
}
export interface PostFormPayload {
  title: string;
  context: string;
  tags: string[];
  isShareable: boolean;
  status?: "published" | "draft";
  url_list: string[];
  files:File[];
}
export interface CommentFormPayload {
  context: string;
  files:File[];
  point_id?:number;
}
// export interface PostSummary {
//   id: string
//   author: UserSummary
//   title: string
//   prompt: string
//   resultSnippet: string
//   tags: string[]
//   likeCount: number
//   favoriteCount: number
//   commentCount: number
//   createdAt: string
//   updatedAt?: string
//   status: 'published' | 'draft' | 'deleted'
// }

export interface GenerationRecord {
  id: string;
  ownerId: string;
  model: string;
  parameters: Record<string, unknown>;
  prompt: string;
  output: string;
  createdAt: string;
  publishedPostId?: string;
}

export interface RecommendationItem {
  id: string;
  type: "post" | "prompt" | "user";
  relevanceScore: number;
  payload: PostSummary | GenerationRecord | UserSummary;
}

export interface MessageThread {
  id: string;
  participants: UserSummary[];
  lastMessageAt: string;
  unreadCount: number;
}

export interface NotificationItem {
  id: string;
  kind: "comment" | "like" | "favorite" | "follow";
  createdAt: string;
  isRead: boolean;
  actor: UserSummary;
  post?: PostSummary;
  message: string;
}

export interface AdminStatistic {
  label: string;
  value: number;
  trend?: number;
  unit?: string;
}

export interface SearchPostResult {
  id: number;
  title: string;
  context: string;
  author: string;
  timestamp: string;
  cover_image?: string;
  tags: string[];
  browse_count: number;
  like_count: number;
  comment_count: number;
}
