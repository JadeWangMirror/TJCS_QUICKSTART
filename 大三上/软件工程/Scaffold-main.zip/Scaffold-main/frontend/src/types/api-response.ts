import type{UserSummary, PostSummary,PostDetail, SearchPostResult } from './models';
// 后端 API 分页返回结构
export interface smallPostSummary {
  id: number;
  author: string;
  title: string;
  // prompt: string
  tags: string[];
  likeCount: number;
  favoriteCount: number;
  commentCount: number;
  createdAt: string;
  // updatedAt?: string;
  status: "published" | "draft" | "deleted";
}
export interface ApiPostsListResponse {
  status: "success" | "error";
  page_count: number;
  limit: number;
  page_num: number;
  posts: PostSummary[];
}
export interface PostHistorySummary extends PostSummary{
  record_id:number
}
// 后端创建帖子返回结构
export interface CreatePostResponse {
  status:"success" | "error";
  message: string;
  post_id: number;
  image_urls: string[];
}
export interface DeletePostResponse {
  status:"success" | "error";
  message: string;
}
export interface UpdatePostResponse {
  status:"success" | "error";
  message: string;
}
export interface CreateCommentResponse{
  comment_id:number;
  url_list:string[];
  message: string;
}
export interface PostDetailResponse {
  status: 'success' | 'error';
  message:string;
  post: PostDetail;
}
export interface LikePostResponse {
  status: "success" | "error";
  message: string;
  post_id: number;
  is_liked: boolean;
  like_count: number;
}

export interface LikeStatusResponse {
    status: "success" | "error";
    post_id: number;
    is_liked: boolean; 
}

export interface SearchResponse {
  status: string;
  count: number;
  limit: number;
  offset: number;
  posts: SearchPostResult[];
  query: string;
  search_type: string;
}
export interface FavoritePostResponse {
  status: "success" | "error";
  message: string;
  post_id: number;
  is_favorited: boolean;
  favorite_count: number;
}

export interface FavoriteStatusResponse {
    status: "success" | "error";
    post_id: number;
    is_favorited: boolean; 
}
export interface PostRecord{
  post_id: number;
  timestamp: string;
  title: string;
}
export interface PostHistoryResponse {
    count: number;
    page_size: number;
    page_num: number;
    records: PostHistorySummary[];
    status: 'success' | string;
    total: number;
}