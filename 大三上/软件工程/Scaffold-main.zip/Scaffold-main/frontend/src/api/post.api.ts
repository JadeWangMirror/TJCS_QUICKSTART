import { httpClient } from "@/utils/httpClients";
import type { PostDetail } from "@/types/models";
import type {
  LikeStatusResponse,
  LikePostResponse,
  CreatePostResponse,
  PostDetailResponse,
  DeletePostResponse,
  UpdatePostResponse,
  FavoritePostResponse,
  FavoriteStatusResponse,
} from "@/types/api-response";
import type { ApiResult } from "@/types/api";

export const postApi = {
  /**
   * [POST] 创建新帖子 API (支持文件上传，使用 form-data)
   * @param user_id 当前用户ID
   * @param payload 包含 title, context, tags, files 的 FormData
   * @returns CreatePostResponse
   */
  async createPost(
    user_id: number,
    payload: FormData
  ): Promise<CreatePostResponse> {
    const url = `/api/user/${user_id}/create_post`;
    const responseData = await httpClient<CreatePostResponse>(url, {
      method: "POST",
      body: payload,
    });

    return responseData; // httpClient 已经返回了 data
  },

  /**
   * [GET] 获取帖子详情
   * @param user_id 当前用户ID
   * @param post_id 帖子ID
   * @returns ApiResult<PostDetail>
   */
  async fetchPostDetail(
    post_id: number,
    user_id: number
  ): Promise<ApiResult<PostDetail>> {
    const url = `/api/user/post/${post_id}?user_id=${user_id}`;

    try {
      // 1. 使用 httpClient 发起请求，直接获取到后端返回的整个 JSON 对象 (PostDetailResponse)
      const apiResponse = await httpClient<PostDetailResponse>(url, {
        method: "GET",
      });
      // 2. 检查自定义的业务状态字段
      if (apiResponse.status === "success") {
        return {
          success: true,
          message: "Detail fetched successfully (httpClient)",
          data: apiResponse.post,
        };
      } else {
        throw new Error(`API Status Error: ${apiResponse.status}`);
      }
    } catch (error) {
      let errorMessage: string = "未知错误";
      if (typeof error === "object" && error !== null && "message" in error) {
        errorMessage = (error as { message: string }).message;
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }

      console.error(`Error fetching post ${post_id}:`, error);

      return {
        success: false,
        message: `Failed to fetch detail: ${errorMessage}`,
        data: null,
      };
    }
  },

  /**
   * [PUT] 更新帖子 API (空链接)
   */
  async updatePost(
    user_id: number,
    post_id: number,
    payload: FormData
  ): Promise<UpdatePostResponse> {
    const url = `/api/user/${user_id}/${post_id}/update_post`;
    const responseData = await httpClient<DeletePostResponse>(url, {
      method: "PUT",
      body: payload,
    });

    return responseData; // httpClient 已经返回了 data
  },
  /**
   * [DELETE] 删除帖子 API
   */
  async deletePost(
    user_id: number,
    post_id: number
  ): Promise<DeletePostResponse> {
    const url = `/api/user/${user_id}/${post_id}/delete_post`;
    const responseData = await httpClient<DeletePostResponse>(url, {
      method: "DELETE",
    });

    return responseData; // httpClient 已经返回了 data
  },
  async likePost(user_id: number, post_id: number): Promise<LikePostResponse> {
    const url = `/api/user/${user_id}/${post_id}/like`;
    const responseData = await httpClient<LikePostResponse>(url, {
      method: "POST",
    });

    return responseData;
  },
  async getLikeStatus(
    user_id: number,
    post_id: number
  ): Promise<LikePostResponse> {
    const url = `/api/user/${user_id}/${post_id}/like/status`
    const responseData = await httpClient<LikePostResponse>(url, {
      method: 'GET',
    })

    return responseData
  },

  async favoritePost(
    user_id: number,
    post_id: number
  ): Promise<FavoritePostResponse> {
    const url = `/api/user/${user_id}/${post_id}/favorite`;
    const responseData = await httpClient<FavoritePostResponse>(url, {
      method: "POST",
    });

    return responseData;
  },
  async getfavoriteStatus(
    user_id: number,
    post_id: number
  ): Promise<FavoriteStatusResponse> {
    const url = `/api/user/${user_id}/${post_id}/favorite/status`;
    const responseData = await httpClient<FavoritePostResponse>(url, {
      method: "GET",
    });

    return responseData;
  },
};
