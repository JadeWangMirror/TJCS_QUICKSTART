import { httpClient } from "@/utils/httpClients";
import type { ApiPostsListResponse } from "@/types/api-response";
function buildQueryString(params: Record<string, any>): string {
  const searchParams = new URLSearchParams();
  for (const key in params) {
    if (params[key] !== undefined && params[key] !== null) {
      searchParams.append(key, String(params[key]));
    }
  }
  return searchParams.toString();
}
export const recommendationsApi = {
  /**
   * [GET] 获取帖子列表 (Newest/Hottest/Recommend)
   * @param user_id 当前用户ID
   * @param endpoint 'newest', 'hotest', or 'recommend'
   * @param limit 限制数量 (pageSize)
   * @param offset 偏移量
   * @returns 后端原生的 ApiPostsListResponse (现在通过 httpClient 直接返回数据)
   */
  async fetchPosts(
    user_id: number | undefined,
    endpoint: "newest" | "hotest" | "recommend",
    limit: number,
    page_num: number
  ): Promise<ApiPostsListResponse> {
    let url = "";

    // 确定 URL 路径
    if (endpoint === "recommend") {
      if (user_id === undefined) {
        throw new Error("获取推荐帖子需要用户ID (user_id)");
      }
      url = `/api/user/${user_id}/${endpoint}`;
    } else {
      // newest 和 hotest 接口不需要 user_id
      url = `/api/user/${endpoint}`;
    }
    const queryParams = {
      limit: limit,
      page_num: page_num,
    };
    const queryString = buildQueryString(queryParams);
    if (queryString) {
      url = `${url}?${queryString}`;
    }
    const responseData = await httpClient<ApiPostsListResponse>(url, {
      method: "GET", // 明确指定为 GET
    });
    return responseData;
  },
};
