import { httpClient } from "@/utils/httpClients";
import type { ApiPostsListResponse } from "@/types/api-response";
function buildQueryString(params: Record<string, any>): string {
  const searchParams = new URLSearchParams();
  for (const key in params) {
    if (params[key] !== undefined && params[key] !== null) {
      searchParams.append(key, String(params[key]));
    }
  }
  return searchParams.toString();
}
export const PostListApi = {
  /**
   * [GET] 获取帖子列表 (Newest/Hottest/Recommend)
   * @param user_id 当前用户ID
   * @param limit 限制数量 (pageSize)
   * @param offset 偏移量
   * @returns 后端原生的 ApiPostsListResponse (现在通过 httpClient 直接返回数据)
   */
  async fetchPosts(
    user_id: number,
    limit: number,
    page_num: number
  ): Promise<ApiPostsListResponse> {
    if (user_id === undefined) {
      throw new Error("获取我的帖子需要用户ID (user_id)");
    }
    let url = "";
    url = `/api/user/${user_id}/posts`;
    // 确定 URL 路径
    const queryParams = {
      limit: limit,
      page_num: page_num,
    };
    const queryString = buildQueryString(queryParams);
    if (queryString) {
      url = `${url}?${queryString}`;
    }
    const responseData = await httpClient<ApiPostsListResponse>(url, {
      method: "GET", // 明确指定为 GET
    });
    return responseData;
  },
  /**
   * [GET] 获取帖子列表 (Newest/Hottest/Recommend)
   * @param user_id 当前用户ID
   * @param limit 限制数量 (pageSize)
   * @param offset 偏移量
   * @returns 后端原生的 ApiPostsListResponse (现在通过 httpClient 直接返回数据)
   */
  async fetchFavoritePosts(
    user_id: number,
    limit: number,
    page_num: number
  ): Promise<ApiPostsListResponse> {
    if (user_id === undefined) {
      throw new Error("获取我的帖子需要用户ID (user_id)");
    }
    let url = "";
    url = `/api/user/${user_id}/favorites`;
    // 确定 URL 路径
    const queryParams = {
      limit: limit,
      page_num: page_num,
    };
    const queryString = buildQueryString(queryParams);
    if (queryString) {
      url = `${url}?${queryString}`;
    }
    const responseData = await httpClient<ApiPostsListResponse>(url, {
      method: "GET", // 明确指定为 GET
    });
    return responseData;
  },
};
