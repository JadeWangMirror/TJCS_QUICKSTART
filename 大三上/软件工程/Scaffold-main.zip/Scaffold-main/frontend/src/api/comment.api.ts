import { httpClient } from '@/utils/httpClients' 
import type { CreateCommentResponse} from '@/types/api-response'

export const commentApi = {
  /**
   * [POST] 创建新帖子 API (支持文件上传，使用 form-data)
   * @param post_id 当前帖子ID
   * @param user_id 当前用户ID
   * @param point_id 当前指向的评论/帖子
   * @param payload 包含 title, context, tags, files 的 FormData
   * @returns CreateCommentResponse
   */
  async createComment(
    user_id: number,
    post_id:number,
    payload: FormData
  ): Promise<CreateCommentResponse> {
    const url = `/api/user/${user_id}/${post_id}/create_comment`
    const responseData = await httpClient<CreateCommentResponse>(url, {
      method: 'POST',
      body: payload,
    })

    return responseData // httpClient 已经返回了 data
  },
  async deleteComment(
      user_id: number,
      comment_id:number,
    ): Promise<{message:string}> {
      const url = `/api/user/${user_id}/${comment_id}/delete_comment`
      const responseData = await httpClient<{message:string}>(url, {
        method: 'DELETE',
      })
  
      return responseData // httpClient 已经返回了 data
    },
}