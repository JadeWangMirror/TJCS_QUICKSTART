import { httpClient } from "@/utils/httpClients";
import type { PostHistoryResponse } from "@/types/api-response";
import type { PostHistorySummary } from "@/types/api-response";
import type { SearchFilters } from "@/types/api";
interface BackendPostRecord {
  author: string;
  browse_count: number; // 忽略
  comment_count: number;
  id: number; // 浏览记录id (-> record_id)
  like_count: number;
  post_id: number; // 帖子id (-> id)
  timestamp: string; // (-> createdAt)
  title: string;
}

interface BackendPostHistoryResponse {
  count: number; // 本次返回的记录数量
  limit: number; // 每页数量 (-> page_size)
  offset: number; // 偏移量，即 (page_num - 1) * limit
  records: BackendPostRecord[];
  status: "success" | string;
  total_count: number; // 总记录数
}
function mapBackendToFrontend(
  backendData: BackendPostHistoryResponse
): PostHistoryResponse {
  // 映射 records 列表
  const records: PostHistorySummary[] = backendData.records.map((record) => ({
    // 映射 PostHistorySummary 字段
    record_id: record.id,

    // 映射 PostSummary 字段
    id: record.post_id,
    author: record.author,
    title: record.title,
    like_count: record.like_count,
    commentCount: record.comment_count,
    timestamp: record.timestamp,
    tags: [],
    favoriteCount: 0,
    status: "published", // 假设浏览记录默认状态为已发布
  }));

  // 映射分页信息
  const limit = backendData.limit;
  const offset = backendData.offset;

  // 根据 offset 和 limit 计算 page_num (假设 page_num 是 1-based)
  // page_num = (offset / limit) + 1。需要确保 limit > 0
  const pageNum = offset;

  // 映射顶层字段
  return {
    count: backendData.count,
    page_size: limit,
    page_num: pageNum,
    records: records,
    status: backendData.status,
    total: backendData.total_count,
  };
}
export const browseHistoryApi = {
  /**
   * [GET] 查找用户浏览历史
   * @param user_id 当前用户ID
   * @returns PostHistoryResponse
   */
  async FetchBrowseHistory(
    user_id: number,
    filters?: SearchFilters
  ): Promise<PostHistoryResponse> {
    const url = `/api/user/${user_id}/history/browse`;
    const backendData = await httpClient<BackendPostHistoryResponse>(url, {
      method: "GET",
      params: {
        limit: filters?.pageSize,
        offset: filters?.page,
      },
    });

    // 2. 调用映射函数，返回前端所需的数据结构
    return mapBackendToFrontend(backendData);
  },
  async DeleteBrowseHistory(
    user_id: number,
    record_id: number
  ): Promise<{ status: string; message: string }> {
    const url = `/api/user/${user_id}/history/browse/${record_id}`;
    const responseData = await httpClient<{ status: string; message: string }>(
      url,
      {
        method: "DELETE",
      }
    );

    return responseData; // httpClient 已经返回了 data
  },
  async DeleteAllBrowseHistory(
    user_id: number
  ): Promise<{ status: string; message: string }> {
    const url = `/api/user/${user_id}/history/browse`;
    const responseData = await httpClient<{ status: string; message: string }>(
      url,
      {
        method: "DELETE",
      }
    );

    return responseData; // httpClient 已经返回了 data
  },
};
