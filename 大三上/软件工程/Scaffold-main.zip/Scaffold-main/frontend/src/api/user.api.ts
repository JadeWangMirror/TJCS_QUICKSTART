import { httpClient } from '@/utils/httpClients'

// -------------------------------------------------------------
// API 响应类型定义
// -------------------------------------------------------------

interface RawUser {
  id?: number | string | null
  name?: string | null
  nickname?: string | null
  introduce?: string | null
  bio?: string | null
  tag?: string[] | null
  tags?: string[] | null
  created_at?: string | null
  createdAt?: string | null
  joined_at?: string | null
  joinedAt?: string | null
  avatarUrl?: string | null
  avatar_url?: string | null
  email?: string | null
  followers?: number | null
  following?: number | null
  role?: string | null
  status?: string | null
}

export interface CurrentUserResponse {
  success: boolean
  data?: {
    user?: RawUser | null
  }
  message?: string
}

export interface PublicUserResponse {
  status: 'success' | 'error'
  user?: RawUser | null
  message?: string
}

export interface UpdateUserPayload {
  introduce?: string
  tag?: string[]
}

export interface UpdateUserResponse {
  success: boolean
  message: string
}

// 保留原有的接口以保持兼容性
export interface ApiUserResponse {
  status: 'success' | 'error'
  user: RawUser
}

// -------------------------------------------------------------
// API 层实现
// -------------------------------------------------------------

export const userApi = {
  /**
   * [GET] 获取当前用户信息
   * @returns 当前用户的完整信息
   */
  async getCurrentUserProfile(): Promise<CurrentUserResponse> {
    const url = '/api/user/me'
    return await httpClient<CurrentUserResponse>(url, { method: 'GET' })
  },

  /**
   * [GET] 获取指定用户信息
   * @param userId 用户ID
   * @returns 用户的公开信息
   */
  async getUserProfile(userId: number | string): Promise<PublicUserResponse> {
    const url = `/api/user/${userId}`
    return await httpClient<PublicUserResponse>(url, { method: 'GET' })
  },

  /**
   * [PUT] 更新用户信息
   * @param userId 用户ID
   * @param payload 要更新的用户信息
   * @returns 更新结果
   */
  async updateUserProfile(
    userId: number | string,
    payload: UpdateUserPayload
  ): Promise<UpdateUserResponse> {
    const url = `/api/user/${userId}`
    return await httpClient<UpdateUserResponse>(url, { method: 'PUT', body: payload })
  },

  /**
   * [GET] 获取用户摘要信息（保留原有方法以保持兼容性）
   * @param user_identifier 用户标识符
   * @returns 用户摘要信息
   */
  async fetchUserSummary(user_identifier: string | number): Promise<ApiUserResponse> {
    const url = `/api/user/${user_identifier}`
    return await httpClient<ApiUserResponse>(url, { method: 'GET' })
  },
}