import { httpClient } from '@/utils/httpClients'
import type { SearchResponse } from '@/types/api-response'

export const searchApi = {
  /**
   * [GET] 搜索帖子
   * @param user_id 当前用户ID
   * @param query 搜索关键词
   * @param type 搜索类型
   * @param limit 每页数量
   * @param offset 分页偏移量
   */
  async searchPosts(
    user_id: number,
    query: string,
    type: string,
    limit: number = 10,
    offset: number = 0
  ): Promise<SearchResponse> {
    const url = `/api/user/${user_id}/search?q=${encodeURIComponent(query)}&type=${type}&user_id=${user_id}&limit=${limit}&offset=${offset}`
    const responseData = await httpClient<SearchResponse>(url, {
      method: 'GET',
    })

    return responseData
  },
}
