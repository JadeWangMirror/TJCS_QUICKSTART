import { httpClient } from "@/utils/httpClients";
export interface FileResponse {
  status:string
  data: string[];
}
export const fileApi = {
  /**
   * [POST] 创建文件的URLlist
   * @param payload 包含  files 的 FormData
   * @returns FileResponse
   */
  async fileToUrl(payload: File[]): Promise<FileResponse> {
    const formData = new FormData();
    const url = `/api/file/upload`;
    if (payload && payload.length > 0) {
      payload.forEach((file) => {
        formData.append("files", file);
      });
    }
    const responseData = await httpClient<FileResponse>(url, {
      method: "POST",
      body: formData,
    });
    return responseData;
  },
};
