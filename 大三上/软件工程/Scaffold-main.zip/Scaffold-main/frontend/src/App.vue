<script setup lang="ts">
import { RouterView } from 'vue-router'

import { getLayoutComponent, layoutNames } from '@/layouts'
import type { LayoutKey } from '@/layouts'

const isLayoutKey = (value: unknown): value is LayoutKey => {
  return typeof value === 'string' && (layoutNames as readonly string[]).includes(value)
}

const resolveLayout = (layout?: unknown) =>
  getLayoutComponent(isLayoutKey(layout) ? layout : undefined)
</script>

<template>
  <RouterView v-slot="{ Component, route }">
    <component :is="resolveLayout(route.meta.layout)" :key="route.meta.layout ?? 'main'">
      <keep-alive include="HomeView">
        <component :is="Component" :key="route.name ?? route.fullPath" />
      </keep-alive>
    </component>
  </RouterView>
</template>

<style scoped>
:global(body) {
  margin: 0;
  font-family: 'Microsoft YaHei', 'Segoe UI', system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
  background-color: #f8fafc;
  color: #0f172a;
}

a {
  color: inherit;
}
</style>
