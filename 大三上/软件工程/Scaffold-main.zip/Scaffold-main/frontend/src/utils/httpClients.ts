/**
 * HTTP 客户端 - 基于 axios 的实际实现
 */
import axios, { type AxiosRequestConfig } from "axios";
import { getCookie, removeCookie } from "./cookie";
import { useAuthStore } from "@/store/modules/auth";

// 创建 axios 实例
import.meta.env.VITE_API_BASE_URL || "";
export const axiosInstance = axios.create({
  baseURL: "http://ccb.aoinatsu.com",
  timeout: 95000,
  // headers: { "Content-Type": "application/json" },
});

// 请求拦截器 - 自动添加 token
axiosInstance.interceptors.request.use(
  (config) => {
    // 优先从 localStorage 获取 token
    let token = localStorage.getItem("access_token");
    
    // 如果 localStorage 没有，尝试从 cookie 获取（作为备用）
    if (!token) {
      token = getCookie("access_token");
    }

    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// 响应拦截器 - 统一处理错误
axiosInstance.interceptors.response.use(
  (response) => {
    return response.data; // 直接返回 data 部分
  },
  (error) => {
    if (error.response) {
      // 服务器返回错误
      const { status, data } = error.response;

      if (status === 401) {
        // Token 过期或无效，清除本地存储和 cookie，并跳转到登录页
        localStorage.removeItem("access_token");
        localStorage.removeItem("refresh_token");
        localStorage.removeItem("auth_tokens");
        
        // 清除 cookie
        removeCookie("access_token");
        removeCookie("refresh_token");

        // 清除 store 状态
        try {
          const authStore = useAuthStore();
          authStore.currentUser = null;
          authStore.tokens = null;
        } catch (e) {
          console.error('Failed to clear auth store:', e);
        }

        // 如果不在登录页，跳转到登录页
        if (window.location.pathname !== "/auth/login") {
          window.location.href = "/auth/login";
        }
      }

      // 返回服务器的错误信息
      return Promise.reject({
        message: data?.message || "请求失败",
        status,
        data,
      });
    } else if (error.request) {
      // 请求已发出但没有收到响应
      return Promise.reject({
        message: "网络错误，请检查您的网络连接",
        status: 0,
      });
    } else {
      // 其他错误
      return Promise.reject({
        message: error.message || "未知错误",
        status: 0,
      });
    }
  }
);

export interface HttpRequestOptions<TBody = unknown> {
  method?: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
  body?: TBody;
  headers?: Record<string, string>;
  auth?: boolean; // 是否需要认证（默认 true）
  params?: Record<string, any>;
}

export const httpClient = async <TResponse>(
  endpoint: string,
  { method = "GET", body, headers, auth = true ,params}: HttpRequestOptions = {}
): Promise<TResponse> => {
  const config: AxiosRequestConfig = {
    method,
    url: endpoint,
    data: body,
    headers: {
      ...headers,
    },
    params,
  };
  if (!auth && config.headers) {
    delete config.headers.Authorization;
  }
  try {
    const response = await axiosInstance.request<unknown, TResponse>(config);
    return response;
  } catch (error) {
    // 错误已经在拦截器中处理
    throw error;
  }
};
