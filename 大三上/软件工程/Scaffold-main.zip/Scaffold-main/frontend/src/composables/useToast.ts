import { ref, readonly } from 'vue';

// 初始状态
const isVisible = ref(false);
const currentMessage = ref('');
const timeoutId = ref<ReturnType<typeof setTimeout> | null>(null);
const DURATION = 1000; 

/**
 * 核心显示函数
 * @param {string} message 要显示的消息
 */


const show = (message: string) => {
    // 1. 清除上一个计时器（如果存在）
    if (timeoutId.value !== null) {
        clearTimeout(timeoutId.value);
        timeoutId.value = null; // 立即清除
    }
    currentMessage.value = message;
    isVisible.value = true;
    timeoutId.value = setTimeout(() => {
        // 隐藏逻辑：
        isVisible.value = false;
        timeoutId.value = null; 
    }, DURATION);
    // console.log(timeoutId) // 可以在这里打印
};

// 暴露给外部使用的接口
export function useToast() {
  return {
    // 只读属性，防止在组件外被直接修改状态
    isVisible: readonly(isVisible),
    message: readonly(currentMessage),
    
    // 方法
    show
  };
}