<script setup lang="ts">
import { gsap } from 'gsap';
import { nextTick, onBeforeUpdate, onMounted, onUnmounted, ref, watch, type VNodeRef } from 'vue';
import { TopRight } from '@element-plus/icons-vue';

type CardNavLink = {
  label: string;
  href?: string;
  ariaLabel: string;
  onClick?: () => void;
};

export type CardNavItem = {
  label: string;
  bgColor: string;
  textColor: string;
  links: CardNavLink[];
};

export interface CardNavProps {
  logo: string;
  logoAlt?: string;
  items: CardNavItem[];
  className?: string;
  ease?: string;
  baseColor?: string;
  menuColor?: string;
  buttonBgColor?: string;
  buttonTextColor?: string;
  ctaLabel?: string;
  ctaTo?: string;
}

// 调整默认 easing 为更平滑的曲线
const props = withDefaults(defineProps<CardNavProps>(), {
  logoAlt: 'Logo',
  className: '',
  ease: 'power4.out',
  // 1. 修改：默认背景色改为淡雅高雅的紫色
  baseColor: '#F3E8FF' 
});

const isHamburgerOpen = ref(false);
const isExpanded = ref(false);

const navRef = ref<HTMLDivElement | null>(null);
const cardsRef = ref<HTMLDivElement[]>([]);
const tlRef = ref<gsap.core.Timeline | null>(null);

const setCardRef =
  (i: number): VNodeRef =>
  el => {
    if (el && el instanceof HTMLDivElement) {
      cardsRef.value[i] = el;
    }
  };

onBeforeUpdate(() => {
  cardsRef.value = [];
});

const calculateHeight = () => {
  const navEl = navRef.value;
  if (!navEl) return 260;

  const isMobile = window.matchMedia('(max-width: 768px)').matches;
  if (isMobile) {
    const contentEl = navEl.querySelector('.card-nav-content') as HTMLElement;
    if (contentEl) {
      const wasVisible = contentEl.style.visibility;
      const wasPosition = contentEl.style.position;
      const wasHeight = contentEl.style.height;

      contentEl.style.visibility = 'visible';
      contentEl.style.position = 'static';
      contentEl.style.height = 'auto';

      const topBar = 60;
      const padding = 16;
      const contentHeight = contentEl.scrollHeight;

      contentEl.style.visibility = wasVisible;
      contentEl.style.position = wasPosition;
      contentEl.style.height = wasHeight;

      return topBar + contentHeight + padding;
    }
  }
  return 260;
};

const createTimeline = () => {
  const navEl = navRef.value;
  if (!navEl) return null;

  // 初始状态设置
  gsap.set(navEl, { height: 60, overflow: 'hidden' });
  gsap.set(cardsRef.value, { y: 30, opacity: 0, scale: 0.98 }); 

  const tl = gsap.timeline({ paused: true });

  tl.to(navEl, {
    height: calculateHeight,
    // 2. 修改：动画速度略快一些 (0.5 -> 0.35)
    duration: 0.35, 
    ease: props.ease
  });

  tl.to(cardsRef.value, { 
    y: 0, 
    opacity: 1, 
    scale: 1,
    // 2. 修改：动画速度略快一些 (0.5 -> 0.35)
    duration: 0.35, 
    ease: props.ease, 
    // 2. 修改：交错时间也相应缩短，更紧凑 (0.06 -> 0.04)
    stagger: 0.04 
  }, '-=0.25'); // 调整重叠时间以匹配新的速度

  return tl;
};

const toggleMenu = () => {
  const tl = tlRef.value;
  if (!tl) return;
  if (!isExpanded.value) {
    isHamburgerOpen.value = true;
    isExpanded.value = true;
    nextTick(() => {
      tl.play(0);
    });
  } else {
    isHamburgerOpen.value = false;
    tl.eventCallback('onReverseComplete', () => {
      isExpanded.value = false;
      tl.eventCallback('onReverseComplete', null);
    });
    tl.reverse();
  }
};

const handleResize = () => {
  if (!tlRef.value) return;

  if (isExpanded.value) {
    const newHeight = calculateHeight();
    gsap.set(navRef.value, { height: newHeight });

    tlRef.value.kill();
    const newTl = createTimeline();
    if (newTl) {
      newTl.progress(1);
      tlRef.value = newTl;
    }
  } else {
    tlRef.value.kill();
    tlRef.value = createTimeline();
  }
};

onMounted(() => {
  tlRef.value = createTimeline();
  window.addEventListener('resize', handleResize);
});

onUnmounted(() => {
  tlRef.value?.kill();
  tlRef.value = null;
  window.removeEventListener('resize', handleResize);
});

watch(
  () => [props.ease, props.items],
  () => {
    nextTick(() => {
      if (tlRef.value) tlRef.value.kill();
      tlRef.value = createTimeline();
    });
  }
);
</script>

<template>
  <div
    :class="`card-nav-container absolute left-1/2 -translate-x-1/2 w-[92%] max-w-[800px] z-[99] top-[1.5em] md:top-[2em] ${props.className}`"
  >
    <nav
      ref="navRef"
      :class="[
        'card-nav block h-[60px] p-0 rounded-2xl relative overflow-hidden will-change-[height]',
        'shadow-[0_8px_30px_rgb(0,0,0,0.08)] ring-1 ring-black/5 backdrop-blur-xl',
        { open: isExpanded }
      ]"
      :style="{ backgroundColor: props.baseColor }"
    >
      <div
        class="card-nav-top top-0 z-[2] absolute inset-x-0 flex justify-between items-center p-2 px-[1.2rem] h-[60px]"
      >
        <div
          :class="[
            'hamburger-menu group h-10 w-10 rounded-full flex flex-col items-center justify-center cursor-pointer gap-[5px] order-2 md:order-none transition-colors duration-200 hover:bg-black/5',
            { open: isHamburgerOpen }
          ]"
          @click="toggleMenu"
          role="button"
          :aria-label="isExpanded ? 'Close menu' : 'Open menu'"
          tabindex="0"
          :style="{ color: props.menuColor || '#1a1a1a' }"
        >
          <div
            :class="[
              'hamburger-line w-[22px] h-[2px] rounded-full bg-current transition-[transform,opacity,margin] duration-300 ease-[cubic-bezier(0.16,1,0.3,1)]',
              { 'translate-y-[3.5px] rotate-45': isHamburgerOpen }
            ]"
          />
          <div
            :class="[
              'hamburger-line w-[22px] h-[2px] rounded-full bg-current transition-[transform,opacity,margin] duration-300 ease-[cubic-bezier(0.16,1,0.3,1)]',
              { '-translate-y-[3.5px] -rotate-45': isHamburgerOpen }
            ]"
          />
        </div>

        <div
          class="md:top-1/2 md:left-1/2 md:absolute flex items-center order-1 md:order-none md:-translate-x-1/2 md:-translate-y-1/2 logo-container"
        >
          <img :src="props.logo" :alt="props.logoAlt" class="h-[36px] w-auto object-contain logo" />
        </div>

        <RouterLink
          v-if="props.ctaLabel && props.ctaTo"
          :to="props.ctaTo"
          class="hidden md:inline-flex px-5 py-2 rounded-xl h-[40px] font-semibold text-[14px] transition-all duration-300 cursor-pointer card-nav-cta-button items-center justify-center no-underline shadow-sm hover:shadow-md active:scale-95"
          :style="{
            backgroundColor: props.buttonBgColor,
            color: props.buttonTextColor
          }"
        >
          {{ props.ctaLabel }}
        </RouterLink>
        <button
          v-else-if="props.ctaLabel"
          type="button"
          class="hidden md:inline-flex px-5 py-2 rounded-xl h-[40px] font-semibold text-[14px] transition-all duration-300 cursor-pointer card-nav-cta-button shadow-sm hover:shadow-md active:scale-95"
          :style="{
            backgroundColor: props.buttonBgColor,
            color: props.buttonTextColor
          }"
        >
          {{ props.ctaLabel }}
        </button>
      </div>

      <div
        :class="[
          'card-nav-content absolute left-0 right-0 top-[60px] bottom-0 p-3 flex flex-col items-stretch gap-3 justify-start z-[1] md:flex-row md:items-end md:gap-3',
          isExpanded ? 'visible pointer-events-auto' : 'invisible pointer-events-none'
        ]"
        :aria-hidden="!isExpanded"
      >
        <div
          v-for="(item, idx) in (props.items || []).slice(0, 3)"
          :key="`${item.label}-${idx}`"
          :ref="setCardRef(idx)"
          class="relative flex flex-col flex-[1_1_auto] md:flex-[1_1_0%] gap-3 p-5 rounded-xl min-w-0 h-auto md:h-full min-h-[60px] md:min-h-0 select-none nav-card transition-all duration-300 hover:brightness-95 shadow-sm ring-1 ring-black/5"
          :style="{ backgroundColor: item.bgColor, color: item.textColor }"
        >
          <div class="font-medium text-[17px] md:text-[20px] tracking-tight nav-card-label">
            {{ item.label }}
          </div>
          <div class="flex flex-col gap-2 mt-auto nav-card-links">
            <template v-for="(lnk, i) in item.links" :key="`${lnk.label}-${i}`">
              <a
                v-if="lnk.onClick"
                href="javascript:void(0)"
                @click.prevent="lnk.onClick"
                class="inline-flex items-center gap-2 opacity-80 hover:opacity-100 text-[14px] md:text-[15px] font-medium no-underline transition-all duration-200 cursor-pointer nav-card-link group"
                :aria-label="lnk.ariaLabel"
                :style="{ color: item.textColor }"
              >
                <div class="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center transition-transform group-hover:scale-110">
                   <TopRight class="nav-card-link-icon shrink-0 w-3 h-3" aria-hidden="true" />
                </div>
                {{ lnk.label }}
              </a>
              <RouterLink
                v-else-if="lnk.href && lnk.href.startsWith('/')"
                :to="lnk.href"
                class="inline-flex items-center gap-2 opacity-80 hover:opacity-100 text-[14px] md:text-[15px] font-medium no-underline transition-all duration-200 cursor-pointer nav-card-link group"
                :aria-label="lnk.ariaLabel"
                :style="{ color: item.textColor }"
              >
                <div class="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center transition-transform group-hover:scale-110">
                   <TopRight class="nav-card-link-icon shrink-0 w-3 h-3" aria-hidden="true" />
                </div>
                {{ lnk.label }}
              </RouterLink>
              <a
                v-else
                class="inline-flex items-center gap-2 opacity-80 hover:opacity-100 text-[14px] md:text-[15px] font-medium no-underline transition-all duration-200 cursor-pointer nav-card-link group"
                :href="lnk.href"
                :aria-label="lnk.ariaLabel"
                :style="{ color: item.textColor }"
              >
                <div class="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center transition-transform group-hover:scale-110">
                   <TopRight class="nav-card-link-icon shrink-0 w-3 h-3" aria-hidden="true" />
                </div>
                {{ lnk.label }}
              </a>
            </template>
          </div>
        </div>
      </div>
    </nav>
  </div>
</template>
