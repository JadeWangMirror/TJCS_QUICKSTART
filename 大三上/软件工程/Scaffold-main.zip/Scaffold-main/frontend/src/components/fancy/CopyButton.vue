<template>
  <button class="button copy-button" @click="$emit('click')">
    <svg viewBox="0 0 448 512" class="svgIcon copyIcon">
      <path d="M416 192H224C210.7 192 200 202.7 200 216v240C200 470.7 210.7 480 224 480h240C470.7 480 480 469.3 480 456V216C480 202.7 470.7 192 456 192H416zM0 64C0 46.33 14.33 32 32 32h288C333.7 32 348 46.33 348 64v240C348 317.7 333.7 332 316 332h-284C14.33 332 0 317.7 0 300V64z"></path>
    </svg>
  </button>
</template>

<script setup>
import { defineEmits } from 'vue';

// 定义一个 click 事件，让父组件可以监听
const emits = defineEmits(['click']);
</script>

<style scoped>
/* 基础按钮样式 (圆形、黑色背景、居中、阴影) */
.button {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: rgb(20, 20, 20);
  border: none;
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.164);
  cursor: pointer;
  transition-duration: 0.3s;
  overflow: hidden;
  position: relative;
  outline: none;
  flex-shrink: 0;
}

/* SVG 图标基础样式 */
.svgIcon {
  width: 18px;
  transition-duration: 0.3s;
  position: absolute;
}

.svgIcon path {
  fill: white;
}

/* 按钮 1: 复制优化结果 (Copy Button) - 蓝色动画 */
.copy-button:hover {
  width: 140px;
  border-radius: 50px;
  transition-duration: 0.3s;
  background-color: rgb(0, 150, 255); /* 蓝色悬停背景 */
  align-items: center;
}

.copy-button:hover .copyIcon {
  width: 50px;
  transition-duration: 0.3s;
  transform: translateY(60%); /* 图标向下移动 */
}

/* 悬停文字 - before */
.copy-button::before {
  position: absolute;
  top: -20px;
  content: "复制优化结果";
  color: white;
  transition-duration: 0.3s;
  font-size: 2px;
  white-space: nowrap;
}

/* 悬停文字显示 */
.copy-button:hover::before {
  font-size: 13px;
  opacity: 1;
  transform: translateY(30px);
  transition-duration: 0.3s;
}
</style>