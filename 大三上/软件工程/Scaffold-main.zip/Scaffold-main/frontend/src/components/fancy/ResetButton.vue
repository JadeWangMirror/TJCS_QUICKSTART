<template>
  <button class="button reset-button" @click="$emit('click')">
    <svg viewBox="0 0 512 512" class="svgIcon resetIcon">
      <path d="M463.5 224H416v-47.5C416 111.9 352.1 48 275.5 48h-39.2C167.9 48 104 111.9 104 184.5v47.5H48c-8.84 0-16 7.16-16 16v240c0 8.84 7.16 16 16 16h416c8.84 0 16-7.16 16-16V240c0-8.84-7.16-16-16-16zm-383.5 16h383.5v240H80V240zM224 352c0-22.1 17.9-40 40-40s40 17.9 40 40-17.9 40-40 40-40-17.9-40-40z"></path>
    </svg>
  </button>
</template>

<script setup>
import { defineEmits } from 'vue';
const emits = defineEmits(['click']);
</script>

<style scoped>
/* 基础按钮样式 (圆形、黑色背景、居中、阴影) */
.button {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: rgb(20, 20, 20);
  border: none;
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.164);
  cursor: pointer;
  transition-duration: 0.3s;
  overflow: hidden;
  position: relative;
  outline: none;
  flex-shrink: 0;
}

/* SVG 图标基础样式 */
.svgIcon {
  width: 18px;
  transition-duration: 0.3s;
  position: absolute;
}

.svgIcon path {
  fill: white;
}

/* 按钮 2: 开始新的优化 (Reset Button) - 橙色动画 */
.reset-button {
  background-color: rgb(40, 40, 40);
}

.reset-button:hover {
  width: 140px;
  border-radius: 50px;
  transition-duration: 0.3s;
  background-color: rgb(255, 165, 0); /* 橙色悬停背景 */
  box-shadow: 0 0 20px rgba(255, 165, 0, 0.5);
}

.reset-button .resetIcon {
  transition: transform 0.5s ease;
}

.reset-button:hover .resetIcon {
  transform: rotate(-360deg);
  width: 25px;
}
.reset-button:hover .svgIcon{
  left: 10%;
}
/* 悬停文字 - after (右侧滑入) */
.reset-button::after {
  content: "开始新的优化";
  color: white;
  opacity: 0;
  transform: translateX(100%);
  transition: opacity 0.3s ease, transform 0.3s ease;
  position: absolute;
  left: 20%;
  padding-left: 20px;
  font-size: 13px;
  white-space: nowrap;
}

.reset-button:hover::after {
  opacity: 1;
  transform: translateX(10px);
}
</style>