<script setup lang="ts">
import { computed } from 'vue'
import { useAuthStore } from '@/store/modules/auth'
import CardNav, { type CardNavItem } from '@/components/fancy/CardNav.vue'
// Assuming logo exists, or I'll use a placeholder if it fails.
// Actually I should check if logo exists. If not, I'll use a data URI or just text.
// The user's example used `import logo from './logo.svg'`, but that file might not exist in `components/navigation`.
// I'll check if `src/assets/logo.svg` exists. If not, I'll use a placeholder.

import { useRouter } from 'vue-router'

const authStore = useAuthStore()
const router = useRouter()
const isLoggedIn = computed(() => authStore.isLoggedIn)

const handleLogout = async () => {
  if (!confirm('确认退出登录？')) return
  try { 
    await authStore.logout() 
  } catch (error) {
    console.error('Logout failed:', error)
  } finally {
    router.push('/auth/login')
  }
}

const items = computed<CardNavItem[]>(() => {
  const baseItems = [
    {
      label: "发布",
      bgColor: "#0D0716",
      textColor: "#fff",
      links: [
        { label: "发布交流帖", href: "/posts/new", ariaLabel: "Create new post" },
        // { label: "我的草稿", href: "/profile?tab=drafts", ariaLabel: "My drafts" }
      ]
    },
    {
      label: "AI生成",
      bgColor: "#170D27",
      textColor: "#fff",
      links: [
        { label: "提示词工作台", href: "/ai/workbench", ariaLabel: "Prompt Workbench" },
        { label: "生图工坊", href: "/ai/generate", ariaLabel: "Image Generation" },
        { label: "生成历史", href: "/ai/history", ariaLabel: "Generation History" }
      ]
    }
  ]

  const authItem = isLoggedIn.value ? {
    label: "个人中心",
    bgColor: "#271E37",
    textColor: "#fff",
    links: [
      { label: "个人资料", href: "/profile", ariaLabel: "Profile" },
      { label: "我的收藏", href: "/profile/favorites", ariaLabel: "Favorites" },
      { label: "退出登录", onClick: handleLogout, ariaLabel: "Logout" }
    ]
  } : {
    label: "登录/注册",
    bgColor: "#271E37",
    textColor: "#fff",
    links: [
      { label: "登录", href: "/auth/login", ariaLabel: "Login" },
      { label: "注册", href: "/auth/register", ariaLabel: "Register" },
      { label: "找回密码", href: "/auth/forgot-password", ariaLabel: "Forgot Password" }
    ]
  }

  return [...baseItems, authItem]
})

// Use a placeholder logo if real one is missing, or just text. 
// Since I can't easily check file existence in this step without a tool call, I'll assume a placeholder or text.
// But wait, the user's CardNav expects a `logo` prop which is a src string.
const logoSrc = '/logo.png' 
</script>

<template>
  <header class="app-header-container">
    <CardNav
      :logo="logoSrc"
      logoAlt="Scaffold Logo"
      :items="items"
      baseColor="#ffffff"
      menuColor="#000"
      buttonBgColor="#7c3aed"
      buttonTextColor="#fff"
      ease="power3.out"
      ctaLabel="搜索"
      ctaTo="/posts/search"
    />
  </header>
</template>

<style scoped>
.app-header-container {
  position: relative;
  z-index: 100;
  height: 80px; /* Reserve space for the header */
}
</style>
