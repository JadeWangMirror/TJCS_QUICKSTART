<template>
  <aside class="admin-sidebar">
    <div class="admin-sidebar__brand">
      <span>后台管理</span>
    </div>
    <nav>
      <RouterLink to="/admin/dashboard" exact-active-class="is-active">数据概览</RouterLink>
      <RouterLink to="/admin/users">用户管理</RouterLink>
      <RouterLink to="/admin/content">内容审核</RouterLink>
      <RouterLink to="/admin/tags">标签管理</RouterLink>
      <RouterLink to="/admin/statistics">数据统计</RouterLink>
    </nav>
  </aside>
</template>

<style scoped>
.admin-sidebar {
  background: linear-gradient(180deg, rgba(124, 58, 237, 0.18), transparent),
    rgba(15, 23, 42, 0.95);
  color: #e2e8f0;
  padding: 2rem 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.admin-sidebar__brand {
  font-size: 1.25rem;
  font-weight: 700;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: #c4b5fd;
}

.admin-sidebar nav {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.admin-sidebar a {
  color: rgba(226, 232, 240, 0.84);
  text-decoration: none;
  font-weight: 500;
  padding: 0.6rem 0.75rem;
  border-radius: 10px;
  transition: background-color 0.15s ease, color 0.15s ease;
}

.admin-sidebar a:hover,
.admin-sidebar .is-active {
  background: rgba(79, 70, 229, 0.24);
  color: #ffffff;
}
</style>
