<script setup>
import { ref } from 'vue'

const menuItems = ref([
  {
    title: '发现',
    expanded: true,
    items: [
      { text: '首页', to: '/' },
      { text: '个性化推荐', to: '/recommendations/personal' },
      { text: '热门话题', to: '/recommendations/trending' },
      { text: '最新发布', to: '/recommendations/latest' },
      { text: '搜索', to: '/posts/search' }
    ]
  },
  {
    title: '生成工作台',
    expanded: true,
    items: [
      { text: '提示词工作台', to: '/ai/workbench' },
      { text: '生成历史', to: '/ai/history' },
      { text: '生图工坊', to: '/ai/generate' },
      { text: '生图历史', to: '/ai/genhistory' }
    ]
  },
  {
    title: '我的',
    expanded: true,
    items: [
      { text: '个人资料', to: '/profile' },
      { text: '收藏夹', to: '/profile/favorites' },
      { text: '浏览记录', to: '/history/browse' },
      // { text: '关注动态', to: '/profile/follows' },
      // { text: '私信', to: '/messages' }
    ]
  }
])

const toggleSection = (index) => {
  menuItems.value[index].expanded = !menuItems.value[index].expanded
}
</script>

<template>
  <aside class="main-sidebar">
    <div 
      v-for="(section, index) in menuItems" 
      :key="index" 
      class="main-sidebar__section"
    >
      <div class="section-header" @click="toggleSection(index)">
        <h2>{{ section.title }}</h2>
        <svg 
          class="chevron-icon" 
          :class="{ 'is-expanded': section.expanded }"
          xmlns="http://www.w3.org/2000/svg" 
          width="20" 
          height="20" 
          viewBox="0 0 24 24" 
          fill="none" 
          stroke="currentColor" 
          stroke-width="2" 
          stroke-linecap="round" 
          stroke-linejoin="round"
        >
          <polyline points="6 9 12 15 18 9"></polyline>
        </svg>
      </div>
      
      <div 
        class="section-content"
        :style="{ maxHeight: section.expanded ? '500px' : '0' }"
      >
        <nav>
          <RouterLink 
            v-for="item in section.items" 
            :key="item.to" 
            :to="item.to" 
            exact-active-class="is-active"
          >
            {{ item.text }}
          </RouterLink>
        </nav>
      </div>
    </div>
  </aside>
</template>

<style scoped>
.main-sidebar {
  background: #ffffff;
  border-radius: 18px;
  box-shadow: 0 18px 42px rgba(15, 23, 42, 0.12);
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  transition: all 0.3s ease;

  /* Sticky Positioning */
  position: sticky;
  top: 5.5rem; /* 4rem header + 1.5rem gap */
  z-index: 10;
  max-height: calc(100vh - 7rem); /* Viewport - top offset - bottom gap */
  overflow-y: auto;

  /* Scrollbar Styling */
  scrollbar-width: thin;
  scrollbar-color: transparent transparent; /* Hidden by default */
}

.main-sidebar:hover {
  scrollbar-color: #cbd5e1 transparent;
}

.main-sidebar::-webkit-scrollbar {
  width: 4px;
}

.main-sidebar::-webkit-scrollbar-track {
  background: transparent;
}

.main-sidebar::-webkit-scrollbar-thumb {
  background-color: transparent;
  border-radius: 20px;
}

.main-sidebar:hover::-webkit-scrollbar-thumb {
  background-color: #cbd5e1;
}

.main-sidebar__section {
  display: flex;
  flex-direction: column;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: pointer;
  padding: 0.5rem 0;
  user-select: none;
  transition: opacity 0.2s ease;
}

.section-header:hover {
  opacity: 0.8;
}

.section-header h2 {
  margin: 0;
  font-size: 1rem;
  font-weight: 700;
  text-transform: uppercase;
  color: #a57de4;
  letter-spacing: 0.06em;
}

.chevron-icon {
  color: #a57de4;
  transition: transform 0.3s ease;
}

.chevron-icon.is-expanded {
  transform: rotate(180deg);
}

.section-content {
  overflow: hidden;
  transition: max-height 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.main-sidebar nav {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  padding-top: 0.5rem;
}

.main-sidebar a {
  color: #475569;
  text-decoration: none;
  font-weight: 500;
  padding: 0.6rem 0.75rem;
  border-radius: 12px;
  transition: all 0.2s ease;
  font-size: 0.95rem;
  display: flex;
  align-items: center;
}

.main-sidebar a:hover {
  background-color: rgba(165, 125, 228, 0.08);
  color: #7c3aed;
  transform: translateX(4px);
}

.main-sidebar .is-active {
  background-color: rgba(124, 58, 237, 0.1);
  color: #6d28d9;
  font-weight: 600;
}
</style>
