<template>
  <transition name="toast-fade">
    <div v-if="visible" class="custom-toast">
      <svg viewBox="0 0 24 24" class="icon-success">
        <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
      </svg>
      {{ message }}
    </div>
  </transition>
</template>

<script setup>

// 接收父组件传递的两个属性
const props = defineProps({
  message: {
    type: String,
    required: true
  },
  visible: {
    type: Boolean,
    default: false
  }
});
</script>

<style scoped>
/* ======================== 核心样式 ======================== */
.custom-toast {
  /* 定位：固定在屏幕上，确保在最上层 */
  position: fixed;
  bottom: 50px; /* 距离底部 50px */
  left: 50%;
  transform: translateX(-50%); /* 确保精确水平居中 */
  
  /* 外观 */
  background-color: rgba(0, 0, 0, 0.75); /* 半透明背景 */
  color: white;
  padding: 10px 20px;
  border-radius: 8px;
  z-index: 9999; /* 确保在任何其他元素之上 */
  
  /* 布局 */
  display: flex;
  align-items: center;
  font-size: 14px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

/* 图标样式 */
.icon-success {
  width: 16px;
  height: 16px;
  margin-right: 8px;
  fill: #4CAF50; /* 成功的绿色 */
}

/* ======================== 动画样式 ======================== */
/* 定义进入和离开动画的过渡属性 */
.toast-fade-enter-active,
.toast-fade-leave-active {
  transition: opacity 0.3s ease, transform 0.3s ease;
}

/* 动画起始/结束状态：不透明度为 0，且向下偏移 20px (实现从下往上弹出) */
.toast-fade-enter-from,
.toast-fade-leave-to {
  opacity: 0;
  transform: translate(-50%, 20px); /* 水平居中 ( -50%) + 向下偏移 20px */
}
</style>