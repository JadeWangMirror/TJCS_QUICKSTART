<template>
  <div class="preview-container">
    <!-- 渲染缩略图 -->
      <img v-for="(url, index) in images" :key="index" :src="url" class="preview-image" alt="图片预览" loading="lazy"
        @click="openModal(index)" />
      <div v-if="showModal" class="image-modal" @click.self="closeModal">
        <span class="close-btn" @click="closeModal">&times;</span>
        <img :src="images[currentIndex]" alt="放大图片" />
        <!-- 添加导航按钮 -->
        <button v-if="images.length > 1" class="nav-btn prev-btn" @click.stop="prevImage">‹</button>
        <button v-if="images.length > 1" class="nav-btn next-btn" @click.stop="nextImage">›</button>
        <div class="image-counter" v-if="images.length > 1">
          {{ currentIndex + 1 }} / {{ images.length }}
        </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
  import { ref, defineProps } from 'vue';

  const props = defineProps<{
    images: string[]; // 图片数组
  }>();

  const showModal = ref(false);
  const currentIndex = ref(0);

  const openModal = (index: number) => {
    currentIndex.value = index;
    showModal.value = true;
  };

  const closeModal = () => {
    showModal.value = false;
  };

  const prevImage = () => {
    currentIndex.value = (currentIndex.value - 1 + props.images.length) % props.images.length;
  };

  const nextImage = () => {
    currentIndex.value = (currentIndex.value + 1) % props.images.length;
  };
</script>

<style scoped>
  .preview-container {
    display: contents;
  }

  .preview-image {
    width: 100%;
    height: 150px;
    object-fit: cover;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
  }

  .preview-image:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  }

  .image-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.9);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 9999;
  }

  .image-modal img {
    max-width: 90%;
    max-height: 80%;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
  }

  .close-btn {
    position: absolute;
    top: 1rem;
    right: 1.5rem;
    font-size: 2rem;
    color: #fff;
    cursor: pointer;
    user-select: none;
  }

  /* 导航按钮 */
  .nav-btn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: rgba(255, 255, 255, 0.2);
    color: white;
    border: none;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    font-size: 1.5rem;
    cursor: pointer;
    transition: all 0.2s ease;
  }

  .nav-btn:hover {
    background: rgba(255, 255, 255, 0.3);
  }

  .prev-btn {
    left: 2rem;
  }

  .next-btn {
    right: 2rem;
  }

  /* 图片计数器 */
  .image-counter {
    position: absolute;
    bottom: 1rem;
    left: 50%;
    transform: translateX(-50%);
    background: rgba(0, 0, 0, 0.5);
    color: white;
    padding: 0.25rem 1rem;
    border-radius: 20px;
    font-size: 0.9rem;
  }
</style>