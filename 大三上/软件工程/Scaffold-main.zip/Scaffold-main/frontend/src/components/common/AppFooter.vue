<template>
  <footer class="app-footer">
    <p>© {{ new Date().getFullYear() }} PromptHub · 创享论坛</p>
    <nav aria-label="底部导航">
      <RouterLink to="/about">关于我们</RouterLink>
      <RouterLink to="/guidelines">社区规范</RouterLink>
      <RouterLink to="/support">支持与帮助</RouterLink>
      <RouterLink to="/feedback">反馈建议</RouterLink>
    </nav>
  </footer>
</template>

<style scoped>
.app-footer {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  align-items: center;
  gap: 0.75rem;
  padding: 1.25rem 2rem;
  border-top: 1px solid rgba(15, 23, 42, 0.08);
  background-color: #fff;
  font-size: 0.9rem;
  color: #64748b;
}

.app-footer nav {
  display: flex;
  gap: 1rem;
}

.app-footer a {
  color: inherit;
  text-decoration: none;
  transition: color 0.15s ease;
}

.app-footer a:hover {
  color: #7c3aed;
}
</style>
