
import { createApp } from 'vue'

import App from './App.vue'
import router from './router'
import './assets/styles/main.css'
import ElementPlus from 'element-plus'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import { createPinia } from 'pinia'
import { useAuthStore } from './store/modules/auth'

const app = createApp(App)
const pinia = createPinia()
app.use(pinia)
app.use(router)
app.use(ElementPlus)
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}

// 挂载应用
app.mount('#app')

// 初始化 auth store，恢复登录状态（不阻塞应用启动）
const authStore = useAuthStore()
authStore.initAuth().catch((error) => {
  console.error('Failed to initialize auth:', error)
})