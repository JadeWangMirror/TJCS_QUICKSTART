<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { authService } from '@/services/auth.service'

const router = useRouter()

const email = ref('')
const verificationCode = ref('')
const newPassword = ref('')
const confirmPassword = ref('')
const errorMessage = ref('')
const successMessage = ref('')
const isLoading = ref(false)
const isSendingCode = ref(false)
const countdown = ref(0)

// 倒计时定时器
let countdownTimer: number | null = null

const startCountdown = () => {
  countdown.value = 60
  if (countdownTimer) {
    clearInterval(countdownTimer)
  }
  countdownTimer = window.setInterval(() => {
    countdown.value--
    if (countdown.value <= 0) {
      if (countdownTimer) {
        clearInterval(countdownTimer)
        countdownTimer = null
      }
    }
  }, 1000)
}

const handleSendCode = async () => {
  if (!email.value) {
    errorMessage.value = '请输入邮箱地址'
    return
  }

  // 邮箱格式验证
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!emailRegex.test(email.value)) {
    errorMessage.value = '请输入有效的邮箱地址'
    return
  }

  errorMessage.value = ''
  isSendingCode.value = true

  try {
    const response = await authService.sendVerificationCode(email.value)
    if (response.status === 'success') {
      successMessage.value = '验证码已发送，请查收邮件'
      startCountdown()
    } else {
      errorMessage.value = response.message || '发送验证码失败'
    }
  } catch (error: any) {
    errorMessage.value = error?.message || '发送验证码失败，请稍后重试'
  } finally {
    isSendingCode.value = false
  }
}

const handleResetPassword = async () => {
  errorMessage.value = ''
  successMessage.value = ''

  // 表单验证
  if (!email.value) {
    errorMessage.value = '请输入邮箱地址'
    return
  }

  if (!verificationCode.value) {
    errorMessage.value = '请输入验证码'
    return
  }

  if (!newPassword.value) {
    errorMessage.value = '请输入新密码'
    return
  }

  if (newPassword.value.length < 8) {
    errorMessage.value = '密码长度至少 8 位'
    return
  }

  if (newPassword.value !== confirmPassword.value) {
    errorMessage.value = '两次输入的密码不一致'
    return
  }

  isLoading.value = true

  try {
    const response = await authService.resetPassword({
      email: email.value,
      new_password: newPassword.value,
      verification_code: verificationCode.value,
    })

    if (response.status === 'success') {
      successMessage.value = response.message || '密码重置成功，请使用新密码登录'
      // 3秒后跳转到登录页
      setTimeout(() => {
        router.push('/auth/login')
      }, 3000)
    } else {
      errorMessage.value = response.message || '密码重置失败'
    }
  } catch (error: any) {
    errorMessage.value = error?.message || '密码重置失败，请稍后重试'
  } finally {
    isLoading.value = false
  }
}
</script>

<template>
  <div class="auth-view">
    <header>
      <h1>找回密码</h1>
      <p>输入注册邮箱和验证码，重置您的密码。</p>
    </header>

    <form class="auth-view__form" @submit.prevent="handleResetPassword">
      <!-- 错误提示 -->
      <div v-if="errorMessage" class="error-message">
        {{ errorMessage }}
      </div>

      <!-- 成功提示 -->
      <div v-if="successMessage" class="success-message">
        {{ successMessage }}
        <span v-if="successMessage.includes('成功')">3秒后将跳转到登录页面...</span>
      </div>

      <label>
        <span>注册邮箱</span>
        <input
          v-model="email"
          type="email"
          name="email"
          placeholder="you@example.com"
          required
          :disabled="isLoading"
        />
      </label>

      <label>
        <span>验证码</span>
        <div class="verification-code-group">
          <input
            v-model="verificationCode"
            type="text"
            name="verification_code"
            placeholder="请输入验证码"
            maxlength="6"
            required
            :disabled="isLoading"
            class="verification-code-input"
          />
          <button
            type="button"
            @click="handleSendCode"
            :disabled="isSendingCode || countdown > 0 || isLoading"
            class="send-code-btn"
          >
            {{ countdown > 0 ? `${countdown}秒后重发` : isSendingCode ? '发送中...' : '发送验证码' }}
          </button>
        </div>
      </label>

      <label>
        <span>新密码</span>
        <input
          v-model="newPassword"
          type="password"
          name="new_password"
          placeholder="至少 8 位密码"
          required
          :disabled="isLoading"
        />
      </label>

      <label>
        <span>确认密码</span>
        <input
          v-model="confirmPassword"
          type="password"
          name="confirm_password"
          placeholder="再次输入新密码"
          required
          :disabled="isLoading"
        />
      </label>

      <button type="submit" :disabled="isLoading">
        {{ isLoading ? '重置中...' : '重置密码' }}
      </button>
    </form>

    <section class="auth-view__info">
      <h2>安全提示</h2>
      <ul>
        <li>验证码有效期为 10 分钟。</li>
        <li>如未收到，可在垃圾邮箱中查找或重新发送。</li>
        <li>密码长度至少 8 位，建议包含字母、数字和特殊字符。</li>
        <li>如仍有问题，请联系管理员协助处理。</li>
      </ul>
    </section>

    <footer>
      <RouterLink to="/auth/login">返回登录</RouterLink>
    </footer>
  </div>
</template>

<style scoped>
.auth-view {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

header h1 {
  margin: 0;
  font-size: 1.8rem;
}

header p {
  margin: 0.5rem 0 0;
  color: #475569;
}

.error-message {
  padding: 0.75rem 1rem;
  background: #fee2e2;
  border: 1px solid #fca5a5;
  border-radius: 8px;
  color: #991b1b;
  font-size: 0.9rem;
}

.success-message {
  padding: 0.75rem 1rem;
  background: #d1fae5;
  border: 1px solid #86efac;
  border-radius: 8px;
  color: #065f46;
  font-size: 0.9rem;
}

.success-message span {
  display: block;
  margin-top: 0.25rem;
  font-size: 0.85rem;
  opacity: 0.8;
}

.auth-view__form {
  display: grid;
  gap: 1rem;
}

label {
  display: grid;
  gap: 0.5rem;
  font-weight: 500;
}

input {
  padding: 0.75rem 1rem;
  border-radius: 12px;
  border: 1px solid rgba(148, 163, 184, 0.6);
  font-size: 1rem;
}

input:disabled {
  background: #f1f5f9;
  cursor: not-allowed;
}

.verification-code-group {
  display: flex;
  gap: 0.75rem;
}

.verification-code-input {
  flex: 1;
}

.send-code-btn {
  padding: 0.75rem 1rem;
  background: rgba(79, 70, 229, 0.1);
  color: #4f46e5;
  border: 1px solid rgba(79, 70, 229, 0.2);
  border-radius: 12px;
  font-weight: 500;
  cursor: pointer;
  white-space: nowrap;
  transition: all 0.2s;
}

.send-code-btn:hover:not(:disabled) {
  background: rgba(79, 70, 229, 0.15);
}

.send-code-btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

button[type='submit'] {
  background: linear-gradient(120deg, #14b8a6, #0ea5e9);
  color: #fff;
  padding: 0.75rem 1.8rem;
  border: none;
  border-radius: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: opacity 0.2s;
}

button[type='submit']:hover:not(:disabled) {
  opacity: 0.9;
}

button[type='submit']:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.auth-view__info {
  background: rgba(45, 212, 191, 0.12);
  padding: 1.2rem;
  border-radius: 16px;
}

.auth-view__info h2 {
  margin: 0 0 0.75rem;
  font-size: 1.1rem;
  color: #0f766e;
}

.auth-view__info ul {
  margin: 0;
  padding-left: 1.2rem;
  color: #334155;
}

footer {
  display: flex;
  justify-content: flex-start;
}

footer a {
  color: #0ea5e9;
  font-weight: 600;
}
</style>
