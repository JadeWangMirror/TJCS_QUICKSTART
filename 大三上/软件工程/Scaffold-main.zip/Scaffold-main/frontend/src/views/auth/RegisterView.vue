<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/store'
import { authService } from '@/services/auth.service'

const router = useRouter()
const authStore = useAuthStore()

const username = ref('')
const email = ref('')
const verificationCode = ref('')
const introduce = ref('')
const password = ref('')
const confirmPassword = ref('')
const errorMessage = ref('')
const successMessage = ref('')
const isLoading = ref(false)
const isSendingCode = ref(false)
const countdown = ref(0)

const passwordTips = [
  '至少 8 位字符，推荐包含大小写字母与数字',
  '需要邮箱验证码验证，请先发送验证码',
  '注册完成后将跳转至登录页面',
]

const handleSendCode = async () => {
  errorMessage.value = ''
  
  // 验证邮箱
  if (!email.value) {
    errorMessage.value = '请先输入邮箱'
    return
  }
  
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!emailRegex.test(email.value)) {
    errorMessage.value = '请输入有效的邮箱地址'
    return
  }
  
  isSendingCode.value = true
  
  try {
    const response = await authService.sendVerificationCode(email.value)
    if (response.status === 'success') {
      successMessage.value = '验证码已发送，请查收邮件'
      // 开始倒计时
      countdown.value = 60
      const timer = setInterval(() => {
        countdown.value--
        if (countdown.value <= 0) {
          clearInterval(timer)
        }
      }, 1000)
    } else {
      errorMessage.value = response.message || '发送失败，请稍后重试'
    }
  } catch (error: any) {
    errorMessage.value = error?.message || '发送验证码失败'
  } finally {
    isSendingCode.value = false
  }
}

const handleRegister = async () => {
  errorMessage.value = ''
  successMessage.value = ''
  
  // 表单验证
  if (!username.value || !email.value || !verificationCode.value || !password.value || !confirmPassword.value) {
    errorMessage.value = '请填写所有必填项'
    return
  }
  
  if (password.value.length < 8) {
    errorMessage.value = '密码长度至少 8 位'
    return
  }
  
  if (password.value !== confirmPassword.value) {
    errorMessage.value = '两次输入的密码不一致'
    return
  }
  
  isLoading.value = true
  
  try {
    await authStore.register({
      name: username.value,
      email: email.value,
      verification_code: verificationCode.value,
      password: password.value,
      introduce: introduce.value || '',
      tag: []
    })
    
    successMessage.value = '注册成功！3 秒后跳转到登录页...'
    
    // 3秒后跳转到登录页
    setTimeout(() => {
      router.push('/auth/login')
    }, 3000)
  } catch (error: any) {
    errorMessage.value = error?.message || '注册失败，请稍后重试'
  } finally {
    isLoading.value = false
  }
}
</script>

<template>
  <div class="auth-view">
    <header>
      <h1>注册新账号</h1>
      <p>成为创享论坛会员，开启提示词与生成作品的交流旅程。</p>
    </header>

    <form class="auth-view__form" @submit.prevent="handleRegister">
      <!-- 成功提示 -->
      <div v-if="successMessage" class="success-message">
        {{ successMessage }}
      </div>
      
      <!-- 错误提示 -->
      <div v-if="errorMessage" class="error-message">
        {{ errorMessage }}
      </div>
      
      <label>
        <span>用户名 *</span>
        <input 
          v-model="username"
          type="text" 
          name="username" 
          placeholder="请输入用户名" 
          required 
          maxlength="24"
          :disabled="isLoading"
        />
      </label>
      <label>
        <span>邮箱 *</span>
        <input 
          v-model="email"
          type="email" 
          name="email" 
          placeholder="your@email.com"
          required
          :disabled="isLoading"
        />
      </label>
      <label>
        <span>邮箱验证码 *</span>
        <div style="display: flex; gap: 0.5rem;">
          <input 
            v-model="verificationCode"
            type="text" 
            name="verificationCode" 
            placeholder="请输入6位验证码"
            required
            maxlength="6"
            :disabled="isLoading"
            style="flex: 1;"
          />
          <button 
            type="button" 
            @click="handleSendCode"
            :disabled="isSendingCode || countdown > 0 || isLoading"
            style="padding: 0.75rem 1rem; white-space: nowrap; min-width: 100px;"
          >
            {{ countdown > 0 ? `${countdown}秒后重试` : isSendingCode ? '发送中...' : '发送验证码' }}
          </button>
        </div>
      </label>
      <label>
        <span>个人简介（可选）</span>
        <input 
          v-model="introduce"
          type="text" 
          name="introduce" 
          placeholder="介绍一下自己"
          :disabled="isLoading"
        />
      </label>
      <label>
        <span>设置密码 *</span>
        <input 
          v-model="password"
          type="password" 
          name="password" 
          placeholder="输入密码（至少 8 位）" 
          required 
          maxlength="32"
          :disabled="isLoading"
        />
      </label>
      <label>
        <span>确认密码 *</span>
        <input 
          v-model="confirmPassword"
          type="password" 
          name="confirmPassword" 
          placeholder="再次输入密码" 
          required 
          maxlength="32"
          :disabled="isLoading"
        />
      </label>
      <button type="submit" :disabled="isLoading">
        {{ isLoading ? '注册中...' : '注册并继续' }}
      </button>
    </form>

    <section class="auth-view__tips">
      <h2>完善账号信息</h2>
      <ul>
        <li v-for="tip in passwordTips" :key="tip">{{ tip }}</li>
      </ul>
    </section>

    <footer>
      <p>
        已有账号？
        <RouterLink to="/auth/login">返回登录</RouterLink>
      </p>
    </footer>
  </div>
</template>

<style scoped>
.auth-view {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

header h1 {
  margin: 0;
  font-size: 1.8rem;
}

header p {
  margin: 0.5rem 0 0;
  color: #475569;
}

.success-message {
  padding: 0.75rem 1rem;
  background: #d1fae5;
  border: 1px solid #6ee7b7;
  border-radius: 8px;
  color: #065f46;
  font-size: 0.9rem;
}

.error-message {
  padding: 0.75rem 1rem;
  background: #fee2e2;
  border: 1px solid #fca5a5;
  border-radius: 8px;
  color: #991b1b;
  font-size: 0.9rem;
}

.auth-view__form {
  display: grid;
  gap: 1rem;
}

label {
  display: grid;
  gap: 0.5rem;
  font-weight: 500;
}

input {
  padding: 0.75rem 1rem;
  border-radius: 12px;
  border: 1px solid rgba(148, 163, 184, 0.6);
  font-size: 1rem;
}

input:disabled {
  background: #f1f5f9;
  cursor: not-allowed;
}

button[type='submit'] {
  background: linear-gradient(120deg, #2563eb, #7c3aed);
  color: #fff;
  padding: 0.75rem 1.8rem;
  border: none;
  border-radius: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: opacity 0.2s;
}

button[type='submit']:hover:not(:disabled) {
  opacity: 0.9;
}

button[type='submit']:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.auth-view__tips {
  background: rgba(96, 165, 250, 0.12);
  padding: 1.25rem;
  border-radius: 16px;
}

.auth-view__tips h2 {
  margin: 0 0 0.75rem;
  font-size: 1.1rem;
  color: #1e3a8a;
}

.auth-view__tips ul {
  margin: 0;
  padding-left: 1.2rem;
  color: #334155;
}

footer p {
  margin: 0;
  color: #475569;
}

footer a {
  color: #2563eb;
  font-weight: 600;
}
</style>
