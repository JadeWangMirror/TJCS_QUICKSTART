<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/store'

const router = useRouter()
const authStore = useAuthStore()

const username = ref('')
const password = ref('')
const errorMessage = ref('')
const isLoading = ref(false)

const providers = [
  { id: 'google', label: 'Google' },
  { id: 'github', label: 'GitHub' },
  { id: 'wechat', label: '微信' },
]

const handleLogin = async () => {
  errorMessage.value = ''
  
  // 表单验证
  if (!username.value || !password.value) {
    errorMessage.value = '请输入用户名和密码'
    return
  }
  
  isLoading.value = true
  
  try {
    await authStore.login({
      name: username.value,
      password: password.value,
    })
    
    // token 已经在 store 的 login action 中统一保存到 localStorage 和 cookie
    // 登录成功，跳转到首页
    router.push('/')
  } catch (error: any) {
    errorMessage.value = error?.message || '登录失败，请检查用户名和密码'
  } finally {
    isLoading.value = false
  }
}
</script>

<template>
  <div class="auth-view">
    <header>
      <h1>登录账号</h1>
      <p>欢迎回来！继续探索提示词灵感，记录你的生成创作。</p>
    </header>

    <form class="auth-view__form" @submit.prevent="handleLogin">
      <!-- 错误提示 -->
      <div v-if="errorMessage" class="error-message">
        {{ errorMessage }}
      </div>
      
      <label>
        <span>用户名</span>
        <input 
          v-model="username"
          type="text" 
          name="username" 
          placeholder="请输入用户名" 
          required 
          maxlength="24"
          :disabled="isLoading"
        />
      </label>
      <label>
        <span>密码</span>
        <input 
          v-model="password"
          type="password" 
          name="password" 
          placeholder="至少 8 位密码" 
          required 
          maxlength="32"
          :disabled="isLoading"
        />
      </label>
      <div class="auth-view__actions">
        <RouterLink to="/auth/forgot-password">忘记密码？</RouterLink>
        <button type="submit" :disabled="isLoading">
          {{ isLoading ? '登录中...' : '登录' }}
        </button>
      </div>
    </form>


    <footer>
      <p>
        还没有账号？
        <RouterLink to="/auth/register">立即注册</RouterLink>
      </p>
    </footer>
  </div>
</template>

<style scoped>
.auth-view {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

header h1 {
  margin: 0;
  font-size: 1.8rem;
}

header p {
  margin: 0.5rem 0 0;
  color: #475569;
}

.error-message {
  padding: 0.75rem 1rem;
  background: #fee2e2;
  border: 1px solid #fca5a5;
  border-radius: 8px;
  color: #991b1b;
  font-size: 0.9rem;
}

.auth-view__form {
  display: grid;
  gap: 1rem;
}

label {
  display: grid;
  gap: 0.5rem;
  font-weight: 500;
}

input {
  padding: 0.75rem 1rem;
  border-radius: 12px;
  border: 1px solid rgba(148, 163, 184, 0.6);
  font-size: 1rem;
}

input:disabled {
  background: #f1f5f9;
  cursor: not-allowed;
}

.auth-view__actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

button[type='submit'] {
  background: linear-gradient(120deg, #7c3aed, #4c1d95);
  color: #fff;
  padding: 0.7rem 1.6rem;
  border: none;
  border-radius: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: opacity 0.2s;
}

button[type='submit']:hover:not(:disabled) {
  opacity: 0.9;
}

button[type='submit']:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.auth-view__providers {
  display: grid;
  gap: 0.75rem;
}

.auth-view__providers div {
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
}

.auth-view__providers button {
  flex: 1;
  min-width: 120px;
  padding: 0.7rem 1rem;
  border-radius: 12px;
  border: 1px solid rgba(99, 102, 241, 0.25);
  background: rgba(79, 70, 229, 0.06);
  color: #312e81;
  cursor: pointer;
}

.auth-view__providers button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

footer p {
  margin: 0;
  color: #475569;
}

footer a {
  color: #7c3aed;
  font-weight: 600;
}
</style>
