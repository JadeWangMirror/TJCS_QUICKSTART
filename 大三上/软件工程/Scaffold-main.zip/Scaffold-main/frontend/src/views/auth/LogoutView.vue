<script setup lang="ts">
const steps = [
  '清除本地会话与缓存凭证',
  '通知后端撤销 token 或刷新令牌',
  '跳转至登录页面或首页',
]
</script>

<template>
  <section class="logout-view">
    <h1>退出登录</h1>
    <p>即将安全退出账号，请确认当前工作已保存。</p>
    <ol>
      <li v-for="step in steps" :key="step">{{ step }}</li>
    </ol>
    <div class="logout-view__actions">
      <button type="button">确认退出</button>
      <RouterLink to="/">取消</RouterLink>
    </div>
  </section>
</template>

<style scoped>
.logout-view {
  display: grid;
  gap: 1.25rem;
  max-width: 540px;
}

h1 {
  margin: 0;
  font-size: 1.8rem;
}

p {
  margin: 0;
  color: #475569;
}

ol {
  margin: 0;
  padding-left: 1.2rem;
  color: #334155;
}

.logout-view__actions {
  display: flex;
  gap: 1rem;
  align-items: center;
}

button {
  padding: 0.75rem 1.6rem;
  background: linear-gradient(120deg, #ef4444, #f59e0b);
  border: none;
  border-radius: 12px;
  color: #fff;
  font-weight: 600;
}

a {
  color: #4c1d95;
}
</style>
