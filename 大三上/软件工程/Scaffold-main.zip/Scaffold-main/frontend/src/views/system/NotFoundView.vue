<template>
  <section class="not-found">
    <h1>404</h1>
    <p>页面走丢了，返回首页继续探索创意灵感。</p>
    <RouterLink to="/">返回首页</RouterLink>
  </section>
</template>

<style scoped>
.not-found {
  min-height: 50vh;
  display: grid;
  place-items: center;
  gap: 1rem;
  text-align: center;
}

h1 {
  font-size: 6rem;
  margin: 0;
  color: rgba(124, 58, 237, 0.6);
}

p {
  margin: 0;
  color: #475569;
}

a {
  color: #7c3aed;
  font-weight: 600;
}
</style>
