<template>
  <section class="latest-page-ultra browse-history-page">
    <header class="page-header">
      <div class="header-content">
        <span class="badge-pill history-badge">🕒 浏览历史</span>
        <h1>
          <span class="title-cn gradient-title">浏览历史</span>
          <span class="title-en">History Records</span>
        </h1>
        <p>您最近探索的内容 · 仅您可见</p>
      </div>
    </header>

    <div class="history-controls">
      <button @click="dealDelete" class="control-btn manage-btn">
        {{ isManagingHistory ? '取消管理' : '管理记录' }}
      </button>

      <button v-if="isManagingHistory" @click="confirmDeleteSelected"
        :disabled="deleteList.size === 0 || isLoading" class="delete-all-btn">
        批量删除 ({{ deleteList.size }})
      </button>

      <button v-if="!isManagingHistory" @click="confirmDeleteAll" class="control-btn secondary-action">
        清空全部
      </button>
    </div>

    <div class="trending-list" v-if="BrowseHistoryStore.feed?.records?.length">
      <article v-for="(item, index) in BrowseHistoryStore.feed.records" :key="item.record_id" class="post-card group history-card"
        :class="{ 'is-selected-for-delete': isManagingHistory && deleteList.has(item.record_id) }"
        @click="isManagingHistory && toggleDelete(item.record_id)">
        
        <div class="glow-border"></div>
        
        <div class="rank-badge history-rank" :class="`rank-${(currentPage - 1) * pageSize + index + 1}`">
          <span class="rank-num">{{ (currentPage - 1) * pageSize + index + 1 }}</span>
        </div>

        <div class="content-info card-content">
          <h2 class="post-title card-title title-text">{{ item.title }}</h2>
          <p class="post-meta card-meta">
            <span class="author-info">
              <div class="avatar-ring">
                <div class="avatar-fallback">{{ item.author ? item.author.slice(0, 2).toUpperCase() : 'U' }}</div>
              </div>
                            <span class="author-name">{{ item.author.length>10?(item.author.slice(0,5)+"..."):item.author}}</span>
            </span>
            <span class="meta-right time-tag">
              点赞: {{ item.like_count }}
            </span>
          </p>
        </div>

        <footer class="post-actions">
          <RouterLink v-if="!isManagingHistory" :to="`/posts/${item.id}`" class="magic-btn primary-action view-btn">
            查看详情
          </RouterLink>
          <div v-else class="delete-checkbox-wrapper">
            <input type="checkbox" :checked="deleteList.has(item.record_id)" @click.stop="toggleDelete(item.record_id)"
              class="delete-checkbox" />
          </div>
        </footer>
      </article>
    </div>

    <div v-else class="no-data-message">
      <div class="empty-visual">📭</div>
      <h3>{{ isLoading ? '正在加载历史记录...' : '暂无历史记录' }}</h3>
    </div>

    <div class="pagination-wrapper">
      <button @click="goToPreviousPage" :disabled="currentPage <= 1 || isLoading" class="magic-btn">
        <span class="btn-icon">←</span>
        <span class="btn-text">上一页</span>
      </button>

      <div class="page-dots">
        <span class="current">{{ currentPage }}</span>
        <span class="divider">/</span>
        <span class="total">{{ totalPages }}</span>
      </div>

      <button @click="goToNextPage" :disabled="currentPage >= (totalPages) || isLoading" class="magic-btn">
        <span class="btn-text">下一页</span>
        <span class="btn-icon">→</span>
      </button>
    </div>
  </section>
  <CustomToast :message="toast.message.value" :visible="toast.isVisible.value" />
</template>
<script lang="ts" setup>
  // 保持脚本逻辑不变
  import { ref, reactive, watch, computed } from 'vue';
  import type { SearchFilters } from '@/types/api';
  import { useBrowseHistoryStore } from '@/store/modules/browsehistory';
  import { useRoute, useRouter } from 'vue-router';
  import CustomToast from '@/components/common/CustomToast.vue';
  import { useToast } from '@/composables/useToast';
  import { useAuthStore } from '@/store';
  import { storeToRefs } from 'pinia';
  const BrowseHistoryStore = useBrowseHistoryStore();
  const route = useRoute();
  const router = useRouter();
  const toast = useToast();
  const AuthStore = useAuthStore();
  const { loading: authLoading, currentUser } = storeToRefs(AuthStore);
  const authReady = computed<boolean>(() => {
    // 只有在 Auth Store 加载完成（loading 为 false）且 currentUser 存在时，才认为认证就绪
    return !authLoading.value && !!currentUser.value?.id;
  });
  const currentPage = computed<number>({
    get() {
      // 尝试从 URL query 获取 'page' 参数，如果不存在或无效，则默认为 1
      const page = parseInt(route.query.page as string);
      return isNaN(page) || page < 1 ? 1 : page;
    },
    // set 方法用于更新 URL
    set(newValue: number) {
      // 调用 router.push 来更新 URL 中的 query 参数，但保持其他参数不变
      router.push({
        name: route.name as string, // 保持当前路由名称
        query: { ...route.query, page: newValue.toString() }
      });
      // 新增：分页跳转时滚动到顶部，提升用户体验
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  });
  const isLoading = ref(false);
  const pageSize: number = 10;
  const filters = reactive<SearchFilters>({
    page: currentPage.value, // 初始值
    pageSize: pageSize,
  });
  watch(authReady, async (isReady) => {
    if (isReady) {
      // 仅在首次认证就绪时，根据当前 URL 的页码进行加载
      // console.log("认证就绪，首次加载浏览记录。");
      await fetchBrowseHistory();
    } else {
      // 认证未就绪且正在加载时，显示 loading 状态，等待
      // 如果 authLoading 为 true，页面将显示 '正在努力加载历史记录...'
      isLoading.value = authLoading.value;
    }
  }, { immediate: true });

  async function fetchBrowseHistory() {
    if (isLoading.value)
      return;

    isLoading.value = true;
    filters.page = currentPage.value;

    try {
      await BrowseHistoryStore.fetchBrowseHistory(filters);
    } catch (error) {
      console.error("获取历史记录数据失败:", error);
      // 实际项目中应有更友好的错误处理
    } finally {
      isLoading.value = false;
    }
  }

  watch(
    currentPage,
    (newPage: number) => {
      // 只有当 Auth Ready 且页码有效时，才触发分页请求
      if (authReady.value && newPage > 0) {
        // console.log(`页码变化到 ${newPage}，重新加载浏览记录。`);
        fetchBrowseHistory();
      }
    }
  );
  const totalPages = computed<number>(() => {
    const totalRecords = BrowseHistoryStore.feed?.total ?? 990;
    if (totalRecords === 0) return 1;
    // 使用 Math.ceil 向上取整
    return Math.ceil(totalRecords / pageSize);
  });
  // --- 分页控制函数 ---
  function goToNextPage() {
    const total = totalPages.value;
    if (currentPage.value < total) {
      currentPage.value++;
    }
  }

  function goToPreviousPage() {
    if (currentPage.value > 1) {
      currentPage.value--;
    }
  }
  let isManagingHistory = ref(false);
  const deleteList = ref<Set<number>>(new Set());
  function dealDelete() {
    isManagingHistory.value = !isManagingHistory.value;
    // 退出管理模式时，清空删除列表
    if (!isManagingHistory.value) {
      deleteList.value.clear();
    }
  }
  function toggleDelete(record_id: number) {
    if (deleteList.value.has(record_id)) {
      deleteList.value.delete(record_id);
    } else {
      deleteList.value.add(record_id);
    }
  }

  // 批量删除选中的记录
  async function confirmDeleteSelected() {
    if (deleteList.value.size === 0) {
      toast.show("请选择要删除的记录");
      return;
    }

    if (!confirm(`确定要删除选中的 ${deleteList.value.size} 条历史记录吗？此操作不可逆！`)) {
      return;
    }

    isLoading.value = true;
    const deletePromises = [];

    // 遍历 Set 并对每个 ID 调用删除方法
    for (const recordId of deleteList.value) {
      // 假设 BrowseHistoryStore.deleteBrowseHistory(record: string) 接收单个 ID
      deletePromises.push(BrowseHistoryStore.deleteBrowseHistory(recordId));
    }

    try {
      // 等待所有删除请求完成
      await Promise.all(deletePromises);

      // 删除成功后，清空删除列表，并重新获取数据
      deleteList.value.clear();
      toast.show(`成功删除 ${deletePromises.length} 条记录`);

      // 重新获取当前页数据，保持列表更新
      isLoading.value = false;
      if (BrowseHistoryStore.feed?.records?.length === 0 && currentPage.value > 1) {
        currentPage.value--; // 触发 watch 重新加载
      }
      else {
        await fetchBrowseHistory();
      }

    } catch (error) {
      console.error('Failed to delete selected posts:', error);
      toast.show("部分或全部记录删除失败");
    } finally {
      isLoading.value = false;
      isManagingHistory.value = false;
    }
  }
  async function confirmDeleteAll() {
    if (!confirm('确定要删除**所有**浏览历史记录吗？此操作不可逆！')) { // 修正提示
      return;
    }

    isLoading.value = true;
    try {
      await BrowseHistoryStore.deleteAllBrowseHistory();
      toast.show("全部历史记录删除成功");
      if (currentPage.value !== 1) {
        currentPage.value = 1;
      }
      isLoading.value = false;
      await fetchBrowseHistory();

    } catch (error) {
      console.error('Failed to delete all history:', error);
      toast.show("全部历史记录删除失败");
    } finally {
      isLoading.value = false;
    }
  }
</script>

<style scoped>
  .latest-page-ultra {
    --font-display: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;

    /* 颜色变量：简约科技主题 */
    --c-bg-page: #f8fafc;
    --c-bg-card: #ffffff;
    --c-text-primary: #0f172a;
    --c-text-secondary: #64748b;

    --c-accent: #0ea5e9;
    --c-accent-light: #bae6fd;
    --c-accent-dark: #0369a1;
    --c-accent-glow: rgba(14, 165, 233, 0.2);

    --shadow-sm: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px -1px rgba(0, 0, 0, 0.1);
    --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1);
    --shadow-hover: 0 10px 20px -5px rgba(14, 165, 233, 0.15);

    --ease-out: cubic-bezier(0.2, 0.8, 0.2, 1);

    max-width: 1300px;
    margin: 0 auto;
    padding: 50px 24px;
    background-color: var(--c-bg-page);
    min-height: 100vh;
    font-family: var(--font-display);
  }

  .page-header {
    text-align: center;
    margin-bottom: 50px;
    padding-bottom: 20px;
    border-bottom: 1px solid #e2e8f0;
  }

  .header-content {
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  .badge-pill {
    display: inline-block;
    padding: 6px 16px;
    background: rgba(14, 165, 233, 0.1);
    color: #0369a1;
    font-size: 0.85rem;
    font-weight: 600;
    border-radius: 50px;
    margin-bottom: 16px;
    border: 1px solid rgba(14, 165, 233, 0.2);
  }

  .page-header h1 {
    font-size: 2.5rem;
    margin: 0 0 12px;
    font-weight: 700;
    color: var(--c-text-primary);
    letter-spacing: -0.02em;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 15px;
    flex-wrap: wrap;
  }
  
  .gradient-title {
    background: linear-gradient(135deg, #0ea5e9, #3b82f6);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    font-weight: 800;
  }
  
  .title-en {
    background: linear-gradient(135deg, #0ea5e9, #3b82f6);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    font-weight: 800;
  }

  .page-header p {
    color: var(--c-text-secondary);
    font-size: 1.1rem;
    margin: 0;
  }

  .history-controls {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    margin-bottom: 25px;
  }

  .control-btn, .secondary-action {
    padding: 10px 20px;
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    color: var(--c-text-primary);
    font-weight: 500;
    font-size: 0.95rem;
    cursor: pointer;
    transition: all 0.2s var(--ease-out);
    box-shadow: var(--shadow-sm);
  }

  .control-btn:hover, .secondary-action:hover {
    transform: translateY(-1px);
    box-shadow: var(--shadow-md);
    border-color: var(--c-accent-light);
    color: var(--c-accent-dark);
  }

  .delete-all-btn {
    padding: 10px 20px;
    background: #fef2f2;
    border: 1px solid #fecaca;
    border-radius: 8px;
    color: #b91c1c;
    font-weight: 500;
    font-size: 0.95rem;
    cursor: pointer;
    transition: all 0.2s var(--ease-out);
    box-shadow: var(--shadow-sm);
  }

  .delete-all-btn:hover:not(:disabled) {
    background: #fee2e2;
    box-shadow: var(--shadow-md);
    transform: translateY(-1px);
  }

  .delete-all-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  .trending-list {
    display: grid;
    grid-template-columns: 1fr;
    gap: 16px;
  }

  .post-card {
    position: relative;
    background: var(--c-bg-card);
    border-radius: 16px;
    box-shadow: var(--shadow-sm);
    cursor: pointer;
    transform: translateZ(0);
    transition: transform 0.3s var(--ease-out), box-shadow 0.3s var(--ease-out);
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1.5rem;
    overflow: hidden;
    border: 1px solid #f1f5f9;
  }

  .post-card:hover {
    transform: translateY(-2px);
    box-shadow: var(--shadow-hover);
    z-index: 10;
  }

  .glow-border {
    position: absolute;
    inset: 0;
    border-radius: 16px;
    padding: 1px;
    background: linear-gradient(135deg, var(--c-accent-light), #7dd3fc);
    mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
    -webkit-mask-composite: xor;
    mask-composite: exclude;
    opacity: 0;
    transition: opacity 0.3s ease;
    pointer-events: none;
    z-index: 20;
  }

  .post-card:hover .glow-border {
    opacity: 1;
  }

  .rank-badge {
    position: static;
    width: 40px;
    height: 40px;
    min-width: 40px;
    border-radius: 10px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    z-index: 5;
    font-weight: 700;
    line-height: 1;
    padding: 0 6px;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);
    backdrop-filter: blur(2px);
    border: 1px solid rgba(255, 255, 255, 0.5);
    margin-right: 20px;
    flex-shrink: 0;
    background-color: #f1f5f9;
    color: #64748b;
  }

  .rank-num {
    font-size: 1.1em;
    font-weight: 700;
    margin-bottom: 0;
  }

  .rank-badge span {
    display: block;
    line-height: 1;
  }

  .rank-1, .rank-11, .rank-21, .rank-31 {
    background: linear-gradient(135deg, #e0f2fe 0%, #7dd3fc 100%);
    color: var(--c-accent-dark);
    border-color: var(--c-accent-light);
    box-shadow: 0 4px 12px rgba(14, 165, 233, 0.2);
  }

  .rank-2, .rank-12, .rank-22, .rank-32 {
    background: linear-gradient(135deg, #dbeafe 0%, #93c5fd 100%);
    color: #1d4ed8;
    border-color: #bfdbfe;
  }

  .rank-3, .rank-13, .rank-23, .rank-33 {
    background: linear-gradient(135deg, #f0f9ff 0%, #7dd3fc 100%);
    color: #0369a1;
    border-color: #bae6fd;
  }

  .content-info {
    flex-grow: 1;
    margin-right: 20px;
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .card-title {
    margin: 0;
    font-size: 1.2rem;
    font-weight: 600;
    line-height: 1.4;
    color: var(--c-text-primary);
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    white-space: normal;
  }

  .title-text {
    background-image: linear-gradient(90deg, var(--c-text-primary), var(--c-text-primary));
    background-size: 0% 2px;
    background-position: 0 100%;
    background-repeat: no-repeat;
    transition: background-size 0.3s ease, color 0.3s ease;
  }

  .post-card:hover .title-text {
    color: var(--c-accent-dark);
    background-image: linear-gradient(90deg, var(--c-accent-dark), var(--c-accent-dark));
    background-size: 100% 2px;
  }

  .post-meta {
    margin: 0;
    font-size: 0.9rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: var(--c-text-secondary);
  }

  .author-info {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .avatar-ring {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    padding: 1px;
    background: transparent;
    transition: background 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .post-card:hover .avatar-ring {
    background: linear-gradient(135deg, var(--c-accent-light), #7dd3fc);
  }

  .avatar-fallback {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    object-fit: cover;
    border: 1px solid #fff;
    background: #e0f2fe;
    color: var(--c-accent-dark);
    font-weight: 600;
    font-size: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .author-name {
    font-size: 0.9rem;
    font-weight: 500;
    color: #334155;
    max-width: 140px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .meta-right.time-tag {
    font-size: 0.9rem;
    color: #94a3b8;
    font-weight: 500;
  }

  .post-meta strong {
    color: var(--c-text-primary);
    font-weight: 600;
  }

  .post-actions {
    display: flex;
    gap: 10px;
    flex-shrink: 0;
    align-items: center;
  }

  .magic-btn {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 16px;
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    color: var(--c-text-primary);
    font-weight: 500;
    font-size: 0.95rem;
    cursor: pointer;
    transition: all 0.3s var(--ease-out);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.03);
    text-decoration: none;
  }

  .magic-btn:hover:not(:disabled) {
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(14, 165, 233, 0.1);
    border-color: var(--c-accent);
    color: var(--c-accent-dark);
  }

  .post-card.is-selected-for-delete {
    border: 2px solid #fecaca;
    background-color: #fff5f5;
    box-shadow: 0 4px 12px rgba(254, 202, 202, 0.2);
    transform: none;
  }

  .delete-checkbox-wrapper {
    flex-shrink: 0;
    margin-right: 0;
  }

  .delete-checkbox {
    width: 20px;
    height: 20px;
    cursor: pointer;
    accent-color: #dc2626;
  }

  .no-data-message {
    text-align: center;
    padding: 70px 0;
    color: #94a3b8;
    background-color: transparent;
  }

  .empty-visual {
    font-size: 3.5rem;
    margin-bottom: 20px;
  }

  .pagination-wrapper {
    margin-top: 50px;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 25px;
  }

  .magic-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
    background: #f8fafc;
    border-color: #e2e8f0;
    color: #94a3b8;
    box-shadow: none;
    transform: none;
  }

  .page-dots {
    font-size: 1.1rem;
    font-weight: 600;
    color: #cbd5e1;
    display: flex;
    gap: 6px;
  }

  .page-dots .current {
    color: var(--c-text-primary);
  }

  .btn-icon {
    display: block;
    width: 1em;
    height: 1em;
    font-size: 1.1em;
    line-height: 1;
  }

  @media (max-width: 768px) {
    .latest-page-ultra {
      padding: 30px 16px;
    }
    
    .page-header h1 {
      font-size: 2rem;
    }
    
    .post-card {
      flex-direction: column;
      align-items: flex-start;
      padding: 1.2rem;
    }

    .rank-badge {
      margin-bottom: 15px;
      margin-right: 0;
    }

    .content-info {
      margin-right: 0;
      width: 100%;
      margin-bottom: 15px;
    }

    .card-title {
      font-size: 1.1rem;
    }

    .post-meta {
      flex-direction: column;
      align-items: flex-start;
      margin-top: 8px;
      gap: 4px;
    }

    .post-actions {
      margin-top: 10px;
      width: 100%;
      flex-direction: row;
      justify-content: space-between;
    }

    .post-actions .magic-btn {
      flex: 1;
      text-align: center;
      padding: 10px;
      font-size: 0.9rem;
    }

    .delete-checkbox-wrapper {
      margin-right: 0;
    }
    
    .pagination-wrapper {
      margin-top: 30px;
      gap: 15px;
    }
  }
</style>