<template>
  <section class="admin-dashboard">
    <header>
      <h1>管理总览</h1>
      <p>快速查看平台关键指标并进入具体模块操作。</p>
    </header>

    <div class="admin-dashboard__stats">
      <article>
        <span>注册用户</span>
        <strong>12,480</strong>
        <small>较昨日 +3.6%</small>
      </article>
      <article>
        <span>本周发帖</span>
        <strong>946</strong>
        <small>较昨日 +1.2%</small>
      </article>
      <article>
        <span>AI 生成次数</span>
        <strong>4,236</strong>
        <small>较昨日 +5.4%</small>
      </article>
      <article>
        <span>待审核内容</span>
        <strong>18</strong>
        <small>较昨日 -12%</small>
      </article>
    </div>

    <section class="admin-dashboard__panels">
      <article>
        <h2>内容审核队列</h2>
        <p>快速处理用户举报的帖子与评论，确保社区健康。</p>
        <RouterLink to="/admin/content">进入审核</RouterLink>
      </article>
      <article>
        <h2>标签维护</h2>
        <p>维护标签树结构，优化搜索和推荐效果。</p>
        <RouterLink to="/admin/tags">管理标签</RouterLink>
      </article>
      <article>
        <h2>用户管理</h2>
        <p>查看用户状态，执行封禁、解封操作。</p>
        <RouterLink to="/admin/users">管理用户</RouterLink>
      </article>
    </section>
  </section>
</template>

<style scoped>
.admin-dashboard {
  display: grid;
  gap: 2rem;
}

header h1 {
  margin: 0;
  font-size: 2rem;
  color: #1e3a8a;
}

header p {
  margin: 0.5rem 0 0;
  color: rgba(148, 163, 184, 0.8);
}

.admin-dashboard__stats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1.25rem;
}

.admin-dashboard__stats article {
  background: rgba(15, 23, 42, 0.8);
  border-radius: 20px;
  padding: 1.5rem;
  display: grid;
  gap: 0.5rem;
  color: #f1f5f9;
  box-shadow: 0 20px 42px rgba(15, 23, 42, 0.38);
}

.admin-dashboard__stats span {
  font-size: 0.95rem;
  color: rgba(226, 232, 240, 0.74);
}

.admin-dashboard__stats strong {
  font-size: 2rem;
}

.admin-dashboard__stats small {
  color: rgba(96, 165, 250, 0.9);
}

.admin-dashboard__panels {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 1.5rem;
}

.admin-dashboard__panels article {
  background: rgba(15, 23, 42, 0.85);
  color: #e0e7ff;
  border-radius: 18px;
  padding: 1.75rem;
  display: grid;
  gap: 0.75rem;
}

.admin-dashboard__panels h2 {
  margin: 0;
  font-size: 1.25rem;
}

.admin-dashboard__panels p {
  margin: 0;
  color: rgba(191, 219, 254, 0.78);
}

.admin-dashboard__panels a {
  color: #fbbf24;
  font-weight: 600;
}
</style>
