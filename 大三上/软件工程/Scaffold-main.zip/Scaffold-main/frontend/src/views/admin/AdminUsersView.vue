<template>
  <section class="admin-users">
    <header>
      <h1>用户管理</h1>
      <p>查询用户状态，执行封禁/解封操作。</p>
    </header>

    <div class="admin-users__toolbar">
      <input type="search" placeholder="搜索邮箱或昵称" />
      <select>
        <option>全部状态</option>
        <option>正常</option>
        <option>封禁中</option>
      </select>
      <button type="button">导出列表</button>
    </div>

    <table>
      <thead>
        <tr>
          <th>用户</th>
          <th>邮箱</th>
          <th>注册时间</th>
          <th>状态</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="index in 8" :key="index">
          <td>创作者 {{ index }}</td>
          <td>user{{ index }}@example.com</td>
          <td>2024-06-1{{ index }}</td>
          <td>
            <span class="status" :class="{ blocked: index === 3 }">
              {{ index === 3 ? '封禁中' : '正常' }}
            </span>
          </td>
          <td>
            <button type="button">查看</button>
            <button type="button">{{ index === 3 ? '解封' : '封禁' }}</button>
          </td>
        </tr>
      </tbody>
    </table>
  </section>
</template>

<style scoped>
.admin-users {
  display: grid;
  gap: 1.75rem;
  color: #e2e8f0;
}

header h1 {
  margin: 0;
  font-size: 1.9rem;
}

header p {
  margin: 0.4rem 0 0;
  color: rgba(148, 163, 184, 0.8);
}

.admin-users__toolbar {
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
}

input,
select,
button {
  padding: 0.6rem 1rem;
  border-radius: 12px;
  border: 1px solid rgba(148, 163, 184, 0.36);
  background: rgba(15, 23, 42, 0.7);
  color: inherit;
}

button {
  border: 1px solid rgba(96, 165, 250, 0.5);
  color: #bfdbfe;
}

table {
  width: 100%;
  border-collapse: collapse;
  background: rgba(15, 23, 42, 0.85);
  border-radius: 18px;
  overflow: hidden;
  box-shadow: 0 18px 40px rgba(15, 23, 42, 0.4);
}

th,
td {
  padding: 1rem 1.25rem;
  text-align: left;
  border-bottom: 1px solid rgba(148, 163, 184, 0.18);
}

thead {
  background: rgba(30, 41, 59, 0.9);
}

.status {
  padding: 0.25rem 0.75rem;
  border-radius: 999px;
  font-size: 0.85rem;
  background: rgba(34, 197, 94, 0.2);
  color: #bbf7d0;
}

.status.blocked {
  background: rgba(248, 113, 113, 0.2);
  color: #fecaca;
}

td button {
  margin-right: 0.4rem;
}

@media (max-width: 768px) {
  table {
    display: block;
    overflow-x: auto;
  }
}
</style>
