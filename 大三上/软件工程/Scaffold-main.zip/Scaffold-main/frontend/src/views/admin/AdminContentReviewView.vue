<template>
  <section class="admin-review">
    <header>
      <h1>内容审核</h1>
      <p>处理系统检测或用户举报的帖子与评论，确保内容合规。</p>
    </header>

    <div class="admin-review__grid">
      <aside>
        <h2>筛选条件</h2>
        <label>
          <span>类型</span>
          <select>
            <option>全部</option>
            <option>帖子</option>
            <option>评论</option>
          </select>
        </label>
        <label>
          <span>举报原因</span>
          <select>
            <option>全部</option>
            <option>敏感词</option>
            <option>版权问题</option>
            <option>其他</option>
          </select>
        </label>
      </aside>

      <section class="admin-review__list">
        <article v-for="index in 5" :key="index">
          <header>
            <h2>待审核内容 {{ index }}</h2>
            <span>举报时间：2024-09-1{{ index }}</span>
          </header>
          <p>内容摘要：包含疑似敏感词，需人工复核。</p>
          <div class="admin-review__meta">
            <span>举报人：用户 {{ index }}</span>
            <span>原作者：创作者 {{ index + 2 }}</span>
          </div>
          <footer>
            <button type="button" class="danger">删除</button>
            <button type="button">保留</button>
            <button type="button" class="ghost">加入观察</button>
          </footer>
        </article>
      </section>
    </div>
  </section>
</template>

<style scoped>
.admin-review {
  display: grid;
  gap: 1.75rem;
  color: #e2e8f0;
}

header h1 {
  margin: 0;
  font-size: 1.9rem;
}

header p {
  margin: 0.4rem 0 0;
  color: rgba(148, 163, 184, 0.8);
}

.admin-review__grid {
  display: grid;
  grid-template-columns: 260px 1fr;
  gap: 1.5rem;
}

aside {
  background: rgba(30, 41, 59, 0.85);
  border-radius: 18px;
  padding: 1.5rem;
  display: grid;
  gap: 1rem;
}

aside h2 {
  margin: 0;
  color: #bfdbfe;
}

label {
  display: grid;
  gap: 0.5rem;
  font-weight: 500;
  color: rgba(191, 219, 254, 0.86);
}

select {
  padding: 0.6rem 1rem;
  border-radius: 12px;
  border: none;
  background: rgba(148, 163, 184, 0.2);
  color: inherit;
}

.admin-review__list {
  display: grid;
  gap: 1.2rem;
}

article {
  background: rgba(15, 23, 42, 0.85);
  border-radius: 18px;
  padding: 1.75rem;
  display: grid;
  gap: 0.75rem;
  box-shadow: 0 20px 40px rgba(15, 23, 42, 0.5);
}

article header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

article h2 {
  margin: 0;
  font-size: 1.2rem;
}

article span {
  color: rgba(148, 163, 184, 0.7);
}

article p {
  margin: 0;
  color: rgba(226, 232, 240, 0.88);
}

.admin-review__meta {
  display: flex;
  justify-content: space-between;
  color: rgba(148, 163, 184, 0.74);
}

footer {
  display: flex;
  gap: 0.75rem;
}

button {
  padding: 0.6rem 1.4rem;
  border-radius: 12px;
  border: 1px solid rgba(148, 163, 184, 0.4);
  background: transparent;
  color: inherit;
  font-weight: 600;
}

.danger {
  border-color: rgba(248, 113, 113, 0.6);
  color: #fecaca;
}

.ghost {
  color: rgba(191, 219, 254, 0.78);
}

@media (max-width: 960px) {
  .admin-review__grid {
    grid-template-columns: 1fr;
  }

  .admin-review__meta {
    flex-direction: column;
    gap: 0.5rem;
  }

  footer {
    flex-direction: column;
  }
}
</style>
