<template>
  <section class="admin-tags">
    <header>
      <h1>标签管理</h1>
      <p>维护标签分类结构，支持增删改查。</p>
    </header>

    <div class="admin-tags__grid">
      <aside>
        <h2>标签树</h2>
        <ul>
          <li>
            创作方向
            <ul>
              <li>AI 绘画</li>
              <li>写作助手</li>
              <li>视频脚本</li>
            </ul>
          </li>
          <li>
            场景行业
            <ul>
              <li>电商促销</li>
              <li>教育培训</li>
              <li>品牌营销</li>
            </ul>
          </li>
        </ul>
      </aside>

      <form>
        <label>
          <span>标签名称</span>
          <input type="text" placeholder="例如：夜景" />
        </label>
        <label>
          <span>所属分类</span>
          <select>
            <option>创作方向</option>
            <option>场景行业</option>
          </select>
        </label>
        <label>
          <span>描述</span>
          <textarea rows="3" placeholder="补充标签使用说明"></textarea>
        </label>
        <div class="admin-tags__actions">
          <button type="submit">保存</button>
          <button type="button" class="ghost">删除</button>
        </div>
      </form>
    </div>
  </section>
</template>

<style scoped>
.admin-tags {
  display: grid;
  gap: 1.75rem;
  color: #e2e8f0;
}

header h1 {
  margin: 0;
  font-size: 1.9rem;
}

header p {
  margin: 0.4rem 0 0;
  color: rgba(148, 163, 184, 0.8);
}

.admin-tags__grid {
  display: grid;
  grid-template-columns: 280px 1fr;
  gap: 1.5rem;
}

aside {
  background: rgba(30, 41, 59, 0.85);
  border-radius: 18px;
  padding: 1.5rem;
}

aside h2 {
  margin: 0 0 1rem;
  color: #bfdbfe;
}

aside ul {
  margin: 0;
  padding-left: 1.2rem;
  list-style: disc;
  color: rgba(191, 219, 254, 0.85);
}

form {
  background: rgba(15, 23, 42, 0.85);
  border-radius: 18px;
  padding: 1.75rem;
  display: grid;
  gap: 1rem;
  box-shadow: 0 18px 40px rgba(15, 23, 42, 0.5);
}

label {
  display: grid;
  gap: 0.5rem;
  font-weight: 500;
  color: rgba(191, 219, 254, 0.85);
}

input,
select,
textarea {
  border-radius: 12px;
  border: none;
  background: rgba(148, 163, 184, 0.2);
  color: inherit;
  padding: 0.75rem 1rem;
}

textarea {
  resize: vertical;
}

.admin-tags__actions {
  display: flex;
  gap: 1rem;
}

button {
  padding: 0.7rem 1.6rem;
  border-radius: 12px;
  border: 1px solid rgba(96, 165, 250, 0.4);
  background: transparent;
  color: #bfdbfe;
  font-weight: 600;
}

.ghost {
  border-color: rgba(248, 113, 113, 0.6);
  color: #fecaca;
}

@media (max-width: 960px) {
  .admin-tags__grid {
    grid-template-columns: 1fr;
  }

  .admin-tags__actions {
    flex-direction: column;
  }
}
</style>
