<template>
  <section class="admin-stats">
    <header>
      <h1>数据统计</h1>
      <p>可视化展示平台用户、帖子与生成数据趋势。</p>
    </header>

    <div class="admin-stats__grid">
      <article>
        <h2>用户增长趋势</h2>
        <p>折线图占位：未来接入 ECharts 或 AntV 显示周增长数据。</p>
      </article>
      <article>
        <h2>发帖与生成对比</h2>
        <p>柱状图占位：展示帖子数量与生成次数的关系。</p>
      </article>
      <article>
        <h2>热门标签分布</h2>
        <p>饼图占位：统计标签的使用占比。</p>
      </article>
      <article>
        <h2>活跃度热力图</h2>
        <p>热力图占位：显示用户一周内的不同时段活跃情况。</p>
      </article>
    </div>
  </section>
</template>

<style scoped>
.admin-stats {
  display: grid;
  gap: 1.75rem;
  color: #e2e8f0;
}

header h1 {
  margin: 0;
  font-size: 1.9rem;
}

header p {
  margin: 0.4rem 0 0;
  color: rgba(148, 163, 184, 0.8);
}

.admin-stats__grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 1.5rem;
}

article {
  background: rgba(15, 23, 42, 0.85);
  border-radius: 18px;
  padding: 1.75rem;
  display: grid;
  gap: 0.75rem;
  box-shadow: 0 20px 40px rgba(15, 23, 42, 0.4);
}

h2 {
  margin: 0;
  font-size: 1.2rem;
  color: #bfdbfe;
}

p {
  margin: 0;
  color: rgba(226, 232, 240, 0.82);
}
</style>
