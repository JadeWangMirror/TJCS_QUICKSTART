<template>
  <section class="recommend-personal latest-page-ultra">
    <header class="page-header">
      <h1>个性化推荐</h1>
      <p>为您精选的优质内容</p>
    </header>
    <div v-if="canSeePersonalRecommendation">

      <div class="recommend-personal__list card-grid">
        <article v-for="(item, index) in RecommendPersonal.feed?.posts" :key="item.id" class="post-card group"
          @click="goToPost(item.id)" :style="{ '--delay': `${index * 50}ms` }">
          <div class="glow-border"></div>
          <div class="rank-badge" :class="getRankClass(index)">
            <span class="rank-num">{{ (currentPage - 1) * pageSize + index + 1 }}</span>
            <span class="rank-label" v-if="index < 3">TOP</span>
          </div>
          <div class="card-media">
            <img v-if="getThumb(item)" :src="getThumb(item) || ''" alt="Art" loading="lazy" />
            <div v-else class="media-placeholder"></div>
            <div class="vignette-overlay"></div>
            <div class="shine-effect"></div>

            <button class="remix-btn" @click.stop="goToWorkbench" title="创作同款">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="remix-icon">
                <path stroke-linecap="round" stroke-linejoin="round"
                  d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
              </svg>
              <span>Remix</span>
            </button>
          </div>

          <div class="card-content">
            <h3 class="card-title" :title="item.title">
              <span class="title-text">{{ item.title }}</span>
            </h3>

            <div class="card-meta">
              <div class="author-info">
                <div class="avatar-ring">
                  <img v-if="getAvatar(item)" :src="getAvatar(item) || ''" alt="avatar" />
                  <div v-else class="avatar-fallback">{{ getInitials(item.author) }}</div>
                </div>
                             <span class="author-name">{{ item.author.length>8?(item.author.slice(0,5)+"..."):item.author}}</span>
              </div>
              <div class="meta-right">
                <span class="time-tag">{{ formatDate(item.timestamp) }}</span>
              </div>

            </div>
          </div>
        </article>

        <div v-if="!RecommendPersonal.feed?.posts?.length" class="no-data-message">
          <div class="empty-visual">✨</div>
          <h3>暂无推荐内容</h3>
          <p>请稍后再试，我们将为您准备更多惊喜</p>
        </div>

      </div>

      <div class="pagination-wrapper">
        <button @click="goToPreviousPage" :disabled="currentPage <= 1" class="magic-btn">
          <span class="btn-icon">←</span>
          <span class="btn-text">Previous</span>
        </button>

        <div class="page-dots">
          <span class="current">{{ currentPage }}</span>
          <span class="divider">/</span>
          <span class="total">{{ RecommendPersonal.feed?.page_count || '∞' }}</span>
        </div>

        <button @click="goToNextPage" :disabled="currentPage >= (RecommendPersonal.feed?.page_count || 999)"
          class="magic-btn">
          <span class="btn-text">Next</span>
          <span class="btn-icon">→</span>
        </button>
      </div>
    </div>
    <div v-else style="text-align: center;">
      <h2>请先登录！</h2>
    </div>
  </section>
</template>
<script lang="ts" setup>
  import { ref, onMounted, reactive, computed, watch } from 'vue'
  import type { SearchFilters } from '@/types/api';
  import { useRecommendationStore } from '@/store/modules/recommendation.ts';
  import { useRoute, useRouter } from 'vue-router';
  import { useAuthStore } from '@/store';
  import { storeToRefs } from 'pinia';
  import { formatDate } from '@/hooks/FormatTimeStamp';
  let RecommendPersonal = useRecommendationStore();
  const route = useRoute();
  const router = useRouter();
  const AuthStore = useAuthStore();
  const { loading: authLoading, currentUser } = storeToRefs(AuthStore);
  const authReady = computed<boolean>(() => {
    // 只有在 Auth Store 加载完成（loading 为 false）且 currentUser 存在时，才认为认证就绪
    return !authLoading.value && !!currentUser.value?.id;
  });

  const currentPage = computed<number>({
    get() {
      // 尝试从 URL query 获取 'page' 参数，如果不存在或无效，则默认为 1
      const page = parseInt(route.query.page as string);
      return isNaN(page) || page < 1 ? 1 : page;
    },
    // set 方法用于更新 URL
    set(newValue: number) {
      // 调用 router.push 来更新 URL 中的 query 参数，但保持其他参数不变
      router.push({
        name: route.name as string, // 保持当前路由名称
        query: { ...route.query, page: newValue.toString() }
      });
    }
  });
  watch(authReady, (isReady) => {
    if (isReady) {
      // 仅在首次认证就绪时，根据当前 URL 的页码进行加载
      // console.log("认证就绪，首次加载浏览记录。");
      fetchRecommendations();
    } else {
      // 认证未就绪且正在加载时，显示 loading 状态，等待
      // 如果 authLoading 为 true，页面将显示 '正在努力加载历史记录...'
      canSeePersonalRecommendation.value = authLoading.value;
    }
  });
  let pageSize: number = 12
  const filters = reactive<SearchFilters>({
    page: currentPage.value, // 初始值
    pageSize: pageSize,
  });
  let canSeePersonalRecommendation = ref(false);
  // 4. 定义获取数据的函数
  async function fetchRecommendations() {
    // 每次获取数据前，更新 filters 中的页码
    filters.page = currentPage.value;

    // 调用 store 的方法获取数据
    try {
      const result = await RecommendPersonal.fetchFeed("recommend", filters)

      if (result.success) {
        // console.log('Personal recommend successfully.');
        canSeePersonalRecommendation.value = true
      } else if (result && result.message) {
        // 处理业务API返回的非权限错误（Store未抛出异常的情况）
        console.error('Failed to show personel recommendation status:', result.message);
        canSeePersonalRecommendation.value = false
      }
    } catch (error) {
      // 捕获 Store Action 抛出的未登录/权限异常
      if (error instanceof Error && error.message === "User not authenticated.") {
        console.warn("User attempted to check personel recommendation without being logged in.");
        canSeePersonalRecommendation.value = false
      } else {
        console.error('An unexpected error occurred during liking:', error);
        canSeePersonalRecommendation.value = false
      }
    }


    // 注意：这里的 totalPages 假设是在 store 的 fetchFeed 内部根据后端响应更新的
  }

  watch(
    () => route.query.page,
    (newPageValue) => { // 接收的参数类型为 string | string[] | undefined
      let pageStr: string | undefined;
      if (typeof newPageValue === 'string') {
        pageStr = newPageValue;
      } else if (Array.isArray(newPageValue) && newPageValue.length > 0) {
        // 如果是数组，使用第一个元素（通常页码不会是数组）
        pageStr = newPageValue[0] || undefined;
      }
      const newPageNumber = currentPage.value;
      if (newPageNumber > 0) {
        fetchRecommendations();
      }
    },
    { immediate: true }
  );


  function goToNextPage() {
    // 使用 store 中的 totalPages 来进行边界判断
    // const total = RecommendPersonal.totalPages || Infinity; 
    const total = Infinity;
    if (currentPage.value < total) {
      currentPage.value++
    }
  }

  function goToPreviousPage() {
    if (currentPage.value > 1) {
      currentPage.value--
    }
  }
  // 辅助函数：获取帖子图片 URL
  const getThumb = (item: any) => item?.url_list?.[0] ?? item?.cover_image ?? null;
  // 辅助函数：获取作者头像 URL
  const getAvatar = (item: any) => item?.author_avatar ?? item?.authorAvatar ?? item?.avatarUrl ?? item?.avatar ?? null;
  // 辅助函数：获取作者名字首字母
  function getInitials(name: any): string {
    if (!name) return 'U';
    return String(name).slice(0, 2).toUpperCase();
  }

  // 辅助函数：用于卡片点击事件（跳转到详情页）
  function goToPost(id: number | string) {
    if (!id) return;
    router.push({ path: `/posts/${id}` });
  }

  // 辅助函数：用于 Remix 按钮（跳转到工作台）
  function goToWorkbench() {
    router.push('/ai/workbench');
  }
  function getRankClass(index: number) {
    const rank = (currentPage.value - 1) * pageSize + index + 1;
    if (rank === 1) return 'rank-1'; // 最鲜
    if (rank === 2) return 'rank-2';
    if (rank === 3) return 'rank-3';
    return 'rank-normal';
  }
</script>

<style scoped>
  /* --- 导入 LatestView.vue 的完整样式 --- */

  /* --- 变量定义：【青/蓝】科技主题 --- */
  .latest-page-ultra {
    --font-display: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;

    /* 颜色变量：Fresh Theme */
    --c-bg-page: #f0fdfa;
    /* 非常淡的青色背景 */
    --c-bg-card: #ffffff;
    --c-text-primary: #0f172a;
    --c-text-secondary: #64748b;

    --c-accent: #06b6d4;
    /* Cyan 500 */
    --c-accent-dark: #3b82f6;
    /* Blue 500 */
    --c-accent-glow: rgba(6, 182, 212, 0.25);

    --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
    --shadow-hover: 0 20px 40px -10px rgba(6, 182, 212, 0.2), 0 10px 20px -5px rgba(0, 0, 0, 0.04);

    --ease-elastic: cubic-bezier(0.34, 1.56, 0.64, 1);
    --ease-out: cubic-bezier(0.2, 0.8, 0.2, 1);

    max-width: 1400px;
    margin: 0 auto;
    padding: 60px 24px;
    background-color: var(--c-bg-page);
    min-height: 100vh;
    font-family: var(--font-display);
  }

  /* --- Header --- */
  .page-header {
    text-align: center;
    margin-bottom: 70px;
  }

  /* 移除 LatestView 中的徽章样式，这里不需要 */
  /* .badge-pill { ... } */

  .page-header h1 {
    font-size: 3.5rem;
    margin: 0 0 16px;
    font-weight: 900;
    letter-spacing: -0.04em;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 15px;
    flex-wrap: wrap;
  }

  .page-header p {
    color: var(--c-text-secondary);
    font-size: 1.25rem;
    margin-top: 8px;
    font-weight: 400;
  }


  /* 覆盖/融合原有标题样式，使其居中 */
  .recommend-personal .page-header {
    text-align: center;
    border-bottom: none;
    /* 移除原来的底线 */
    padding-bottom: 0;
  }

  .recommend-personal .page-header h1 {
    font-size: 3.5rem;
    /* 使用 LatestView 的大号标题 */
    font-weight: 900;
    margin-bottom: 0.5rem;
  }

  .recommend-personal .page-header p {
    font-size: 1.25rem;
    color: var(--c-text-secondary);
    margin: 0;
  }

  /* 兼容原标题结构，这里只需要一个标题 */
  .title-cn {
    color: var(--c-text-primary);
  }

  .title-en {
    display: none;
  }

  /* 隐藏 LatestView 中的英文标题，只显示中文 */


  /* --- Grid & Card --- */
  .card-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
    gap: 32px;
    padding: 10px;
  }

  .post-card {
    position: relative;
    background: var(--c-bg-card);
    border-radius: 20px;
    box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.04), var(--shadow-sm);
    cursor: pointer;
    transform: translateZ(0);
    transition: transform 0.4s var(--ease-out), box-shadow 0.4s var(--ease-out);
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }

  .post-card:hover {
    transform: translateY(-8px) scale(1.005);
    box-shadow: var(--shadow-hover);
    z-index: 10;
  }

  /* 边框流光：青色系 */
  .glow-border {
    position: absolute;
    inset: 0;
    border-radius: 20px;
    padding: 2px;
    background: linear-gradient(135deg, #22d3ee, #3b82f6);
    mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
    -webkit-mask-composite: xor;
    mask-composite: exclude;
    opacity: 0;
    transition: opacity 0.4s ease;
    pointer-events: none;
    z-index: 20;
  }

  .post-card:hover .glow-border {
    opacity: 1;
  }

  /* --- 图片与功能按钮 --- */
  .card-media {
    height: 240px;
    position: relative;
    overflow: hidden;
    background: #f1f5f9;
  }

  .card-media img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.8s var(--ease-out);
  }

  .post-card:hover .card-media img {
    transform: scale(1.08);
  }

  /* Remix 按钮 */
  .remix-btn {
    position: absolute;
    top: 12px;
    right: 12px;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    background: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(4px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 20px;
    color: #fff;
    font-size: 0.8rem;
    font-weight: 600;
    cursor: pointer;
    opacity: 0;
    transform: translateY(-10px);
    transition: all 0.3s ease;
    z-index: 10;
  }

  .remix-btn:hover {
    background: var(--c-accent-dark);
    border-color: var(--c-accent-dark);
  }

  .remix-icon {
    width: 14px;
    height: 14px;
  }

  /* Hover 时显示 Remix 按钮 */
  .post-card:hover .remix-btn {
    opacity: 1;
    transform: translateY(0);
  }

  .vignette-overlay {
    position: absolute;
    inset: 0;
    background: linear-gradient(to bottom, rgba(0, 0, 0, 0) 60%, rgba(0, 0, 0, 0.05) 100%);
    pointer-events: none;
  }

  .shine-effect {
    position: absolute;
    top: 0;
    left: -100%;
    width: 50%;
    height: 100%;
    background: linear-gradient(to right, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, 0.3) 100%);
    transform: skewX(-25deg);
    pointer-events: none;
    transition: none;
  }

  .post-card:hover .shine-effect {
    left: 200%;
    transition: left 0.8s ease-in-out;
  }

  /* --- 内容区域 --- */
  .card-content {
    padding: 16px 20px 18px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    background: linear-gradient(180deg, #fff 0%, #fafafa 100%);
  }

  .card-title {
    margin: 0;
    font-size: 1.15rem;
    font-weight: 700;
    line-height: 1.35;
    color: var(--c-text-primary);
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }

  .title-text {
    background-image: linear-gradient(90deg, var(--c-text-primary), var(--c-text-primary));
    background-size: 0% 2px;
    background-position: 0 100%;
    background-repeat: no-repeat;
    transition: background-size 0.3s ease, color 0.3s ease;
  }

  .post-card:hover .title-text {
    color: var(--c-accent-dark);
    background-image: linear-gradient(90deg, var(--c-accent-dark), var(--c-accent-dark));
    background-size: 100% 2px;
  }

  .card-meta {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 4px;
  }

  .author-info {
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .avatar-ring {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    padding: 2px;
    background: transparent;
    transition: background 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .post-card:hover .avatar-ring {
    background: linear-gradient(135deg, #22d3ee, #3b82f6);
    /* 青蓝光圈 */
  }

  .author-info img,
  .avatar-fallback {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid #fff;
    background: #e0f2fe;
    color: #0369a1;
    font-weight: 700;
    font-size: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .author-name {
    font-size: 0.95rem;
    font-weight: 600;
    color: #334155;
    max-width: 110px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  /* 按钮区域：适配 PersonalizedRecommendView 的两个按钮 */
  .meta-right {
    display: flex;
    gap: 0.75rem;
    /* 按钮之间的间距 */
  }

  /* 按钮统一样式 (兼容 RouterLink) - 使用 LatestView 的主题色 */
  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0.5rem 1rem;
    font-size: 0.85rem;
    font-weight: 500;
    text-align: center;
    text-decoration: none;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.2s ease, transform 0.2s ease;
    flex: 1;
    min-width: 80px;
    /* 确保按钮不会太小 */
  }

  .btn-primary {
    background-color: var(--c-accent-dark);
    /* Blue 500 */
    color: white;
  }

  .btn-primary:hover {
    background-color: #3b82f6;
    box-shadow: 0 4px 10px rgba(59, 130, 246, 0.3);
    transform: translateY(-1px);
  }

  .btn-secondary {
    background-color: #e5e7eb;
    color: var(--c-text-primary);
    border: 1px solid #d1d5db;
  }

  .btn-secondary:hover {
    background-color: #f3f4f6;
    border-color: var(--c-accent);
    color: var(--c-accent);
    transform: translateY(-1px);
  }


  /* Empty State & Pagination */
  .no-data-message {
    /* 确保空状态跨越所有列 */
    grid-column: 1 / -1;
    text-align: center;
    padding: 80px 0;
    color: #94a3b8;
    background: #fff;
    border-radius: 20px;
    box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.04), var(--shadow-sm);
  }

  .empty-visual {
    font-size: 4rem;
    margin-bottom: 20px;
  }

  .no-data-message h3 {
    color: var(--c-text-primary);
  }

  .no-data-message p {
    color: var(--c-text-secondary);
  }


  .pagination-wrapper {
    margin-top: 50px;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 30px;
  }

  .magic-btn {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 28px;
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    color: var(--c-text-primary);
    font-weight: 600;
    font-size: 1rem;
    cursor: pointer;
    transition: all 0.3s var(--ease-out);
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
  }

  .magic-btn:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 12px 20px -5px rgba(6, 182, 212, 0.15);
    border-color: var(--c-accent);
    color: var(--c-accent);
  }

  .magic-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
    background: #f8fafc;
  }

  .page-dots {
    font-size: 1.2rem;
    font-weight: 700;
    color: #cbd5e1;
    display: flex;
    gap: 8px;
  }

  .page-dots .current {
    color: var(--c-text-primary);
  }

  /* --- 排名徽章 --- */
  .rank-badge {
    position: absolute;
    top: 16px;
    left: 16px;
    min-width: 44px;
    height: 44px;
    border-radius: 12px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    z-index: 5;
    font-weight: 800;
    line-height: 1;
    padding: 0 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(4px);
    border: 1px solid rgba(255, 255, 255, 0.6);
  }

  .rank-num {
    font-size: 1.3rem;
    margin-bottom: 2px;
  }

  .rank-label {
    font-size: 0.6rem;
    text-transform: uppercase;
    letter-spacing: 1px;
    opacity: 0.9;
  }

  /* 金 */
  .rank-1 {
    background: linear-gradient(135deg, #FFF7D1 0%, #FFD700 100%);
    color: #925a0b;
    border-color: #ffeeb0;
    box-shadow: 0 8px 20px rgba(255, 215, 0, 0.3);
  }

  /* 银 */
  .rank-2 {
    background: linear-gradient(135deg, #F9FAFB 0%, #D1D5DB 100%);
    color: #4B5563;
    border-color: #e5e7eb;
  }

  /* 铜 */
  .rank-3 {
    background: linear-gradient(135deg, #FFEDD5 0%, #FDBA74 100%);
    color: #9A3412;
    border-color: #fed7aa;
  }

  /* 普通 */
  .rank-normal {
    background: rgba(255, 255, 255, 0.9);
    color: #94a3b8;
    font-style: italic;
    font-family: 'Georgia', serif;
  }


  /* 媒体查询 (保持 LatestView 的响应式效果) */
  @media (max-width: 768px) {
    .page-header h1 {
      font-size: 2.2rem;
    }

    .card-grid {
      grid-template-columns: repeat(auto-fill, minmax(170px, 1fr));
      gap: 16px;
    }

    .card-media {
      height: 180px;
    }

    .meta-right {
      flex-direction: column;
      gap: 0.5rem;
    }

    .btn {
      font-size: 0.75rem;
      padding: 0.4rem 0.8rem;
    }
  }
</style>