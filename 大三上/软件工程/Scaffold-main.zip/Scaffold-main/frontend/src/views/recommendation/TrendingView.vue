<template>
  <section class="trending-page-ultra">
    <header class="page-header">
      <div class="header-content">
        <!-- 1. 保留了您喜欢的 Inspiration Gallery 徽章 -->
        <span class="badge-pill">✨ Inspiration Gallery</span>
        
        <!-- 2. 中英文双色标题 -->
        <h1>
          <span class="title-cn">热门趋势榜</span>
          <span class="title-en">Top Trends</span>
        </h1>
        
        <p>探索全网最受欢迎的高质量创意与提示词</p>
      </div>
    </header>

    <!-- 骨架屏 Loading -->
    <div v-if="isLoading" class="trending-list card-grid">
      <div v-for="n in pageSize" :key="`skeleton-${n}`" class="post-card skeleton-card">
        <div class="skeleton-media shimmer"></div>
        <div class="skeleton-body">
          <div class="skeleton-line title shimmer"></div>
          <div class="skeleton-line title-short shimmer"></div>
          <div class="skeleton-footer">
            <div class="skeleton-circle shimmer"></div>
            <div class="skeleton-pill shimmer"></div>
          </div>
        </div>
      </div>
    </div>

    <!-- 真实数据列表 -->
    <TransitionGroup 
      v-else-if="TrendingStore.feed?.posts?.length" 
      tag="div" 
      class="trending-list card-grid" 
      name="stagger-fade"
      appear
    >
      <article 
        v-for="(item, index) in TrendingStore.feed.posts" 
        :key="item.id" 
        class="post-card group" 
        @click="goToPost(item.id)"
        :style="{ '--delay': `${index * 50}ms` }"
      >
        <!-- 高级流光边框层 -->
        <div class="glow-border"></div>

        <!-- 3. 排名标记：金银铜逻辑 -->
        <div class="rank-badge" :class="getRankClass(index)">
          <span class="rank-num">{{ (currentPage - 1) * pageSize + index + 1 }}</span>
          <span class="rank-label" v-if="index < 3">TOP</span>
        </div>

        <!-- 图片区域 -->
        <div class="card-media">
          <img 
            v-if="getThumb(item)" 
            :src="getThumb(item) || ''" 
            alt="Art" 
            loading="lazy" 
          />
          <div v-else class="media-placeholder"></div>
          
          <!-- 电影感暗角 -->
          <div class="vignette-overlay"></div>
          <!-- 扫光特效 -->
          <div class="shine-effect"></div>
        </div>

        <!-- 内容区域 -->
        <div class="card-content">
          <h3 class="card-title" :title="item.title">
            <span class="title-text">{{ item.title }}</span>
          </h3>

          <div class="card-meta">
            <div class="author-info">
              <div class="avatar-ring">
                <img v-if="getAvatar(item)" :src="getAvatar(item) || ''" alt="avatar" />
                <div v-else class="avatar-fallback">{{ getInitials(item.author) }}</div>
              </div>
              <span class="author-name">{{ item.author.length>8?(item.author.slice(0,5)+"..."):item.author}}</span>
            </div>

            <button class="like-btn" title="Like">
              <div class="icon-box">
                <svg viewBox="0 0 24 24" class="heart-icon">
                  <path :d="heartPath" />
                </svg>
              </div>
              <span class="count">{{ formatNumber(getLikeCount(item)) }}</span>
            </button>
          </div>
        </div>
      </article>
    </TransitionGroup>

    <!-- 空状态 -->
    <div v-else class="empty-state">
      <div class="empty-visual">🔭</div>
      <h3>暂无探索结果</h3>
      <p>世界还在沉睡，稍后再来看看吧</p>
    </div>

    <!-- 分页控件 -->
    <div class="pagination-wrapper">
      <button 
        @click="goToPreviousPage" 
        :disabled="currentPage <= 1 || isLoading" 
        class="magic-btn"
      >
        <span class="btn-icon">←</span>
        <span class="btn-text">Previous</span>
      </button>
      
      <div class="page-dots">
        <span class="current">{{ currentPage }}</span>
        <span class="divider">/</span>
        <span class="total">{{ TrendingStore.feed?.page_count || '∞' }}</span>
      </div>
      
      <button 
        @click="goToNextPage" 
        :disabled="currentPage >= (TrendingStore.feed?.page_count||999) || isLoading" 
        class="magic-btn"
      >
        <span class="btn-text">Next</span>
        <span class="btn-icon">→</span>
      </button>
    </div>
  </section>
</template>

<script lang="ts" setup>
import { ref, reactive, watch, computed } from 'vue';
import type { SearchFilters } from '@/types/api';
import { useRecommendationStore } from '@/store/modules/recommendation.ts';
import { usePostStore } from '@/store/modules/posts';
import { useRoute, useRouter } from 'vue-router';

const TrendingStore = useRecommendationStore();
const PostStore = usePostStore();
const route = useRoute(); 
const router = useRouter();

const pageSize = 12;
const isLoading = ref(false); 

const currentPage = computed<number>({
  get() {
    const page = parseInt(route.query.page as string);
    // 默认逻辑在这里处理了，如果 page 是 undefined，这里会返回 1
    return isNaN(page) || page < 1 ? 1 : page;
  },
  set(newValue:number) {
    router.push({ 
      name: route.name as string, 
      query: { ...route.query, page: newValue.toString() } 
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
});

const filters = reactive<SearchFilters>({
  page: currentPage.value, 
  pageSize: pageSize,
});

const heartPath = 'M12.001 4.529c1.349-1.43 3.528-1.68 5.06-.55 1.532 1.129 1.828 3.29.576 4.904l-5.636 6.89a1 1 0 0 1-1.485 0l-5.636-6.89c-1.253-1.614-0.957-3.775.576-4.904 1.532-1.13 3.71-0.88 5.06.55L12 6.35l.001-1.821z';

const getThumb = (item: any) => item?.url_list?.[0] ?? item?.cover_image ?? null;
const getLikeCount = (item: any) => Number(item?.like_count ?? item?.likeCount ?? 0);
const getAvatar = (item: any) => item?.author_avatar ?? item?.authorAvatar ?? item?.avatarUrl ?? item?.avatar ?? null;

function getInitials(name: any): string {
  if (!name) return 'U';
  return String(name).slice(0, 2).toUpperCase();
}

function formatNumber(num: number): string {
  if (num >= 1000) return (num / 1000).toFixed(1) + 'k';
  return num.toString();
}

function getRankClass(index: number) {
  const rank = (currentPage.value - 1) * pageSize + index + 1;
  if (rank === 1) return 'rank-1'; // Gold
  if (rank === 2) return 'rank-2'; // Silver
  if (rank === 3) return 'rank-3'; // Bronze
  return 'rank-normal';
}

function goToPost(id: number | string) {
  if (!id) return;
  router.push({ path: `/posts/${id}` });
}

async function fetchTrending() {
  if (isLoading.value) return; 
  isLoading.value = true; 
  // 确保使用最新的 currentPage
  filters.page = currentPage.value; 

  try {
    await TrendingStore.fetchFeed("hotest", filters);
  } catch (error) {
    console.error("Fetch Error:", error);
  } finally {
    isLoading.value = false; 
  }
}

// ✅ 核心修复：移除错误的 if 判断
// 只要路由参数变化（或首次加载），就无条件执行获取数据
watch(() => route.query.page, () => { 
    fetchTrending();
  }, { immediate: true }
);

function goToNextPage() {
  const total = TrendingStore.feed?.page_count || 999;
  if (currentPage.value < total) currentPage.value++;
}

function goToPreviousPage() {
  if (currentPage.value > 1) currentPage.value--;
}
</script>

<style scoped>
.trending-page-ultra {
  --font-display: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  
  /* 颜色变量 */
  --c-bg-page: #f8f9fc;
  --c-bg-card: #ffffff;
  --c-text-primary: #0f172a;
  --c-text-secondary: #64748b;
  --c-accent: #8A8BF8; 
  --c-accent-dark: #B685FB; 
  
  --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --shadow-hover: 0 20px 40px -10px rgba(138, 139, 248, 0.25), 0 10px 20px -5px rgba(0, 0, 0, 0.04);
  
  --ease-elastic: cubic-bezier(0.34, 1.56, 0.64, 1);
  --ease-out: cubic-bezier(0.2, 0.8, 0.2, 1);
  
  max-width: 1400px;
  margin: 0 auto;
  padding: 60px 24px;
  background-color: var(--c-bg-page);
  min-height: 100vh;
  font-family: var(--font-display);
}

/* --- 头部样式重构 --- */
.page-header {
  text-align: center;
  margin-bottom: 70px;
}

/* 徽章样式 (Restored) */
.badge-pill {
  display: inline-block;
  padding: 6px 16px;
  background: rgba(138, 139, 248, 0.1); /* 配合主题色的淡紫 */
  color: var(--c-accent-dark);
  font-size: 0.8rem;
  font-weight: 700;
  border-radius: 100px;
  text-transform: uppercase;
  letter-spacing: 1.5px;
  margin-bottom: 20px;
  border: 1px solid rgba(138, 139, 248, 0.2);
}

.page-header h1 {
  font-size: 3.5rem;
  margin: 0 0 16px;
  font-weight: 900; 
  letter-spacing: -0.04em;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 15px;
  flex-wrap: wrap;
}

.title-cn {
  color: #39424F; 
}

.title-en {
  background: linear-gradient(135deg, #8A8BF8 0%, #B685FB 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.page-header p {
  color: var(--c-text-secondary);
  font-size: 1.25rem;
  margin-top: 8px;
  font-weight: 400;
}

/* --- 卡片网格 --- */
.card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 32px;
  padding: 10px;
}

/* --- 核心卡片样式 --- */
.post-card {
  position: relative;
  background: var(--c-bg-card);
  border-radius: 20px;
  box-shadow: 0 0 0 1px rgba(0,0,0,0.04), var(--shadow-sm);
  cursor: pointer;
  transform: translateZ(0);
  transition: transform 0.4s var(--ease-out), box-shadow 0.4s var(--ease-out);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.post-card:hover {
  transform: translateY(-8px) scale(1.005);
  box-shadow: var(--shadow-hover);
  z-index: 10;
}

/* 边框流光 */
.glow-border {
  position: absolute; inset: 0;
  border-radius: 20px;
  padding: 2px;
  background: linear-gradient(135deg, #8A8BF8, #B685FB);
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask-composite: exclude;
  opacity: 0;
  transition: opacity 0.4s ease;
  pointer-events: none;
  z-index: 20;
}
.post-card:hover .glow-border { opacity: 1; }

/* --- 排名徽章 --- */
.rank-badge {
  position: absolute; top: 16px; left: 16px;
  min-width: 44px; height: 44px;
  border-radius: 12px;
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  z-index: 5;
  font-weight: 800;
  line-height: 1;
  padding: 0 8px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.1);
  backdrop-filter: blur(4px);
  border: 1px solid rgba(255,255,255,0.6);
}

.rank-num { font-size: 1.3rem; margin-bottom: 2px; }
.rank-label { font-size: 0.6rem; text-transform: uppercase; letter-spacing: 1px; opacity: 0.9; }

/* 金 */
.rank-1 {
  background: linear-gradient(135deg, #FFF7D1 0%, #FFD700 100%);
  color: #925a0b;
  border-color: #ffeeb0;
  box-shadow: 0 8px 20px rgba(255, 215, 0, 0.3);
}

/* 银 */
.rank-2 {
  background: linear-gradient(135deg, #F9FAFB 0%, #D1D5DB 100%);
  color: #4B5563;
  border-color: #e5e7eb;
}

/* 铜 */
.rank-3 {
  background: linear-gradient(135deg, #FFEDD5 0%, #FDBA74 100%);
  color: #9A3412;
  border-color: #fed7aa;
}

/* 普通 */
.rank-normal {
  background: rgba(255, 255, 255, 0.9);
  color: #94a3b8;
  font-style: italic;
  font-family: 'Georgia', serif; 
}

/* --- 媒体图片 --- */
.card-media {
  height: 240px;
  position: relative;
  overflow: hidden;
  background: #f1f5f9;
}
.card-media img {
  width: 100%; height: 100%; object-fit: cover;
  transition: transform 0.8s var(--ease-out);
}
.post-card:hover .card-media img { transform: scale(1.08); }
.vignette-overlay {
  position: absolute; inset: 0;
  background: linear-gradient(to bottom, rgba(0,0,0,0) 60%, rgba(0,0,0,0.05) 100%);
  pointer-events: none;
}
.shine-effect {
  position: absolute; top: 0; left: -100%; width: 50%; height: 100%;
  background: linear-gradient(to right, rgba(255,255,255,0) 0%, rgba(255,255,255,0.3) 100%);
  transform: skewX(-25deg);
  pointer-events: none;
  transition: none;
}
.post-card:hover .shine-effect { left: 200%; transition: left 0.8s ease-in-out; }

/* --- 内容区域 --- */
.card-content {
  padding: 16px 20px 18px;
  display: flex; flex-direction: column;
  gap: 10px;
  background: linear-gradient(180deg, #fff 0%, #fafafa 100%);
}

.card-title {
  margin: 0;
  font-size: 1.15rem;
  font-weight: 700;
  line-height: 1.35;
  color: var(--c-text-primary);
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
}
.title-text {
  background-image: linear-gradient(90deg, var(--c-text-primary), var(--c-text-primary));
  background-size: 0% 2px;
  background-position: 0 100%;
  background-repeat: no-repeat;
  transition: background-size 0.3s ease, color 0.3s ease;
}
.post-card:hover .title-text {
  color: var(--c-accent);
  background-image: linear-gradient(90deg, var(--c-accent), var(--c-accent));
  background-size: 100% 2px;
}

/* Meta Footer */
.card-meta {
  display: flex; justify-content: space-between; align-items: center;
  margin-top: 4px;
}

/* Author */
.author-info { display: flex; align-items: center; gap: 10px; }
.avatar-ring {
  width: 42px; height: 42px;
  border-radius: 50%;
  padding: 2px;
  background: transparent;
  transition: background 0.3s ease;
  display: flex; align-items: center; justify-content: center;
}
.post-card:hover .avatar-ring {
  background: linear-gradient(135deg, #8A8BF8, #B685FB);
}
.author-info img, .avatar-fallback {
  width: 100%; height: 100%;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid #fff;
  background: #e0e7ff; color: #4338ca;
  font-weight: 700; font-size: 14px;
  display: flex; align-items: center; justify-content: center;
}
.author-name {
  font-size: 0.95rem; font-weight: 600; color: #334155;
  max-width: 110px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}

/* Like Button */
.like-btn {
  display: flex; align-items: center; gap: 6px;
  background: transparent; border: none; padding: 4px 8px;
  cursor: pointer; border-radius: 8px; transition: background 0.2s;
}
.like-btn:hover { background: #f1f5f9; }
.icon-box {
  display: flex; align-items: center; justify-content: center;
  transition: transform 0.3s var(--ease-elastic);
}
.heart-icon { width: 24px; height: 24px; fill: #cbd5e1; transition: fill 0.3s; }
.count { font-size: 1rem; font-weight: 700; color: #94a3b8; font-variant-numeric: tabular-nums; transition: color 0.3s; }
.post-card:hover .heart-icon { fill: #ef4444; }
.post-card:hover .count { color: #475569; }
.post-card:hover .icon-box { transform: scale(1.15); }

/* 骨架屏 & 分页 (保持不变) */
.skeleton-card { background: #fff; box-shadow: none; border: 1px solid #f1f5f9; }
.skeleton-media { height: 240px; background: #f1f5f9; }
.skeleton-body { padding: 20px; }
.skeleton-line { height: 18px; margin-bottom: 12px; border-radius: 4px; background: #e2e8f0; }
.title { width: 80%; }
.title-short { width: 50%; margin-bottom: 24px; }
.skeleton-footer { display: flex; justify-content: space-between; align-items: center; }
.skeleton-circle { width: 40px; height: 40px; border-radius: 50%; background: #e2e8f0; }
.skeleton-pill { width: 50px; height: 20px; border-radius: 4px; background: #e2e8f0; }
.shimmer {
  background: linear-gradient(to right, #f1f5f9 0%, #e2e8f0 20%, #f1f5f9 40%, #f1f5f9 100%);
  background-size: 1000px 100%; animation: shimmer 1.5s infinite linear;
}
@keyframes shimmer { 0% {background-position: -1000px 0;} 100% {background-position: 1000px 0;} }

.pagination-wrapper { margin-top: 80px; display: flex; justify-content: center; align-items: center; gap: 30px; }
.magic-btn { display: flex; align-items: center; gap: 12px; padding: 12px 28px; background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; color: var(--c-text-primary); font-weight: 600; font-size: 1rem; cursor: pointer; transition: all 0.3s var(--ease-out); box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
.magic-btn:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 12px 20px -5px rgba(0,0,0,0.1); border-color: var(--c-accent); color: var(--c-accent); }
.magic-btn:disabled { opacity: 0.5; cursor: not-allowed; background: #f8fafc; }
.page-dots { font-size: 1.2rem; font-weight: 700; color: #cbd5e1; display: flex; gap: 8px; }
.page-dots .current { color: var(--c-text-primary); }

.stagger-fade-enter-active { transition: all 0.5s ease; transition-delay: var(--delay); }
.stagger-fade-leave-active { transition: all 0.3s ease; }
.stagger-fade-enter-from { opacity: 0; transform: translateY(40px); }

@media (max-width: 768px) {
  .page-header h1 { font-size: 2.2rem; gap: 8px; }
  .card-grid { grid-template-columns: repeat(auto-fill, minmax(170px, 1fr)); gap: 16px; }
  .card-media { height: 180px; }
}
</style>
