<template>
  <section class="recommend-tags">
    <header>
      <h1>标签推荐</h1>
      <p>根据你正在浏览的标签，寻找相似主题的帖子。</p>
    </header>

    <div class="recommend-tags__grid">
      <article v-for="index in 6" :key="index">
        <h2>#推荐标签 {{ index }}</h2>
        <p>相关帖子 2{{ index }} · 近 7 日浏览 1{{ index }}0 次。</p>
        <RouterLink to="/posts/tags/1">进入标签</RouterLink>
      </article>
    </div>
  </section>
</template>

<style scoped>
.recommend-tags {
  display: grid;
  gap: 1.75rem;
}

header h1 {
  margin: 0;
  font-size: 1.9rem;
}

header p {
  margin: 0.4rem 0 0;
  color: #475569;
}

.recommend-tags__grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 1.25rem;
}

article {
  background: #ffffff;
  border-radius: 18px;
  padding: 1.5rem;
  display: grid;
  gap: 0.6rem;
  box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08);
}

h2 {
  margin: 0;
  font-size: 1.2rem;
  color: #312e81;
}

p {
  margin: 0;
  color: #475569;
}

a {
  color: #7c3aed;
  font-weight: 600;
}
</style>
