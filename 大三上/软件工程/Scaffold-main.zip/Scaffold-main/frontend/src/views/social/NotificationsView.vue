<template>
  <section class="notifications-view">
    <header>
      <h1>互动通知</h1>
      <p>查看评论、点赞、收藏及关注等最新动态。</p>
    </header>

    <div class="notifications-view__filters">
      <button type="button" class="active">全部</button>
      <button type="button">评论</button>
      <button type="button">点赞/评分</button>
      <button type="button">关注</button>
    </div>

    <ul>
      <li v-for="index in 6" :key="index">
        <div>
          <h2>创作者 {{ index }} 评论了你的帖子</h2>
          <p>“这套提示词很实用，已收藏，期待后续迭代版本。”</p>
          <small>2024-09-12 18:3{{ index }}</small>
        </div>
        <RouterLink to="/posts/1">查看</RouterLink>
      </li>
    </ul>
  </section>
</template>

<style scoped>
.notifications-view {
  display: grid;
  gap: 1.75rem;
}

header h1 {
  margin: 0;
  font-size: 1.9rem;
}

header p {
  margin: 0.4rem 0 0;
  color: #475569;
}

.notifications-view__filters {
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
}

.notifications-view__filters button {
  padding: 0.5rem 1.2rem;
  border-radius: 999px;
  border: 1px solid rgba(124, 58, 237, 0.25);
  background: rgba(124, 58, 237, 0.08);
  color: #4c1d95;
  font-weight: 500;
}

.notifications-view__filters .active {
  background: linear-gradient(120deg, #7c3aed, #4c1d95);
  color: #ffffff;
  border-color: transparent;
}

ul {
  margin: 0;
  padding: 0;
  list-style: none;
  display: grid;
  gap: 1rem;
}

li {
  background: #ffffff;
  border-radius: 18px;
  padding: 1.25rem;
  display: flex;
  justify-content: space-between;
  gap: 1rem;
  align-items: flex-start;
  box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08);
}

h2 {
  margin: 0;
  font-size: 1.15rem;
  color: #312e81;
}

p {
  margin: 0.4rem 0;
  color: #475569;
}

small {
  color: #94a3b8;
}

a {
  color: #7c3aed;
  font-weight: 600;
  white-space: nowrap;
}

@media (max-width: 640px) {
  li {
    flex-direction: column;
  }
}
</style>
