<template>
  <section class="messages-view">
    <header>
      <h1>私信</h1>
      <p>与其他创作者进行一对一交流，支持富文本与附件。</p>
    </header>

    <div class="messages-view__grid">
      <aside>
        <h2>会话列表</h2>
        <ul>
          <li v-for="index in 5" :key="index" :class="{ active: index === 1 }">
            <span>创作者 {{ index }}</span>
            <small>最新：期待你分享更多提示词</small>
          </li>
        </ul>
      </aside>

      <section class="messages-view__conversation">
        <header>
          <h2>与「灵感猎人」的对话</h2>
          <button type="button">查看更多资料</button>
        </header>
        <div class="messages-view__timeline">
          <div class="message is-incoming">
            <p>你好！很喜欢你分享的夜景提示词，方便交流更多吗？</p>
            <small>2024-09-12 21:03</small>
          </div>
          <div class="message is-outgoing">
            <p>当然，后续我会整理一份参数模板发给你。</p>
            <small>2024-09-12 21:05</small>
          </div>
        </div>
        <form class="messages-view__input">
          <textarea rows="3" placeholder="输入私信内容..."></textarea>
          <div>
            <button type="button" class="ghost">添加附件</button>
            <button type="submit">发送</button>
          </div>
        </form>
      </section>
    </div>
  </section>
</template>

<style scoped>
.messages-view {
  display: grid;
  gap: 1.75rem;
}

header h1 {
  margin: 0;
  font-size: 1.9rem;
}

header p {
  margin: 0.4rem 0 0;
  color: #475569;
}

.messages-view__grid {
  display: grid;
  grid-template-columns: 240px 1fr;
  gap: 1.5rem;
}

aside,
.messages-view__conversation {
  background: #ffffff;
  border-radius: 18px;
  padding: 1.75rem;
  box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08);
}

aside h2 {
  margin: 0 0 1rem;
  color: #312e81;
}

aside ul {
  margin: 0;
  padding: 0;
  list-style: none;
  display: grid;
  gap: 0.75rem;
}

aside li {
  padding: 0.75rem;
  border-radius: 12px;
  background: rgba(15, 23, 42, 0.04);
  display: grid;
  gap: 0.35rem;
}

aside li.active {
  background: rgba(124, 58, 237, 0.12);
  color: #4c1d95;
}

aside small {
  color: #94a3b8;
}

.messages-view__conversation header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.messages-view__conversation button {
  padding: 0.6rem 1.2rem;
  border-radius: 12px;
  border: none;
  background: rgba(124, 58, 237, 0.1);
  color: #4c1d95;
  font-weight: 600;
}

.messages-view__timeline {
  display: grid;
  gap: 1rem;
  margin: 1.5rem 0;
}

.message {
  max-width: 75%;
  padding: 0.75rem 1rem;
  border-radius: 16px;
  display: grid;
  gap: 0.35rem;
  background: rgba(15, 23, 42, 0.06);
}

.message small {
  color: #94a3b8;
  font-size: 0.8rem;
}

.is-outgoing {
  justify-self: end;
  background: rgba(124, 58, 237, 0.16);
  color: #4c1d95;
}

.messages-view__input {
  display: grid;
  gap: 0.75rem;
}

.messages-view__input textarea {
  border-radius: 12px;
  border: 1px solid rgba(148, 163, 184, 0.6);
  padding: 0.75rem 1rem;
  resize: vertical;
}

.messages-view__input div {
  display: flex;
  gap: 0.75rem;
}

.messages-view__input button {
  padding: 0.7rem 1.5rem;
  border-radius: 12px;
  border: none;
  font-weight: 600;
}

.messages-view__input button[type='submit'] {
  background: linear-gradient(120deg, #7c3aed, #4c1d95);
  color: #fff;
}

.ghost {
  background: rgba(15, 23, 42, 0.06);
  color: #334155;
}

@media (max-width: 960px) {
  .messages-view__grid {
    grid-template-columns: 1fr;
  }

  .message {
    max-width: 90%;
  }
}
</style>
