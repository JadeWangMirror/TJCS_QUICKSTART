<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useRecommendationStore } from '@/store/modules/recommendation'

const router = useRouter()
const recommendationStore = useRecommendationStore()

// 使用推荐系统获取的最新帖子替代原来的硬编码数据
const loadLatestPosts = async () => {
  try {
    await recommendationStore.fetchFeed('newest', { page: 1, pageSize: 4 })
  } catch (error) {
    console.error('获取最新帖子失败:', error)
  }
}

// 截取字符串前10个字符并添加省略号
const truncateText = (text: string, length: number = 10) => {
  if (!text) return ''
  return text.length > length ? text.substring(0, length) + '...' : text
}

// 跳转到帖子详情页
const goToPostDetail = (postId: number) => {
  router.push({ name: 'posts.detail', params: { id: postId } })
}

onMounted(() => {
  loadLatestPosts()
})
</script>

<template>
  <section class="home-view">
    <!-- Hero 区域：增加弥散背景与磨砂质感 -->
    <header class="home-view__hero">
      <div class="hero-bg-glow"></div>
      <div class="hero-content">
        <div class="hero-text">
          <span class="hero-badge">灵感引擎 2.0</span>
          <h1>激发你的<br /><span class="text-gradient">无限创作潜能</span></h1>
          <p>
            汇聚全球创作者的智慧，探索 AI 提示词的边界。<br>
            从这里开始，重新定义你的创作流。
          </p>
          <div class="hero-actions">
            <RouterLink to="/posts/new" class="btn btn-primary">
              <span class="icon">+</span> 发布交流帖
            </RouterLink>
            <RouterLink to="/recommendations/trending" class="btn btn-secondary">
              探索社区
            </RouterLink>
          </div>
        </div>
        <!-- 装饰性图形，模拟 3D 元素 -->
        <div class="hero-visual">
          <div class="abstract-card card-1">Prompt</div>
          <div class="abstract-card card-2">Image</div>
        </div>
      </div>
    </header>

    <!-- Bento Grid 布局：非对称设计 -->
    <div class="bento-grid">
      
      <!-- 左侧：主要内容流 -->
      <div class="main-column">
        <article class="card feed-card">
          <header class="card-header">
            <div class="header-title">
              <h2>社区动态</h2>
              <span class="subtitle">实时灵感瀑布流</span>
            </div>
            <RouterLink to="/recommendations/latest" class="link-arrow">全部动态 &rarr;</RouterLink>
          </header>
          
          <div class="post-list">
            <div 
              v-for="post in recommendationStore.feed?.posts" 
              :key="post.id" 
              class="post-item"
              @click="goToPostDetail(post.id)"
            >
              <div class="post-meta">
                <span class="author-avatar">{{ post.author[0] }}</span>
                <span class="author-name">@{{ post.author }}</span>
              </div>
              <h3>{{ post.title }}</h3>
<!--              <p>{{ truncateText(post.context, 10) }}</p>-->
              <div class="post-footer">
                <div class="tags">
                  <span v-for="tag in post.tags?.slice(0, 3)" :key="tag" class="tag">#{{ tag }}</span>
                </div>
                <div class="likes">
                  <svg class="heart-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                  <span class="like-count">{{ post.like_count || 0 }}</span>
                </div>
              </div>
            </div>
          </div>
        </article>
      </div>

      <!-- 右侧：侧边栏功能区 -->
      <aside class="sidebar-column">
        
        <!-- 个性化推荐 -->
        <article class="card highlight-card">
          <header class="card-header">
            <h2>专属推荐</h2>
          </header>
          <p class="desc">基于你的收藏习惯定制</p>
          <ul class="action-list">
            <li>
              <div class="icon-box purple">剧</div>
              <div>
                <strong>AI 剧本生成器</strong>
                <span>继续上次的创作</span>
              </div>
            </li>
            <li>
              <div class="icon-box blue">艺</div>
              <div>
                <strong>风格挑战赛</strong>
                <span>剩余 2 天结束</span>
              </div>
            </li>
          </ul>
          <RouterLink to="/recommendations" class="btn-sm">查看更多</RouterLink>
        </article>

        <!-- 热门榜单 -->
        <article class="card list-card">
          <header class="card-header">
            <h2>热门话题</h2>
            <RouterLink to="/posts/hot" class="link-sm">榜单</RouterLink>
          </header>
          <ul class="ranking-list">
            <li>
              <span class="rank rank-1">1</span>
              <span>新锐创作者周榜</span>
            </li>
            <li>
              <span class="rank rank-2">2</span>
              <span>高评分 (4.5+) 提示词</span>
            </li>
            <li>
              <span class="rank rank-3">3</span>
              <span>Stable Diffusion XL 模型评测</span>
            </li>
          </ul>
        </article>

      </aside>
    </div>
  </section>
</template>

<style scoped>
/* 
  设计系统变量 
  使用 CSS 变量方便统一调整色调
*/
.home-view {
  --primary: #6366f1;
  --primary-dark: #4f46e5;
  --secondary: #8b5cf6;
  --bg-color: #f8fafc;
  --card-bg: #ffffff;
  --text-main: #1e293b;
  --text-sub: #64748b;
  --border-color: rgba(226, 232, 240, 0.8);
  --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
  --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
  --shadow-glow: 0 20px 25px -5px rgba(99, 102, 241, 0.15), 0 8px 10px -6px rgba(99, 102, 241, 0.1);
  
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  color: var(--text-main);
  max-width: 1200px;
  margin: 0 auto;
  padding: 1rem;
}

/* ================= 全局动画定义 ================= */
@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes slideInLeft {
  from {
    opacity: 0;
    transform: translateX(-40px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

@keyframes slideInRight {
  from {
    opacity: 0;
    transform: translateX(40px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

@keyframes float {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-10px);
  }
}

@keyframes glow-pulse {
  0%, 100% {
    opacity: 0.8;
  }
  50% {
    opacity: 1;
  }
}

@keyframes shimmer {
  0% {
    background-position: -1000px 0;
  }
  100% {
    background-position: 1000px 0;
  }
}

@keyframes rotate-slow {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

@keyframes bounce-gentle {
  0%, 100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-8px);
  }
}

@keyframes scale-in {
  from {
    opacity: 0;
    transform: scale(0.95);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

@keyframes gradient-shift {
  0%, 100% {
    background-position: 0% 50%;
  }
  50% {
    background-position: 100% 50%;
  }
}

/* ================= Hero Section ================= */
.home-view__hero {
  position: relative;
  border-radius: 24px;
  background: #0f172a; /* 深色背景显高级 */
  color: white;
  padding: 4rem 3rem;
  overflow: hidden;
  margin-bottom: 2rem;
  box-shadow: var(--shadow-glow);
  animation: fadeInUp 0.8s ease-out;
}

/* 背景光效 */
.hero-bg-glow {
  position: absolute;
  top: -50%;
  left: -20%;
  width: 80%;
  height: 200%;
  background: radial-gradient(circle, rgba(99,102,241,0.4) 0%, rgba(139,92,246,0.1) 40%, transparent 70%);
  filter: blur(60px);
  z-index: 0;
  pointer-events: none;
  animation: glow-pulse 3s ease-in-out infinite;
}

.hero-content {
  position: relative;
  z-index: 1;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.hero-text {
  max-width: 600px;
  animation: slideInLeft 0.8s ease-out 0.1s both;
}

.hero-badge {
  display: inline-block;
  padding: 0.35rem 0.75rem;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 100px;
  font-size: 0.85rem;
  font-weight: 500;
  margin-bottom: 1.5rem;
  color: #e2e8f0;
  animation: scale-in 0.6s ease-out 0.2s both;
}

.hero-text h1 {
  font-size: 3rem;
  line-height: 1.1;
  font-weight: 800;
  margin-bottom: 1.25rem;
  letter-spacing: -0.02em;
  animation: slideInLeft 0.8s ease-out 0.3s both;
}

.text-gradient {
  background: linear-gradient(135deg, #818cf8 0%, #c084fc 100%);
  background-size: 300% 300%;
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: gradient-shift 4s ease infinite;
}

.hero-text p {
  font-size: 1.125rem;
  color: #94a3b8;
  margin-bottom: 2rem;
  line-height: 1.6;
  animation: slideInLeft 0.8s ease-out 0.4s both;
}

.hero-actions {
  display: flex;
  gap: 1rem;
}

.btn {
  padding: 0.875rem 1.75rem;
  border-radius: 12px;
  font-weight: 600;
  text-decoration: none;
  transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  animation: slideInLeft 0.8s ease-out 0.5s both;
}

.btn-primary {
  background: white;
  color: #0f172a;
  position: relative;
  overflow: hidden;
}

.btn-primary::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
  transition: left 0.5s;
}

.btn-primary:hover::before {
  left: 100%;
}

.btn-primary:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 24px rgba(255, 255, 255, 0.4);
}

.btn-primary:active {
  transform: translateY(-2px);
  box-shadow: 0 6px 12px rgba(255, 255, 255, 0.3);
}

.btn-secondary {
  background: rgba(255, 255, 255, 0.05);
  color: white;
  border: 1px solid rgba(255, 255, 255, 0.1);
  position: relative;
  overflow: hidden;
}

.btn-secondary::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: 0;
  height: 0;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 50%;
  transform: translate(-50%, -50%);
  transition: width 0.6s, height 0.6s;
}

.btn-secondary:hover::after {
  width: 300px;
  height: 300px;
}

.btn-secondary:hover {
  background: rgba(255, 255, 255, 0.15);
  border-color: rgba(255, 255, 255, 0.2);
}

/* 右侧抽象装饰 */
.hero-visual {
  position: relative;
  width: 300px;
  height: 300px;
  display: none; /* 移动端隐藏 */
}

@media (min-width: 900px) {
  .hero-visual {
    display: block;
    animation: slideInRight 0.8s ease-out 0.1s both;
  }
}

.abstract-card {
  position: absolute;
  width: 180px;
  height: 220px;
  background: rgba(255, 255, 255, 0.03);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  color: rgba(255,255,255,0.3);
  font-size: 1.5rem;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
  transition: all 0.4s ease;
}

.card-1 {
  top: 0;
  right: 0;
  transform: rotate(6deg);
  z-index: 1;
  background: linear-gradient(145deg, rgba(255,255,255,0.1), rgba(255,255,255,0.01));
  animation: float 3s ease-in-out infinite 0.2s;
}

.card-1:hover {
  transform: rotate(8deg) translateY(-5px);
  box-shadow: 0 35px 60px -12px rgba(99, 102, 241, 0.4);
}

.card-2 {
  bottom: 0;
  left: 0;
  transform: rotate(-6deg);
  background: linear-gradient(145deg, rgba(99,102,241,0.2), rgba(99,102,241,0.05));
  animation: float 3s ease-in-out infinite 0.4s reverse;
}

.card-2:hover {
  transform: rotate(-8deg) translateY(-5px);
  box-shadow: 0 35px 60px -12px rgba(139, 92, 246, 0.4);
}

/* ================= Bento Grid Layout ================= */
.bento-grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: 1.5rem;
}

@media (min-width: 900px) {
  .bento-grid {
    grid-template-columns: 1fr 340px; /* 左宽右窄 */
  }
}

/* 通用卡片样式 */
.card {
  background: var(--card-bg);
  border-radius: 20px;
  border: 1px solid var(--border-color);
  padding: 1.5rem;
  box-shadow: var(--shadow-sm);
  transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
  animation: fadeInUp 0.6s ease-out both;
}

.card:nth-child(1) { animation-delay: 0.1s; }
.card:nth-child(2) { animation-delay: 0.2s; }
.card:nth-child(3) { animation-delay: 0.3s; }

.card:hover {
  box-shadow: var(--shadow-lg);
  transform: translateY(-8px);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
}

.card-header h2 {
  font-size: 1.25rem;
  margin: 0;
  font-weight: 700;
  color: var(--text-main);
  position: relative;
  display: inline-block;
}

.card-header h2::after {
  content: '';
  position: absolute;
  bottom: -4px;
  left: 0;
  width: 0;
  height: 2px;
  background: linear-gradient(90deg, var(--primary), var(--secondary));
  transition: width 0.4s ease;
}

.card-header:hover h2::after {
  width: 100%;
}

.subtitle {
  font-size: 0.85rem;
  color: var(--text-sub);
  font-weight: 400;
  margin-left: 0.5rem;
}

.link-arrow {
  font-size: 0.9rem;
  color: var(--primary);
  text-decoration: none;
  font-weight: 500;
  transition: all 0.3s ease;
  display: inline-flex;
  align-items: center;
  gap: 0.3rem;
}

.link-arrow:hover {
  gap: 0.6rem;
  color: var(--secondary);
}

/* ================= Feed (Main Column) ================= */
.post-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.post-item {
  padding: 1.25rem;
  border-radius: 16px;
  background: #f8fafc; /* 浅灰底让内容突起 */
  border: 1px solid transparent;
  transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
  cursor: pointer;
  position: relative;
  overflow: hidden;
  animation: slideInLeft 0.6s ease-out both;
  will-change: transform, box-shadow;
}

.post-item::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(99, 102, 241, 0.05), transparent);
  opacity: 0;
  transition: opacity 0.4s ease;
}

.post-item:hover::before {
  opacity: 1;
  animation: shimmer 0.6s ease-in-out;
}

.post-item:nth-child(1) { animation-delay: 0.2s; }
.post-item:nth-child(2) { animation-delay: 0.3s; }
.post-item:nth-child(3) { animation-delay: 0.4s; }
.post-item:nth-child(4) { animation-delay: 0.5s; }

.post-item:hover {
  background: white;
  border-color: var(--primary);
  box-shadow: 0 12px 24px rgba(99, 102, 241, 0.15);
  transform: translateY(-4px) scale(1.01);
  z-index: 1;
}

.post-meta {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 0.5rem;
  font-size: 0.85rem;
  color: var(--text-sub);
}

.author-avatar {
  width: 24px;
  height: 24px;
  background: linear-gradient(135deg, #e0e7ff, #c7d2fe);
  color: var(--primary-dark);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 0.7rem;
  transition: all 0.3s ease;
  box-shadow: 0 2px 8px rgba(99, 102, 241, 0.2);
}

.post-item:hover .author-avatar {
  transform: scale(1.2) rotate(360deg);
  box-shadow: 0 4px 12px rgba(99, 102, 241, 0.4);
}

.author-name {
  font-weight: 500;
}

.post-item h3 {
  margin: 0.25rem 0 0.5rem;
  font-size: 1.1rem;
  color: var(--text-main);
  transition: color 0.3s ease, transform 0.3s ease;
  font-weight: 600;
}

.post-item:hover h3 {
  color: var(--primary);
  transform: translateX(2px);
}

.post-item p {
  font-size: 0.95rem;
  color: var(--text-sub);
  margin-bottom: 1rem;
  line-height: 1.5;
}

.post-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 0.75rem;
  border-top: 1px solid rgba(226, 232, 240, 0.5);
  transition: all 0.3s ease;
  font-size: 0.9rem;
}

.post-item:hover .post-footer {
  border-top-color: var(--primary);
  padding-left: 2px;
}

.tags {
  display: flex;
  gap: 0.5rem;
}

.tag {
  font-size: 0.75rem;
  padding: 0.15rem 0.6rem;
  border-radius: 6px;
  background: rgba(99, 102, 241, 0.1);
  color: var(--primary-dark);
  font-weight: 500;
  transition: all 0.3s ease;
  cursor: default;
  border: 1px solid rgba(99, 102, 241, 0.15);
  will-change: transform;
}

.tag:hover {
  background: rgba(99, 102, 241, 0.2);
  border-color: rgba(99, 102, 241, 0.3);
  transform: translateY(-1px) scale(1.05);
  box-shadow: 0 4px 8px rgba(99, 102, 241, 0.15);
}

.likes {
  font-size: 0.85rem;
  color: var(--text-sub);
  transition: all 0.3s ease;
  font-weight: 500;
  display: flex;
  align-items: center;
  gap: 0.4rem;
  cursor: pointer;
  padding: 0.25rem 0.5rem;
  border-radius: 6px;
}

.heart-icon {
  width: 18px;
  height: 18px;
  color: #cbd5e1;
  transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
  flex-shrink: 0;
  will-change: transform, color;
}

.heart-icon:hover {
  color: #ef4444;
  transform: scale(1.2);
  animation: heart-beat 0.4s ease;
}

.like-count {
  transition: color 0.3s ease, transform 0.3s ease;
  font-feature-settings: 'tnum';
}

.post-item:hover .likes {
  color: #ef4444;
  background-color: rgba(239, 68, 68, 0.1);
}

.post-item:hover .heart-icon {
  color: #ef4444;
  transform: scale(1.1);
}

@keyframes heart-beat {
  0%, 100% {
    transform: scale(1);
  }
  25% {
    transform: scale(1.3);
  }
  50% {
    transform: scale(1.1);
  }
  75% {
    transform: scale(1.25);
  }
}

/* ================= Sidebar Styles ================= */
.sidebar-column {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

/* 推荐卡片 */
.highlight-card {
  background: linear-gradient(160deg, #ffffff 0%, #f3f4f6 100%);
  animation: slideInRight 0.6s ease-out 0.2s both;
}

.desc {
  font-size: 0.9rem;
  color: var(--text-sub);
  margin-bottom: 1.25rem;
}

.action-list {
  list-style: none;
  padding: 0;
  margin: 0 0 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.action-list li {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.75rem;
  background: white;
  border-radius: 12px;
  border: 1px solid rgba(0,0,0,0.03);
  box-shadow: var(--shadow-sm);
  transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
  cursor: pointer;
  overflow: hidden;
  position: relative;
}

.action-list li::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(99, 102, 241, 0.1), transparent);
  transition: left 0.6s ease;
  z-index: 0;
}

.action-list li:hover::before {
  left: 100%;
}

.action-list li:hover {
  border-color: var(--primary);
  box-shadow: 0 8px 16px rgba(99, 102, 241, 0.15);
  transform: translateX(6px);
}

.action-list li:nth-child(1) {
  animation: fadeInUp 0.6s ease-out 0.3s both;
}

.action-list li:nth-child(2) {
  animation: fadeInUp 0.6s ease-out 0.4s both;
}

.icon-box {
  width: 36px;
  height: 36px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.2rem;
  font-weight: 700;
  transition: all 0.3s ease;
  flex-shrink: 0;
  z-index: 1;
}

.action-list li:hover .icon-box {
  transform: scale(1.15) rotate(-10deg);
}

.icon-box.purple { 
  background: #f3e8ff;
  color: #a855f7;
}

.icon-box.blue { 
  background: #dbeafe;
  color: #3b82f6;
}

.action-list li div {
  display: flex;
  flex-direction: column;
  z-index: 1;
}

.action-list strong {
  font-size: 0.9rem;
  color: var(--text-main);
  transition: color 0.3s ease;
}

.action-list li:hover strong {
  color: var(--primary);
}

.action-list span {
  font-size: 0.75rem;
  color: var(--text-sub);
}

.btn-sm {
  width: 100%;
  display: block;
  text-align: center;
  padding: 0.6rem;
  background: white;
  border: 1px solid var(--border-color);
  border-radius: 8px;
  color: var(--text-main);
  text-decoration: none;
  font-size: 0.9rem;
  font-weight: 500;
  transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
  position: relative;
  overflow: hidden;
  cursor: pointer;
}

.btn-sm::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: 0;
  height: 0;
  background: rgba(99, 102, 241, 0.1);
  border-radius: 50%;
  transform: translate(-50%, -50%);
  transition: width 0.6s, height 0.6s;
}

.btn-sm:hover::after {
  width: 300px;
  height: 300px;
}

.btn-sm:hover {
  border-color: var(--primary);
  color: var(--primary);
}

/* 榜单列表 */
.ranking-list {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
}

.ranking-list li {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  font-size: 0.95rem;
  color: var(--text-main);
  padding: 0.8rem 0.8rem 0.8rem 0;
  border-bottom: 1px dashed var(--border-color);
  transition: all 0.3s ease;
  cursor: pointer;
}

.ranking-list li:hover {
  padding-left: 0.5rem;
  color: var(--primary);
}

.ranking-list li:last-child {
  border-bottom: none;
  padding-bottom: 0;
}

.rank {
  font-weight: 800;
  font-size: 1rem;
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  transition: all 0.3s ease;
}

.ranking-list li:hover .rank {
  transform: scale(1.2);
}

.rank-1 { 
  color: #f59e0b; 
  background: #fef3c7;
}

.rank-2 { 
  color: #64748b; 
  background: #f1f5f9;
}

.rank-3 { 
  color: #b45309; 
  background: #fff7ed;
}

.link-sm {
  font-size: 0.8rem;
  color: var(--text-sub);
  text-decoration: none;
  transition: all 0.3s ease;
}

.link-sm:hover {
  color: var(--primary);
}
</style>
