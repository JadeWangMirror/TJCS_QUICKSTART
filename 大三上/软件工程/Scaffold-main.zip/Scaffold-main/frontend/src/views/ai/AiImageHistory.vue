<template>
  <div id="app">
    <div class="container">
      <h1>图片生成历史记录</h1>
      
      <!-- 历史记录列表 -->
      <div class="history-list" v-if="!selectedRecord">
        <div class="list-header">
          <h2 class="list-title">生成历史</h2>
          <div class="stats">
            <span class="badge">共 {{ totalRecords }} 条</span>
          </div>
        </div>
        
        <div class="records-grid">
          <div 
            class="record-card" 
            v-for="(record, index) in records" 
            :key="record.id"
            @click="viewRecordDetail(record.id)"
            :style="{ animationDelay: `${index * 0.05}s` }"
          >
            <div class="card-image-wrapper">
              <img :src="record.url" :alt="record.prompt_preview" @error="handleImageError" class="card-image" />
              <div class="card-overlay">
                <span class="view-icon">查看详情</span>
              </div>
            </div>
            <div class="card-content">
              <h3 class="card-title">记录 #{{ record.id }}</h3>
              <p class="card-prompt">{{ record.prompt_preview }}</p>
              <p class="card-timestamp">{{ formatDate(record.timestamp) }}</p>
            </div>
          </div>
        </div>
        
        <div class="pagination" v-if="totalRecords > limit">
          <button class="pagination-btn" @click="prevPage" :disabled="offset === 0">
            <span>←</span> 上一页
          </button>
          <span class="pagination-info">第 {{ Math.floor(offset / limit) + 1 }} / {{ Math.ceil(totalRecords / limit) }} 页</span>
          <button class="pagination-btn" @click="nextPage" :disabled="offset + limit >= totalRecords">
            下一页 <span>→</span>
          </button>
        </div>
        
        <div class="empty-state" v-if="records.length === 0 && !loading">
          <div class="empty-icon">
            <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="8" y="14" width="32" height="22" rx="3" fill="#cbd5e1" stroke="#64748b" stroke-width="2"/>
              <rect x="4" y="8" width="40" height="8" rx="2" fill="#94a3b8" stroke="#64748b" stroke-width="2"/>
              <rect x="16" y="22" width="16" height="8" rx="2" fill="#e0e7ef"/>
            </svg>
          </div>
          <p>暂无历史记录</p>
          <span class="empty-tip">开始生成图片后，历史记录将显示在这里</span>
        </div>
      </div>
      
      <!-- 记录详情 -->
      <transition name="detail-fade">
        <div class="record-detail" v-if="selectedRecord">
          <div class="detail-back-header">
            <button @click="backToList" class="back-circle-btn" aria-label="返回">
              <svg width="32" height="32" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" role="img" aria-hidden="true">
                <defs>
                  <linearGradient id="backChevronGradient" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stop-color="#667eea"/>
                    <stop offset="1" stop-color="#764ba2"/>
                  </linearGradient>
                </defs>
                  <!-- 更粗的填充 Chevron，线条加粗 -->
                  <path class="back-chevron" d="M17.5 4.5 L9 12 L17.5 19.5 L15.8 21 L6.5 12 L15.8 3 L17.5 4.5 Z" fill="url(#backChevronGradient)" stroke="#667eea" stroke-width="2.5" />
              </svg>
            </button>
            <div class="detail-badge">详情</div>
          </div>
          
          <div class="detail-main">
            <div class="detail-image-section">
              <div class="detail-image-wrapper">
                <img :src="selectedRecord.url" :alt="selectedRecord.prompt" @error="handleImageError" class="detail-image" />
              </div>
            </div>
            
            <div class="detail-info-section">
              <div class="info-card">
                <div class="info-header">
                  <span class="info-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M8 15a4 4 0 1 1 8 0c0 2-2 3-2 3v2a1 1 0 0 1-2 0v-2s-2-1-2-3z" fill="#fbbf24" stroke="#667eea" stroke-width="2"/>
                      <path d="M12 3a7 7 0 0 1 7 7c0 3.5-2.5 5.5-3.5 6.5" stroke="#667eea" stroke-width="2" fill="none"/>
                      <path d="M12 3a7 7 0 0 0-7 7c0 3.5 2.5 5.5 3.5 6.5" stroke="#667eea" stroke-width="2" fill="none"/>
                    </svg>
                  </span>
                  <h3>生成提示词</h3>
                </div>
                <p class="info-content prompt-full">{{ selectedRecord.prompt }}</p>
              </div>
              
              <div class="info-card">
                <div class="info-header">
                  <span class="info-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <circle cx="12" cy="12" r="10" stroke="#667eea" stroke-width="2" fill="#e0e7ef"/>
                      <path d="M12 7v5l4 2" stroke="#667eea" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                  </span>
                  <h3>生成时间</h3>
                </div>
                <p class="info-content">{{ formatDate(selectedRecord.timestamp) }}</p>
              </div>
              
              <!-- 用户ID 已移除 -->
            </div>
          </div>
        </div>
      </transition>
      
      <!-- 加载状态 -->
      <div class="loading" v-if="loading">
        <p>加载中...</p>
      </div>
      
      <!-- 错误提示 -->
      <div class="error" v-if="error">
        <p>{{ error }}</p>
        <button @click="retry">重试</button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import { httpClient } from '@/utils/httpClients'
import { useAuthStore } from '@/store/modules/auth'

// 定义类型
interface HistoryRecord {
  id: number
  url: string
  prompt: string
  prompt_preview: string
  timestamp: string
  user_id: string
}

interface ApiResponse<T> {
  status: string
  records?: T[]
  record?: T
  total?: number
}

// 响应式数据
const userId = ref<number>(0)
const records = ref<HistoryRecord[]>([])
const selectedRecord = ref<HistoryRecord | null>(null)
const loading = ref<boolean>(false)
const error = ref<string>('')
const totalRecords = ref<number>(0)
const limit = ref<number>(20)
const offset = ref<number>(0)
const authStore = useAuthStore()

// 监听用户状态变化
watch(
  () => authStore.currentUser?.id,
  (newUserId) => {
    if (newUserId && newUserId !== userId.value) {
      userId.value = newUserId
      // 只有在列表视图且没有加载时才自动获取历史记录
      if (!selectedRecord.value && !loading.value) {
        fetchHistory()
      }
    }
  }
)

// 获取用户ID - 异步等待版本
const getUserId = async (): Promise<boolean> => {
  try {
    // 如果已经有用户ID，直接返回
    if (authStore.currentUser?.id) {
      userId.value = authStore.currentUser.id
      return true
    }

    // 等待用户状态恢复（适用于持久化存储的情况）
    let retries = 0
    const maxRetries = 5 // 增加重试次数
    const retryInterval = 100 // 重试间隔(ms)

    while (!authStore.currentUser?.id && retries < maxRetries) {
      await new Promise(resolve => setTimeout(resolve, retryInterval))
      retries++
    }

    const currentUserId = authStore.currentUser?.id
    
    if (!currentUserId) {
      error.value = "用户未认证，请先登录"
      return false
    }
    
    userId.value = currentUserId
    return true
  } catch (err) {
    console.error('获取用户ID失败:', err)
    error.value = "获取用户信息失败"
    return false
  }
}

// 获取历史记录
const fetchHistory = async (): Promise<void> => {
  const hasUserId = await getUserId()
  if (!hasUserId) {
    return
  }

  loading.value = true
  error.value = ''
  
  try {
    const url = `/api/user/${userId.value}/history/image?limit=${limit.value}&offset=${offset.value}`
    const data = await httpClient<ApiResponse<HistoryRecord>>(url, {
      method: 'GET',
    })
    
    if (data.status === "success" && data.records && data.total !== undefined) {
      records.value = data.records
      totalRecords.value = data.total
    } else {
      throw new Error("获取历史记录失败")
    }
  } catch (err) {
    console.error("获取历史记录时出错:", err)
    error.value = `加载失败: ${err instanceof Error ? err.message : '未知错误'}`
  } finally {
    loading.value = false
  }
}

// 查看记录详情
const viewRecordDetail = async (historyId: number): Promise<void> => {
  const hasUserId = await getUserId()
  if (!hasUserId) {
    return
  }

  loading.value = true
  error.value = ''
  
  try {
    const url = `/api/user/${userId.value}/history/image/${historyId}`
    const data = await httpClient<ApiResponse<HistoryRecord>>(url, {
      method: 'GET',
    })
    
    if (data.status === "success" && data.record) {
      selectedRecord.value = data.record
    } else {
      throw new Error("获取记录详情失败")
    }
  } catch (err) {
    console.error("获取记录详情时出错:", err)
    error.value = `加载详情失败: ${err instanceof Error ? err.message : '未知错误'}`
  } finally {
    loading.value = false
  }
}

// 返回列表
const backToList = (): void => {
  selectedRecord.value = null
  error.value = ''
}

// 分页
const nextPage = (): void => {
  if (offset.value + limit.value < totalRecords.value) {
    offset.value += limit.value
    fetchHistory()
  }
}

const prevPage = (): void => {
  if (offset.value >= limit.value) {
    offset.value -= limit.value
    fetchHistory()
  }
}

// 格式化日期
const formatDate = (timestamp: string): string => {
  const date = new Date(timestamp)
  return date.toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  })
}

// 图片加载错误处理
const handleImageError = (event: Event): void => {
  const target = event.target as HTMLImageElement
  target.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZGRkIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtc2l6ZT0iMTgiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGR5PSIuM2VtIj7lm77niYc8L3RleHQ+PC9zdmc+'
}

// 重试
const retry = (): void => {
  error.value = ''
  if (selectedRecord.value) {
    viewRecordDetail(selectedRecord.value.id)
  } else {
    fetchHistory()
  }
}

// 生命周期
onMounted(async () => {
  await getUserId()
  if (userId.value) {
    await fetchHistory()
  }
})
</script>

<style scoped>
/* 重置和全局样式 */
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
  min-height: 100vh;
  background: #ffffff;
}

h1 {
  margin: 0 0 2rem 0;
  font-size: 2.2rem;
  font-weight: 700;
  background: linear-gradient(120deg, #667eea 0%, #764ba2 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  text-align: left;
}

/* 历史列表 */
.history-list {
  display: grid;
  gap: 2rem;
  animation: listFadeIn 0.6s ease-out;
}

@keyframes listFadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.list-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 16px;
  box-shadow: 0 8px 24px rgba(15, 23, 42, 0.08);
  backdrop-filter: blur(10px);
}

.list-title {
  font-size: 1.5rem;
  font-weight: 600;
  color: #312e81;
  margin: 0;
}

.badge {
  background: linear-gradient(120deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 0.5rem 1.2rem;
  border-radius: 20px;
  font-size: 0.9rem;
  font-weight: 600;
}

.records-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 1.5rem;
}

.record-card {
  background: white;
  border-radius: 16px;
  overflow: hidden;
  cursor: pointer;
  box-shadow: 0 8px 20px rgba(15, 23, 42, 0.08);
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  animation: cardSlideIn 0.5s ease-out forwards;
  opacity: 0;
  transform: translateY(20px);
}

@keyframes cardSlideIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.record-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 16px 40px rgba(102, 126, 234, 0.15);
}

.card-image-wrapper {
  position: relative;
  width: 100%;
  height: 220px;
  overflow: hidden;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.card-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s ease;
}

.record-card:hover .card-image {
  transform: scale(1.08);
}

.card-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(49, 46, 129, 0.7);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity 0.3s ease;
}

.record-card:hover .card-overlay {
  opacity: 1;
}

.view-icon {
  color: white;
  font-size: 1rem;
  font-weight: 600;
  backdrop-filter: blur(4px);
  padding: 0.6rem 1.2rem;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 8px;
}

.card-content {
  padding: 1.5rem;
}

.card-title {
  font-size: 1.1rem;
  font-weight: 600;
  color: #312e81;
  margin-bottom: 0.8rem;
}

.card-prompt {
  color: #475569;
  margin-bottom: 1rem;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  line-height: 1.4;
  font-size: 0.95rem;
}

.card-timestamp {
  color: #94a3b8;
  font-size: 0.85rem;
  margin: 0;
}

/* 分页 */
.pagination {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 1.5rem;
  margin-top: 2rem;
  padding: 1.5rem;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 16px;
  box-shadow: 0 8px 24px rgba(15, 23, 42, 0.08);
  flex-wrap: wrap;
}

.pagination-btn {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  background: linear-gradient(120deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  border-radius: 12px;
  cursor: pointer;
  font-weight: 600;
  font-size: 0.95rem;
  transition: all 0.3s;
}

.pagination-btn:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
}

.pagination-btn:disabled {
  background: #cbd5e1;
  cursor: not-allowed;
  transform: none;
}

.pagination-info {
  color: #475569;
  font-weight: 600;
  min-width: 120px;
  text-align: center;
}

/* 空状态 */
.empty-state {
  text-align: center;
  padding: 4rem 2rem;
  background: rgba(255, 255, 255, 0.95);
  border-radius: 16px;
  box-shadow: 0 8px 24px rgba(15, 23, 42, 0.08);
}

.empty-icon {
  font-size: 4rem;
  margin-bottom: 1rem;
  display: inline-block;
  animation: float 3s ease-in-out infinite;
}

@keyframes float {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-20px);
  }
}

.empty-state p {
  font-size: 1.3rem;
  color: #312e81;
  margin-bottom: 0.5rem;
  font-weight: 600;
}

.empty-tip {
  color: #64748b;
  font-size: 0.95rem;
  display: block;
}

/* 详情页面 */
.record-detail {
  display: grid;
  gap: 1.5rem;
  animation: detailFadeIn 0.4s ease-out;
}

@keyframes detailFadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.detail-fade-enter-active, .detail-fade-leave-active {
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
}

.detail-fade-enter-from {
  opacity: 0;
  transform: translateY(20px);
}

.detail-fade-leave-to {
  opacity: 0;
  transform: translateY(-20px);
}

.detail-back-header {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  padding: 1rem;
}

/* 圆形返回按钮样式 */
.back-circle-btn {
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: none;
  border: none;
  padding: 0;
  cursor: pointer;
  transition: box-shadow 0.3s;
  box-shadow: 0 4px 16px rgba(102, 126, 234, 0.15);
}
.back-circle-btn:hover {
  box-shadow: 0 12px 30px rgba(102, 126, 234, 0.20);
  transform: translateY(-1px);
}

/* 增强 chevron 动效 */
.back-circle-btn svg {
  display: block;
}
.back-circle-btn .back-chevron {
  transition: transform 220ms cubic-bezier(.2,.9,.3,1), filter 220ms, opacity 220ms;
  transform-origin: 50% 50%;
}
.back-circle-btn:hover .back-chevron {
  transform: translateX(-2px) scale(1.04);
  filter: drop-shadow(0 6px 12px rgba(102,126,234,0.14));
  opacity: 0.98;
}

.detail-badge {
  background: linear-gradient(120deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 0.5rem 1.2rem;
  border-radius: 20px;
  font-size: 0.85rem;
  font-weight: 600;
}

.detail-main {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  background: #fff;
  border-radius: 20px;
  padding: 2rem;
  box-shadow: 0 12px 32px rgba(15, 23, 42, 0.12);
  backdrop-filter: blur(10px);
}

.detail-image-section {
  display: flex;
  align-items: center;
  justify-content: center;
}

.detail-image-wrapper {
  width: 100%;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 16px 40px rgba(102, 126, 234, 0.12);
  background: #fff;
  padding: 8px;
  border: 1px solid rgba(15,23,42,0.04);
}

.detail-image {
  width: 100%;
  height: auto;
  object-fit: contain;
  border-radius: 12px;
  display: block;
}

.detail-info-section {
  display: grid;
  gap: 1.5rem;
}

.info-card {
  background: #fff;
  border: 1px solid rgba(15,23,42,0.06);
  border-radius: 14px;
  padding: 1.5rem;
  transition: all 0.18s ease;
}

.info-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(102, 126, 234, 0.15);
  border-color: rgba(102, 126, 234, 0.3);
}

.info-header {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  margin-bottom: 1rem;
}

.info-icon {
  font-size: 1.5rem;
}

.info-header h3 {
  margin: 0;
  color: #312e81;
  font-size: 1rem;
  font-weight: 600;
}

.info-content {
  margin: 0;
  color: #475569;
  line-height: 1.6;
  font-size: 0.95rem;
}

.prompt-full {
  white-space: pre-wrap;
  word-break: break-word;
  background: rgba(255, 255, 255, 0.7);
  padding: 1rem;
  border-radius: 10px;
  border-left: 3px solid #667eea;
}

/* 用户ID 样式已移除，因为详情中不再显示用户ID */

/* 加载和错误 */
.loading, .error {
  text-align: center;
  padding: 3rem;
  font-size: 1.1rem;
  background: rgba(255, 255, 255, 0.95);
  border-radius: 16px;
  box-shadow: 0 8px 24px rgba(15, 23, 42, 0.08);
  animation: listFadeIn 0.6s ease-out;
}

.loading {
  color: #667eea;
}

.error {
  color: #dc2626;
  display: grid;
  gap: 1.5rem;
}

.error button {
  padding: 0.75rem 1.5rem;
  background: linear-gradient(120deg, #ef4444 0%, #dc2626 100%);
  color: white;
  border: none;
  border-radius: 12px;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.3s;
  align-self: center;
}

.error button:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(239, 68, 68, 0.4);
}

/* 响应式设计 */
@media (max-width: 1024px) {
  .detail-main {
    grid-template-columns: 1fr;
    gap: 1.5rem;
    padding: 1.5rem;
  }
  
  .records-grid {
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  }
}

@media (max-width: 768px) {
  .container {
    padding: 1rem;
  }
  
  h1 {
    font-size: 1.6rem;
    margin-bottom: 1.5rem;
  }
  
  .list-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 1rem;
  }
  
  .records-grid {
    grid-template-columns: 1fr;
  }
  
  .card-image-wrapper {
    height: 180px;
  }
  
  .detail-back-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 1rem;
  }
  
  .detail-main {
    padding: 1rem;
  }
  
  .pagination {
    gap: 1rem;
  }
  
  .pagination-btn {
    padding: 0.65rem 1.2rem;
    font-size: 0.85rem;
  }
}

@media (max-width: 480px) {
  .container {
    padding: 0.75rem;
  }
  
  h1 {
    font-size: 1.4rem;
    margin-bottom: 1rem;
  }
  
  .list-header {
    padding: 1rem;
  }
  
  .records-grid {
    grid-template-columns: 1fr;
    gap: 1rem;
  }
  
  .card-content {
    padding: 1rem;
  }
  
  .card-title {
    font-size: 1rem;
  }
  
  .detail-info-section {
    gap: 1rem;
  }
  
  .info-card {
    padding: 1rem;
  }
}
</style>