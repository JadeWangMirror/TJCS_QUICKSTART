<template>
  <section class="chat-layout">
    <!-- 1. 对话滚动区域 -->
    <div class="chat-viewport">
      <div class="chat-container">
        
        <!-- A. 欢迎/空状态 (当没有开始优化且没有结果时显示) -->
        <div v-if="!isOptimizing && !optimizationResult" class="welcome-screen">
          <div class="welcome-content">
            <div class="logo-icon">
              <span class="icon-text">AI</span>
            </div>
            <h1>提示词优化工作台</h1>
            <p>输入初始提示词，专家团队将为您分析、扩展并润色。</p>
          </div>
        </div>

        <!-- B. 对话流 (当正在优化 或 有结果时显示) -->
        <div v-else class="message-stream">
          
          <!-- 用户消息 (原始提示词) -->
          <div class="message-row user-row">
            <div class="avatar user-avatar">
              <span class="avatar-text">我</span>
            </div>
            <div class="message-bubble user-bubble">
              <!-- 如果有结果，显示结果中的原始词(防止input变动)，否则显示当前prompt -->
              {{ optimizationResult ? optimizationResult.original_prompt : prompt }}
            </div>
          </div>

          <!-- AI 消息 (进度 + 结果) -->
          <div class="message-row ai-row">
            <div class="avatar ai-avatar">
              <span class="avatar-text">AI</span>
            </div>
            <div class="message-content">
              
              <!-- 1. 优化进度展示 (Think Process) -->
              <div v-if="isOptimizing || optimizationResult" class="process-block" :class="{ 'collapsed': optimizationResult }">
                <div class="process-header">
                  <span class="status-icon" v-if="isOptimizing">
                    <div class="spinner-icon"></div>
                  </span>
                  <span class="status-icon" v-else>
                    <div class="check-icon">✓</div>
                  </span>
                  <span>{{ isOptimizing ? 'AI 专家团队正在思考...' : '优化已完成' }}</span>
                </div>
                
                <!-- 进度步骤条 -->
                <div class="process-steps" v-if="isOptimizing">
                  <div 
                    v-for="stage in stages" 
                    :key="stage.key"
                    class="step-item"
                    :class="getStageStatus(stage.key)"
                  >
                    <div class="step-icon">
                      <span v-if="getStageStatus(stage.key) === 'finish'">✓</span>
                      <div v-else-if="getStageStatus(stage.key) === 'process'" class="spinner-dot"></div>
                      <div v-else class="wait-dot"></div>
                    </div>
                    <span class="step-text">{{ stage.title }}</span>
                  </div>
                </div>
              </div>

              <!-- 2. 最终结果展示 -->
              <div v-if="optimizationResult" class="result-block">
                <div class="result-content">
                  <pre>{{ optimizationResult.optimized_prompt }}</pre>
                </div>
                <div class="result-actions">
                  <button 
                    class="action-btn copy-btn" 
                    @click="copyOptimizedPrompt" 
                    title="复制"
                    :class="{ 'copy-success': copySuccess }"
                    :disabled="copySuccess"
                  >
                    <span class="btn-text">{{ copySuccess ? '已复制' : '复制' }}</span>
                    <span class="copy-icon" :class="{ 'success': copySuccess }">
                      <svg v-if="!copySuccess" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                      </svg>
                      <svg v-else width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    </span>
                  </button>
<!--                  <button class="action-btn reset-btn" @click="resetAll" title="重新开始">-->
<!--                    <span class="btn-text">重新开始</span>-->
<!--                    <span class="reset-icon">-->
<!--                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">-->
<!--                        <path d="M1 4v6h6"></path>-->
<!--                        <path d="M23 20v-6h-6"></path>-->
<!--                        <path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15"></path>-->
<!--                      </svg>-->
<!--                    </span>-->
<!--                  </button>-->
                </div>
              </div>

            </div>
          </div>
        </div>
        
        <!-- 底部占位，防止内容被输入框遮挡 -->
        <div class="bottom-spacer"></div>
      </div>
    </div>

    <!-- 2. 底部固定输入区域 -->
    <div class="chat-input-area">
      <div class="input-wrapper">
        <textarea
          v-model="prompt"
          class="chat-textarea"
          :disabled="isOptimizing"
          placeholder="在此输入您的提示词..."
          rows="1"
          @keydown.enter.prevent="(!isOptimizing && prompt.trim()) ? handleOptimize() : null"
        ></textarea>
        <div class="input-actions">
          <button 
            class="send-btn"
            @click="handleOptimize" 
            :disabled="!prompt.trim() || isOptimizing"
            title="发送"
          >
            <span class="send-text">发送</span>
          </button>
        </div>
      </div>
      <div class="footer-note">
        AI 生成内容仅供参考，请根据实际情况调整。
      </div>
    </div>
  </section>

  <!-- 简化的 Toast 组件 -->
  <div v-if="showToast" class="custom-toast">
    {{ toastMessage }}
  </div>
</template>

<script setup lang="ts">
  import { computed, ref } from 'vue'
  import { useOptimizeStore } from '@/store/modules/ai'

  type StageKey = 'analysis' | 'expansion' | 'structuring' | 'refinement'

  interface StageDefinition {
    key: StageKey
    title: string
    description: string
  }

  interface OptimizationStage {
    stage: StageKey
    summary?: string
  }

  interface OptimizationResult {
    original_prompt: string
    optimized_prompt: string
    stages?: OptimizationStage[]
  }

  type StepStatus = 'wait' | 'process' | 'finish'

  const prompt = ref<string>('')
  const showToast = ref(false)
  const toastMessage = ref('')
  const copySuccess = ref(false)
  let copySuccessTimer: number | null = null

  const stages: StageDefinition[] = [
    { key: 'analysis', title: '分析', description: '拆解' },
    { key: 'expansion', title: '扩展', description: '补充' },
    { key: 'structuring', title: '结构', description: '重构' },
    { key: 'refinement', title: '润色', description: '最终' }
  ]

  const store = useOptimizeStore();
  const isOptimizing = computed<boolean>(() => Boolean(store.isLoading))
  const optimizationResult = computed<OptimizationResult | null>(() => {
    return (store.currentOptimization as OptimizationResult | null) ?? null
  })

  const completedStageKeys = computed<Set<StageKey>>((): Set<StageKey> => {
    const stageList = optimizationResult.value?.stages ?? []
    return new Set(stageList.map(({ stage }) => stage))
  })

  const getStageStatus = (stageKey: StageKey): StepStatus => {
    const completed = completedStageKeys.value
    if (completed.has(stageKey)) {
      return 'finish'
    }

    if (isOptimizing.value) {
      const nextStage = stages.find(stage => !completed.has(stage.key))
      if (nextStage?.key === stageKey) {
        return 'process'
      }
    }

    return 'wait'
  }

  const handleOptimize = async (): Promise<void> => {
    if (!prompt.value.trim()) {
      showToastMessage('请输入提示词')
      return
    }

    try {
      await store.optimizePrompt(prompt.value.trim())
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : ''
      showToastMessage(`优化失败${message ? `：${message}` : ''}`)
    }
  }

  const copyOptimizedPrompt = async (): Promise<void> => {
    const optimized = optimizationResult.value?.optimized_prompt
    if (!optimized) {
      showToastMessage('暂无可复制的内容')
      return
    }

    try {
      if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(optimized)
    } else {
      // 兜底方案：创建隐藏 input
      const textArea = document.createElement("textarea")
      textArea.value = optimized
      document.body.appendChild(textArea)
      textArea.select()
      document.execCommand('copy')
      document.body.removeChild(textArea)
    }
      copySuccess.value = true
      showToastMessage('已成功复制到剪贴板！')
      
      // 清除之前的计时器
      if (copySuccessTimer) {
        clearTimeout(copySuccessTimer)
      }
      
      // 2秒后恢复按钮状态
      copySuccessTimer = window.setTimeout(() => {
        copySuccess.value = false
      }, 2000)
    } catch {
      showToastMessage('复制失败，请重试')
    }
  }

  const resetAll = (): void => {
    prompt.value = ''
    store.setOptimizationResult(null)
    copySuccess.value = false
    if (copySuccessTimer) {
      clearTimeout(copySuccessTimer)
      copySuccessTimer = null
    }
  }

  const showToastMessage = (message: string) => {
    toastMessage.value = message
    showToast.value = true
    setTimeout(() => {
      showToast.value = false
    }, 3000)
  }
</script>

<style scoped>
/* 全局容器设置 */
.chat-layout {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background-color: #ffffff;
  position: relative;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  color: #0f172a;
}

/* 1. 滚动区域 */
.chat-viewport {
  flex: 1;
  overflow-y: auto;
  scroll-behavior: smooth;
  padding: 0 1rem;
}

.chat-container {
  max-width: 800px;
  margin: 0 auto;
  padding-top: 2rem;
  display: flex;
  flex-direction: column;
}

.bottom-spacer {
  height: 160px;
  flex-shrink: 0;
}

/* 2. 欢迎界面 */
.welcome-screen {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 60vh;
  text-align: center;
}

.welcome-content .logo-icon {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #4f46e5, #7c3aed);
  color: white;
  font-weight: 600;
  font-size: 1.5rem;
  margin-bottom: 1.5rem;
}

.logo-icon .icon-text {
  font-size: 1.5rem;
}

.welcome-content h1 {
  font-size: 1.8rem;
  margin: 0 0 0.5rem 0;
  color: #1e293b;
}

.welcome-content p {
  color: #64748b;
  font-size: 1rem;
}

/* 3. 消息流布局 */
.message-stream {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.message-row {
  display: flex;
  gap: 1rem;
  align-items: flex-start;
}

.message-row.user-row {
  flex-direction: row-reverse;
}

.avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  font-size: 0.8rem;
  font-weight: 500;
}

.user-avatar {
  background-color: #f1f5f9;
  color: #475569;
}

.ai-avatar {
  background: linear-gradient(135deg, #4f46e5, #7c3aed);
  color: #fff;
}

.avatar-text {
  font-weight: 600;
}

.message-content {
  flex: 1;
  min-width: 0;
}

/* 用户气泡 */
.user-bubble {
  background-color: #f1f5f9;
  padding: 0.8rem 1.2rem;
  border-radius: 18px;
  border-top-right-radius: 4px;
  font-size: 1rem;
  line-height: 1.6;
  white-space: pre-wrap;
  color: #1e293b;
  max-width: 80%;
  word-break: break-word;
}

/* AI 内容区域 */
/* 进度条样式 */
.process-block {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  padding: 1rem;
  margin-bottom: 1rem;
  transition: all 0.3s ease;
}

.process-block.collapsed {
  padding: 0.5rem 1rem;
  background: transparent;
  border: none;
  margin-bottom: 0.5rem;
}

.process-block.collapsed .process-header {
  color: #10b981;
  font-size: 0.9rem;
}

.process-header {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: 600;
  color: #334155;
  margin-bottom: 0.5rem;
}

.process-block.collapsed .process-header {
  margin-bottom: 0;
}

.spinner-icon {
  width: 16px;
  height: 16px;
  border: 2px solid #4f46e5;
  border-top-color: transparent;
  border-radius: 50%;
  animation: rotate 1s linear infinite;
}

.check-icon {
  color: #10b981;
  font-weight: bold;
  font-size: 0.9rem;
}

@keyframes rotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.process-steps {
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  margin-top: 0.8rem;
}

.step-item {
  display: flex;
  align-items: center;
  gap: 0.4rem;
  font-size: 0.85rem;
  color: #94a3b8;
}

.step-item.process {
  color: #4f46e5;
  font-weight: 500;
}

.step-item.finish {
  color: #10b981;
}

.spinner-dot {
  width: 12px;
  height: 12px;
  border: 2px solid currentColor;
  border-right-color: transparent;
  border-radius: 50%;
  animation: rotate 1s linear infinite;
}

.wait-dot {
  width: 8px;
  height: 8px;
  background-color: #cbd5e1;
  border-radius: 50%;
}

/* 最终结果代码块 */
.result-block {
  animation: fadeIn 0.5s ease;
  background: #f8fafc;
  border-radius: 12px;
  padding: 1.5rem;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}

.result-content pre {
  margin: 0;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: 'SF Mono', Monaco, 'Cascadia Code', Consolas, monospace;
  font-size: 0.95rem;
  line-height: 1.7;
  color: #1e293b;
  background: transparent;
  padding: 0;
}

.result-actions {
  margin-top: 1rem;
  display: flex;
  gap: 0.75rem;
}

.action-btn {
  padding: 0.5rem 1rem;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  background: white;
  color: #64748b;
  cursor: pointer;
  font-size: 0.9rem;
  font-weight: 500;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  min-width: 100px;
  position: relative;
  overflow: hidden;
}

.action-btn::before {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: 5px;
  height: 5px;
  background: rgba(255, 255, 255, 0.5);
  opacity: 0;
  border-radius: 100%;
  transform: scale(1, 1) translate(-50%, -50%);
  transform-origin: 50% 50%;
}

.action-btn:focus:not(:active)::before {
  animation: ripple 1s ease-out;
}

@keyframes ripple {
  0% {
    transform: scale(0, 0);
    opacity: 0.5;
  }
  100% {
    transform: scale(20, 20);
    opacity: 0;
  }
}

.action-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.action-btn:active {
  transform: translateY(0);
  transition: transform 0.1s;
}

.action-btn.copy-btn {
  color: #4f46e5;
  border-color: rgba(79, 70, 229, 0.3);
  background: linear-gradient(to right, rgba(79, 70, 229, 0.05), rgba(79, 70, 229, 0.02));
}

.action-btn.copy-btn:hover {
  background: linear-gradient(to right, rgba(79, 70, 229, 0.1), rgba(79, 70, 229, 0.05));
  border-color: #4f46e5;
  box-shadow: 0 4px 12px rgba(79, 70, 229, 0.2);
}

.action-btn.copy-btn.copy-success {
  background: linear-gradient(to right, rgba(16, 185, 129, 0.1), rgba(16, 185, 129, 0.05));
  border-color: #10b981;
  color: #10b981;
  animation: success-pulse 0.6s ease;
}

@keyframes success-pulse {
  0% { transform: scale(1); }
  50% { transform: scale(1.05); }
  100% { transform: scale(1); }
}

.action-btn.copy-btn.copy-success .copy-icon {
  animation: checkmark-bounce 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
}

@keyframes checkmark-bounce {
  0% { transform: scale(0); opacity: 0; }
  50% { transform: scale(1.2); }
  70% { transform: scale(0.9); }
  100% { transform: scale(1); opacity: 1; }
}

.action-btn.reset-btn {
  color: #f59e0b;
  border-color: rgba(245, 158, 11, 0.3);
  background: linear-gradient(to right, rgba(245, 158, 11, 0.05), rgba(245, 158, 11, 0.02));
}

.action-btn.reset-btn:hover {
  background: linear-gradient(to right, rgba(245, 158, 11, 0.1), rgba(245, 158, 11, 0.05));
  border-color: #f59e0b;
  box-shadow: 0 4px 12px rgba(245, 158, 11, 0.2);
}

.action-btn.reset-btn:hover .reset-icon {
  animation: rotate-refresh 0.6s ease;
}

@keyframes rotate-refresh {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.action-btn:disabled {
  opacity: 0.7;
  cursor: not-allowed;
  transform: none;
  box-shadow: none;
}

.copy-icon,
.reset-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  transition: transform 0.3s ease;
}

.copy-icon.success {
  color: #10b981;
}

.btn-text {
  font-weight: 500;
  transition: all 0.3s ease;
}

.action-btn.copy-btn.copy-success .btn-text {
  font-weight: 600;
}

/* 4. 底部输入区域 */
.chat-input-area {
  position: sticky;
  bottom: 0;
  width: 100%;
  padding: 1rem 1rem 1.5rem;
  background: linear-gradient(to bottom, rgba(255,255,255,0) 0%, #ffffff 30%);
  display: flex;
  flex-direction: column;
  align-items: center;
  z-index: 10;
}

.input-wrapper {
  display: flex;
  align-items: flex-end;
  width: 100%;
  max-width: 800px;
  background: #ffffff;
  border-radius: 1.5rem;
  box-shadow: 0 0 15px rgba(0,0,0,0.05), 0 0 0 1px rgba(0,0,0,0.05);
  padding: 0.75rem;
  transition: box-shadow 0.2s;
  gap: 0.75rem;
}

.input-wrapper:focus-within {
  box-shadow: 0 0 15px rgba(0,0,0,0.08), 0 0 0 1px rgba(79, 70, 229, 0.4);
}

.chat-textarea {
  flex: 1;
  border: none;
  outline: none;
  background: transparent;
  padding: 0.5rem;
  font-size: 1rem;
  font-family: inherit;
  line-height: 1.5;
  resize: none;
  min-height: 24px;
  max-height: 200px;
  overflow-y: auto;
  color: #1e293b;
}

.chat-textarea::placeholder {
  color: #94a3b8;
}

.chat-textarea:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.input-actions {
  flex-shrink: 0;
}

.send-btn {
  padding: 0 1.5rem;
  height: 40px;
  border-radius: 10px;
  background: #4f46e5;
  color: white;
  border: none;
  cursor: pointer;
  font-size: 0.95rem;
  font-weight: 500;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s;
  min-width: 80px;
}

.send-btn:hover:not(:disabled) {
  background: #4338ca;
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(79, 70, 229, 0.2);
}

.send-btn:disabled {
  background: #cbd5e1;
  cursor: not-allowed;
  opacity: 0.6;
}

.send-text {
  font-weight: 500;
}

.footer-note {
  font-size: 0.75rem;
  color: #94a3b8;
  margin-top: 0.8rem;
  text-align: center;
}

/* Toast 样式 */
.custom-toast {
  position: fixed;
  bottom: 100px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(0, 0, 0, 0.85);
  color: white;
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  font-size: 0.9rem;
  font-weight: 500;
  z-index: 1000;
  animation: fadeInOut 3s ease;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
}

@keyframes fadeInOut {
  0%, 100% { opacity: 0; transform: translateX(-50%) translateY(10px); }
  10%, 90% { opacity: 1; transform: translateX(-50%) translateY(0); }
}

/* 响应式设计 */
@media (max-width: 640px) {
  .chat-viewport {
    padding: 0 0.5rem;
  }
  
  .message-row {
    gap: 0.5rem;
  }
  
  .avatar {
    width: 32px;
    height: 32px;
    font-size: 0.7rem;
  }
  
  .user-bubble {
    max-width: 85%;
    font-size: 0.95rem;
    padding: 0.6rem 1rem;
  }
  
  .chat-input-area {
    padding: 0.75rem 0.75rem 1rem;
  }
  
  .input-wrapper {
    border-radius: 1rem;
    padding: 0.6rem;
  }
  
  .chat-textarea {
    font-size: 0.95rem;
  }
  
  .send-btn {
    height: 36px;
    padding: 0 1rem;
    min-width: 60px;
  }
  
  .action-btn {
    padding: 0.4rem 0.8rem;
    min-width: 90px;
    font-size: 0.85rem;
    gap: 0.3rem;
  }
  
  .copy-icon,
  .reset-icon {
    width: 14px;
    height: 14px;
  }
}

@media (max-width: 768px) {
  .chat-container {
    padding-top: 1rem;
  }
  
  .welcome-content .logo-icon {
    width: 60px;
    height: 60px;
  }
  
  .logo-icon .icon-text {
    font-size: 1.2rem;
  }
  
  .welcome-content h1 {
    font-size: 1.5rem;
  }
}
</style>