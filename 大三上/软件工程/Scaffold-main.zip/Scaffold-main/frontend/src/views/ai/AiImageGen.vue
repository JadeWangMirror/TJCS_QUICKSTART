<template>
  <section class="chat-container">
    <!-- 侧边栏 - 对话信息 -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <div class="app-title">
          <span class="title-icon">◆</span>
          <div class="title-text">
            <div class="title-name">AI 图片生成</div>
            <div class="title-subtitle">Imagine & Create</div>
          </div>
        </div>
      </div>
      
      <div class="chat-history">
        <div class="history-title">对话统计</div>
        <div class="history-stats">
          <div class="stat-item">
            <span class="stat-label">消息数</span>
            <span class="stat-value">{{ currentChat.messages.length }}</span>
          </div>
          <div class="stat-item">
            <span class="stat-label">生成图片</span>
            <span class="stat-value">{{ totalImageCount }}</span>
          </div>
        </div>
        <div class="divider"></div>
        <div class="history-tips">
          <div class="tips-title">使用提示</div>
          <ul class="tips-list">
            <li>输入详细的提示词效果更好</li>
            <li>支持中英文混合提示</li>
            <li>生成过程需要10-30秒</li>
            <li>可点击图片进行下载</li>
          </ul>
        </div>
      </div>
    </aside>

    <!-- 主聊天区域 -->
    <main class="chat-main">
      <!-- 聊天消息区域 -->
      <div class="chat-messages" ref="messagesContainer">
        <!-- 空状态 -->
        <div v-if="currentChat.messages.length === 0" class="empty-state">
          <div class="empty-content">
            <h2>AI 图片生成助手</h2>
            <p>输入您的想象，让AI帮您创作</p>
            
            <div class="preset-prompts-grid">
              <h4>快速开始：</h4>
              <div class="preset-buttons">
                <button
                  v-for="preset in presetPrompts"
                  :key="preset.id"
                  @click="usePresetPrompt(preset)"
                  class="preset-btn"
                >
                  {{ preset.name }}
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- 消息列表 -->
        <div v-else class="messages-list">
          <div
            v-for="(message, index) in currentChat.messages"
            :key="index"
            :class="['message', message.role]"
          >
            <div v-if="message.role !== 'user'" class="message-avatar" :class="message.role">
              <span class="avatar-icon">AI</span>
            </div>
            <div class="message-content">
              <div v-if="message.role === 'user'" class="user-message-text">
                {{ message.text }}
              </div>
              <div v-else class="assistant-message">
                <p v-if="message.loading" class="loading-text">
                  <span class="spinner-small"></span>
                  AI正在创作中，请稍候...
                </p>
                <p v-else-if="message.error" class="error-text">
                  {{ message.error }}
                </p>
                <div v-else-if="message.images && message.images.length > 0" class="message-images">
                  <div
                    v-for="(image, imgIndex) in message.images"
                    :key="imgIndex"
                    class="image-card"
                  >
                    <img :src="image.url" :alt="image.filename" class="message-image" />
                    <div class="image-actions">
                      <a 
                        :href="image.url" 
                        :download="image.filename"
                        class="action-btn download-btn"
                        target="_blank"
                        title="下载"
                      >
                        <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                          <polyline points="7 10 12 15 17 10"></polyline>
                          <line x1="12" y1="15" x2="12" y2="3"></line>
                        </svg>
                      </a>
<!--                      <button-->
<!--                        @click="removeMessageImage(index, imgIndex)"-->
<!--                        class="action-btn remove-btn"-->
<!--                        title="删除"-->
<!--                      >-->
<!--                        <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">-->
<!--                          <line x1="18" y1="6" x2="6" y2="18"></line>-->
<!--                          <line x1="6" y1="6" x2="18" y2="18"></line>-->
<!--                        </svg>-->
<!--                      </button>-->
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div v-if="message.role === 'user'" class="message-avatar" :class="message.role">
              <span  class="avatar-icon">U</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 错误信息 -->
      <div v-if="error" class="error-banner">
        <p>{{ error }}</p>
        <button @click="error = ''" class="close-error">
          <svg class="close-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>

      <!-- 输入框区域 -->
      <div class="chat-input-area">
        <div class="input-wrapper">
          <textarea
            v-model="userPrompt"
            @keydown.enter.ctrl="sendMessage"
            @keydown.enter.meta="sendMessage"
            @input="autoResizeTextarea"
            placeholder="输入提示词... (Ctrl+Enter 发送)"
            class="chat-input"
            ref="textareaRef"
            maxlength="1000"
          ></textarea>
          <div class="input-controls">
            <span class="char-count">{{ userPrompt.length }}/1000</span>
            <button 
              @click="sendMessage" 
              :disabled="loading || !userPrompt.trim()"
              class="send-btn"
              :title="loading ? '生成中...' : '发送'"
            >
              <svg class="send-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="12 19 19 12 12 5"></polyline>
                <line x1="19" y1="12" x2="5" y2="12"></line>
              </svg>
            </button>
          </div>
        </div>
      </div>
    </main>
  </section>
</template>

<script setup>
import { ref, computed, watch, nextTick } from 'vue'
import { httpClient } from '@/utils/httpClients'
import { useAuthStore } from "@/store/modules/auth"

// 响应式数据
const userPrompt = ref('')
const loading = ref(false)
const error = ref('')
const textareaRef = ref(null)
const messagesContainer = ref(null)

// 对话数据结构
const chatHistory = ref([])
const currentChatIndex = ref(0)

// 预设提示词
const presetPrompts = ref([
  {
    id: 1,
    name: '古典对联',
    prompt: '一副典雅庄重的对联悬挂于厅堂之中，房间是个安静古典的中式布置，桌子上放着一些青花瓷，对联上左书"义本生知人机同道善思新"，右书"通云赋智乾坤启数高志远"，横批"智启通义"，字体飘逸，中间挂在一着一副中国风的画作，内容是岳阳楼。'
  },
  {
    id: 2,
    name: '山水风景',
    prompt: '一幅中国传统水墨山水画，远山如黛，近水含烟，云雾缭绕，松柏挺立，小桥流水人家，意境深远，墨色浓淡相宜。'
  },
  {
    id: 3,
    name: '现代城市',
    prompt: '未来主义城市景观，高楼林立，飞行汽车穿梭，霓虹灯光璀璨，充满科技感的建筑设计，夜晚的城市天际线。'
  },
  {
    id: 4,
    name: '可爱动物',
    prompt: '一只可爱的卡通风格熊猫在竹林中玩耍，阳光透过竹叶洒下斑驳光影，熊猫表情憨态可掬，背景虚化，色彩明亮温暖。'
  }
])

// 计算当前对话
const currentChat = computed(() => {
  if (chatHistory.value.length === 0) {
    chatHistory.value.push({
      title: `对话 1`,
      messages: []
    })
  }
  return chatHistory.value[currentChatIndex.value]
})

// 计算生成的图片总数
const totalImageCount = computed(() => {
  return currentChat.value.messages.reduce((total, msg) => {
    if (msg.images && msg.images.length > 0) {
      return total + msg.images.length
    }
    return total
  }, 0)
})

// 获取用户ID
const getUserId = () => {
  const authStore = useAuthStore()
  const user_id = authStore.currentUser?.id
  if (!user_id) {
    throw new Error("用户未认证，请先登录")
  }
  return user_id
}

// 自动调整文本框高度
const autoResizeTextarea = () => {
  if (textareaRef.value) {
    textareaRef.value.style.height = 'auto'
    textareaRef.value.style.height = textareaRef.value.scrollHeight + 'px'
  }
}

// 滚动到底部
const scrollToBottom = () => {
  nextTick(() => {
    if (messagesContainer.value) {
      messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
    }
  })
}

// 发送消息
const sendMessage = async () => {
  if (!userPrompt.value.trim()) {
    error.value = '请输入提示词'
    return
  }

  const prompt = userPrompt.value.trim()
  
  // 添加用户消息
  currentChat.value.messages.push({
    role: 'user',
    text: prompt
  })
  
  // 添加AI加载消息
  const aiMessageData = {
    role: 'assistant',
    loading: true,
    error: null,
    images: []
  }
  currentChat.value.messages.push(aiMessageData)
  const aiMessage = currentChat.value.messages[currentChat.value.messages.length - 1]

  userPrompt.value = ''
  loading.value = true
  error.value = ''
  
  scrollToBottom()

  try {
    const user_id = getUserId()
    
    const data = await httpClient('/api/generate_image', {
      method: 'POST',
      body: {
        prompt: prompt,
        user_id: user_id,
        size: '1328x1328',
        n: 1,
        model: 'qwen-image-plus'
      }
    })
    
    if (data.status === 'success') {
      const imageData = data.data
      const images = []
      
      // 解析图片数据
      if (imageData.image_urls && Array.isArray(imageData.image_urls)) {
        images.push(...imageData.image_urls.map((item, index) => ({
          url: item.image_url,
          filename: item.file_name || `generated_image_${Date.now()}_${index + 1}.png`
        })))
      } else if (imageData.output && Array.isArray(imageData.output)) {
        images.push(...imageData.output.map((item, index) => ({
          url: item.image_url,
          filename: item.file_name || `generated_image_${Date.now()}_${index + 1}.png`
        })))
      } else if (Array.isArray(imageData)) {
        images.push(...imageData.map((item, index) => ({
          url: item.image_url,
          filename: item.file_name || `generated_image_${Date.now()}_${index + 1}.png`
        })))
      } else if (imageData.image_url) {
        images.push({
          url: imageData.image_url,
          filename: imageData.file_name || `generated_image_${Date.now()}_1.png`
        })
      }
      
      if (images.length === 0) {
        aiMessage.loading = false
        aiMessage.error = '未能解析出图片URL，请检查API响应结构'
      } else {
        aiMessage.loading = false
        aiMessage.images = images
      }
    } else {
      aiMessage.loading = false
      aiMessage.error = data.error || '图片生成失败'
    }
  } catch (err) {
    console.error('生成图片时出错:', err)
    aiMessage.loading = false
    aiMessage.error = err.message || '生成图片时发生错误，请稍后重试'
  } finally {
    loading.value = false
    if (textareaRef.value) {
      textareaRef.value.style.height = 'auto'
    }
    scrollToBottom()
  }
}

// 使用预设提示词
const usePresetPrompt = (preset) => {
  userPrompt.value = preset.prompt
  nextTick(() => {
    autoResizeTextarea()
    textareaRef.value?.focus()
  })
}

// 删除消息中的图片
const removeMessageImage = (messageIndex, imageIndex) => {
  currentChat.value.messages[messageIndex].images.splice(imageIndex, 1)
}

// 切换对话
const switchChat = (index) => {
  currentChatIndex.value = index
  userPrompt.value = ''
  error.value = ''
  scrollToBottom()
}
</script>

<style scoped>
* {
  box-sizing: border-box;
}

.chat-container {
  display: flex;
  height: 100vh;
  background: #fff;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', sans-serif;
}

/* ============ 侧边栏 ============ */
.sidebar {
  width: 260px;
  background: #f7f7f7;
  border-right: 1px solid #e5e5e5;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.sidebar-header {
  padding: 20px;
  border-bottom: 1px solid #e5e5e5;
}

.app-title {
  display: flex;
  align-items: center;
  gap: 12px;
}

.title-icon {
  font-size: 20px;
  color: #3b82f6;
  font-weight: bold;
}

.title-text {
  flex: 1;
}

.title-name {
  font-size: 15px;
  font-weight: 600;
  color: #1f2937;
  line-height: 1.2;
}

.title-subtitle {
  font-size: 11px;
  color: #999;
  margin-top: 2px;
  letter-spacing: 0.5px;
}

.chat-history {
  flex: 1;
  overflow-y: auto;
  padding: 15px 10px;
}

.history-title {
  font-size: 12px;
  color: #999;
  font-weight: 600;
  text-transform: uppercase;
  padding: 0 10px 12px;
  letter-spacing: 0.5px;
}

.history-stats {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  padding: 0 10px 15px;
}

.stat-item {
  background: #f5f5f5;
  padding: 12px;
  border-radius: 8px;
  text-align: center;
}

.stat-label {
  display: block;
  font-size: 11px;
  color: #999;
  margin-bottom: 6px;
  font-weight: 500;
}

.stat-value {
  display: block;
  font-size: 18px;
  font-weight: 700;
  color: #3b82f6;
}

.divider {
  height: 1px;
  background: #e5e5e5;
  margin: 12px 0;
}

.history-tips {
  padding: 12px 10px;
}

.tips-title {
  font-size: 11px;
  color: #999;
  font-weight: 600;
  text-transform: uppercase;
  margin-bottom: 10px;
  letter-spacing: 0.5px;
}

.tips-list {
  list-style: none;
  margin: 0;
  padding: 0;
}

.tips-list li {
  font-size: 12px;
  color: #666;
  margin-bottom: 8px;
  padding-left: 16px;
  position: relative;
  line-height: 1.4;
}

.tips-list li:before {
  content: '•';
  position: absolute;
  left: 6px;
  color: #3b82f6;
  font-weight: bold;
}

/* ============ 主聊天区域 ============ */
.chat-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  background: #fff;
}

.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 20px 40px;
  display: flex;
  flex-direction: column;
}

.empty-state {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
}

.empty-content {
  text-align: center;
  color: #999;
}

.empty-content h2 {
  font-size: 28px;
  color: #333;
  margin: 0 0 10px 0;
}

.empty-content p {
  font-size: 14px;
  color: #999;
  margin: 0 0 30px 0;
}

.preset-prompts-grid {
  margin-top: 30px;
}

.preset-prompts-grid h4 {
  font-size: 12px;
  color: #999;
  font-weight: 600;
  text-transform: uppercase;
  margin: 0 0 15px 0;
}

.preset-buttons {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
  justify-content: center;
}

.preset-btn {
  padding: 10px 18px;
  border: 1px solid #d0d0d0;
  background: #fff;
  color: #333;
  border-radius: 20px;
  cursor: pointer;
  font-size: 13px;
  transition: all 0.3s ease;
  font-weight: 500;
}

.preset-btn:hover {
  border-color: #3b82f6;
  color: #3b82f6;
  background: #f0f7ff;
  box-shadow: 0 2px 8px rgba(59, 130, 246, 0.1);
}

.messages-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.message {
  display: flex;
  gap: 12px;
  animation: slideUp 0.3s ease-out;
}

@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.message.user {
  justify-content: flex-end;
}

.message.assistant {
  justify-content: flex-start;
}

.message-avatar {
  font-size: 24px;
  flex-shrink: 0;
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  font-weight: 600;
}

.message-avatar.user {
  background: #e7f1ff;
  border: 2px solid #3b82f6;
}

.message-avatar.assistant {
  background: #f0f0f0;
  border: 2px solid #d0d0d0;
}

.avatar-icon {
  font-size: 12px;
  font-weight: 700;
  color: inherit;
}

.message-avatar.user .avatar-icon {
  color: #3b82f6;
}

.message-avatar.assistant .avatar-icon {
  color: #666;
}

.message-content {
  max-width: 70%;
  word-wrap: break-word;
}

.message.user .message-content {
  max-width: 80%;
}

.user-message-text {
  background: #3b82f6;
  color: white;
  padding: 12px 16px;
  border-radius: 16px;
  border-bottom-right-radius: 4px;
  font-size: 14px;
  line-height: 1.5;
}

.assistant-message {
  background: transparent;
}

.loading-text {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: #666;
  margin: 0;
}

.spinner-small {
  display: inline-block;
  width: 16px;
  height: 16px;
  border: 2px solid #e5e5e5;
  border-top-color: #3b82f6;
  border-right-color: #3b82f6;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.error-text {
  color: #e74c3c;
  font-size: 14px;
  margin: 0;
  padding: 12px 16px;
  background: #fcf0ef;
  border-radius: 8px;
}

.message-images {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}

.image-card {
  position: relative;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  background: #f5f5f5;
  max-width: 300px;
}

.message-image {
  width: 100%;
  height: auto;
  display: block;
  transition: transform 0.3s ease;
}

.image-card:hover .message-image {
  transform: scale(1.02);
}

.image-actions {
  position: absolute;
  top: 8px;
  right: 8px;
  display: flex;
  gap: 8px;
  opacity: 0;
  transition: opacity 0.2s ease;
}

.image-card:hover .image-actions {
  opacity: 1;
}

.action-btn {
  width: 32px;
  height: 32px;
  border-radius: 6px;
  border: none;
  background: rgba(0, 0, 0, 0.6);
  color: white;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  transition: all 0.2s ease;
  text-decoration: none;
  padding: 0;
}

.action-btn:hover {
  background: rgba(0, 0, 0, 0.8);
  transform: scale(1.1);
}

.action-btn.download-btn {
  background: rgba(59, 130, 246, 0.7);
}

.action-btn.download-btn:hover {
  background: rgba(59, 130, 246, 0.9);
}

.action-btn.remove-btn {
  background: rgba(239, 68, 68, 0.7);
}

.action-btn.remove-btn:hover {
  background: rgba(239, 68, 68, 0.9);
}

.btn-icon {
  width: 16px;
  height: 16px;
  stroke-linecap: round;
  stroke-linejoin: round;
}

/* ============ 错误信息 ============ */
.error-banner {
  background: #fcf0ef;
  border-top: 1px solid #f5c6cb;
  padding: 12px 40px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: #e74c3c;
  font-size: 13px;
}

.error-banner p {
  margin: 0;
  flex: 1;
}

.close-error {
  background: none;
  border: none;
  color: #e74c3c;
  cursor: pointer;
  font-size: 18px;
  opacity: 0.6;
  transition: opacity 0.2s ease;
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  flex-shrink: 0;
}

.close-error:hover {
  opacity: 1;
}

.close-icon {
  width: 16px;
  height: 16px;
  stroke-linecap: round;
  stroke-linejoin: round;
}

/* ============ 输入框区域 ============ */
.chat-input-area {
  border-top: 1px solid #e5e5e5;
  padding: 16px 40px;
  background: #fff;
}

.input-wrapper {
  display: flex;
  flex-direction: column;
  gap: 10px;
  max-width: 100%;
  margin: 0 auto;
}

.chat-input {
  width: 100%;
  max-height: 200px;
  padding: 12px 16px;
  border: 1px solid #e5e5e5;
  border-radius: 8px;
  font-size: 14px;
  font-family: inherit;
  resize: none;
  transition: all 0.2s ease;
  line-height: 1.4;
  min-height: 44px;
}

.chat-input:hover {
  border-color: #d0d0d0;
}

.chat-input:focus {
  outline: none;
  border-color: #3b82f6;
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

.input-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 12px;
  color: #999;
}

.input-controls {
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  gap: 12px;
  font-size: 12px;
  color: #999;
}

.char-count {
  color: #999;
  white-space: nowrap;
}

.send-btn {
  width: 36px;
  height: 36px;
  padding: 0;
  background: #3b82f6;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s ease;
  flex-shrink: 0;
}

.send-btn:hover:not(:disabled) {
  background: #2563eb;
  box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
  transform: translateY(-2px);
}

.send-btn:active:not(:disabled) {
  transform: translateY(0);
}

.send-btn:disabled {
  background: #cbd5e1;
  cursor: not-allowed;
  opacity: 0.6;
}

.send-icon {
  width: 18px;
  height: 18px;
  stroke-linecap: round;
  stroke-linejoin: round;
}

/* ============ 滚动条美化 ============ */
.chat-messages::-webkit-scrollbar,
.chat-history::-webkit-scrollbar {
  width: 8px;
}

.chat-messages::-webkit-scrollbar-track,
.chat-history::-webkit-scrollbar-track {
  background: transparent;
}

.chat-messages::-webkit-scrollbar-thumb,
.chat-history::-webkit-scrollbar-thumb {
  background: #e5e5e5;
  border-radius: 4px;
}

.chat-messages::-webkit-scrollbar-thumb:hover,
.chat-history::-webkit-scrollbar-thumb:hover {
  background: #d0d0d0;
}

/* ============ 响应式设计 ============ */
@media (max-width: 768px) {
  .chat-container {
    flex-direction: column;
  }

  .sidebar {
    width: 100%;
    height: 200px;
    border-right: none;
    border-bottom: 1px solid #e5e5e5;
    display: flex;
    flex-direction: row;
  }

  .sidebar-header {
    padding: 15px;
    border-bottom: none;
    border-right: 1px solid #e5e5e5;
    min-width: 140px;
  }

  .chat-history {
    flex-direction: row;
    gap: 10px;
    padding: 15px;
    overflow-x: auto;
    overflow-y: hidden;
  }

  .history-item {
    white-space: nowrap;
    flex-shrink: 0;
  }

  .chat-messages {
    padding: 16px 20px;
  }

  .message-content {
    max-width: 90% !important;
  }

  .chat-input-area {
    padding: 12px 20px;
  }

  .input-wrapper {
    gap: 8px;
  }

  .chat-input {
    font-size: 16px;
  }

  .preset-buttons {
    justify-content: flex-start;
  }

  .empty-content {
    padding: 0 20px;
  }

  .empty-content h2 {
    font-size: 24px;
  }
}
</style>