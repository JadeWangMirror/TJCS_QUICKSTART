<template>
  <section class="history">
    <div
      v-if="toast"
      class="history__toast"
      :class="`history__toast--${toast?.type ?? 'info'}`"
    >
      {{ toast.message }}
    </div>

    <header class="history__header">
      <div class="history__heading">
        <div class="history__heading-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 8V12L15 15M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <div>
          <h1>提示词优化历史</h1>
          <p>回顾每一次优化任务，快速定位原始输入与多阶段产出细节。</p>
        </div>
      </div>
      <div class="history__actions">
        <span v-if="hasHistory" class="history__counter">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 4px;">
            <path d="M4 19.5V4.5C4 3.67157 4.67157 3 5.5 3H18.5C19.3284 3 20 3.67157 20 4.5V19.5C20 20.3284 19.3284 21 18.5 21H5.5C4.67157 21 4 20.3284 4 19.5Z" stroke="currentColor" stroke-width="1.5"/>
            <path d="M8 7H16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <path d="M8 11H16" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <path d="M8 15H12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
          {{ totalRecords }} 条记录
        </span>
        <button type="button" class="history__button history__button--ghost" @click="goToWorkbench">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 4px;">
            <path d="M19 12H5M5 12L12 19M5 12L12 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          返回优化工作台
        </button>
      </div>
    </header>

    <div :class="['history__layout', { 'history__layout--with-summary': hasHistory }]">
      <aside v-if="hasHistory" class="history__summary">
        <div class="history__summary-card">
          <div class="history__summary-header">
            <h2>关键指标</h2>
            <p>快速了解近期优化表现</p>
          </div>
          <div class="history__summary-grid">
            <div v-for="item in summaryCards" :key="item.key" class="history__summary-item">
              <span class="history__summary-icon" aria-hidden="true">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path :d="item.icon" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </span>
              <div>
                <p class="history__summary-value">{{ item.value }}</p>
                <p class="history__summary-label">{{ item.label }}</p>
                <p v-if="item.hint" class="history__summary-hint">{{ item.hint }}</p>
              </div>
            </div>
          </div>
        </div>

        <div class="history__snapshot">
          <div class="history__snapshot-header">
            <div>
              <span class="history__snapshot-title">最近一次优化</span>
              <p class="history__snapshot-time">{{ lastOptimizedAt }}</p>
            </div>
            <button
              type="button"
              class="history__button history__button--link"
              :disabled="!latestRecord"
              @click="latestRecord && showDetail(latestRecord.id)"
            >
              查看详情
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-left: 4px;">
                <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </button>
          </div>

          <div v-if="latestRecord" class="history__snapshot-content">
            <span class="history__snapshot-label">原始</span>
            <p class="history__snapshot-text">{{ truncateText(latestRecord.original_prompt) }}</p>
            <span class="history__snapshot-label">优化</span>
            <p class="history__snapshot-text history__snapshot-text--highlight">
              {{ truncateText(latestRecord.optimized_prompt) }}
            </p>
            <span class="history__snapshot-meta">阶段：{{ latestStageSummary }}</span>
          </div>
          <div v-else class="history__snapshot-empty">暂无记录</div>
        </div>
      </aside>

      <div class="history__card">
        <div v-if="hasHistory || loading" class="history__table-wrapper">
          <div class="history__table-header">
            <h2>历史记录</h2>
            <p>所有提示词优化的时间线</p>
          </div>

          <div class="history__table-scroll">
            <table class="history__table">
              <thead>
                <tr>
                  <th>时间</th>
                  <th>原始提示词</th>
                  <th>优化后提示词</th>
                  <th class="history__table-actions">操作</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="row in paginatedHistory" :key="row.id">
                  <td>
                    <div class="history__time">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 6px;">
                        <path d="M12 8V12L15 15M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                      <span>{{ formatDate(row.timestamp) }}</span>
                    </div>
                  </td>
                  <td>
                    <div class="history__prompt history__prompt--original">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 6px;">
                        <path d="M9 12H15M9 16H15M17 21H7C5.89543 21 5 20.1046 5 19V5C5 3.89543 5.89543 3 7 3H12.5858C12.851 3 13.1054 3.10536 13.2929 3.29289L18.7071 8.70711C18.8946 8.89464 19 9.149 19 9.41421V19C19 20.1046 18.1046 21 17 21Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                      </svg>
                      <span class="history__prompt-text">{{ row.original_preview }}</span>
                    </div>
                  </td>
                  <td>
                    <div class="history__prompt history__prompt--optimized">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 6px;">
                        <path d="M9 12.75L11.25 15L15 9.75M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                      <span class="history__prompt-text">{{ row.optimized_preview }}</span>
                    </div>
                  </td>
                  <td class="history__table-actions">
                    <button type="button" class="history__button history__button--link" @click="showDetail(row.id)">
                      查看详情
                    </button>
                  </td>
                </tr>
                <tr v-if="!paginatedHistory.length">
                  <td colspan="4" class="history__table-empty">{{ loading ? '正在加载...' : '暂无数据' }}</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div class="history__pagination" v-if="hasHistory">
            <div class="history__pagination-info">
              共 {{ totalRecords }} 条 · 第 {{ currentPage }} / {{ totalPages }} 页
            </div>
            <div class="history__pagination-controls">
              <button
                type="button"
                class="history__button history__button--ghost"
                :disabled="currentPage === 1"
                @click="handleCurrentChange(currentPage - 1)"
              >
                上一页
              </button>
              <button
                type="button"
                class="history__button history__button--ghost"
                :disabled="currentPage === totalPages"
                @click="handleCurrentChange(currentPage + 1)"
              >
                下一页
              </button>
              <label class="history__pagination-size">
                每页
                <select :value="pageSize" @change="handleSizeChange(($event.target as HTMLSelectElement).value)">
                  <option v-for="size in pageSizeOptions" :key="size" :value="size">
                    {{ size }}
                  </option>
                </select>
              </label>
            </div>
          </div>
        </div>

        <div v-else class="history__empty">
          <p class="history__empty-title">暂无优化记录</p>
          <p class="history__empty-desc">开始优化您的第一个提示词吧。</p>
          <button type="button" class="history__button" @click="goToWorkbench">
            立即前往
          </button>
        </div>
      </div>
    </div>
  </section>

  <!-- 详情弹窗 -->
  <div v-if="detailVisible" class="history-detail__overlay" @click.self="detailVisible = false">
    <div class="history-detail__panel" role="dialog" aria-modal="true" aria-labelledby="historyDetailTitle">
      <header class="history-detail__header">
        <div>
          <h2 id="historyDetailTitle">优化详情</h2>
          <p class="history-detail__subtitle">完成时间：{{ currentDetailTime }}</p>
        </div>
        <button type="button" class="history__button history__button--ghost" @click="detailVisible = false">
          关闭
        </button>
      </header>

      <div v-if="detailLoading" class="history-detail__skeleton">
        <div v-for="n in 8" :key="n" class="history-detail__skeleton-line"></div>
      </div>

      <div v-else-if="currentDetail" class="history-detail__content">
        <div class="history-detail__stats-grid">
          <article class="history-detail__stat-card">
            <div class="history-detail__stat">
              <span class="history-detail__stat-icon history-detail__stat-icon--original" aria-hidden="true">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 12H15M9 16H15M17 21H7C5.89543 21 5 20.1046 5 19V5C5 3.89543 5.89543 3 7 3H12.5858C12.851 3 13.1054 3.10536 13.2929 3.29289L18.7071 8.70711C18.8946 8.89464 19 9.149 19 9.41421V19C19 20.1046 18.1046 21 17 21Z" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
              </span>
              <div>
                <p class="history-detail__stat-value">{{ currentDetail.original_prompt?.length || 0 }}</p>
                <p class="history-detail__stat-label">原始长度</p>
              </div>
            </div>
          </article>
          <article class="history-detail__stat-card">
            <div class="history-detail__stat">
              <span class="history-detail__stat-icon history-detail__stat-icon--optimized" aria-hidden="true">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 12.75L11.25 15L15 9.75M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </span>
              <div>
                <p class="history-detail__stat-value">{{ currentDetail.optimized_prompt?.length || 0 }}</p>
                <p class="history-detail__stat-label">优化长度</p>
              </div>
            </div>
          </article>
          <article class="history-detail__stat-card">
            <div class="history-detail__stat">
              <span
                class="history-detail__stat-icon"
                :class="`history-detail__stat-icon--${getLengthChangeClass()}`"
                aria-hidden="true"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M7 10L12 15L17 10M12 3V15" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </span>
              <div>
                <p
                  class="history-detail__stat-value"
                  :class="`history-detail__stat-value--${getLengthChangeClass()}`"
                >
                  {{ calculateLengthChange() }}
                </p>
                <p class="history-detail__stat-label">长度变化</p>
              </div>
            </div>
          </article>
          <article class="history-detail__stat-card">
            <div class="history-detail__stat">
              <span class="history-detail__stat-icon history-detail__stat-icon--stages" aria-hidden="true">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M13 10V3L4 14H11V21L20 10H13Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </span>
              <div>
                <p class="history-detail__stat-value">{{ currentDetail.workflow_history?.length || 0 }}</p>
                <p class="history-detail__stat-label">优化阶段</p>
              </div>
            </div>
          </article>
        </div>

        <div class="history-detail__prompts">
          <article class="history-detail__prompt-card">
            <div class="history-detail__prompt-header">
              <div>
                <span class="history-detail__prompt-title">原始提示词</span>
                <span class="history-detail__tag history-detail__tag--warning">原始版本</span>
              </div>
            </div>
            <div class="history-detail__prompt-body">
              <pre>{{ currentDetail.original_prompt }}</pre>
            </div>
            <footer class="history-detail__prompt-footer">
              <button
                type="button"
                class="history__button history__button--ghost"
                @click="copyText(currentDetail.original_prompt)"
              >
                复制原文
              </button>
              <span class="history-detail__char-count">
                {{ currentDetail.original_prompt?.length || 0 }} 字符
              </span>
            </footer>
          </article>

          <article class="history-detail__prompt-card">
            <div class="history-detail__prompt-header">
              <div>
                <span class="history-detail__prompt-title">优化后提示词</span>
                <span class="history-detail__tag history-detail__tag--info">
                  {{ viewMode === 'rendered' ? '渲染视图' : '源代码视图' }}
                </span>
                <span class="history-detail__tag">优化版本</span>
              </div>
            </div>
            <div v-if="viewMode === 'rendered'" class="history-detail__prompt-body markdown-body">
              <div v-if="!markdownError" v-html="renderedMarkdown"></div>
              <div v-else class="history-detail__error">
                <p>Markdown 渲染失败，以下为原始内容：</p>
                <pre>{{ currentDetail.optimized_prompt }}</pre>
              </div>
            </div>
            <div v-else class="history-detail__prompt-body history-detail__prompt-body--source">
              <pre>{{ currentDetail.optimized_prompt }}</pre>
            </div>
            <footer class="history-detail__prompt-footer">
              <button
                type="button"
                class="history__button"
                @click="copyText(currentDetail.optimized_prompt)"
              >
                复制优化文本
              </button>
              <button
                type="button"
                class="history__button history__button--ghost"
                @click="toggleViewMode"
              >
                {{ viewMode === 'rendered' ? '查看源代码' : '查看渲染' }}
              </button>
              <span class="history-detail__char-count">
                {{ currentDetail.optimized_prompt?.length || 0 }} 字符
              </span>
            </footer>
          </article>
        </div>

        <section class="history-detail__workflow">
          <div class="history-detail__workflow-header">
            <div>
              <span class="history-detail__prompt-title">优化过程</span>
              <span class="history-detail__tag history-detail__tag--info">工作流记录</span>
            </div>
          </div>
          <div class="history-detail__timeline">
            <article
              v-for="(stage, index) in currentDetail.workflow_history"
              :key="index"
              class="history-detail__stage-card"
              :class="`history-detail__stage-card--${getTimelineType(stage.role)}`"
            >
              <header class="history-detail__stage-header">
                <div class="history-detail__stage-title">
                  <span
                    class="history-detail__stage-icon"
                    :class="`history-detail__stage-icon--${getTimelineType(stage.role)}`"
                    aria-hidden="true"
                  >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path :d="getStageIcon(stage.role)" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                  </span>
                  <strong>{{ stage.role_name || stage.role }}</strong>
                  <span class="history-detail__tag" :class="`history-detail__tag--${getTimelineType(stage.role)}`">
                    {{ getStageTypeText(stage.role) }}
                  </span>
                </div>
                <div class="history-detail__stage-meta">
                  <span class="history-detail__stage-time">{{ formatDate(stage.timestamp) }}</span>
                  <button
                    v-if="stage.role !== 'original'"
                    type="button"
                    class="history__button history__button--ghost history-detail__collapse"
                    @click="toggleStageCollapse(index)"
                  >
                    {{ stageCollapseStates[index] ? '展开' : '折叠' }}
                  </button>
                </div>
              </header>
              <div class="history-detail__stage-content">
                <div v-if="stage.role === 'original'" class="history-detail__stage-output">
                  <pre>{{ stage.output }}</pre>
                </div>
                <div v-else>
                  <div v-show="!stageCollapseStates[index]" class="history-detail__stage-output markdown-body">
                    <div v-html="renderStageMarkdown(stage.output)"></div>
                  </div>
                  <div v-if="stageCollapseStates[index]" class="history-detail__stage-hint">
                    内容已折叠，点击展开查看详情
                  </div>
                </div>
                <div
                  v-if="stage.output && (!stageCollapseStates[index] || stage.role === 'original')"
                  class="history-detail__stage-actions"
                >
                  <button
                    type="button"
                    class="history__button history__button--ghost"
                    @click="copyText(stage.output)"
                  >
                    复制内容
                  </button>
                  <span class="history-detail__char-count">
                    {{ stage.output?.length || 0 }} 字符
                  </span>
                </div>
              </div>
            </article>
          </div>
        </section>
      </div>

      <footer class="history-detail__footer">
        <button type="button" class="history__button history__button--ghost" @click="detailVisible = false">
          关闭
        </button>
        <div class="history-detail__footer-actions">
          <button
            v-if="currentDetail"
            type="button"
            class="history__button history__button--ghost"
            @click="exportRecord"
          >
            导出记录
          </button>
          <button
            v-if="currentDetail"
            type="button"
            class="history__button"
            @click="showPublishDialog = true"
          >
            一键发布帖子
          </button>
        </div>
      </footer>
    </div>
  </div>

  <!-- 发布确认对话框 -->
  <div v-if="showPublishDialog" class="history-detail__overlay" @click.self="showPublishDialog = false">
    <div class="history-detail__panel history-detail__publish-panel" role="dialog" aria-modal="true">
      <header class="history-detail__header">
        <h2>发布帖子</h2>
        <button type="button" class="history__button history__button--ghost" @click="showPublishDialog = false">
          关闭
        </button>
      </header>

      <div class="history-detail__publish-content">
        <div class="history-detail__publish-field">
          <label for="postTitle" class="history-detail__publish-label">标题</label>
          <input
            id="postTitle"
            v-model="postTitle"
            type="text"
            class="history-detail__publish-input"
            placeholder="请输入帖子标题"
            maxlength="100"
          />
          <span class="history-detail__char-count">{{ postTitle.length }}/100</span>
        </div>

        <div class="history-detail__publish-field">
          <label class="history-detail__publish-label">标签</label>
          <div class="history-detail__tags">
            <span
              v-for="tag in availableTags"
              :key="tag"
              class="history-detail__tag"
              :class="{ 'history-detail__tag--selected': selectedTags.includes(tag) }"
              @click="toggleTag(tag)"
            >
              {{ tag }}
            </span>
          </div>
        </div>

        <div class="history-detail__publish-preview">
          <h4>预览</h4>
          <div class="history-detail__preview-content markdown-body" v-html="renderedMarkdown"></div>
        </div>
      </div>

      <footer class="history-detail__footer">
        <button type="button" class="history__button history__button--ghost" @click="showPublishDialog = false">
          取消
        </button>
        <button
          type="button"
          class="history__button"
          @click="confirmPublish"
          :disabled="publishing || !postTitle.trim()"
        >
          <span v-if="publishing">发布中...</span>
          <span v-else>确认发布</span>
        </button>
      </footer>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { computed, onMounted, onUnmounted, ref, watch } from 'vue'
  import { useRouter } from 'vue-router'
  import { marked } from 'marked'
  import type { MarkedOptions } from 'marked'
  import DOMPurify from 'dompurify'
  import { promptAPI } from '@/services/ai.service'
  import { useOptimizeStore } from '@/store/modules/ai.ts'
  import { storeToRefs } from 'pinia'
  import type { OptimizationDetailResponse, OptimizationRecord, OptimizationStage } from '@/types/ai'
  import { usePostStore } from '@/store/modules/posts'
  import type { PostFormPayload } from "@/types/models"

  type ToastKind = 'info' | 'success' | 'warning' | 'error'

  interface ToastMessage {
    message: string
    type: ToastKind
  }

  interface SummaryCard {
    key: string
    label: string
    value: string
    icon: string
    hint?: string
  }

  // SVG路径数据
  const summaryIcons = {
    total: 'M4 19.5V4.5C4 3.67157 4.67157 3 5.5 3H18.5C19.3284 3 20 3.67157 20 4.5V19.5C20 20.3284 19.3284 21 18.5 21H5.5C4.67157 21 4 20.3284 4 19.5Z M8 7H16 M8 11H16 M8 15H12',
    latest: 'M12 8V12L15 15M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z',
    average: 'M7 10L12 15L17 10M12 3V15',
    totalChars: 'M9 12H15M9 16H15M17 21H7C5.89543 21 5 20.1046 5 19V5C5 3.89543 5.89543 3 7 3H12.5858C12.851 3 13.1054 3.10536 13.2929 3.29289L18.7071 8.70711C18.8946 8.89464 19 9.149 19 9.41421V19C19 20.1046 18.1046 21 17 21Z'
  }

  const stageIcons = {
    original: 'M9 12H15M9 16H15M17 21H7C5.89543 21 5 20.1046 5 19V5C5 3.89543 5.89543 3 7 3H12.5858C12.851 3 13.1054 3.10536 13.2929 3.29289L18.7071 8.70711C18.8946 8.89464 19 9.149 19 9.41421V19C19 20.1046 18.1046 21 17 21Z',
    analyzer: 'M21 21L15 15M17 10C17 13.866 13.866 17 10 17C6.13401 17 3 13.866 3 10C3 6.13401 6.13401 3 10 3C13.866 3 17 6.13401 17 10Z',
    optimizer: 'M9 12.75L11.25 15L15 9.75M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z',
    reviewer: 'M11.35 3.836C11.757 3.317 12.243 3.317 12.65 3.836L21.615 15.084C22.141 15.748 21.677 16.75 20.842 16.75H3.158C2.323 16.75 1.859 15.748 2.385 15.084L11.35 3.836Z M12 9V12M12 15H12.01'
  }

  const resolveErrorMessage = (error: unknown): string => {
    if (error instanceof Error && error.message) {
      return error.message
    }
    if (typeof error === 'string') {
      return error
    }
    if (error && typeof error === 'object' && 'message' in error) {
      const candidate = (error as { message?: unknown }).message
      if (typeof candidate === 'string') {
        return candidate
      }
    }
    return ''
  }

  const router = useRouter()
  const optimizeStore = useOptimizeStore()
  const postStore = usePostStore()
  const { optimizationHistory } = storeToRefs(optimizeStore)

  const loading = ref(false)
  const detailLoading = ref(false)
  const detailVisible = ref(false)
  const currentDetail = ref<OptimizationRecord | null>(null)
  const currentPage = ref(1)
  const pageSize = ref(10)
  const totalRecords = ref(0)
  const markdownError = ref(false)
  const viewMode = ref<'rendered' | 'source'>('rendered')
  const stageCollapseStates = ref<Record<number, boolean>>({})
  const toast = ref<ToastMessage | null>(null)
  let toastTimer: number | null = null

  // 发布相关状态
  const publishing = ref(false)
  const showPublishDialog = ref(false)
  const postTitle = ref('')
  const selectedTags = ref<string[]>(['AI', '提示词优化'])
  const availableTags = ['AI', '提示词优化', 'GPT', '机器学习', '自然语言处理', '编程']

  const pageSizeOptions = [10, 20, 50, 100] as const

  const markedOptions: Partial<MarkedOptions> = {
    breaks: true,
    gfm: true,
    async: false
  }

  marked.setOptions(markedOptions as MarkedOptions)

  const history = computed<OptimizationRecord[]>(() => optimizationHistory.value ?? [])

  const paginatedHistory = computed<OptimizationRecord[]>(() => {
    const start = (currentPage.value - 1) * pageSize.value
    const end = start + pageSize.value
    return history.value.slice(start, end)
  })

  const renderMarkdown = (content: string): string => {
    const rendered = marked.parse(content)
    if (typeof rendered === 'string') {
      return DOMPurify.sanitize(rendered)
    }
    console.warn('Expected synchronous markdown rendering result.')
    return ''
  }

  const renderedMarkdown = computed(() => {
    const content = currentDetail.value?.optimized_prompt
    if (!content) return ''
    try {
      return renderMarkdown(content)
    } catch (error) {
      console.error('Markdown rendering error:', error)
      markdownError.value = true
      return ''
    }
  })

  const formatDate = (timestamp: string | number | Date | null | undefined) => {
    if (!timestamp) return '未知时间'
    return new Date(timestamp).toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    })
  }

  const formatNumber = (value: number | null | undefined) =>
    new Intl.NumberFormat('zh-CN').format(value ?? 0)

  const formatLengthDelta = (value: number | null | undefined) => {
    if (!value) return '0'
    const rounded = Math.round(value)
    return `${rounded > 0 ? '+' : ''}${rounded}`
  }

  const truncateText = (text: string | undefined | null, length = 52) => {
    if (!text) return '—'
    return text.length > length ? `${text.slice(0, length)}…` : text
  }

  const showToast = (message: string, type: ToastKind = 'info') => {
    toast.value = { message, type }
    if (toastTimer !== null) {
      window.clearTimeout(toastTimer)
    }
    toastTimer = window.setTimeout(() => {
      toast.value = null
      toastTimer = null
    }, 2400)
  }

  const hasHistory = computed(() => history.value.length > 0)

  const latestRecord = computed<OptimizationRecord | null>(() => {
    const [first] = history.value
    return first ?? null
  })

  const lastOptimizedAt = computed(() =>
    latestRecord.value ? formatDate(latestRecord.value.timestamp ?? null) : '—'
  )

  const currentDetailTime = computed(() =>
    currentDetail.value?.timestamp ? formatDate(currentDetail.value.timestamp) : '—'
  )

  const totalOptimizedLength = computed(() =>
    history.value.reduce<number>(
      (total, record) => total + (record.optimized_prompt?.length ?? 0),
      0
    )
  )

  const averageLengthChange = computed(() => {
    if (!history.value.length) return 0
    let aggregate = 0
    let count = 0
    history.value.forEach((record) => {
      const originalLength = record.original_prompt?.length ?? 0
      const optimizedLength = record.optimized_prompt?.length ?? 0
      if (originalLength || optimizedLength) {
        aggregate += optimizedLength - originalLength
        count += 1
      }
    })
    return count ? aggregate / count : 0
  })

  const latestStageSummary = computed(() => {
    const stages = latestRecord.value?.workflow_history
    if (!stages?.length) return '—'
    return stages
      .map((stage) => stage.role_name || stage.role || '')
      .filter(Boolean)
      .join(' / ')
  })

  const summaryCards = computed<SummaryCard[]>(() => {
    if (!hasHistory.value) return []
    const latest = latestRecord.value
    return [
      {
        key: 'total',
        label: '累计记录',
        value: formatNumber(totalRecords.value),
        hint: '包含所有优化历史',
        icon: summaryIcons.total
      },
      {
        key: 'latest',
        label: '最近优化',
        value: lastOptimizedAt.value,
        hint: truncateText(latest?.optimized_prompt || latest?.optimized_preview || ''),
        icon: summaryIcons.latest
      },
      {
        key: 'average',
        label: '平均长度变化',
        value: formatLengthDelta(averageLengthChange.value),
        hint: '优化字数 VS 原始',
        icon: summaryIcons.average
      },
      {
        key: 'totalChars',
        label: '累计优化字数',
        value: formatNumber(totalOptimizedLength.value),
        hint: '优化版本总字数',
        icon: summaryIcons.totalChars
      }
    ]
  })

  const totalPages = computed(() => {
    if (!totalRecords.value) return 1
    return Math.max(1, Math.ceil(totalRecords.value / pageSize.value))
  })

  const renderStageMarkdown = (content?: string) => {
    if (!content) return ''
    try {
      return renderMarkdown(content)
    } catch (error) {
      console.error('Stage markdown rendering error:', error)
      return content
    }
  }

  const toggleStageCollapse = (index: number) => {
    stageCollapseStates.value[index] = !stageCollapseStates.value[index]
  }

  const initStageCollapseStates = (workflowHistory?: OptimizationStage[]) => {
    if (!workflowHistory) return
    stageCollapseStates.value = {}
    workflowHistory.forEach((stage, index) => {
      if (stage.role !== 'original') {
        stageCollapseStates.value[index] = true
      }
    })
  }

  const getStageIcon = (role: string) => {
    return stageIcons[role as keyof typeof stageIcons] || stageIcons.original
  }

  const getTimelineType = (role: string) => {
    const types: Record<string, string> = {
      original: 'original',
      analyzer: 'analyzer',
      optimizer: 'optimizer',
      reviewer: 'reviewer'
    }
    return types[role] || 'default'
  }

  const getStageTagType = (role: string) => getTimelineType(role)

  const getStageTypeText = (role: string) => {
    const texts: Record<string, string> = {
      original: '原始输入',
      analyzer: '分析阶段',
      optimizer: '优化阶段',
      reviewer: '审核阶段'
    }
    return texts[role] || role
  }

  const loadHistory = async () => {
    loading.value = true
    try {
      await optimizeStore.loadHistory()
      totalRecords.value = history.value.length
    } catch (error) {
      console.error('Load history error:', error)
      const message = resolveErrorMessage(error) || '未知错误'
      showToast(`加载历史记录失败：${message}`, 'error')
    } finally {
      loading.value = false
    }
  }

  const showDetail = async (recordId?: string | number) => {
    if (recordId === undefined || recordId === null) {
      showToast('记录不存在', 'error')
      detailVisible.value = false
      return
    }
    detailLoading.value = true
    detailVisible.value = true
    markdownError.value = false
    viewMode.value = 'rendered'

    try {
      const data: OptimizationDetailResponse = await promptAPI.getHistoryDetail(recordId)
      const record = data?.record
      if (!record) {
        throw new Error('记录不存在')
      }
      currentDetail.value = record
      initStageCollapseStates(record.workflow_history)
    } catch (error) {
      console.error('Load detail error:', error)
      const message = resolveErrorMessage(error) || '未知错误'
      showToast(`加载详情失败：${message}`, 'error')
      detailVisible.value = false
    } finally {
      detailLoading.value = false
    }
  }

  const copyText = async (text: string | null | undefined) => {
    if (!text) {
      showToast('没有可复制的内容', 'warning')
      return
    }
    try {
      await navigator.clipboard.writeText(text)
      showToast('已复制到剪贴板')
    } catch {
      const textArea = document.createElement('textarea')
      textArea.value = text
      textArea.style.position = 'fixed'
      textArea.style.opacity = '0'
      document.body.appendChild(textArea)
      textArea.focus()
      textArea.select()
      try {
        document.execCommand('copy')
        showToast('已复制到剪贴板')
      } catch {
        showToast('复制失败', 'error')
      }
      document.body.removeChild(textArea)
    }
  }

  const toggleViewMode = () => {
    viewMode.value = viewMode.value === 'rendered' ? 'source' : 'rendered'
  }

  const calculateLengthChange = () => {
    if (!currentDetail.value) return '0'
    const original = currentDetail.value.original_prompt?.length ?? 0
    const optimized = currentDetail.value.optimized_prompt?.length ?? 0
    const change = optimized - original
    return change > 0 ? `+${change}` : change.toString()
  }

  const getLengthChangeClass = () => {
    const original = currentDetail.value?.original_prompt?.length ?? 0
    const optimized = currentDetail.value?.optimized_prompt?.length ?? 0
    const change = optimized - original
    if (change > 0) return 'increase'
    if (change < 0) return 'decrease'
    return 'same'
  }

  const exportRecord = async () => {
    if (!currentDetail.value) return
    try {
      const content = JSON.stringify(currentDetail.value, null, 2)
      const blob = new Blob([content], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `prompt-optimization-${currentDetail.value.id || Date.now()}.json`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
      showToast('导出成功', 'success')
    } catch (error) {
      console.error('Export error:', error)
      showToast('导出失败', 'error')
    }
  }

  // 发布相关方法
  const toggleTag = (tag: string) => {
    const index = selectedTags.value.indexOf(tag)
    if (index > -1) {
      selectedTags.value.splice(index, 1)
    } else {
      selectedTags.value.push(tag)
    }
  }

  const confirmPublish = async () => {
    if (!currentDetail.value || !postTitle.value.trim()) return
    
    publishing.value = true
    try {
      const payload: PostFormPayload = {
        title: postTitle.value.trim(),
        context: currentDetail.value.optimized_prompt || '',
        tags: selectedTags.value,
        isShareable: true,
        // PostFormPayload 定义中要求必须包含 url_list 字段，补上空数组作为默认值
        url_list: [],
        files: []
      }

      const result = await postStore.createPost(payload)
      
      if (result.success) {
        showToast('帖子发布成功！', 'success')
        showPublishDialog.value = false
        resetPublishForm()
      } else {
        throw new Error(result.message || '发布失败')
      }
    } catch (error) {
      console.error('Publish post error:', error)
      const message = resolveErrorMessage(error) || '未知错误'
      showToast(`发布失败：${message}`, 'error')
    } finally {
      publishing.value = false
    }
  }

  const resetPublishForm = () => {
    postTitle.value = ''
    selectedTags.value = ['AI', '提示词优化']
  }

  const handleSizeChange = (newSize: string | number) => {
    const size = Number(newSize) || pageSizeOptions[0]
    pageSize.value = size
    currentPage.value = 1
  }

  const handleCurrentChange = (newPage: number) => {
    const page = Math.min(Math.max(1, newPage), totalPages.value)
    currentPage.value = page
  }

  const goToWorkbench = () => {
    router.push('/ai/history')
  }

  onMounted(() => {
    loadHistory()
  })

  watch(detailVisible, (visible: boolean) => {
    if (!visible) {
      currentDetail.value = null
      viewMode.value = 'rendered'
      markdownError.value = false
      stageCollapseStates.value = {}
    }
  })

  watch(showPublishDialog, (visible) => {
    if (visible && currentDetail.value) {
      // 初始化发布表单
      postTitle.value = `优化提示词 - ${formatDate(currentDetail.value.timestamp)}`
    }
  })

  onUnmounted(() => {
    if (toastTimer !== null) {
      window.clearTimeout(toastTimer)
      toastTimer = null
    }
  })

  defineExpose({
    history,
    paginatedHistory,
    hasHistory,
    loading,
    detailLoading,
    detailVisible,
    currentDetail,
    currentDetailTime,
    latestRecord,
    currentPage,
    pageSize,
    totalRecords,
    totalPages,
    summaryCards,
    lastOptimizedAt,
    latestStageSummary,
    renderedMarkdown,
    markdownError,
    viewMode,
    stageCollapseStates,
    formatDate,
    truncateText,
    showDetail,
    copyText,
    toggleViewMode,
    toggleStageCollapse,
    renderStageMarkdown,
    getStageIcon,
    getTimelineType,
    getStageTagType,
    getStageTypeText,
    calculateLengthChange,
    getLengthChangeClass,
    exportRecord,
    handleSizeChange,
    handleCurrentChange,
    goToWorkbench,
    publishPost: () => showPublishDialog.value = true,
    publishing
  })
</script>

<style scoped>
.history {
  display: grid;
  gap: 1.75rem;
  padding-bottom: 2.5rem;
}

.history__toast {
  position: fixed;
  top: 1.5rem;
  right: 1.5rem;
  padding: 0.85rem 1.2rem;
  border-radius: 12px;
  background: #0f172a;
  color: #fff;
  box-shadow: 0 12px 24px rgba(15, 23, 42, 0.15);
  z-index: 2000;
  font-size: 0.95rem;
  pointer-events: none;
}

.history__toast--success {
  background: #15803d;
}

.history__toast--warning {
  background: #ca8a04;
}

.history__toast--error {
  background: #b91c1c;
}

.history__header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 1.5rem;
  flex-wrap: wrap;
}

.history__heading {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.history__heading-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 48px;
  height: 48px;
  border-radius: 14px;
  background: rgba(99, 102, 241, 0.12);
  color: #4338ca;
}

.history__header h1 {
  margin: 0;
  font-size: 1.9rem;
  font-weight: 700;
  color: #0f172a;
  letter-spacing: -0.5px;
}

.history__header p {
  margin: 0.35rem 0 0;
  color: #64748b;
  font-size: 0.95rem;
  line-height: 1.5;
  max-width: 40rem;
}

.history__actions {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  flex-wrap: wrap;
}

.history__counter {
  display: inline-flex;
  align-items: center;
  padding: 0.4rem 0.9rem;
  border-radius: 20px;
  background: rgba(99, 102, 241, 0.12);
  color: #4338ca;
  font-weight: 600;
  font-size: 0.9rem;
}

.history__button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.35rem;
  padding: 0.55rem 1.1rem;
  border-radius: 10px;
  border: none;
  background: linear-gradient(120deg, #6366f1, #22d3ee);
  color: #fff;
  font-weight: 600;
  font-size: 0.9rem;
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
}

.history__button:hover {
  transform: translateY(-1px);
  box-shadow: 0 10px 18px rgba(99, 102, 241, 0.25);
}

.history__button:active {
  transform: translateY(0);
}

.history__button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
  box-shadow: none;
  transform: none;
}

.history__button--ghost {
  background: transparent;
  border: 1.5px solid rgba(99, 102, 241, 0.4);
  color: #4338ca;
  box-shadow: none;
}

.history__button--ghost:hover {
  background: rgba(99, 102, 241, 0.08);
  box-shadow: none;
}

.history__button--link {
  background: none;
  border: none;
  color: #2563eb;
  padding: 0;
  font-weight: 600;
  font-size: 0.9rem;
}

.history__layout {
  display: grid;
  gap: 1.5rem;
}

.history__layout--with-summary {
  grid-template-columns: minmax(0, 280px) minmax(0, 1fr);
  align-items: start;
}

.history__summary {
  display: grid;
  gap: 1.25rem;
}

.history__summary-card,
.history__snapshot,
.history__card {
  background: #ffffff;
  border-radius: 16px;
  border: 1px solid #e2e8f0;
  box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08);
  padding: 1.2rem;
  transition: box-shadow 0.2s ease;
}

.history__summary-card:hover,
.history__snapshot:hover,
.history__card:hover {
  box-shadow: 0 20px 40px rgba(15, 23, 42, 0.12);
}

.history__summary-header h2 {
  margin: 0;
  font-size: 1.05rem;
  font-weight: 600;
  color: #1f2937;
  letter-spacing: -0.3px;
}

.history__summary-header p {
  margin: 0.35rem 0 0;
  color: #64748b;
  font-size: 0.85rem;
}

.history__summary-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
  gap: 0.9rem;
  margin-top: 1.1rem;
}

.history__summary-item {
  display: flex;
  gap: 0.65rem;
  padding: 0.65rem 0.5rem;
  border-radius: 10px;
  background: rgba(248, 250, 252, 0.8);
  transition: background-color 0.2s ease;
}

.history__summary-item:hover {
  background: rgba(248, 250, 252, 1);
}

.history__summary-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  color: #4338ca;
  flex-shrink: 0;
}

.history__summary-value {
  margin: 0;
  font-size: 1.1rem;
  font-weight: 700;
  color: #0f172a;
}

.history__summary-label {
  margin: 0.15rem 0 0;
  color: #475569;
  font-size: 0.8rem;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.4px;
}

.history__summary-hint {
  margin: 0.2rem 0 0;
  color: #94a3b8;
  font-size: 0.75rem;
  line-height: 1.3;
}

.history__snapshot-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 0.9rem;
  margin-bottom: 0.9rem;
}

.history__snapshot-title {
  display: block;
  font-weight: 600;
  color: #1f2937;
  font-size: 0.95rem;
}

.history__snapshot-time {
  margin: 0.2rem 0 0;
  color: #94a3b8;
  font-size: 0.8rem;
}

.history__snapshot-content {
  display: grid;
  gap: 0.5rem;
}

.history__snapshot-label {
  font-size: 0.7rem;
  font-weight: 600;
  color: #94a3b8;
  letter-spacing: 0.4px;
  text-transform: uppercase;
}

.history__snapshot-text {
  margin: 0;
  color: #1f2937;
  line-height: 1.4;
  font-size: 0.9rem;
  word-break: break-word;
}

.history__snapshot-text--highlight {
  color: #2563eb;
  font-weight: 500;
}

.history__snapshot-meta {
  margin-top: 0.3rem;
  font-size: 0.75rem;
  color: #94a3b8;
  font-style: italic;
}

.history__snapshot-empty {
  color: #94a3b8;
  text-align: center;
  padding: 1.2rem 0;
  font-size: 0.9rem;
  font-style: italic;
}

.history__table-wrapper {
  display: grid;
  gap: 1.2rem;
}

.history__table-header h2 {
  margin: 0;
  font-size: 1.2rem;
  font-weight: 600;
  color: #1f2937;
  letter-spacing: -0.3px;
}

.history__table-header p {
  margin: 0.35rem 0 0;
  color: #94a3b8;
  font-size: 0.9rem;
}

.history__table-scroll {
  overflow-x: auto;
  border-radius: 12px;
  border: 1px solid #e2e8f0;
  background: #fff;
}

.history__table {
  width: 100%;
  border-collapse: collapse;
  min-width: 720px;
}

.history__table th,
.history__table td {
  padding: 0.9rem 1rem;
  text-align: left;
  border-bottom: 1px solid #e2e8f0;
  vertical-align: top;
}

.history__table thead th {
  background: #f8fafc;
  color: #1e293b;
  font-weight: 600;
  font-size: 0.9rem;
  text-transform: uppercase;
  letter-spacing: 0.4px;
}

.history__table tbody tr {
  transition: background-color 0.2s ease;
}

.history__table tbody tr:hover {
  background: rgba(99, 102, 241, 0.05);
}

.history__table-actions {
  width: 110px;
  text-align: right;
}

.history__table-empty {
  text-align: center;
  padding: 1.8rem 1rem;
  color: #94a3b8;
  font-style: italic;
}

.history__time {
  display: flex;
  align-items: center;
  gap: 0.45rem;
  color: #475569;
  font-size: 0.88rem;
}

.history__prompt {
  display: flex;
  gap: 0.6rem;
  color: #475569;
}

.history__prompt-text {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  word-break: break-word;
  font-size: 0.9rem;
  line-height: 1.4;
}

.history__pagination {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 1rem;
  margin-top: 1rem;
  flex-wrap: wrap;
}

.history__pagination-info {
  color: #475569;
  font-size: 0.85rem;
}

.history__pagination-controls {
  display: flex;
  align-items: center;
  gap: 0.6rem;
  flex-wrap: wrap;
}

.history__pagination-size {
  display: flex;
  align-items: center;
  gap: 0.35rem;
  color: #475569;
  font-size: 0.85rem;
}

.history__pagination-size select {
  padding: 0.3rem 0.6rem;
  border-radius: 6px;
  border: 1.5px solid #cbd5f5;
  background: #fff;
  font-size: 0.85rem;
  transition: border-color 0.2s ease;
}

.history__pagination-size select:focus {
  outline: none;
  border-color: #6366f1;
  box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
}

.history__empty {
  text-align: center;
  padding: 3.5rem 1rem;
}

.history__empty-title {
  margin: 0;
  font-size: 1.3rem;
  font-weight: 600;
  color: #1f2937;
  letter-spacing: -0.3px;
}

.history__empty-desc {
  margin: 0.65rem 0 1.3rem;
  color: #94a3b8;
  font-size: 0.95rem;
}

/* 详情弹窗样式 */
.history-detail__overlay {
  position: fixed;
  inset: 0;
  background: rgba(15, 23, 42, 0.45);
  backdrop-filter: blur(4px);
  display: grid;
  place-items: center;
  padding: 2rem;
  z-index: 1500;
  animation: overlayFadeIn 0.2s ease;
}

@keyframes overlayFadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

.history-detail__panel {
  width: min(960px, 100%);
  max-height: calc(100vh - 4rem);
  background: #ffffff;
  border-radius: 18px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  box-shadow: 0 28px 60px rgba(15, 23, 42, 0.2);
  animation: panelSlideIn 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

@keyframes panelSlideIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.history-detail__header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 1rem;
  padding: 1.4rem 1.75rem 1.2rem;
  border-bottom: 1px solid #e2e8f0;
  background: linear-gradient(to bottom, #ffffff, #f8fafc);
}

.history-detail__header h2 {
  margin: 0;
  font-size: 1.35rem;
  font-weight: 700;
  color: #0f172a;
  letter-spacing: -0.3px;
}

.history-detail__subtitle {
  margin: 0.4rem 0 0;
  color: #94a3b8;
  font-size: 0.9rem;
}

.history-detail__content {
  padding: 1.5rem 1.75rem;
  overflow-y: auto;
  display: grid;
  gap: 1.5rem;
  background: #f9fafb;
}

.history-detail__stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 1rem;
}

.history-detail__stat-card {
  background: #ffffff;
  border-radius: 14px;
  padding: 0.9rem 1rem;
  border: 1px solid #e2e8f0;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.history-detail__stat-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(15, 23, 42, 0.1);
}

.history-detail__stat {
  display: flex;
  align-items: center;
  gap: 0.9rem;
}

.history-detail__stat-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 48px;
  height: 48px;
  border-radius: 12px;
  color: #fff;
  flex-shrink: 0;
}

.history-detail__stat-icon--original {
  background: linear-gradient(135deg, #f59e0b, #fbbf24);
}

.history-detail__stat-icon--optimized {
  background: linear-gradient(135deg, #22c55e, #4ade80);
}

.history-detail__stat-icon--increase {
  background: linear-gradient(135deg, #ef4444, #f87171);
}

.history-detail__stat-icon--decrease {
  background: linear-gradient(135deg, #22c55e, #4ade80);
}

.history-detail__stat-icon--same {
  background: linear-gradient(135deg, #9ca3af, #d1d5db);
}

.history-detail__stat-icon--stages {
  background: linear-gradient(135deg, #6366f1, #818cf8);
}

.history-detail__stat-value {
  margin: 0;
  font-size: 1.45rem;
  font-weight: 700;
  color: #0f172a;
}

.history-detail__stat-value--increase {
  color: #dc2626;
}

.history-detail__stat-value--decrease {
  color: #15803d;
}

.history-detail__stat-value--same {
  color: #475569;
}

.history-detail__stat-label {
  margin: 0.2rem 0 0;
  color: #94a3b8;
  font-size: 0.8rem;
  letter-spacing: 0.4px;
  text-transform: uppercase;
  font-weight: 500;
}

.history-detail__prompts {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 1.2rem;
}

.history-detail__prompt-card {
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  background: #fff;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  transition: box-shadow 0.2s ease;
}

.history-detail__prompt-card:hover {
  box-shadow: 0 12px 32px rgba(15, 23, 42, 0.1);
}

.history-detail__prompt-header {
  padding: 1rem 1.2rem;
  background: #f8fafc;
  display: flex;
  align-items: center;
  gap: 0.6rem;
  flex-wrap: wrap;
  border-bottom: 1px solid #e2e8f0;
}

.history-detail__prompt-title {
  font-weight: 600;
  color: #1f2937;
  margin-right: 0.5rem;
  font-size: 0.95rem;
}

.history-detail__tag {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0.25rem 0.6rem;
  border-radius: 999px;
  font-size: 0.75rem;
  background: rgba(99, 102, 241, 0.1);
  color: #4338ca;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.3px;
  white-space: nowrap;
}

.history-detail__tag--warning {
  background: rgba(245, 158, 11, 0.18);
  color: #b45309;
}

.history-detail__tag--info {
  background: rgba(59, 130, 246, 0.14);
  color: #1d4ed8;
}

.history-detail__tag--original {
  background: rgba(245, 158, 11, 0.18);
  color: #b45309;
}

.history-detail__tag--analyzer {
  background: rgba(249, 115, 22, 0.18);
  color: #c2410c;
}

.history-detail__tag--optimizer {
  background: rgba(34, 197, 94, 0.18);
  color: #15803d;
}

.history-detail__tag--reviewer {
  background: rgba(99, 102, 241, 0.18);
  color: #4338ca;
}

.history-detail__prompt-body {
  padding: 1.2rem;
  background: #f9fafb;
  max-height: 18rem;
  overflow-y: auto;
  flex: 1;
  transition: background-color 0.2s ease;
}

.history-detail__prompt-body--source {
  background: #0f172a;
  color: #e2e8f0;
}

.history-detail__prompt-body pre {
  margin: 0;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: 'Menlo', 'Monaco', 'Courier New', monospace;
  font-size: 0.92rem;
  line-height: 1.6;
}

.history-detail__prompt-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 0.75rem;
  flex-wrap: wrap;
  padding: 0.9rem 1.2rem 1.1rem;
  border-top: 1px solid #e2e8f0;
  background: #f8fafc;
}

.history-detail__char-count {
  font-size: 0.78rem;
  color: #94a3b8;
  font-weight: 500;
}

.history-detail__workflow {
  border: 1px solid #e2e8f0;
  border-radius: 14px;
  background: #fff;
  padding: 1.15rem 1.2rem;
}

.history-detail__workflow-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
  padding-bottom: 0.75rem;
  border-bottom: 1px solid #e2e8f0;
}

.history-detail__timeline {
  display: grid;
  gap: 1rem;
}

.history-detail__stage-card {
  border-radius: 12px;
  border: 1px solid #e5e7eb;
  overflow: hidden;
  background: #f9fafb;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.history-detail__stage-card:hover {
  transform: translateY(-1px);
  box-shadow: 0 8px 24px rgba(15, 23, 42, 0.08);
}

.history-detail__stage-card--original {
  border-left: 4px solid #f59e0b;
}

.history-detail__stage-card--analyzer {
  border-left: 4px solid #f97316;
}

.history-detail__stage-card--optimizer {
  border-left: 4px solid #22c55e;
}

.history-detail__stage-card--reviewer {
  border-left: 4px solid #6366f1;
}

.history-detail__stage-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 1rem;
  padding: 0.95rem 1.1rem;
  background: rgba(255, 255, 255, 0.8);
  border-bottom: 1px solid #e2e8f0;
}

.history-detail__stage-title {
  display: flex;
  align-items: center;
  gap: 0.6rem;
  flex-wrap: wrap;
}

.history-detail__stage-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  border-radius: 10px;
  color: #4338ca;
}

.history-detail__stage-icon--original {
  background: rgba(245, 158, 11, 0.18);
  color: #b45309;
}

.history-detail__stage-icon--analyzer {
  background: rgba(249, 115, 22, 0.18);
  color: #c2410c;
}

.history-detail__stage-icon--optimizer {
  background: rgba(34, 197, 94, 0.18);
  color: #15803d;
}

.history-detail__stage-icon--reviewer {
  background: rgba(99, 102, 241, 0.18);
  color: #4338ca;
}

.history-detail__stage-meta {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  flex-wrap: wrap;
}

.history-detail__stage-time {
  font-size: 0.82rem;
  color: #94a3b8;
  white-space: nowrap;
}

.history-detail__collapse {
  font-size: 0.8rem;
  padding: 0.25rem 0.5rem;
}

.history-detail__stage-content {
  padding: 0.95rem 1.1rem 1.1rem;
  display: grid;
  gap: 0.75rem;
}

.history-detail__stage-output {
  background: #fff;
  border-radius: 10px;
  padding: 0.9rem 1rem;
  border: 1px solid #e2e8f0;
}

.history-detail__stage-output pre {
  margin: 0;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: 'Menlo', 'Monaco', 'Courier New', monospace;
  font-size: 0.85rem;
  line-height: 1.55;
}

.history-detail__stage-hint {
  padding: 0.85rem 1rem;
  border-radius: 10px;
  background: rgba(99, 102, 241, 0.08);
  color: #475569;
  font-size: 0.88rem;
  font-style: italic;
  text-align: center;
}

.history-detail__stage-actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 0.7rem;
  border-top: 1px solid #e2e8f0;
  padding-top: 0.75rem;
}

.history-detail__error {
  color: #b91c1c;
  padding: 1rem;
  background: rgba(185, 28, 28, 0.05);
  border-radius: 8px;
  border: 1px solid rgba(185, 28, 28, 0.2);
}

.history-detail__error pre {
  margin-top: 0.5rem;
  background: rgba(0, 0, 0, 0.05);
  padding: 0.75rem;
  border-radius: 6px;
  overflow-x: auto;
}

.history-detail__footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 0.75rem;
  padding: 1.05rem 1.75rem 1.4rem;
  border-top: 1px solid #e2e8f0;
  background: #f8fafc;
}

.history-detail__footer-actions {
  display: flex;
  gap: 0.75rem;
  align-items: center;
}

.history-detail__skeleton {
  padding: 1.5rem 1.75rem 2rem;
  display: grid;
  gap: 0.75rem;
}

.history-detail__skeleton-line {
  height: 14px;
  border-radius: 8px;
  background: linear-gradient(90deg, #f1f5f9 25%, #e2e8f0 50%, #f1f5f9 75%);
  background-size: 200% 100%;
  animation: skeleton-loading 1.3s infinite;
}

/* 发布对话框样式 */
.history-detail__publish-panel {
  width: min(600px, 100%);
}

.history-detail__publish-content {
  padding: 1.5rem 1.75rem;
  display: grid;
  gap: 1.5rem;
  background: #f9fafb;
}

.history-detail__publish-field {
  display: grid;
  gap: 0.5rem;
}

.history-detail__publish-label {
  font-weight: 600;
  color: #1f2937;
  font-size: 0.9rem;
}

.history-detail__publish-input {
  padding: 0.75rem 1rem;
  border: 1.5px solid #e2e8f0;
  border-radius: 8px;
  font-size: 0.95rem;
  transition: all 0.2s ease;
  background: #ffffff;
}

.history-detail__publish-input:focus {
  outline: none;
  border-color: #6366f1;
  box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
}

.history-detail__publish-input::placeholder {
  color: #94a3b8;
}

.history-detail__tags {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.history-detail__tag {
  padding: 0.4rem 0.8rem;
  border: 1.5px solid #e2e8f0;
  border-radius: 20px;
  font-size: 0.85rem;
  cursor: pointer;
  transition: all 0.2s ease;
  background: #f8fafc;
  color: #475569;
  font-weight: 500;
}

.history-detail__tag:hover {
  border-color: #6366f1;
  color: #4338ca;
}

.history-detail__tag--selected {
  background: #6366f1;
  color: white;
  border-color: #6366f1;
}

.history-detail__publish-preview {
  border: 1.5px solid #e2e8f0;
  border-radius: 8px;
  padding: 1rem;
  background: #f9fafb;
}

.history-detail__publish-preview h4 {
  margin: 0 0 0.75rem 0;
  color: #1f2937;
  font-size: 0.95rem;
  font-weight: 600;
}

.history-detail__preview-content {
  max-height: 200px;
  overflow-y: auto;
  padding: 0.75rem;
  background: white;
  border-radius: 6px;
  border: 1px solid #e2e8f0;
}

@keyframes skeleton-loading {
  0% {
    background-position: 200% 0;
  }
  100% {
    background-position: -200% 0;
  }
}

/* 响应式设计 */
@media (max-width: 960px) {
  .history__header h1 {
    font-size: 1.65rem;
  }

  .history__header p {
    max-width: 100%;
  }

  .history__layout--with-summary {
    grid-template-columns: 1fr;
  }

  .history__summary {
    order: -1;
  }

  .history-detail__panel {
    max-height: 100vh;
    border-radius: 0;
  }

  .history-detail__header,
  .history-detail__content,
  .history-detail__footer {
    padding-left: 1.15rem;
    padding-right: 1.15rem;
  }

  .history-detail__stats-grid {
    grid-template-columns: repeat(2, 1fr);
  }

  .history-detail__prompts {
    grid-template-columns: 1fr;
  }

  .history-detail__publish-content {
    padding: 1rem;
  }
}

@media (max-width: 640px) {
  .history__table {
    min-width: 600px;
  }

  .history-detail__prompt-footer,
  .history-detail__stage-actions {
    flex-direction: column;
    align-items: flex-start;
  }

  .history__toast {
    left: 1rem;
    right: 1rem;
  }

  .history-detail__stats-grid {
    grid-template-columns: 1fr;
  }

  .history-detail__stage-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.5rem;
  }

  .history-detail__stage-meta {
    width: 100%;
    justify-content: space-between;
  }

  .history-detail__footer-actions {
    flex-direction: column;
    width: 100%;
  }
  
  .history-detail__footer-actions .history__button {
    width: 100%;
  }
}

@media (max-width: 480px) {
  .history__header {
    flex-direction: column;
    align-items: flex-start;
    gap: 1rem;
  }

  .history__actions {
    width: 100%;
    justify-content: space-between;
  }

  .history__pagination {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.75rem;
  }

  .history__pagination-controls {
    width: 100%;
    justify-content: space-between;
  }

  .history-detail__overlay {
    padding: 1rem;
  }

  .history-detail__footer {
    flex-direction: column;
    gap: 0.75rem;
  }
  
  .history-detail__footer-actions {
    width: 100%;
    flex-direction: row;
    justify-content: space-between;
  }
}

/* Markdown 渲染样式 */
.markdown-body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif;
  font-size: 0.92rem;
  line-height: 1.7;
  color: #1f2933;
}

.markdown-body h1,
.markdown-body h2,
.markdown-body h3,
.markdown-body h4,
.markdown-body h5,
.markdown-body h6 {
  margin: 1.25rem 0 0.85rem;
  font-weight: 600;
  line-height: 1.25;
}

.markdown-body h1 {
  font-size: 1.4em;
  border-bottom: 2px solid #e2e8f0;
  padding-bottom: 0.3em;
}

.markdown-body h2 {
  font-size: 1.25em;
  border-bottom: 1px solid #e2e8f0;
  padding-bottom: 0.3em;
}

.markdown-body p {
  margin: 0 0 1rem;
}

.markdown-body ul,
.markdown-body ol {
  padding-left: 1.6rem;
  margin-bottom: 1rem;
}

.markdown-body blockquote {
  border-left: 4px solid #cbd5f5;
  padding: 0 1rem;
  color: #475569;
  margin: 1rem 0;
  background: #f8faff;
  border-radius: 0 10px 10px 0;
}

.markdown-body code {
  background: rgba(148, 163, 184, 0.2);
  padding: 0.1rem 0.4rem;
  border-radius: 4px;
  font-family: 'Menlo', 'Monaco', 'Courier New', monospace;
  font-size: 0.85em;
}

.markdown-body pre {
  background: #0f172a;
  color: #e2e8f0;
  padding: 1rem;
  border-radius: 10px;
  overflow: auto;
  margin: 1rem 0;
  border: 1px solid #1e293b;
}

.markdown-body pre code {
  background: none;
  padding: 0;
  border-radius: 0;
  color: inherit;
}

.markdown-body table {
  border-collapse: collapse;
  width: 100%;
  margin: 1rem 0;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(15, 23, 42, 0.08);
}

.markdown-body table th,
.markdown-body table td {
  border: 1px solid #e2e8f0;
  padding: 0.75rem;
  text-align: left;
}

.markdown-body table th {
  background: #f8fafc;
  font-weight: 600;
}

.markdown-body img {
  max-width: 100%;
  height: auto;
  border-radius: 8px;
}

.markdown-body a {
  color: #2563eb;
  text-decoration: none;
  transition: color 0.2s ease;
}

.markdown-body a:hover {
  color: #1d4ed8;
  text-decoration: underline;
}

/* 滚动条样式 */
.history-detail__prompt-body::-webkit-scrollbar,
.history-detail__content::-webkit-scrollbar,
.history__table-scroll::-webkit-scrollbar,
.history-detail__preview-content::-webkit-scrollbar {
  width: 6px;
  height: 6px;
}

.history-detail__prompt-body::-webkit-scrollbar-track,
.history-detail__content::-webkit-scrollbar-track,
.history__table-scroll::-webkit-scrollbar-track,
.history-detail__preview-content::-webkit-scrollbar-track {
  background: #f1f5f9;
  border-radius: 3px;
}

.history-detail__prompt-body::-webkit-scrollbar-thumb,
.history-detail__content::-webkit-scrollbar-thumb,
.history__table-scroll::-webkit-scrollbar-thumb,
.history-detail__preview-content::-webkit-scrollbar-thumb {
  background: #cbd5e1;
  border-radius: 3px;
  transition: background-color 0.2s ease;
}

.history-detail__prompt-body::-webkit-scrollbar-thumb:hover,
.history-detail__content::-webkit-scrollbar-thumb:hover,
.history__table-scroll::-webkit-scrollbar-thumb:hover,
.history-detail__preview-content::-webkit-scrollbar-thumb:hover {
  background: #94a3b8;
}

/* 焦点状态 */
.history__button:focus-visible,
.history-detail__collapse:focus-visible,
.history-detail__tag:focus-visible {
  outline: 2px solid #6366f1;
  outline-offset: 2px;
}

/* 选择框样式 */
.history__pagination-size select:focus {
  outline: 2px solid #6366f1;
  outline-offset: 1px;
}

/* 打印样式 */
@media print {
  .history__actions,
  .history__button,
  .history-detail__footer {
    display: none;
  }
  
  .history__summary-card,
  .history__snapshot,
  .history__card {
    box-shadow: none;
    border: 1px solid #ddd;
  }
}

/* 暗色模式支持 */
@media (prefers-color-scheme: dark) {
  .history__header h1,
  .history__header p,
  .history__summary-header h2,
  .history__summary-value,
  .history__snapshot-title,
  .history__snapshot-text,
  .history-detail__header h2,
  .history-detail__stat-value,
  .history-detail__prompt-title,
  .history-detail__publish-label {
    color: #e2e8f0;
  }
  
  .history__counter,
  .history__button--ghost,
  .history__button--link {
    background: rgba(99, 102, 241, 0.2);
    border-color: rgba(99, 102, 241, 0.4);
  }
  
  .history__summary-card,
  .history__snapshot,
  .history__card,
  .history-detail__panel,
  .history-detail__stat-card,
  .history-detail__prompt-card,
  .history-detail__workflow,
  .history-detail__stage-card {
    background: #1e293b;
    border-color: #334155;
  }
  
  .history__table th,
  .history__table td {
    border-color: #334155;
  }
  
  .history__table thead th {
    background: #1e293b;
    color: #e2e8f0;
  }
}
</style>