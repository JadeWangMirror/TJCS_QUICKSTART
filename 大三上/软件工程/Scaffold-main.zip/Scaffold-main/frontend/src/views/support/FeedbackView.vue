<template>
  <section class="support-feedback">
    <header>
      <h1>反馈与建议</h1>
      <p>欢迎提出意见，帮助我们持续改进创享论坛。</p>
    </header>

    <form>
      <label>
        <span>反馈类型</span>
        <select>
          <option>功能建议</option>
          <option>使用问题</option>
          <option>内容举报</option>
          <option>其他</option>
        </select>
      </label>

      <label>
        <span>详细描述</span>
        <textarea rows="5" placeholder="请描述遇到的问题或建议..."></textarea>
      </label>

      <label>
        <span>联系方式（可选）</span>
        <input type="email" placeholder="your@email.com" />
      </label>

      <button type="submit">提交反馈</button>
    </form>
  </section>
</template>

<style scoped>
.support-feedback {
  display: grid;
  gap: 1.75rem;
}

header h1 {
  margin: 0;
  font-size: 1.9rem;
}

header p {
  margin: 0.4rem 0 0;
  color: #475569;
}

form {
  background: #ffffff;
  border-radius: 18px;
  padding: 1.75rem;
  display: grid;
  gap: 1rem;
  box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08);
}

label {
  display: grid;
  gap: 0.5rem;
  font-weight: 500;
}

select,
textarea,
input {
  border-radius: 12px;
  border: 1px solid rgba(148, 163, 184, 0.6);
  padding: 0.75rem 1rem;
}

textarea {
  resize: vertical;
}

button {
  justify-self: flex-start;
  padding: 0.75rem 1.8rem;
  border-radius: 12px;
  border: none;
  background: linear-gradient(120deg, #7c3aed, #4c1d95);
  color: #fff;
  font-weight: 600;
}
</style>
