<template>
  <section class="support-about">
    <header>
      <h1>关于创享论坛</h1>
      <p>连接创作者与提示词灵感，构建开放且可信赖的生成式 AI 交流社区。</p>
    </header>

    <article>
      <h2>平台愿景</h2>
      <p>
        我们希望通过完善的提示词分享体系、生成历史追踪与多维推荐，帮助每位创作者高效探索创意边界。
      </p>
      <h2>核心能力</h2>
      <ul>
        <li>交流帖管理：发布、编辑、删除、收藏。</li>
        <li>AI 生成工作流：提示词调用、自动保存、迭代发布。</li>
        <li>推荐系统：个性化、热门与标签推荐。</li>
        <li>管理员后台：用户、内容与标签维护，以及数据统计。</li>
      </ul>
    </article>
  </section>
</template>

<style scoped>
.support-about {
  display: grid;
  gap: 1.75rem;
}

header h1 {
  margin: 0;
  font-size: 1.9rem;
}

header p {
  margin: 0.4rem 0 0;
  color: #475569;
}

article {
  background: #ffffff;
  border-radius: 18px;
  padding: 1.75rem;
  display: grid;
  gap: 1rem;
  box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08);
}

h2 {
  margin: 0;
  font-size: 1.2rem;
  color: #312e81;
}

p,
li {
  color: #475569;
}

ul {
  margin: 0;
  padding-left: 1.2rem;
}
</style>
