<template>
  <section class="support-guidelines">
    <header>
      <h1>社区规范</h1>
      <p>保障内容质量与社区氛围，请遵循以下基本原则。</p>
    </header>

    <article>
      <h2>创作要求</h2>
      <ul>
        <li>尊重知识产权，禁止发布侵权或抄袭内容。</li>
        <li>禁止传播违法、敏感或敏感政治内容。</li>
        <li>分享提示词时标注模型、参数与注意事项。</li>
      </ul>

      <h2>互动礼仪</h2>
      <ul>
        <li>积极交流、理性讨论，尊重他人观点。</li>
        <li>发表评论需遵守文明规范，禁止恶意攻击。</li>
        <li>举报违规内容，我们将尽快处理。</li>
      </ul>
    </article>
  </section>
</template>

<style scoped>
.support-guidelines {
  display: grid;
  gap: 1.75rem;
}

header h1 {
  margin: 0;
  font-size: 1.9rem;
}

header p {
  margin: 0.4rem 0 0;
  color: #475569;
}

article {
  background: #ffffff;
  border-radius: 18px;
  padding: 1.75rem;
  display: grid;
  gap: 1rem;
  box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08);
}

h2 {
  margin: 0;
  font-size: 1.2rem;
  color: #312e81;
}

ul {
  margin: 0;
  padding-left: 1.2rem;
  color: #475569;
}
</style>
