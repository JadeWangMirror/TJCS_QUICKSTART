<script lang="ts" setup>
  import {  defineEmits, ref, computed } from 'vue';
  import type { Comment } from '@/types/models';

  // 重点：在 CommentItem 中递归调用 CommentList。
  import CommentList from './CommentList.vue';

  // 接收单条评论对象和判断权限所需的 ID
  const props = defineProps<{
    comment: Comment;
    //  新增：用于判断是否显示删除按钮
    currentUserId?: number; 
    postAuthorId?: number;
  }>();

  // 定义组件可以触发的事件
  const emit = defineEmits<{
    // 回复事件
    (e: 'reply', commentId: number): void;
    //  新增：删除事件，将评论ID向上抛出
    (e: 'delete', commentId: number): void;
  }>();

  // --- 图标 SVG 定义 ---
  const IconReply = { 
    template: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 14 4 9 9 4"></polyline><path d="M20 20v-7a4 4 0 0 0-4-4H4"></path></svg>`
  };

  const IconTrash = { 
    template: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>`
  };
  // -----------------------

  // --- 删除权限判断 ---
  // 修改为只允许评论作者删除自己的评论
  const showDeleteButton = computed(() => {
    if (!props.currentUserId) return false;
    // 只有评论作者本人可以删除评论
    return props.currentUserId === props.comment.author_id;
  });
  // -------------------

  // --- 图片预览状态 (不变) ---
  const previewVisible = ref(false);
  const currentPreview = ref('');

  const openPreview = (src: string) => {
    currentPreview.value = src;
    previewVisible.value = true;
  };

  const closePreview = () => {
    previewVisible.value = false;
    currentPreview.value = '';
  };
  // ----------------------------

  // --- 时间格式化函数 ---
  const formatTime = (timestamp: string) => {
    if (!timestamp) return '';
    
    const date = new Date(timestamp);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) {
      return '刚刚';
    } else if (diffInSeconds < 3600) {
      return `${Math.floor(diffInSeconds / 60)}分钟前`;
    } else if (diffInSeconds < 86400) {
      return `${Math.floor(diffInSeconds / 3600)}小时前`;
    } else {
      return `${Math.floor(diffInSeconds / 86400)}天前`;
    }
  };
  // ------------------------
  
  // --- 获取用户头像文字 ---
  const getAvatarText = (author: string) => {
    return author ? author.charAt(0).toUpperCase() : 'U';
  };
  // ------------------------

  // 处理回复逻辑，将事件向上抛出
  const handleReply = () => {
    emit('reply', props.comment.id);
  };

  //  处理删除逻辑，确认后向上抛出事件
  const handleDelete = () => {
    if(confirm('确定要删除这条评论吗？')) {
      emit('delete', props.comment.id);
    }
  };
</script>

<template>
  <div class="comment-item">
    <div class="comment-item__header">
      <!-- 用户头像 -->
      <div class="user-avatar">
        <div class="avatar-circle">
          {{ getAvatarText(comment.author) }}
        </div>
      </div>
      <!-- 用户信息 -->
      <div class="user-info">
        <strong class="comment-author">{{ comment.author || '佚名' }}</strong>
        <small class="comment-time">{{ formatTime(comment.timestamp) }}</small>
      </div>
    </div>
    <div class="comment-item__content">
      <p class="comment-text">{{ comment.context }}</p>

      <div class="comment-images" v-if="comment.url_list && comment.url_list.length > 0">
        <img v-for="img_url in comment.url_list" :key="img_url" :src="img_url" @click="openPreview(img_url)"
          class="comment-image-thumb" />
      </div>
    </div>

    <div class="comment-item__actions">
      <button type="button" class="action-button reply-button" @click="handleReply">
        <component :is="IconReply" class="action-icon" />
        <span>回复</span>
      </button>
      
      <button v-if="showDeleteButton" type="button" class="action-button delete-button" @click="handleDelete">
        <component :is="IconTrash" class="action-icon" />
        <span>删除</span>
      </button>
    </div>

    <div v-if="comment.comments && comment.comments.length > 0" class="comment-item__children">
      <CommentList 
        :comments="comment.comments" 
        @reply="$emit('reply', $event)" 
        @delete="$emit('delete', $event)"
        :currentUserId="currentUserId"
        :postAuthorId="postAuthorId"
      />
    </div>
  </div>

  <div v-if="previewVisible" class="image-preview-modal" @click="closePreview">
    <img :src="currentPreview" class="preview-image" @click.stop />
    <button class="close-btn" @click.stop="closePreview">X</button>
  </div>
</template>

<style scoped>
  /* 原有的样式保留... */
  .comment-item {
    padding: 1rem;
    border-radius: 12px;
    background: rgba(15, 23, 42, 0.04);
  }

  .comment-item__children {
    margin-top: 1rem;
    padding-left: 1.5rem;
    border-left: 2px solid rgba(124, 58, 237, 0.2);
  }

  .comment-item__children>.comment-list>li>.comment-item {
    background: none;
  }
  
  /* 调整 header 布局 */
  .comment-item__header {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin-bottom: 0.5rem;
  }

  /* 用户头像样式 */
  .user-avatar {
    flex-shrink: 0;
  }

  .avatar-circle {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: linear-gradient(135deg, #6366f1, #8b5cf6);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: 600;
    font-size: 0.875rem;
  }

  /* 用户信息样式 */
  .user-info {
    display: flex;
    flex-direction: column;
  }

  .comment-author {
    font-size: 0.9rem;
    color: #1f2937;
    font-weight: 600;
  }

  .comment-time {
    font-size: 0.75rem;
    color: #9ca3af;
  }

  /* 评论内容样式 */
  .comment-text {
    font-size: 0.95rem;
    line-height: 1.5;
    color: #374151;
    margin-bottom: 0.5rem;
  }

  /* 调整 actions 布局 */
  .comment-item__actions {
    display: flex;
    gap: 0.5rem; 
    margin-top: 0.25rem;
  }

  /* 操作按钮样式 */
  .action-button {
    display: flex;
    align-items: center;
    gap: 0.25rem;
    background: none;
    border: none;
    color: #6b7280;
    font-size: 0.8rem;
    cursor: pointer;
    padding: 0.25rem 0.5rem;
    border-radius: 0.375rem;
    transition: all 0.2s ease;
  }

  .action-button:hover {
    background-color: #f3f4f6;
    color: #1f2937;
  }

  .delete-button:hover {
    background-color: #fee2e2;
    color: #ef4444;
  }

  .action-icon {
    width: 14px;
    height: 14px;
  }

  /* --- 新增样式：图片展示和预览 (保持不变) --- */
  .comment-images {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    /* 图片间的间距 */
    margin-top: 0.5rem;
  }

  .comment-image-thumb {
    width: 80px;
    /* 缩略图大小 */
    height: 80px;
    object-fit: cover;
    /* 保持图片比例裁剪 */
    border-radius: 4px;
    cursor: pointer;
    /* 提示用户可以点击 */
    transition: transform 0.1s;
  }

  .comment-image-thumb:hover {
    transform: scale(1.05);
  }

  /* 预览模态框样式 */
  .image-preview-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background-color: rgba(0, 0, 0, 0.9);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
    /* 确保在最上层 */
  }

  .preview-image {
    max-width: 90%;
    max-height: 90%;
    object-fit: contain;
  }

  .close-btn {
    position: absolute;
    top: 20px;
    right: 20px;
    background: none;
    border: none;
    color: white;
    font-size: 24px;
    cursor: pointer;
  }
</style>