<script lang="ts" setup>
  import type { Comment } from '@/types/models';
  import CommentItem from './CommentItem.vue';

  // 接收一个评论数组和新增的权限 Props
  withDefaults(defineProps<{
    comments: Comment[];
    //  新增：用于向下传递给 CommentItem
    currentUserId?: number;
    postAuthorId?: number;
  }>(), {
    comments: () => [], // 默认值为空数组
  });

  // List 作为一个中转站，需要将事件向上抛出。
  const emit = defineEmits<{
    (e: 'reply', commentId: number): void;
    (e: 'delete', commentId: number): void; //  新增删除事件
  }>();

  const handleReply = (commentId: number) => {
    // 将 CommentItem 触发的回复事件继续向上抛出
    emit('reply', commentId);
  };
  
  //  新增处理删除逻辑
  const handleDelete = (commentId: number) => {
    // 将 CommentItem 触发的删除事件继续向上抛出
    emit('delete', commentId); 
  };
</script>

<template>
  <ul class="comment-list">
    <li v-for="comment in comments" :key="comment.id">
      <CommentItem 
        :comment="comment" 
        @reply="handleReply" 
        @delete="handleDelete"
        :currentUserId="currentUserId"
        :postAuthorId="postAuthorId" 
      />
    </li>
  </ul>
</template>

<style scoped>
  .comment-list {
    margin: 0;
    padding: 0;
    list-style: none;
    display: grid;
    gap: 1.25rem;
    /* 评论之间的垂直间距 */
  }
</style>