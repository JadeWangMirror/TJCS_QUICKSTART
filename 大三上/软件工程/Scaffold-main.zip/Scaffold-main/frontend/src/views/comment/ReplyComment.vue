<script lang="ts" setup>
  import { ref, computed } from 'vue';
  import type { CommentFormPayload } from '@/types/models';
  import { useImageUpload } from '@/hooks/previewAndUploadImage';

  // 接收父组件传递的被回复的评论 ID
  const props = defineProps<{
    pointId: number;
    // 假设父组件可以传递一些额外的显示信息
    replyingToAuthor?: string;
  }>();

  // 定义组件可以触发的事件
  const emit = defineEmits<{
    // 提交回复时触发，将完整的 payload 传递给父组件处理 API
    (e: 'submitReply', payload: CommentFormPayload): void;
    // 取消或关闭弹窗时触发
    (e: 'cancel'): void;
  }>();

  const replyText = ref('');
  const isSubmitting = ref(false);

  // 使用独立的图片上传状态
  const {
    imageItems,
    previewVisible,
    currentPreview,
    handleFileSelect,
    handleDrop,
    removeFile,
    openPreview,
    closePreview,
    getFiles,
    clearAllFiles,
    maxFiles
  } = useImageUpload(3); // 评论最大允许 3 张图片
  const fileInput = ref<HTMLInputElement | null>(null);

  const canSubmit = computed(() => {
    return (replyText.value.trim() !== '' || getFiles().length > 0) && !isSubmitting.value;
  });

  const handleSubmit = (event: Event) => {
    event.preventDefault();

    if (!canSubmit.value) {
      alert('请至少输入回复内容或上传图片！');
      return;
    }

    isSubmitting.value = true;

    // 构建 CommentFormPayload，注意 point_id 由父组件处理
    const payload: CommentFormPayload = {
      context: replyText.value.trim(),
      files: getFiles(),
      point_id: props.pointId, // 确保将回复目标 ID 放入 payload
    };

    // 向上抛出事件，由 PostDetail.vue 调用 API
    emit('submitReply', payload);
  };

  // 暴露一个方法供父组件调用以清理状态和关闭
  const clearState = () => {
    replyText.value = '';
    clearAllFiles();
    isSubmitting.value = false;
  };

  defineExpose({
    clearState
  });
</script>

<template>
  <div class="reply-modal-overlay" @click.self="$emit('cancel')">
    <div class="reply-modal-content">
      <h3>
        回复
        <span class="target-author">{{ replyingToAuthor || '该评论' }}</span>
        的评论
      </h3>

      <form @submit="handleSubmit">
        <textarea rows="4" placeholder="输入回复内容" v-model="replyText"></textarea>

        <div class="reply-upload-area">
          <div class="preview-list">
            <div v-for="(item, index) in imageItems" :key="item.previewUrl" class="preview-item">
              <img :src="item.previewUrl" alt="预览图" @click.stop.prevent="openPreview(item.previewUrl)" />
              <span class="remove-btn" @click.stop.prevent="removeFile(index)">×</span>
            </div>

            <div v-if="imageItems.length < maxFiles" class="upload-slot" @dragover.prevent @drop.prevent="handleDrop"
              @click="fileInput?.click()">
              <span>+</span>
              <input type="file" multiple accept="image/*" ref="fileInput" style="display: none;"
                @change="handleFileSelect" />
            </div>
          </div>
        </div>

        <div class="reply-actions">
          <button type="button" class="cancel-button" @click="$emit('cancel')" :disabled="isSubmitting">取消</button>
          <button type="submit" :disabled="!canSubmit">
            {{ isSubmitting ? '提交中...' : '提交回复' }}
          </button>
        </div>
      </form>
    </div>
  </div>

  <div v-if="previewVisible" class="preview-modal" @click.prevent="closePreview">
    <img :src="currentPreview" alt="放大图" />
  </div>
</template>

<style scoped>

  /* 模态框样式 */
  .reply-modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
  }

  .reply-modal-content {
    background: white;
    padding: 2rem;
    border-radius: 12px;
    width: 90%;
    max-width: 600px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
  }

  .reply-modal-content h3 {
    margin-top: 0;
    border-bottom: 1px solid #eee;
    padding-bottom: 10px;
  }

  .target-author {
    color: #4c1d95;
    font-weight: bold;
  }

  .reply-modal-content form {
    display: grid;
    gap: 1rem;
  }

  .reply-modal-content textarea {
    border-radius: 8px;
    border: 1px solid #ccc;
    padding: 0.75rem;
    resize: vertical;
  }

  .reply-actions {
    display: flex;
    justify-content: flex-end;
    gap: 0.75rem;
  }

  .reply-actions button {
    padding: 0.6rem 1.5rem;
    border-radius: 8px;
    border: none;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s;
  }

  .reply-actions button[type="submit"] {
    background: #7c3aed;
    color: white;
  }

  .reply-actions button.cancel-button {
    background: #eee;
    color: #333;
  }

  /* 图片上传区域样式 (可以从 PostDetail.vue 搬运) */
  .reply-upload-area {
    padding-top: 0.5rem;
  }

  .preview-list {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
  }

  .preview-item,
  .upload-slot {
    width: 80px;
    height: 80px;
    border: 2px dashed #ccc;
    border-radius: 8px;
    overflow: hidden;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
  }

  .preview-item img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  .upload-slot span {
    font-size: 20px;
    color: #888;
  }

  .remove-btn {
    position: absolute;
    top: -5px;
    right: 4px;
    color: white;
    background: rgba(0, 0, 0, 0.5);
    border-radius: 50%;
    font-size: 14px;
    cursor: pointer;
    width: 18px;
    height: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
  }


</style>