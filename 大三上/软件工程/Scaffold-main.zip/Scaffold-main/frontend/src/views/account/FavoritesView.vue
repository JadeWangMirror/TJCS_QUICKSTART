<template>
  <section class="favorites-view">
    <header>
      <h1>收藏夹</h1>
      <p>查看你收藏的提示词与生成作品，支持再次调用或取消收藏。</p>
    </header>

    <div class="favorites-view__filters">
      <select>
        <option>全部类型</option>
        <option>提示词</option>
        <option>生成结果</option>
      </select>
      <select>
        <option>按收藏时间排序</option>
        <option>按热度排序</option>
      </select>
      <input type="search" placeholder="搜索收藏内容" />
    </div>

    <div class="favorites-view__grid">
      <article v-for="index in 6" :key="index">
        <h2>收藏案例 {{ index }}</h2>
        <p>
          提示词：未来都市科幻风格，强调冷色调与霓虹灯效果，重点突出主角背影与远景灯光。
        </p>
        <div class="favorites-view__meta">
          <span>标签：AI绘画</span>
          <span>收藏于：2024-09-0{{ index }}</span>
        </div>
        <footer>
          <button type="button">取消收藏</button>
          <RouterLink to="/ai/workbench">使用提示词</RouterLink>
        </footer>
      </article>
    </div>
  </section>
</template>

<style scoped>
.favorites-view {
  display: grid;
  gap: 1.75rem;
}

header h1 {
  margin: 0;
  font-size: 1.8rem;
}

header p {
  margin: 0.5rem 0 0;
  color: #475569;
}

.favorites-view__filters {
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
}

select,
input[type='search'] {
  padding: 0.6rem 1rem;
  border-radius: 12px;
  border: 1px solid rgba(148, 163, 184, 0.6);
}

.favorites-view__grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 1.5rem;
}

article {
  background: #ffffff;
  border-radius: 18px;
  padding: 1.5rem;
  display: grid;
  gap: 0.75rem;
  box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08);
}

h2 {
  margin: 0;
  font-size: 1.2rem;
  color: #312e81;
}

p {
  margin: 0;
  color: #475569;
}

.favorites-view__meta {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  color: #64748b;
  font-size: 0.9rem;
}

footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

footer button {
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 10px;
  background: rgba(239, 68, 68, 0.12);
  color: #b91c1c;
}

footer a {
  color: #4c1d95;
  font-weight: 600;
}
</style>
