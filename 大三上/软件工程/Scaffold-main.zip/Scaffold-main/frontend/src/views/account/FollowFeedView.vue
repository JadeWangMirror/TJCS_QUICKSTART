<template>
  <section class="follow-feed">
    <header>
      <h1>关注动态</h1>
      <p>查看你关注的创作者最新发布、迭代或互动信息。</p>
    </header>

    <ul class="follow-feed__list">
      <li v-for="index in 5" :key="index">
        <div class="follow-feed__avatar" aria-hidden="true">LN</div>
        <div class="follow-feed__content">
          <h2>灵感猎人 · 发布新帖子</h2>
          <p>
            分享提示词《自然语言写作助手》，包含迭代记录与不同模型参数设置。邀请你一起完善。
          </p>
          <div class="follow-feed__meta">
            <span>10 分钟前</span>
            <RouterLink to="/posts/123">查看帖子</RouterLink>
          </div>
        </div>
      </li>
    </ul>
  </section>
</template>

<style scoped>
.follow-feed {
  display: grid;
  gap: 1.75rem;
}

header h1 {
  margin: 0;
  font-size: 1.8rem;
}

header p {
  margin: 0.5rem 0 0;
  color: #475569;
}

.follow-feed__list {
  margin: 0;
  padding: 0;
  list-style: none;
  display: grid;
  gap: 1.2rem;
}

.follow-feed__list li {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 1rem;
  background: #ffffff;
  border-radius: 18px;
  padding: 1.25rem;
  box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08);
}

.follow-feed__avatar {
  width: 56px;
  height: 56px;
  border-radius: 50%;
  background: rgba(79, 70, 229, 0.12);
  display: flex;
  align-items: center;
  justify-content: center;
  color: #4c1d95;
  font-weight: 700;
}

.follow-feed__content h2 {
  margin: 0;
  font-size: 1.1rem;
}

.follow-feed__content p {
  margin: 0.4rem 0;
  color: #475569;
}

.follow-feed__meta {
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: #64748b;
}

.follow-feed__meta a {
  color: #4c1d95;
  font-weight: 600;
}
</style>
