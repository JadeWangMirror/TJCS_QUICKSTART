<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref, watch, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/store'
import { userService } from '@/services/user.service'
import { authService } from '@/services/auth.service'
import { useRecommendationStore } from '@/store/modules/recommendation'
import type { UserSummary } from '@/types/models'

// --- 类型定义 ---
interface PostItem {
  id: number
  title: string
  author: string // 假设后端返回的是用户名字符串
  author_avatar?: string // 假设后端可能返回头像URL
  image_urls?: string[]
  cover_image?: string
  like_count?: number
  created_at?: string
  [key: string]: any
}

// --- 核心逻辑 ---
const router = useRouter()
const authStore = useAuthStore()
const userPostsStore = useRecommendationStore()

const profile = ref<UserSummary | null>(null)
const isLoading = ref(false)
const errorMessage = ref<string | null>(null)

const userId = computed(() => authStore.currentUser?.id)

// 工具函数
const formatNumber = (num: number) => num >= 1000 ? (num / 1000).toFixed(1) + 'k' : num.toString()
const getInitials = (name: string) => (name ? name.charAt(0).toUpperCase() : 'U')
const getThumb = (item: PostItem) => item?.image_urls?.[0] ?? item?.cover_image ?? null
const getLikeCount = (item: PostItem) => item.like_count || 0

// 数据加载
const loadData = async () => {
  if (!userId.value) return
  isLoading.value = true
  try {
    const [userRes] = await Promise.all([
      userService.getUserProfile(userId.value),
      userPostsStore.fetchFeed('my', { page: 1, pageSize: 6 }).catch(() => {})
    ])
    if (userRes.success && userRes.user) profile.value = userRes.user
    else throw new Error(userRes.message || '用户数据加载失败')
  } catch (err: any) { errorMessage.value = err?.message } finally { isLoading.value = false }
}

// 登出逻辑
const handleLogout = async () => {
  if (!confirm('确认退出登录？')) return
  try { await authStore.logout() } finally { router.push('/auth/login') }
}

// 修改密码逻辑 (简化版)
const useChangePassword = () => {
  const showModal = ref(false)
  const isSending = ref(false)
  const isSubmitting = ref(false)
  const countdown = ref(0)
  let timer: number | null = null
  const form = reactive({ email: '', code: '', newPassword: '', confirmPassword: '' })
  const msg = reactive({ error: '', success: '' })

  const openModal = () => { 
    form.email = profile.value?.email || ''; showModal.value = true 
    msg.error = ''; msg.success = ''
  }
  const closeModal = () => { showModal.value = false; if (timer) clearInterval(timer) }
  
  // 模拟发送与提交 (需对接真实API)
  const sendCode = async () => { /* 逻辑省略，保持原有结构 */ }
  const submit = async () => { /* 逻辑省略，保持原有结构 */ }
  
  onUnmounted(() => { if (timer) clearInterval(timer) })
  return { showModal, form, msg, isSending, isSubmitting, countdown, openModal, closeModal, sendCode, submit }
}
const pwdLogic = useChangePassword()

const avatarInitial = computed(() => profile.value?.name?.charAt(0).toUpperCase() || 'U')

onMounted(loadData)
watch(userId, (id) => { if(id) loadData() })
</script>

<template>
  <div class="profile-view">
    <!-- Loading -->
    <div v-if="isLoading" class="loading-overlay"><div class="spinner"></div></div>
    
    <template v-else-if="profile">
      <!-- 1. Hero 区域 -->
      <header class="profile-hero">
        <div class="hero-bg-glow"></div>
        <div class="hero-content">
          <div class="profile-info">
            <div class="avatar-wrapper">
              <img v-if="profile.avatarUrl" :src="profile.avatarUrl" class="avatar-img" />
              <div v-else class="avatar-placeholder">{{ avatarInitial }}</div>
              <div class="status-dot"></div>
            </div>
            
            <div class="text-info">
              <div class="badges"><span class="hero-badge">LV.{{ Math.floor((profile.followers || 0) / 100) + 1 }} Creator</span></div>
              <h1>Hello, <span class="text-gradient">{{ profile.name }}</span></h1>
              <p class="bio">{{ profile.introduce || '暂无个人介绍' }}</p>
              <div class="hero-actions">
                <button @click="pwdLogic.openModal" class="btn btn-primary">安全设置</button>
                <button @click="handleLogout" class="btn btn-secondary">退出登录</button>
              </div>
            </div>
          </div>

          <div class="stats-visual">
            <div class="stat-card card-1">
              <div class="stat-num">{{ formatNumber(profile.followers || 0) }}</div>
              <div class="stat-label">Followers</div>
            </div>
            <div class="stat-card card-2">
              <div class="stat-num">{{ formatNumber(profile.following || 0) }}</div>
              <div class="stat-label">Following</div>
            </div>
          </div>
        </div>
      </header>

      <!-- 2. Bento Grid 布局 -->
      <div class="bento-grid">
        
        <!-- 左侧：主要作品流 -->
        <main class="main-column">
          <article class="card feed-card">
            <header class="card-header">
              <div class="header-title">
                <h2>我的作品库</h2>
                <span class="subtitle">My Masterpieces</span>
              </div>
            </header>
            
            <div class="gallery-grid" v-if="userPostsStore.feed?.posts?.length">
              <div 
                v-for="item in userPostsStore.feed.posts" 
                :key="item.id" 
                class="post-item group"
                @click="router.push(`/posts/${item.id}`)"
              >
                <!-- 封面图 -->
                <div class="post-thumb">
                  <img v-if="getThumb(item)" :src="getThumb(item)!" loading="lazy" />
                  <div v-else class="no-img">AI</div>
                </div>
                
                <!-- 卡片内容 -->
                <div class="post-content">
                  <h3 class="post-title">{{ item.title }}</h3>
                  
                  <div class="post-footer">
                    <!-- 左下角：用户头像与昵称 -->
                    <div class="author-info">
                      <div class="mini-avatar">
                        {{ getInitials(item.author) }}
                      </div>
                      <span class="author-name">{{ item.author }}</span>
                    </div>

                    <!-- 右下角：点赞 -->
                    <div class="likes-info">
                      <svg class="heart-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                      <span>{{ formatNumber(getLikeCount(item)) }}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div v-else class="empty-state">
              <p>暂无作品，去发布你的第一个灵感吧！</p>
            </div>
          </article>
        </main>

        <!-- 右侧：侧边栏 (已去除 Tag，增加 Latest) -->
        <aside class="sidebar-column">
          <article class="card highlight-card">
            <header class="card-header">
              <h2>快捷导航</h2>
            </header>
            <ul class="action-list">
              <!-- 历史记录 -->
              <li>
                <RouterLink to="/ai/history" class="action-link">
                  <div class="icon-box purple">史</div>
                  <div>
                    <strong>生成历史</strong>
                    <span>查看 AI 创作记录</span>
                  </div>
                </RouterLink>
              </li>
              <!-- 热门话题 -->
              <li>
                <RouterLink to="/recommendations/trending" class="action-link">
                  <div class="icon-box blue">热</div>
                  <div>
                    <strong>热门话题</strong>
                    <span>全站最火内容</span>
                  </div>
                </RouterLink>
              </li>
              <!-- 新增：最新发布 -->
              <li>
                <RouterLink to="/recommendations/latest" class="action-link">
                  <div class="icon-box green">新</div>
                  <div>
                    <strong>最新发布</strong>
                    <span>刚刚更新的灵感</span>
                  </div>
                </RouterLink>
              </li>
            </ul>
          </article>
        </aside>

      </div>
    </template>

    <!-- Modal 部分保持不变，省略以节省长度 -->
    <div v-if="pwdLogic.showModal.value" class="modal-backdrop" @click.self="pwdLogic.closeModal">
        <!-- 这里的弹窗代码和上一个版本一致 -->
    </div>
  </div>
</template>

<style scoped>
/* 
  SaaS Light Theme Style
*/
.profile-view {
  --primary: #6366f1;
  --primary-dark: #4f46e5;
  --secondary: #8b5cf6;
  --bg-color: #f8fafc;
  --card-bg: #ffffff;
  --text-main: #1e293b;
  --text-sub: #64748b;
  --border-color: rgba(226, 232, 240, 0.8);
  --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
  --shadow-glow: 0 20px 25px -5px rgba(99, 102, 241, 0.15);
  
  font-family: 'Inter', system-ui, sans-serif;
  color: var(--text-main);
  background: var(--bg-color);
  min-height: 100vh;
  padding: 20px;
}

/* ================= Hero / Header ================= */
.profile-hero {
  position: relative; max-width: 1200px; margin: 0 auto 2rem;
  border-radius: 24px; background: #ffffff; padding: 3rem;
  box-shadow: var(--shadow-glow); border: 1px solid white;
  overflow: hidden; animation: fadeInUp 0.8s ease-out;
}
.hero-bg-glow {
  position: absolute; top: -50%; left: -20%; width: 80%; height: 200%;
  background: radial-gradient(circle, rgba(99,102,241,0.12) 0%, transparent 70%);
  filter: blur(80px); pointer-events: none;
}
.hero-content { position: relative; display: flex; justify-content: space-between; align-items: center; }
.profile-info { display: flex; align-items: center; gap: 2rem; }

/* Avatar */
.avatar-wrapper { position: relative; width: 110px; height: 110px; flex-shrink: 0; }
.avatar-img, .avatar-placeholder { width: 100%; height: 100%; border-radius: 50%; border: 4px solid #fff; box-shadow: 0 4px 10px rgba(0,0,0,0.1); object-fit: cover; }
.avatar-placeholder { background: #e0e7ff; color: var(--primary); display: flex; align-items: center; justify-content: center; font-size: 2.5rem; font-weight: 700; }
.status-dot { position: absolute; bottom: 5px; right: 5px; width: 18px; height: 18px; background: #10b981; border: 3px solid #fff; border-radius: 50%; }

/* Info Text */
.text-info h1 { font-size: 2.2rem; font-weight: 800; margin: 0.5rem 0; color: var(--text-main); }
.text-gradient { background: linear-gradient(135deg, #6366f1, #a855f7); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.hero-badge { background: rgba(99,102,241,0.1); color: var(--primary); padding: 4px 10px; border-radius: 20px; font-size: 0.75rem; font-weight: 700; }
.bio { color: var(--text-sub); margin-bottom: 1.5rem; max-width: 480px; }
.hero-actions { display: flex; gap: 1rem; }

/* Buttons */
.btn { padding: 0.7rem 1.4rem; border-radius: 10px; font-weight: 600; cursor: pointer; border: none; transition: all 0.2s; font-size: 0.9rem; }
.btn-primary { background: var(--primary); color: white; box-shadow: 0 4px 10px rgba(99,102,241,0.3); }
.btn-primary:hover { transform: translateY(-2px); background: var(--primary-dark); }
.btn-secondary { background: white; color: var(--text-sub); border: 1px solid var(--border-color); }
.btn-secondary:hover { border-color: var(--primary); color: var(--primary); }

/* Stats Right */
.stats-visual { display: flex; gap: 15px; }
.stat-card { background: white; padding: 1rem 1.5rem; border-radius: 14px; box-shadow: 0 4px 20px rgba(0,0,0,0.04); border: 1px solid #f1f5f9; text-align: center; min-width: 90px; }
.stat-num { font-size: 1.4rem; font-weight: 800; color: var(--text-main); }
.stat-label { font-size: 0.75rem; color: var(--text-sub); text-transform: uppercase; margin-top: 4px; }

/* ================= Bento Grid ================= */
.bento-grid { max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: 1fr; gap: 1.5rem; }
@media (min-width: 900px) { .bento-grid { grid-template-columns: 1fr 320px; } }

.card { background: var(--card-bg); border-radius: 20px; border: 1px solid var(--border-color); padding: 1.5rem; box-shadow: var(--shadow-sm); }
.card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; }
.card-header h2 { font-size: 1.2rem; font-weight: 700; margin: 0; }
.subtitle { font-size: 0.85rem; color: var(--text-sub); margin-left: 8px; font-weight: 400; }

/* ================= Post Card (Modified) ================= */
.gallery-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1.5rem; }

.post-item {
  background: #f8fafc; border-radius: 16px; overflow: hidden; border: 1px solid transparent;
  transition: all 0.3s ease; cursor: pointer; display: flex; flex-direction: column;
}
.post-item:hover { background: white; border-color: var(--primary); box-shadow: var(--shadow-lg); transform: translateY(-5px); }

.post-thumb { height: 180px; background: #e2e8f0; overflow: hidden; display: flex; align-items: center; justify-content: center; position: relative; }
.post-thumb img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s; }
.post-item:hover .post-thumb img { transform: scale(1.05); }
.no-img { font-size: 2rem; font-weight: 800; color: #cbd5e1; }

.post-content { padding: 1rem; flex: 1; display: flex; flex-direction: column; justify-content: space-between; }
.post-title { font-size: 1rem; font-weight: 600; color: var(--text-main); margin: 0 0 12px; line-height: 1.4; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }

/* 底部栏：左侧用户，右侧点赞 */
.post-footer { display: flex; justify-content: space-between; align-items: center; padding-top: 8px; border-top: 1px dashed rgba(0,0,0,0.05); margin-top: auto; }

/* 用户信息 */
.author-info { display: flex; align-items: center; gap: 8px; }
.mini-avatar { 
  width: 24px; height: 24px; border-radius: 50%; 
  background: linear-gradient(135deg, #e0e7ff, #c7d2fe); 
  color: var(--primary); font-size: 10px; font-weight: 700;
  display: flex; align-items: center; justify-content: center;
}
.author-name { font-size: 0.85rem; font-weight: 500; color: var(--text-main); }

/* 点赞信息 */
.likes-info { display: flex; align-items: center; gap: 4px; font-size: 0.85rem; color: var(--text-sub); font-weight: 500; }
.heart-icon { width: 16px; height: 16px; transition: color 0.3s; }
.post-item:hover .heart-icon { color: #ef4444; fill: #ef4444; }
.post-item:hover .likes-info { color: #ef4444; }

/* ================= Sidebar ================= */
.action-list { list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 0.8rem; }
.action-link {
  display: flex; align-items: center; gap: 12px; text-decoration: none; padding: 10px;
  border-radius: 12px; transition: all 0.2s; background: white; border: 1px solid transparent;
}
.action-list li:hover .action-link { border-color: var(--primary); box-shadow: 0 4px 12px rgba(99,102,241,0.1); transform: translateX(4px); }

.icon-box {
  width: 38px; height: 38px; border-radius: 10px; display: flex; align-items: center; justify-content: center;
  font-size: 1.1rem; font-weight: 700; flex-shrink: 0;
}
.purple { background: #f3e8ff; color: #a855f7; }
.blue { background: #dbeafe; color: #3b82f6; }
.green { background: #d1fae5; color: #10b981; } /* 新增的绿色 */

.action-link strong { display: block; font-size: 0.95rem; color: var(--text-main); margin-bottom: 2px; }
.action-link span { font-size: 0.75rem; color: var(--text-sub); }

/* Animation */
@keyframes fadeInUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }

/* Mobile */
@media (max-width: 900px) {
  .hero-content { flex-direction: column; text-align: center; gap: 2rem; }
  .profile-info { flex-direction: column; }
  .bento-grid { grid-template-columns: 1fr; }
}
</style>
