<template>
  <section class="generation-archive">
    <header>
      <h1>生成历史归档</h1>
      <p>系统自动记录每一次提示词生成的结果、参数与模型版本。</p>
    </header>

    <div class="generation-archive__toolbar">
      <select>
        <option>全部模型</option>
        <option>文字生成</option>
        <option>图像生成</option>
      </select>
      <select>
        <option>按时间倒序</option>
        <option>按评分排序</option>
      </select>
      <button type="button">导出记录</button>
    </div>

    <table class="generation-archive__table">
      <thead>
        <tr>
          <th>生成时间</th>
          <th>提示词摘要</th>
          <th>模型配置</th>
          <th>状态</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="index in 6" :key="index">
          <td>2024-09-0{{ index }} 18:3{{ index }}</td>
          <td>品牌文案 · 夏日促销主题</td>
          <td>GPT-4o · 温度 0.7</td>
          <td><span class="status status--success">已发布</span></td>
          <td>
            <RouterLink to="/ai/workbench">继续生成</RouterLink>
          </td>
        </tr>
      </tbody>
    </table>
  </section>
</template>

<style scoped>
.generation-archive {
  display: grid;
  gap: 1.75rem;
}

header h1 {
  margin: 0;
  font-size: 1.8rem;
}

header p {
  margin: 0.5rem 0 0;
  color: #475569;
}

.generation-archive__toolbar {
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
}

select,
button {
  padding: 0.6rem 1rem;
  border-radius: 12px;
  border: 1px solid rgba(148, 163, 184, 0.6);
}

button {
  background: rgba(79, 70, 229, 0.08);
  color: #4c1d95;
  font-weight: 600;
}

.generation-archive__table {
  width: 100%;
  border-collapse: collapse;
  background: #ffffff;
  border-radius: 18px;
  overflow: hidden;
  box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08);
}

thead {
  background: rgba(79, 70, 229, 0.08);
  color: #312e81;
}

th,
td {
  padding: 1rem 1.25rem;
  text-align: left;
  border-bottom: 1px solid rgba(148, 163, 184, 0.2);
}

tbody tr:last-child td {
  border-bottom: none;
}

.status {
  padding: 0.25rem 0.75rem;
  border-radius: 999px;
  font-size: 0.85rem;
}

.status--success {
  background: rgba(16, 185, 129, 0.12);
  color: #047857;
}

@media (max-width: 768px) {
  .generation-archive__table {
    display: block;
    overflow-x: auto;
  }
}
</style>
