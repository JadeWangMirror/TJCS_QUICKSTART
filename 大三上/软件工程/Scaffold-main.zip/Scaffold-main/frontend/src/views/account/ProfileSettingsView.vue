<script setup lang="ts">
import { onMounted, reactive, ref, watch } from 'vue'
import { useAuthStore } from '@/store'
import { userService } from '@/services/user.service'
import type { UserSummary } from '@/types/models'

interface ProfileFormState {
  introduce: string
  tagsText: string
}

const authStore = useAuthStore()
const profile = ref<UserSummary | null>(null)
const isLoading = ref(false)
const isSubmitting = ref(false)
const submitMessage = ref<string | null>(null)
const submitError = ref<string | null>(null)

const form = reactive<ProfileFormState>({
  introduce: '',
  tagsText: '',
})

const parseTags = (raw: string) => {
  return raw
    .split(/[,，\s]+/)
    .map((tag) => tag.trim())
    .filter(Boolean)
}

const fillForm = (user: UserSummary) => {
  form.introduce = user.introduce ?? ''
  form.tagsText = user.tag?.join(', ') ?? ''
}

const loadProfile = async () => {
  if (!authStore.tokens) {
    profile.value = null
    return
  }

  isLoading.value = true
  submitError.value = null
  submitMessage.value = null

  try {
    const { success, user, message } = await userService.getCurrentUserProfile()

    if (!success || !user) {
      submitError.value = message || '获取用户信息失败，请稍后再试'
      profile.value = null
      return
    }

    profile.value = user
    fillForm(user)
  } catch (error) {
    const fallbackMessage = '获取用户信息失败，请稍后再试'
    if (typeof error === 'object' && error !== null && 'message' in error) {
      submitError.value = (error as { message?: string }).message || fallbackMessage
    } else {
      submitError.value = fallbackMessage
    }
  } finally {
    isLoading.value = false
  }
}

const handleSubmit = async () => {
  if (!profile.value?.id) return

  isSubmitting.value = true
  submitError.value = null
  submitMessage.value = null

  const payload = {
    introduce: form.introduce.trim(),
    tag: parseTags(form.tagsText),
  }

  try {
    const response = await userService.updateUserProfile(profile.value.id, payload)
    if (!response.success) {
      submitError.value = response.message || '保存失败，请稍后重试'
      return
    }

    submitMessage.value = response.message || '用户信息更新成功'
    profile.value = {
      ...profile.value,
      introduce: payload.introduce,
      tag: payload.tag,
    }
    fillForm(profile.value)
  } catch (error) {
    const fallbackMessage = '保存失败，请稍后重试'
    if (typeof error === 'object' && error !== null && 'message' in error) {
      submitError.value = (error as { message?: string }).message || fallbackMessage
    } else {
      submitError.value = fallbackMessage
    }
  } finally {
    isSubmitting.value = false
  }
}

onMounted(loadProfile)

watch(
  () => authStore.tokens,
  () => {
    loadProfile()
  },
)
</script>

<template>
  <section class="profile-settings">
    <header>
      <h1>个人资料设置</h1>
      <p>更新个人简介与技能标签，帮助更多人了解你。</p>
    </header>

    <div v-if="isLoading" class="profile-settings__state">加载用户信息…</div>
    <form v-else class="profile-settings__form" @submit.prevent="handleSubmit">
      <fieldset>
        <legend>基础信息</legend>
        <label>
          <span>昵称</span>
          <input
            type="text"
            :value="profile?.name || ''"
            placeholder="创作者昵称"
            disabled
          />
        </label>
        <label>
          <span>个人简介</span>
          <textarea
            v-model="form.introduce"
            rows="4"
            placeholder="向社区介绍你自己"
          ></textarea>
        </label>
      </fieldset>

      <fieldset>
        <legend>标签设置</legend>
        <label>
          <span>技能 / 兴趣标签</span>
          <input
            v-model="form.tagsText"
            type="text"
            placeholder="例如：Python, JavaScript, Vue"
          />
          <small>使用逗号或空格分隔多个标签。</small>
        </label>
      </fieldset>

      <div v-if="submitMessage" class="profile-settings__feedback profile-settings__feedback--success">
        {{ submitMessage }}
      </div>
      <div v-if="submitError" class="profile-settings__feedback profile-settings__feedback--error">
        {{ submitError }}
      </div>

      <div class="profile-settings__actions">
        <button type="submit" :disabled="isSubmitting">
          {{ isSubmitting ? '保存中…' : '保存修改' }}
        </button>
        <button type="reset" class="ghost" :disabled="isSubmitting" @click="profile && fillForm(profile)">
          重置
        </button>
      </div>
    </form>
  </section>
</template>

<style scoped>
.profile-settings {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

header h1 {
  margin: 0;
  font-size: 1.8rem;
}

header p {
  margin: 0.5rem 0 0;
  color: #475569;
}

.profile-settings__state {
  padding: 2rem;
  text-align: center;
  color: #475569;
  background: rgba(148, 163, 184, 0.12);
  border-radius: 18px;
}

.profile-settings__form {
  display: grid;
  gap: 1.75rem;
}

fieldset {
  border: 1px solid rgba(148, 163, 184, 0.36);
  border-radius: 18px;
  padding: 1.5rem;
  display: grid;
  gap: 1rem;
}

legend {
  padding: 0 0.5rem;
  font-weight: 600;
  color: #312e81;
}

label {
  display: grid;
  gap: 0.5rem;
  font-weight: 500;
}

input,
textarea {
  padding: 0.75rem 1rem;
  border-radius: 12px;
  border: 1px solid rgba(148, 163, 184, 0.6);
  resize: vertical;
  font: inherit;
}

input:disabled {
  background: rgba(248, 250, 252, 0.8);
  color: #94a3b8;
  cursor: not-allowed;
}

small {
  color: #64748b;
}

.profile-settings__feedback {
  padding: 0.75rem 1rem;
  border-radius: 12px;
  font-size: 0.95rem;
}

.profile-settings__feedback--success {
  background: rgba(34, 197, 94, 0.16);
  color: #166534;
}

.profile-settings__feedback--error {
  background: rgba(248, 113, 113, 0.18);
  color: #b91c1c;
}

.profile-settings__actions {
  display: flex;
  gap: 1rem;
}

.profile-settings__actions button {
  padding: 0.75rem 2rem;
  border-radius: 12px;
  border: none;
  font-weight: 600;
  transition: opacity 0.2s ease;
}

.profile-settings__actions button[disabled] {
  opacity: 0.6;
  cursor: not-allowed;
}

.profile-settings__actions button:first-child {
  background: linear-gradient(120deg, #7c3aed, #4c1d95);
  color: #fff;
}

.profile-settings__actions .ghost {
  background: rgba(15, 23, 42, 0.04);
  color: #334155;
}

@media (max-width: 640px) {
  .profile-settings__actions {
    flex-direction: column;
  }
}
</style>
