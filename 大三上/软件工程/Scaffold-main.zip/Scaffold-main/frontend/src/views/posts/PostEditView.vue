<script lang="ts" setup>
  import { storeToRefs } from 'pinia';
  import { ref, computed, toRaw, watch, onUnmounted } from 'vue';
  import { usePostStore } from '@/store/modules/posts';
  import type { PostFormPayload } from '@/types/models';
  import { useRouter, useRoute } from 'vue-router';
  import { useToast } from '@/composables/useToast';
  import CustomToast from '@/components/common/CustomToast.vue';
  import type { PostDetailWithStatus } from '@/types/models';
  const postStore = usePostStore();
  const router = useRouter();
  const route = useRoute()
  const toast = useToast();
  const { selectedPost, isFetchingDetail } = storeToRefs(postStore);
  const post = computed<PostDetailWithStatus | null>(() => selectedPost.value);

  // ----------------------
  // 状态定义 (表单数据)
  // ----------------------

  const form = ref<PostFormPayload>({
    // 关键字段初始化
    title: '',
    context: '',
    tags: [],
    isShareable: true,
    status: "draft",
    url_list:[],
    files:[]
  });

  // ----------------------
  // 状态定义 (图片管理) 
  // ----------------------

  // 1. 定义统一的图片项类型
  type ImageItem = { type: 'old', url: string } | { type: 'new', file: File, previewUrl: string };

  // 2. 使用这个新 ref 替换 previews、form.files 和 form.oldUrls
  const imageItems = ref<ImageItem[]>([]);

  // (其他状态)
  const currentTagInput = ref('');
  const recommendedTags = ref(['#AI绘画', '#营销文案', '#创意写作', '#模型调优']);
  const isSubmitting = computed(() => postStore.loading);
  const fileInput = ref<HTMLInputElement | null>(null);

  // (预览模态框状态)
  const previewVisible = ref(false);
  const currentPreview = ref('');

  /**
    * 添加标签到 form.tags 数组中
    */
  const addTag = (tag: string) => {
    const trimmedTag = tag.trim().replace(/^#/, ''); // 移除可能的 #
    if (trimmedTag && !form.value.tags.includes(trimmedTag) && form.value.tags.length < 5) {
      form.value.tags.push(trimmedTag);
    }
    currentTagInput.value = ''; // 清空输入框
  };

  /**
    * 移除已添加的标签
    */
  const removeTag = (tagToRemove: string) => {
    form.value.tags = form.value.tags.filter(tag => tag !== tagToRemove);
  };

  /**
  * 图片上传逻辑
  */
  const handleFileSelect = (event: Event) => {
    const input = event.target as HTMLInputElement;
    if (!input.files) return;

    for (const file of input.files) {
      addFile(file);
    }
    input.value = '';
  };

  const handleDrop = (event: DragEvent) => {
    if (!event.dataTransfer?.files) return;
    for (const file of event.dataTransfer.files) {
      addFile(file);
    }
  };

  /**
   * 添加文件到统一状态
   */
  const addFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('只能上传图片文件！');
      return;
    }
    // 检查 imageItems 的长度
    if (imageItems.value.length >= 9) {
      alert('最多上传 9 张图片');
      return;
    }

    // 添加到 imageItems
    const previewUrl = URL.createObjectURL(file);
    imageItems.value.push({ type: 'new', file: file, previewUrl: previewUrl });
  };

  /**
   * 从统一状态移除文件
   */
  const removeFile = (index: number) => {
    const item = imageItems.value[index];

    // 如果是新文件，释放内存
    if (item) {
      if (item.type === 'new') {
        URL.revokeObjectURL(item.previewUrl);
      }
    }

    // 直接从统一数组中删除
    imageItems.value.splice(index, 1);
  };

  // 打开模态 (不变)
  const openPreview = (src: string) => {
    currentPreview.value = src;
    previewVisible.value = true;
  };

  // 关闭模态 (不变)
  const closePreview = () => {
    previewVisible.value = false;
    currentPreview.value = '';
  };

  /**
   * 提交帖子 (发布)
   */
  const handleSubmit = async () => {
    // 1. 简单的客户端校验
    if (!form.value.title.trim()) {
      alert('标题不能为空！');
      return;
    }
    if (!form.value.context.trim()) {
      alert('内容不能为空！');
      return;
    }

    try {
      const postId = post.value?.id;
      if (!postId) {
        toast.show(`修改失败: 帖子ID丢失`);
        return;
      }

      // --- 核心图片处理逻辑 ---
      for (const item of imageItems.value) {
        if (item.type === 'old') {
          form.value.url_list.push(item.url);
        } else {
          form.value.files.push(item.file);
        }
      }
      const result = await postStore.updatePost(postId, form.value);
      if (result?.success) {
        toast.show('帖子修改成功！');
        router.push(`/posts/${post.value?.id}`);
      } else {
        // 失败提示
        toast.show(`修改失败: ${result?.message || '服务器错误'}`);
      }
    } catch (error) {
      if (error instanceof Error && error.message === "User not authenticated.") {
        router.push('/auth/login')
      } else {
        // 其他网络或运行时错误
        toast.show(`发布过程中发生错误:${error}，请稍后重试`,);
        console.error(error);
      }
    }
  };

  /**
   * 获取帖子数据并填充表单和图片
   */
  const fetchPost = async (idParam: string | string[]) => {
    const routePostId = Array.isArray(idParam) ? idParam[0] : idParam;
    const postId = routePostId ? parseInt(routePostId as string) : null;

    if (postId && !isNaN(postId)) {
      await postStore.fetchPostDetail(postId);

      // 确保 post.value 有数据后再填充
      if (post.value) {
        // 1. 填充表单
        form.value.title = post.value.title;
        form.value.context = post.value.context;
        form.value.tags = [...post.value.tags]; // 使用扩展运算符创建新数组
        // 2. 填充图片
        const urlList = post.value.url_list || [];
        imageItems.value = urlList.map(url => ({ type: 'old' as const, url: url }));
      } else {
        console.error("Error: Fetched post data is null.");
      }

    } else if (routePostId) {
      console.error("Error: Invalid postId in route parameters.");
    }
  };

  watch(
    () => route.params.id,
    (newId) => {
      if (newId) {
        // (可选) 如果切换帖子，清理旧的 blob URL
        imageItems.value.forEach(item => {
          if (item.type === 'new') URL.revokeObjectURL(item.previewUrl);
        });
        // 重置状态
        imageItems.value = [];
        form.value.title = '';
        form.value.context = '';
        form.value.tags = [];

        fetchPost(newId);
      }
    },
    { immediate: true }
  );

  /**
   * 【新增】组件卸载时清理内存
   */
  onUnmounted(() => {
    imageItems.value.forEach(item => {
      if (item.type === 'new') {
        URL.revokeObjectURL(item.previewUrl);
      }
    });
  });
</script>

<template>
  <div v-if="isFetchingDetail">正在加载帖子详情...</div>
  <section class="post-edit" v-else-if="post">
    <header>
      <h1>发布交流帖</h1>
      <p>记录提示词与生成结果，帮助更多创作者获得灵感。</p>
    </header>

    <form class="post-edit__form" @submit.prevent="handleSubmit">

      <label>
        <span>标题 <span style="color: red;">*</span></span>
        <input type="text" placeholder="一句话概述你的创作主题" v-model="form.title" required />
      </label>

      <label>
        <span>提示词内容 <span style="color: red;">*</span></span>
        <textarea rows="4" placeholder="完整提示词（支持 Markdown）" v-model="form.context" required></textarea>
      </label>

      <label class="post-edit__upload">
        <span>上传图片</span>
        <div class="preview-list">

          <div v-for="(item, index) in imageItems" :key="item.type === 'old' ? item.url : item.previewUrl"
            class="preview-item">

            <img :src="item.type === 'old' ? item.url : item.previewUrl" alt="预览图"
              @click.stop.prevent="openPreview(item.type === 'old' ? item.url : item.previewUrl)" />

            <span class="remove-btn" @click.stop.prevent="removeFile(index)">×</span>
          </div>

          <div v-if="previewVisible" class="preview-modal" @click.prevent="closePreview">
            <img :src="currentPreview" alt="放大图" />
          </div>

          <div v-if="imageItems.length < 9" class="upload-slot" @dragover.prevent @drop.prevent="handleDrop">
            <span>+</span>
            <input type="file" multiple accept="image/*" ref="fileInput" style="display: none;"
              @change="handleFileSelect" />
          </div>
        </div>
      </label>

      <fieldset>
        <legend>标签与可见性</legend>
        <div class="post-edit__tags">
          <input type="text" placeholder="添加标签（最多5个），按回车确认" v-model="currentTagInput"
            @keydown.enter.prevent="addTag(currentTagInput)" :disabled="form.tags.length >= 5" />

          <div v-if="form.tags.length">
            <span v-for="tag in form.tags" :key="tag">
              #{{ tag }} <span style="cursor: pointer; font-weight: bold;" @click="removeTag(tag)">×</span>
            </span>
          </div>

          <div>
            <span v-for="(tag, index) in recommendedTags" :key="index" @click="addTag(tag)">
              {{ tag }}
            </span>
          </div>
        </div>

      </fieldset>

      <footer>
        <button type="submit" :disabled="isSubmitting" class="">
          {{ isSubmitting ? '修改中...' : '修改' }}
        </button>

      </footer>
    </form>
  </section>
  <div v-else>要修改的帖子不存在！</div>
  <CustomToast :message="toast.message.value" :visible="toast.isVisible.value" />
</template>

<style scoped>
  .post-edit {
    display: grid;
    gap: 1.75rem;
  }

  header h1 {
    margin: 0;
    font-size: 1.9rem;
  }

  header p {
    margin: 0.4rem 0 0;
    color: #475569;
  }

  .post-edit__form {
    display: grid;
    gap: 1.5rem;
    background: #ffffff;
    padding: 2rem;
    border-radius: 18px;
    box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08);
  }

  label {
    display: grid;
    gap: 0.5rem;
    font-weight: 500;
    transition: color 0.2s;
  }

  /* 针对“允许他人复制”的标签，悬停时改变文本颜色，表示可交互 */
  .post-edit__visibility:hover {
    color: #4c1d95;
    /* 悬停时文本变深 */
    cursor: pointer;
  }


  input,
  textarea {
    border-radius: 12px;
    border: 1px solid rgba(148, 163, 184, 0.6);
    padding: 0.75rem 1rem;
    font-size: 1rem;
  }

  textarea {
    resize: vertical;
  }

  fieldset {
    border: 1px solid rgba(124, 58, 237, 0.25);
    border-radius: 16px;
    padding: 1.25rem;
    display: grid;
    gap: 1rem;
  }

  legend {
    padding: 0 0.5rem;
    font-weight: 600;
    color: #4c1d95;
  }

  .post-edit__tags {
    display: grid;
    gap: 0.75rem;
  }

  .post-edit__tags div {
    display: flex;
    gap: 0.5rem;
    flex-wrap: wrap;
  }

  .post-edit__tags span {
    background: rgba(124, 58, 237, 0.12);
    color: #4c1d95;
    padding: 0.35rem 0.75rem;
    border-radius: 999px;
    font-size: 0.85rem;

    /* 新增：使标签看起来可点击 */
    cursor: pointer;
    transition: background 0.2s, opacity 0.2s;
  }

  .post-edit__tags span:hover {
    background: rgba(124, 58, 237, 0.25);
    /* 悬停时背景变深 */
    opacity: 0.85;
    /* 增加轻微透明度变化 */
  }

  /* 针对已添加标签中的移除按钮 ('×') 的样式优化 */
  .post-edit__tags div:first-child span {
    border: 1px solid transparent;
  }

  /* 悬停在已添加标签上时，增加边框或阴影来突出可移除性（可选） */
  .post-edit__tags div:first-child span:hover {
    background: rgba(220, 38, 38, 0.15);
    /* 移除时可以使用红色调 */
    color: #dc2626;
  }

  /* 特别强调 '×' 的可点击性 */
  .post-edit__tags span span {
    margin-left: 0.25rem;
    font-size: 1em;
  }


  .post-edit__visibility {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-weight: 400;
    color: #475569;
  }

  .preview-list {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
  }

  .preview-item,
  .upload-slot {
    width: 200px;
    height: 200px;
    border: 2px dashed #ccc;
    border-radius: 8px;
    overflow: hidden;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
  }

  .preview-item img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  .remove-btn {
    margin-top: 10px;
    position: absolute;
    top: 4px;
    right: 6px;
    background: rgba(0, 0, 0, 0.5);
    color: white;
    border-radius: 50%;
    width: 20px;
    height: 20px;
    line-height: 18px;
    text-align: center;
    cursor: pointer;
    font-weight: bold;
  }

  .upload-slot span {
    font-size: 40px;
    color: #888;
  }


  .remove-btn {
    position: absolute;
    top: -5px;
    right: 4px;
    color: white;
    background: rgba(0, 0, 0, 0.5);
    border-radius: 50%;
    font-size: 14px;
    cursor: pointer;
    width: 18px;
    height: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .preview-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.8);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 999;
    cursor: zoom-out;
  }

  .preview-modal img {
    max-width: 90%;
    max-height: 90%;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
  }

  footer {
    display: flex;
    gap: 1rem;
  }

  button {
    padding: 0.75rem 1.8rem;
    border-radius: 12px;
    font-weight: 600;
    border: none;
    transition: 0.2s, opacity 0.2s, box-shadow 0.2s;
  }

  button[type='submit'] {
    background: linear-gradient(120deg, #7c3aed, #4c1d95);
    color: #fff;
  }

  button[type='submit']:not(:disabled):hover {
    background: linear-gradient(120deg, #6d28d9, #43148f);
    box-shadow: 0 4px 10px rgba(76, 29, 149, 0.4);
    cursor: pointer;
  }

  button:disabled {
    cursor: not-allowed;
    opacity: 0.6;
  }


  /* 2. 草稿按钮悬停效果 (如果您恢复了草稿按钮) */
  .ghost {
    background: rgba(15, 23, 42, 0.05);
    color: #334155;
  }

  .ghost:not(:disabled):hover {
    background: rgba(15, 23, 42, 0.1);
    /* 悬停时背景色加深 */
    color: #1e293b;
  }

  @media (max-width: 640px) {
    footer {
      flex-direction: column;
    }
  }
</style>