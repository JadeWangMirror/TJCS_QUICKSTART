<template>
  <section class="post-collections">
    <header>
      <h1>收藏的帖子</h1>
      <p>集中呈现收藏夹内所有帖子，支持批量管理。</p>
    </header>

    <div class="post-collections__toolbar">
      <label>
        <input type="checkbox" />
        全选
      </label>
      <button type="button">移除收藏</button>
      <button type="button" class="ghost">加入合集</button>
    </div>

    <ul>
      <li v-for="index in 4" :key="index">
        <label>
          <input type="checkbox" />
          <div>
            <h2>提示词案例 {{ index }}</h2>
            <p>收藏于 2024-09-1{{ index }} · 标签：#AI绘画 #霓虹</p>
          </div>
        </label>
        <RouterLink :to="`/posts/${index}`">查看</RouterLink>
      </li>
    </ul>
  </section>
</template>

<style scoped>
.post-collections {
  display: grid;
  gap: 1.75rem;
}

header h1 {
  margin: 0;
  font-size: 1.9rem;
}

header p {
  margin: 0.4rem 0 0;
  color: #475569;
}

.post-collections__toolbar {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.post-collections__toolbar label {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: 500;
}

.post-collections__toolbar button {
  padding: 0.6rem 1.2rem;
  border-radius: 12px;
  border: none;
  background: rgba(124, 58, 237, 0.1);
  color: #4c1d95;
  font-weight: 600;
}

.ghost {
  background: rgba(15, 23, 42, 0.06);
  color: #334155;
}

ul {
  margin: 0;
  padding: 0;
  list-style: none;
  display: grid;
  gap: 1rem;
}

li {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #ffffff;
  border-radius: 18px;
  padding: 1.25rem;
  box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08);
}

label {
  display: flex;
  gap: 1rem;
  align-items: center;
}

h2 {
  margin: 0;
  font-size: 1.2rem;
  color: #312e81;
}

p {
  margin: 0.35rem 0 0;
  color: #475569;
}

a {
  color: #7c3aed;
  font-weight: 600;
}
</style>
