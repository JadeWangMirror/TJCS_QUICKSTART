<template>
  <section class="tag-explore">
    <header>
      <h1>标签探索</h1>
      <p>发现热门标签与推荐主题，快速定位关注领域的交流帖。</p>
    </header>

    <div class="tag-explore__grid">
      <article v-for="index in 8" :key="index">
        <h2>#标签主题 {{ index }}</h2>
        <p>相关帖子：{{ 10 + index }} · 近期热度：{{ 70 + index }}%</p>
        <div>
          <RouterLink :to="`/posts/tags/${index}`">查看详情</RouterLink>
          <button type="button">关注标签</button>
        </div>
      </article>
    </div>
  </section>
</template>

<style scoped>
.tag-explore {
  display: grid;
  gap: 1.75rem;
}

header h1 {
  margin: 0;
  font-size: 1.9rem;
}

header p {
  margin: 0.4rem 0 0;
  color: #475569;
}

.tag-explore__grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 1.25rem;
}

article {
  background: #ffffff;
  border-radius: 18px;
  padding: 1.5rem;
  display: grid;
  gap: 0.6rem;
  box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08);
}

h2 {
  margin: 0;
  font-size: 1.2rem;
  color: #312e81;
}

p {
  margin: 0;
  color: #475569;
}

div {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

a {
  color: #7c3aed;
  font-weight: 600;
}

button {
  padding: 0.5rem 1rem;
  border-radius: 12px;
  border: none;
  background: rgba(124, 58, 237, 0.08);
  color: #4c1d95;
  font-weight: 600;
}
</style>
