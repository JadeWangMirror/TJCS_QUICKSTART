<template>
  <section class="tag-detail">
    <header>
      <h1>#AI绘画 夜景</h1>
      <p>标签简介：聚焦赛博朋克及夜景相关的提示词与生成案例。</p>
      <div>
        <button type="button">关注标签</button>
        <button type="button" class="ghost">取消关注</button>
      </div>
    </header>

    <h2>相关帖子</h2>
    <ul class="tag-detail__posts">
      <li v-for="index in 5" :key="index">
        <div>
          <h3>赛博都市夜景 {{ index }}</h3>
          <p>作者：旅者 Seven · 点赞 86 · 收藏 32</p>
        </div>
        <RouterLink :to="`/posts/${index}`">查看</RouterLink>
      </li>
    </ul>

    <h2>相关推荐标签</h2>
    <div class="tag-detail__related">
      <RouterLink v-for="tag in ['光影', '写实', '霓虹', '雨夜']" :key="tag" to="/posts/tags">
        #{{ tag }}
      </RouterLink>
    </div>
  </section>
</template>

<style scoped>
.tag-detail {
  display: grid;
  gap: 1.75rem;
}

header h1 {
  margin: 0;
  font-size: 2rem;
  color: #312e81;
}

header p {
  margin: 0.5rem 0;
  color: #475569;
}

header div {
  display: flex;
  gap: 0.75rem;
}

button {
  padding: 0.6rem 1.4rem;
  border-radius: 12px;
  border: none;
  background: linear-gradient(120deg, #7c3aed, #4c1d95);
  color: #fff;
  font-weight: 600;
}

.ghost {
  background: rgba(15, 23, 42, 0.05);
  color: #334155;
}

.tag-detail__posts {
  margin: 0;
  padding: 0;
  list-style: none;
  display: grid;
  gap: 1rem;
}

.tag-detail__posts li {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #ffffff;
  border-radius: 14px;
  padding: 1.25rem;
  box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08);
}

.tag-detail__posts h3 {
  margin: 0;
  font-size: 1.1rem;
}

.tag-detail__posts p {
  margin: 0.35rem 0 0;
  color: #475569;
}

.tag-detail__posts a {
  color: #7c3aed;
  font-weight: 600;
}

.tag-detail__related {
  display: flex;
  gap: 0.75rem;
  flex-wrap: wrap;
}

.tag-detail__related a {
  padding: 0.4rem 0.9rem;
  border-radius: 999px;
  background: rgba(124, 58, 237, 0.1);
  color: #4c1d95;
}
</style>
