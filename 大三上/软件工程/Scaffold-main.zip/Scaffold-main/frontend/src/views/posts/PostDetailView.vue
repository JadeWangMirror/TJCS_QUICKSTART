<script lang="ts" setup>
import { storeToRefs, type StoreGeneric } from 'pinia';
import { computed, watch, ref, nextTick } from 'vue';
import { useRoute, RouterLink } from 'vue-router';
import { usePostStore } from '@/store/modules/posts';
import type { PostDetailWithStatus, CommentFormPayload, Comment } from '@/types/models';
import ImagePreview from '@/components/common/ImagePreview.vue';
import { useAuthStore } from '@/store';
import router from '@/router';
import DeleteButton from '@/components/fancy/DeleteButton.vue';
import CommentList from '@/views/comment/CommentList.vue';
import ReplyCommentForm from '@/views/comment/ReplyComment.vue';
import { useImageUpload } from '@/hooks/previewAndUploadImage';

// --- 图标 SVG ---
const IconHeart = { template: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>` };
const IconHeartFilled = { template: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>` };
const IconStar = { template: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>` };
const IconStarFilled = { template: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>` };
const IconEdit = { template: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>` };
const IconSend = { template: `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>` };
const IconImage = { template: `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>` };

// --- Store & Logic ---
const PostStore = usePostStore();
const route = useRoute();
const { selectedPost, isFetchingDetail, isLikingPost, isFavoritingPost } = storeToRefs(PostStore as StoreGeneric);
const post = computed<PostDetailWithStatus | null>(() => selectedPost?.value);

const AuthStore = useAuthStore();
const { loading: authLoading, currentUser } = storeToRefs(AuthStore as StoreGeneric);
const authReady = computed<boolean>(() => !authLoading!.value && !!currentUser!.value?.id);
const currentUserId = computed(() => currentUser!.value?.id);
const postAuthorId = computed(() => post.value?.author_id);
const isAuthor = computed(() => currentUser!.value && post.value && currentUser!.value.id === post.value.author_id);

// --- 评论 Logic ---
const commentText = ref('');
const replyingToCommentId = ref<number | null>(null);
const replyingToAuthor = ref<string | undefined>(undefined);
const replyFormRef = ref<{ clearState: () => void } | null>(null);

const {
  imageItems,
  previewVisible,
  currentPreview,
  handleFileSelect,
  removeFile,
  openPreview,
  closePreview,
  getFiles,
  clearAllFiles
} = useImageUpload(3);
const fileInput = ref<HTMLInputElement | null>(null);

const handleInputResize = (e: Event) => {
  const target = e.target as HTMLTextAreaElement;
  target.style.height = 'auto';
  target.style.height = target.scrollHeight + 'px';
};

const handleLikePost = async () => { if(post.value) await PostStore.likePost(post.value.id); };
const handleFavoritePost = async () => { if(post.value) await PostStore.favoritePost(post.value.id); };
const handleDeletePost = async () => { if(confirm('确认删除？')) { await PostStore.deletePost(post.value!.id); router.push('/'); } };

const handleComment = async (event: Event) => {
  event.preventDefault();
  if ((!commentText.value.trim() && getFiles().length === 0) || !post.value) return;
  
  const payload: CommentFormPayload = { context: commentText.value.trim(), files: getFiles(), point_id: undefined };
  const res = await PostStore.createComment(payload);
  if (res?.success) {
    commentText.value = ''; clearAllFiles();
    nextTick(() => { const el = document.querySelector('.comment-textarea') as HTMLElement; if(el) el.style.height = 'auto'; });
    fetchPost(post.value.id.toString());
  }
};

const findCommentAuthor = (comments: Comment[], id: number): string | undefined => {
  for (const c of comments) { if(c.id === id) return c.author; if(c.comments?.length) { const f = findCommentAuthor(c.comments, id); if(f) return f; } }
};
const handleReplyEvent = (commentId: number) => {
  replyingToCommentId.value = commentId;
  replyingToAuthor.value = findCommentAuthor(post.value?.comments || [], commentId);
};
const handleSubmitReply = async (payload: CommentFormPayload) => {
  const res = await PostStore.createComment(payload);
  if(res?.success) { replyingToCommentId.value = null; fetchPost(post.value!.id.toString()); }
};
const handleDeleteComment = async (id: number) => {
  const res = await PostStore.deleteComment(id);
  if(res?.success) fetchPost(post.value!.id.toString());
};

const fetchPost = (id: string) => { if(authReady.value) PostStore.fetchPostDetail(parseInt(id)); };
watch(authReady, (r) => { if(r && route.params.id) fetchPost(route.params.id as string); }, { immediate: true });
</script>

<template>
  <div class="post-detail-view">
    <transition name="fade" mode="out-in">
      
      <!-- Skeleton Loading -->
      <div v-if="isFetchingDetail" class="skeleton-container" key="skeleton">
        <div class="sk-banner pulse"></div>
        <div class="sk-content">
          <div class="sk-line pulse w-40"></div>
          <div class="sk-line pulse w-100"></div>
          <div class="sk-line pulse w-100"></div>
          <div class="sk-line pulse w-80"></div>
        </div>
      </div>

      <!-- Main Content -->
      <main v-else-if="post" class="main-content" key="content">
        
        <!-- 1. Article Card (Header + Body) -->
        <article class="article-card">
          
          <!-- Header Banner -->
          <header class="hero-header">
            <!-- 背景图 (可以使用动态 url 或固定图) -->
            <div class="hero-bg" style="background-image: url('https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=2564&auto=format&fit=crop')"></div>
            <div class="hero-overlay"></div>
            
            <div class="hero-content">
              <!-- Tags -->
              <div class="hero-tags" v-if="post.tags?.length">
                <span v-for="tag in post.tags" :key="tag" class="hero-tag">#{{ tag }}</span>
              </div>
              
              <!-- Title -->
              <h1 class="hero-title">{{ post.title }}</h1>
              
              <!-- Author Info -->
              <div class="hero-meta">
                <div class="avatar-ring">
                  <div class="avatar">{{ ((post?.author || "U")[0] || "U").toUpperCase() }}</div>
                </div>
                <div class="meta-text">
                  <span class="author-name">{{ post.author }}</span>
                  <span class="post-time">{{ post.timestamp || '发布于近期' }}</span>
                </div>
              </div>
            </div>
          </header>

          <!-- Body Content -->
          <div class="article-body">
            <div class="content-text">
              {{ post.context }}
            </div>
            
            <!-- Gallery -->
            <div v-if="post.url_list?.length" class="content-gallery">
              <ImagePreview :images="post.url_list" />
            </div>

            <!-- Action Footer -->
            <div class="article-footer">
              <div class="action-buttons">
                <button class="action-btn like-btn" :class="{ active: post.is_liked }" @click="handleLikePost" :disabled="isLikingPost">
                  <component :is="post.is_liked ? IconHeartFilled : IconHeart" />
                  <span>{{ post.like_count || 'Like' }}</span>
                </button>
                
                <button class="action-btn star-btn" :class="{ active: post.is_favorited }" @click="handleFavoritePost" :disabled="isFavoritingPost">
                  <component :is="post.is_favorited ? IconStarFilled : IconStar" />
                  <span>{{ post.is_favorited ? 'Starred' : 'Star' }}</span>
                </button>
              </div>

              <div class="owner-actions" v-if="isAuthor">
                <RouterLink :to="`/posts/${post.id}/edit`" class="text-btn">
                  <component :is="IconEdit" /> 编辑
                </RouterLink>
                <DeleteButton @click="handleDeletePost" class="delete-wrapper" />
              </div>
            </div>
          </div>
        </article>

        <!-- 2. Comments Section -->
        <section class="comments-card">
          <div class="section-header">
            <h3>评论 ({{ post.comment_count }})</h3>
          </div>

          <!-- Input Area -->
          <div class="comment-input-wrapper">
            <!-- Uploaded Previews -->
            <div v-if="imageItems.length" class="preview-row">
              <div v-for="(img, idx) in imageItems" :key="idx" class="preview-thumb">
                <img :src="img.previewUrl" />
                <button class="remove-btn" @click="removeFile(idx)">×</button>
              </div>
            </div>

            <form @submit="handleComment" class="input-form">
              <textarea 
                v-model="commentText" 
                class="comment-textarea"
                rows="1" 
                placeholder="分享你的见解..." 
                @input="handleInputResize"
              ></textarea>
              
              <div class="form-actions">
                <div class="icon-tool" @click="fileInput?.click()" title="添加图片">
                  +
                  <component :is="IconImage" />
                  <input type="file" hidden multiple accept="image/*" ref="fileInput" @change="handleFileSelect" />
                </div>
                <button type="submit" class="submit-btn" :disabled="!commentText && !imageItems.length">
                  ↑
                  <component :is="IconSend" />
                </button>
              </div>
            </form>
          </div>

          <!-- List -->
          <div class="comments-list">
            <CommentList 
              v-if="post.comments?.length" 
              :comments="post.comments" 
              @reply="handleReplyEvent"
              @delete="handleDeleteComment" 
              :currentUserId="currentUserId" 
              :postAuthorId="postAuthorId" 
            />
            <div v-else class="empty-placeholder">
              暂无评论，来抢沙发吧
            </div>
          </div>
        </section>

      </main>
      
      <!-- 404 -->
      <div v-else class="not-found" key="error">
        <h2>帖子不存在</h2>
        <RouterLink to="/" class="back-link">返回首页</RouterLink>
      </div>

    </transition>

    <!-- Global Preview -->
    <div v-if="previewVisible" class="lightbox-overlay" @click="closePreview">
      <img :src="currentPreview" class="lightbox-img" />
    </div>

    <!-- Reply Modal -->
    <ReplyCommentForm 
      v-if="replyingToCommentId" 
      :point-id="replyingToCommentId"
      :replying-to-author="replyingToAuthor" 
      @submit-reply="handleSubmitReply" 
      @cancel="() => { replyingToCommentId = null }"
      ref="replyFormRef"
    />
  </div>
</template>

<style scoped>
/* ================= 全局变量 ================= */
.post-detail-view {
  --primary: #6366f1;
  --primary-rgb: 99, 102, 241;
  --text-main: #1e293b;
  --text-sub: #64748b;
  --bg-page: #f8fafc;
  --bg-card: #ffffff;
  --radius-lg: 24px;
  --shadow-card: 0 10px 30px -10px rgba(0, 0, 0, 0.06);
  --shadow-hover: 0 20px 40px -10px rgba(0, 0, 0, 0.1);
  
  max-width: 900px;
  margin: 0 auto;
  padding: 2rem 1rem 4rem;
  font-family: 'Inter', system-ui, sans-serif;
  color: var(--text-main);
}

/* ================= 1. Article Card ================= */
.article-card {
  background: var(--bg-card);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-card);
  overflow: hidden; /* 让 Header 的背景图圆角生效 */
  margin-bottom: 2rem;
  transition: box-shadow 0.3s ease;
}
.article-card:hover { box-shadow: var(--shadow-hover); }

/* --- Hero Header (With Background) --- */
.hero-header {
  position: relative;
  height: 280px; /* 调整高度 */
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  padding: 2.5rem;
  color: white;
}

.hero-bg {
  position: absolute; inset: 0;
  background-size: cover; background-position: center;
  z-index: 1;
}

.hero-overlay {
  position: absolute; inset: 0;
  background: linear-gradient(to bottom, rgba(0,0,0,0.1), rgba(0,0,0,0.7));
  z-index: 2;
  backdrop-filter: blur(0px); /* 可选：轻微模糊背景 */
}

.hero-content {
  position: relative; z-index: 3;
  animation: slideUp 0.6s ease-out;
}

.hero-tags { display: flex; gap: 8px; margin-bottom: 0.8rem; }
.hero-tag {
  background: rgba(255,255,255,0.2); backdrop-filter: blur(4px);
  padding: 4px 10px; border-radius: 20px;
  font-size: 0.75rem; font-weight: 600; letter-spacing: 0.5px;
}

.hero-title {
  font-size: 2.25rem; font-weight: 800; line-height: 1.2;
  margin: 0 0 1.2rem; text-shadow: 0 2px 4px rgba(0,0,0,0.3);
}

.hero-meta { display: flex; align-items: center; gap: 12px; }

.avatar-ring {
  padding: 2px; background: rgba(255,255,255,0.4); border-radius: 50%;
}
.avatar {
  width: 44px; height: 44px; border-radius: 50%;
  background: #fff; color: var(--primary);
  display: flex; align-items: center; justify-content: center;
  font-weight: 700; font-size: 1.1rem;
}

.meta-text { display: flex; flex-direction: column; }
.author-name { font-weight: 600; font-size: 1rem; text-shadow: 0 1px 2px rgba(0,0,0,0.3); }
.post-time { font-size: 0.8rem; opacity: 0.9; }


/* --- Article Body --- */
.article-body { padding: 2.5rem; }

.content-text {
  font-size: 1.05rem; line-height: 1.8; color: #334155;
  white-space: pre-wrap; margin-bottom: 2rem;
}

.content-gallery { margin: 2rem -1rem; }

/* --- Footer Actions --- */
.article-footer {
  display: flex; justify-content: space-between; align-items: center;
  padding-top: 2rem; border-top: 1px dashed #e2e8f0;
}

.action-buttons { display: flex; gap: 12px; }

.action-btn {
  display: flex; align-items: center; gap: 8px;
  padding: 8px 18px; border-radius: 50px;
  border: 1px solid #e2e8f0; background: white;
  color: var(--text-sub); font-weight: 600; font-size: 0.9rem;
  cursor: pointer; transition: all 0.2s;
}
.action-btn:hover { background: #f8fafc; border-color: #cbd5e1; transform: translateY(-1px); }

/* Like Style */
.like-btn.active { background: #fff1f2; border-color: #fecdd3; color: #e11d48; }
.like-btn.active svg { fill: #e11d48; }

/* Star Style */
.star-btn.active { background: #fffbeb; border-color: #fde68a; color: #d97706; }
.star-btn.active svg { fill: #d97706; }

.owner-actions { display: flex; align-items: center; gap: 1rem; }
.text-btn {
  display: flex; align-items: center; gap: 4px; color: var(--text-sub);
  text-decoration: none; font-size: 0.9rem; transition: color 0.2s;
}
.text-btn:hover { color: var(--primary); }
.delete-wrapper :deep(button) { 
  background: none; border: none; padding: 0; color: #ef4444; font-size: 0.9rem;
}
.delete-wrapper :deep(button:hover) { text-decoration: underline; }

/* ================= 2. Comments Card ================= */
.comments-card {
  background: var(--bg-card);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-card);
  padding: 2rem;
}
.section-header h3 { font-size: 1.2rem; font-weight: 700; margin-bottom: 1.5rem; color: #0f172a; }

/* Input Wrapper */
.comment-input-wrapper {
  background: #f8fafc; border: 1px solid #f1f5f9;
  border-radius: 16px; padding: 12px; margin-bottom: 2rem;
  transition: all 0.2s;
}
.comment-input-wrapper:focus-within {
  background: white; border-color: var(--primary); 
  box-shadow: 0 0 0 3px rgba(var(--primary-rgb), 0.1);
}

.preview-row { display: flex; gap: 8px; padding-bottom: 8px; }
.preview-thumb { width: 48px; height: 48px; border-radius: 6px; overflow: hidden; position: relative; }
.preview-thumb img { width: 100%; height: 100%; object-fit: cover; }
.remove-btn {
  position: absolute; inset: 0; background: rgba(0,0,0,0.5); color: white; border: none;
  opacity: 0; cursor: pointer; display: flex; align-items: center; justify-content: center;
}
.preview-thumb:hover .remove-btn { opacity: 1; }

.input-form { display: flex; gap: 12px; align-items: flex-end; }
.comment-textarea {
  flex: 1; background: transparent; border: none; outline: none; resize: none;
  font-size: 0.95rem; color: var(--text-main); min-height: 24px; max-height: 150px;
}
.form-actions { display: flex; align-items: center; gap: 8px; }

.icon-tool {
  background: #123d57;

  width: 32px; height: 32px; border-radius: 8px;
  display: flex; align-items: center; justify-content: center;
  color: #afddf1; cursor: pointer; transition: background 0.2s;
}
.icon-tool:hover { background: #e2e8f0; color: #334155; }

.submit-btn {
  width: 36px; height: 36px; background: #1e2b4c; color: white;
  border: none; border-radius: 10px; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  transition: all 0.2s;
}
.submit-btn:disabled { color: white; background: #384777; cursor: not-allowed; }
.submit-btn:hover:not(:disabled) { transform: scale(1.05); }

/* List */
.comments-list { margin-top: 1rem; }
.empty-placeholder { text-align: center; color: var(--text-sub); padding: 2rem 0; font-style: italic; }

/* Comment Item Overrides for cleaner look */
.comments-list :deep(.comment-item) {
  border-bottom: 1px solid #f1f5f9; padding: 1.5rem 0; background: transparent; box-shadow: none; border-radius: 0;
}
.comments-list :deep(.comment-item:last-child) { border-bottom: none; }

/* ================= Utils & Animations ================= */
.skeleton-container { background: white; border-radius: 20px; overflow: hidden; height: 500px; }
.sk-banner { height: 250px; background: #e2e8f0; }
.sk-content { padding: 2rem; display: flex; flex-direction: column; gap: 1rem; }
.sk-line { height: 16px; background: #f1f5f9; border-radius: 4px; }
.w-40 { width: 40%; } .w-100 { width: 100%; } .w-80 { width: 80%; }
.pulse { animation: pulse 1.5s infinite; }
@keyframes pulse { 0%, 100% { opacity: 0.6; } 50% { opacity: 1; } }

@keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
.fade-enter-active, .fade-leave-active { transition: opacity 0.3s; }
.fade-enter-from, .fade-leave-to { opacity: 0; }

.lightbox-overlay {
  position: fixed; inset: 0; background: rgba(0,0,0,0.9); z-index: 1000;
  display: flex; align-items: center; justify-content: center; cursor: zoom-out;
}
.lightbox-img { max-width: 95vw; max-height: 95vh; border-radius: 4px; }

.not-found { text-align: center; padding: 4rem; }
.back-link { color: var(--primary); font-weight: 600; text-decoration: none; }
</style>
