<template>
  <section class="favorite-page-ultra">
    <header class="page-header">
      <div class="header-content">
        <!-- 徽章：代表新鲜的 Fresh Stream -->
        <span class="badge-pill">收藏夹</span>
        
        <!-- 标题：青蓝色系 -->
        <h1>
          <span class="title-cn">收藏夹</span>
          <span class="title-en">Favorites</span>
        </h1>
        
        <p>查看自己收藏的帖子</p>
      </div>
    </header>

    <!-- 骨架屏 Loading -->
    <div v-if="isLoading" class="favorite-list card-grid">
      <div v-for="n in pageSize" :key="`skeleton-${n}`" class="post-card skeleton-card">
        <div class="skeleton-media shimmer"></div>
        <div class="skeleton-body">
          <div class="skeleton-line title shimmer"></div>
          <div class="skeleton-line title-short shimmer"></div>
          <div class="skeleton-footer">
            <div class="skeleton-circle shimmer"></div>
            <div class="skeleton-pill shimmer"></div>
          </div>
        </div>
      </div>
    </div>

    <!-- 真实数据列表 -->
    <TransitionGroup 
      v-else-if="favoriteStore.feed?.posts?.length" 
      tag="div" 
      class="favorite-list card-grid" 
      name="stagger-fade"
      appear
    >
      <article 
        v-for="(item, index) in favoriteStore.feed.posts" 
        :key="item.id" 
        class="post-card group" 
        @click="goToPost(item.id)"
        :style="{ '--delay': `${index * 50}ms` }"
      >
        <!-- 流光边框 (青色系) -->
        <div class="glow-border"></div>

        <!-- 图片区域 -->
        <div class="card-media">
          <img 
            v-if="getThumb(item)" 
            :src="getThumb(item) || ''" 
            alt="Art" 
            loading="lazy" 
          />
          <div v-else class="media-placeholder"></div>
          <div class="vignette-overlay"></div>
          <div class="shine-effect"></div>

          <!-- Remix (创作同款) 按钮 -->
          <button class="remix-btn" @click.stop="goToWorkbench" title="创作同款">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="remix-icon">
              <path stroke-linecap="round" stroke-linejoin="round" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
            </svg>
            <span>Remix</span>
          </button>
        </div>

        <!-- 内容区域 -->
        <div class="card-content">
          <h3 class="card-title" :title="item.title">
            <span class="title-text">{{ item.title }}</span>
          </h3>

          <div class="card-meta">
            <div class="author-info">
              <div class="avatar-ring">
                <img v-if="getAvatar(item)" :src="getAvatar(item) || ''" alt="avatar" />
                <div v-else class="avatar-fallback">{{ getInitials(item.author) }}</div>
              </div>
              <span class="author-name">{{ item.author.length>8?(item.author.slice(0,5)+"..."):item.author}}</span>
            </div>

            <div class="meta-right">
               <span class="time-tag">{{ formatDate(item.timestamp) }}</span>
            </div>
          </div>
        </div>
      </article>
    </TransitionGroup>

    <!-- 空状态 -->
    <div v-else class="no-data-message">
       <div class="empty-visual">📡</div>
      <h3>暂无收藏</h3>
      <p>雷达正在扫描中，请稍后再试</p>
    </div>

    <!-- 分页控件 -->
    <div class="pagination-wrapper">
      <button 
        @click="goToPreviousPage" 
        :disabled="currentPage <= 1 || isLoading" 
        class="magic-btn"
      >
        <span class="btn-icon">←</span>
        <span class="btn-text">Previous</span>
      </button>
      
      <div class="page-dots">
        <span class="current">{{ currentPage }}</span>
        <span class="divider">/</span>
        <span class="total">{{ favoriteStore.feed?.page_count || '∞' }}</span>
      </div>
      
      <button 
        @click="goToNextPage" 
        :disabled="currentPage >= (favoriteStore.feed?.page_count || 999) || isLoading" 
        class="magic-btn"
      >
        <span class="btn-text">Next</span>
        <span class="btn-icon">→</span>
      </button>
    </div>
  </section>
</template>

<script lang="ts" setup>
import { ref, reactive, watch, computed } from 'vue';
import type { SearchFilters } from '@/types/api';
import { useRoute, useRouter } from 'vue-router';
import { useRecommendationStore } from '@/store/modules/recommendation.ts';

const favoriteStore = useRecommendationStore();
const route = useRoute(); 
const router = useRouter();
import { formatDate } from '@/hooks/FormatTimeStamp';
const pageSize = 12;
const isLoading = ref(false); 

const currentPage = computed<number>({
  get() {
    const page = parseInt(route.query.page as string);
    // 这里的默认值逻辑很重要：如果URL没有page参数，默认为1
    return isNaN(page) || page < 1 ? 1 : page;
  },
  set(newValue:number) {
    router.push({ 
      name: route.name as string, 
      query: { ...route.query, page: newValue.toString() } 
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
});

const filters = reactive<SearchFilters>({
  page: currentPage.value, 
  pageSize: pageSize,
});

const getThumb = (item: any) => item?.url_list?.[0] ?? item?.cover_image ?? null;
const getAvatar = (item: any) => item?.author_avatar ?? item?.authorAvatar ?? item?.avatarUrl ?? item?.avatar ?? null;

function getInitials(name: any): string {
  if (!name) return 'U';
  return String(name).slice(0, 2).toUpperCase();
}

// 颜色逻辑：最新内容用青/蓝色系区分前三名
function getRankClass(index: number) {
  const rank = (currentPage.value - 1) * pageSize + index + 1;
  if (rank === 1) return 'rank-fresh-1'; // 最鲜
  if (rank === 2) return 'rank-fresh-2';
  if (rank === 3) return 'rank-fresh-3';
  return 'rank-normal';
}

function goToPost(id: number | string) {
  if (!id) return;
  router.push({ path: `/posts/${id}` });
}

function goToWorkbench() {
  router.push('/ai/workbench');
}

async function fetchfavorite() {
  if (isLoading.value) return;
  isLoading.value = true; 
  // 确保每次请求都使用当前的 currentPage 值
  filters.page = currentPage.value; 

  try {
    await favoriteStore.fetchFeed("favorite", filters);
  } catch (error) {
    console.error("Fetch favorite Error:", error);
  } finally {
    isLoading.value = false; 
  }
}

// ✅ 核心修复：移除了 if(newPage) 判断
// 只要路由参数变化（或者组件首次加载），就无条件执行 fetchfavorite
// 因为 currentPage 计算属性会自动处理 undefined 的情况，返回默认值 1
watch(() => route.query.page, () => { 
    fetchfavorite();
  }, { immediate: true }
);

function goToNextPage() {
  const total = favoriteStore.feed?.page_count || 999;
  if (currentPage.value < total) currentPage.value++;
}

function goToPreviousPage() {
  if (currentPage.value > 1) currentPage.value--;
}
</script>

<style scoped>
/* --- 变量定义：【青/蓝】科技主题 --- */
.favorite-page-ultra {
  --font-display: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  
  /* 颜色变量：Fresh Theme */
  --c-bg-page: #f0fdfa; /* 非常淡的青色背景 */
  --c-bg-card: #ffffff;
  --c-text-primary: #0f172a;
  --c-text-secondary: #64748b;
  
  --c-accent: #06b6d4; /* Cyan 500 */
  --c-accent-dark: #3b82f6; /* Blue 500 */
  --c-accent-glow: rgba(6, 182, 212, 0.25);
  
  --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --shadow-hover: 0 20px 40px -10px rgba(6, 182, 212, 0.2), 0 10px 20px -5px rgba(0, 0, 0, 0.04);
  
  --ease-elastic: cubic-bezier(0.34, 1.56, 0.64, 1);
  --ease-out: cubic-bezier(0.2, 0.8, 0.2, 1);
  
  max-width: 1400px;
  margin: 0 auto;
  padding: 60px 24px;
  background-color: var(--c-bg-page);
  min-height: 100vh;
  font-family: var(--font-display);
}

/* --- Header --- */
.page-header { text-align: center; margin-bottom: 70px; }

.badge-pill {
  display: inline-block;
  padding: 6px 16px;
  background: rgba(6, 182, 212, 0.1); /* 青色背景 */
  color: #0891b2; /* 青色文字 */
  font-size: 0.8rem;
  font-weight: 700;
  border-radius: 100px;
  text-transform: uppercase;
  letter-spacing: 1.5px;
  margin-bottom: 20px;
  border: 1px solid rgba(6, 182, 212, 0.2);
}

.page-header h1 {
  font-size: 3.5rem;
  margin: 0 0 16px;
  font-weight: 900; 
  letter-spacing: -0.04em;
  display: flex; align-items: center; justify-content: center;
  gap: 15px; flex-wrap: wrap;
}

.title-cn { color: #1e293b; }

/* 标题渐变改为青蓝 */
.title-en {
  background: linear-gradient(135deg, #22d3ee 0%, #3b82f6 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.page-header p { color: var(--c-text-secondary); font-size: 1.25rem; margin-top: 8px; font-weight: 400; }

/* --- Grid & Card --- */
.card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 32px;
  padding: 10px;
}

.post-card {
  position: relative;
  background: var(--c-bg-card);
  border-radius: 20px;
  box-shadow: 0 0 0 1px rgba(0,0,0,0.04), var(--shadow-sm);
  cursor: pointer;
  transform: translateZ(0);
  transition: transform 0.4s var(--ease-out), box-shadow 0.4s var(--ease-out);
  display: flex; flex-direction: column; overflow: hidden;
}

.post-card:hover {
  transform: translateY(-8px) scale(1.005);
  box-shadow: var(--shadow-hover);
  z-index: 10;
}

/* 边框流光：青色系 */
.glow-border {
  position: absolute; inset: 0;
  border-radius: 20px;
  padding: 2px;
  background: linear-gradient(135deg, #22d3ee, #3b82f6);
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask-composite: exclude;
  opacity: 0;
  transition: opacity 0.4s ease;
  pointer-events: none;
  z-index: 20;
}
.post-card:hover .glow-border { opacity: 1; }

/* --- 排名/新鲜度 徽章 --- */
.rank-badge {
  position: absolute; top: 16px; left: 16px;
  min-width: 44px; height: 44px;
  border-radius: 12px;
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  z-index: 5;
  font-weight: 800;
  line-height: 1;
  padding: 0 8px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.1);
  backdrop-filter: blur(4px);
  border: 1px solid rgba(255,255,255,0.6);
}
.rank-num { font-size: 1.3rem; margin-bottom: 2px; }
.rank-label { font-size: 0.6rem; text-transform: uppercase; letter-spacing: 1px; opacity: 0.9; }

/* Rank 1 (最新): Electric Blue */
.rank-fresh-1 {
  background: linear-gradient(135deg, #cffafe 0%, #22d3ee 100%);
  color: #0e7490; border-color: #a5f3fc;
  box-shadow: 0 8px 20px rgba(34, 211, 238, 0.3);
}
/* Rank 2: Sky Blue */
.rank-fresh-2 {
  background: linear-gradient(135deg, #e0f2fe 0%, #7dd3fc 100%);
  color: #0369a1; border-color: #bae6fd;
}
/* Rank 3: Blue */
.rank-fresh-3 {
  background: linear-gradient(135deg, #dbeafe 0%, #93c5fd 100%);
  color: #1d4ed8; border-color: #bfdbfe;
}
.rank-normal {
  background: rgba(255, 255, 255, 0.9);
  color: #94a3b8; font-style: italic; font-family: 'Georgia', serif;
}

/* --- 图片与功能按钮 --- */
.card-media {
  height: 240px; position: relative; overflow: hidden; background: #f1f5f9;
}
.card-media img {
  width: 100%; height: 100%; object-fit: cover; transition: transform 0.8s var(--ease-out);
}
.post-card:hover .card-media img { transform: scale(1.08); }

/* Remix 按钮 */
.remix-btn {
  position: absolute; top: 12px; right: 12px;
  display: flex; align-items: center; gap: 6px;
  padding: 6px 12px;
  background: rgba(0, 0, 0, 0.6);
  backdrop-filter: blur(4px);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 20px;
  color: #fff;
  font-size: 0.8rem; font-weight: 600;
  cursor: pointer;
  opacity: 0; transform: translateY(-10px);
  transition: all 0.3s ease;
  z-index: 10;
}
.remix-btn:hover { background: var(--c-accent-dark); border-color: var(--c-accent-dark); }
.remix-icon { width: 14px; height: 14px; }

/* Hover 时显示 Remix 按钮 */
.post-card:hover .remix-btn { opacity: 1; transform: translateY(0); }

.vignette-overlay {
  position: absolute; inset: 0;
  background: linear-gradient(to bottom, rgba(0,0,0,0) 60%, rgba(0,0,0,0.05) 100%);
  pointer-events: none;
}
.shine-effect {
  position: absolute; top: 0; left: -100%; width: 50%; height: 100%;
  background: linear-gradient(to right, rgba(255,255,255,0) 0%, rgba(255,255,255,0.3) 100%);
  transform: skewX(-25deg); pointer-events: none; transition: none;
}
.post-card:hover .shine-effect { left: 200%; transition: left 0.8s ease-in-out; }

/* --- 内容区域 --- */
.card-content {
  padding: 16px 20px 18px;
  display: flex; flex-direction: column; gap: 10px;
  background: linear-gradient(180deg, #fff 0%, #fafafa 100%);
}

.card-title {
  margin: 0; font-size: 1.15rem; font-weight: 700; line-height: 1.35;
  color: var(--c-text-primary);
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
}
.title-text {
  background-image: linear-gradient(90deg, var(--c-text-primary), var(--c-text-primary));
  background-size: 0% 2px; background-position: 0 100%; background-repeat: no-repeat;
  transition: background-size 0.3s ease, color 0.3s ease;
}
.post-card:hover .title-text {
  color: var(--c-accent-dark);
  background-image: linear-gradient(90deg, var(--c-accent-dark), var(--c-accent-dark));
  background-size: 100% 2px;
}

.card-meta { display: flex; justify-content: space-between; align-items: center; margin-top: 4px; }

.author-info { display: flex; align-items: center; gap: 10px; }
.avatar-ring {
  width: 42px; height: 42px; border-radius: 50%; padding: 2px;
  background: transparent; transition: background 0.3s ease;
  display: flex; align-items: center; justify-content: center;
}
.post-card:hover .avatar-ring {
  background: linear-gradient(135deg, #22d3ee, #3b82f6); /* 青蓝光圈 */
}
.author-info img, .avatar-fallback {
  width: 100%; height: 100%; border-radius: 50%; object-fit: cover;
  border: 2px solid #fff; background: #e0f2fe; color: #0369a1;
  font-weight: 700; font-size: 14px;
  display: flex; align-items: center; justify-content: center;
}
.author-name {
  font-size: 0.95rem; font-weight: 600; color: #334155;
  max-width: 110px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}

.time-tag {
  font-size: 0.85rem; color: #94a3b8; font-weight: 500;
}

/* Empty State & Pagination */
.no-data-message { text-align: center; padding: 80px 0; color: #94a3b8; }
.empty-visual { font-size: 4rem; margin-bottom: 20px; }

.pagination-wrapper { margin-top: 80px; display: flex; justify-content: center; align-items: center; gap: 30px; }
.magic-btn { display: flex; align-items: center; gap: 12px; padding: 12px 28px; background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; color: var(--c-text-primary); font-weight: 600; font-size: 1rem; cursor: pointer; transition: all 0.3s var(--ease-out); box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
.magic-btn:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 12px 20px -5px rgba(6, 182, 212, 0.15); border-color: var(--c-accent); color: var(--c-accent); }
.magic-btn:disabled { opacity: 0.5; cursor: not-allowed; background: #f8fafc; }
.page-dots { font-size: 1.2rem; font-weight: 700; color: #cbd5e1; display: flex; gap: 8px; }
.page-dots .current { color: var(--c-text-primary); }

/* Skeleton & Transitions */
.skeleton-card { background: #fff; box-shadow: none; border: 1px solid #f1f5f9; }
.skeleton-media { height: 240px; background: #f1f5f9; }
.skeleton-body { padding: 20px; }
.skeleton-line { height: 18px; margin-bottom: 12px; border-radius: 4px; background: #e2e8f0; }
.title { width: 80%; }
.title-short { width: 50%; margin-bottom: 24px; }
.skeleton-footer { display: flex; justify-content: space-between; align-items: center; }
.skeleton-circle { width: 40px; height: 40px; border-radius: 50%; background: #e2e8f0; }
.skeleton-pill { width: 50px; height: 20px; border-radius: 4px; background: #e2e8f0; }
.shimmer { background: linear-gradient(to right, #f1f5f9 0%, #e2e8f0 20%, #f1f5f9 40%, #f1f5f9 100%); background-size: 1000px 100%; animation: shimmer 1.5s infinite linear; }
@keyframes shimmer { 0% {background-position: -1000px 0;} 100% {background-position: 1000px 0;} }

.stagger-fade-enter-active { transition: all 0.5s ease; transition-delay: var(--delay); }
.stagger-fade-leave-active { transition: all 0.3s ease; }
.stagger-fade-enter-from { opacity: 0; transform: translateY(40px); }

@media (max-width: 768px) {
  .page-header h1 { font-size: 2.2rem; }
  .card-grid { grid-template-columns: repeat(auto-fill, minmax(170px, 1fr)); gap: 16px; }
  .card-media { height: 180px; }
}
</style>
