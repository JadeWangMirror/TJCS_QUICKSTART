<script setup lang="ts">
const filters = ['全部', '热门', '最新', '高评分', '已收藏']
</script>

<template>
  <section class="post-feed">
    <header class="post-feed__header">
      <div>
        <h1>交流帖广场</h1>
        <p>发现其他创作者分享的提示词、生成结果与实战经验。</p>
      </div>
      <RouterLink to="/posts/new">发布帖子</RouterLink>
    </header>

    <div class="post-feed__filters">
      <button v-for="filter in filters" :key="filter" type="button">
        {{ filter }}
      </button>
      <div class="post-feed__search">
        <input type="search" placeholder="搜索标题、标签或作者" />
      </div>
    </div>

    <div class="post-feed__list">
      <article v-for="index in 5" :key="index">
        <header>
          <h2>AI 提示词实战案例 {{ index }}</h2>
          <RouterLink :to="`/posts/${index}`">查看详情</RouterLink>
        </header>
        <p>
          提示词：以轻松幽默的语气撰写新品发布会邀请函，强调用户痛点和亮点。生成模型：GPT-4o mini。
        </p>
        <footer>
          <div>
            <span>#写作助手</span>
            <span>#营销推广</span>
          </div>
          <div>
            <span>点赞 128</span>
            <span>收藏 56</span>
          </div>
        </footer>
      </article>
    </div>
  </section>
</template>

<style scoped>
.post-feed {
  display: grid;
  gap: 1.75rem;
}

.post-feed__header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.post-feed__header h1 {
  margin: 0;
  font-size: 1.9rem;
}

.post-feed__header p {
  margin: 0.4rem 0 0;
  color: #475569;
}

.post-feed__header a {
  padding: 0.7rem 1.6rem;
  border-radius: 12px;
  background: linear-gradient(120deg, #7c3aed, #4c1d95);
  color: #fff;
  font-weight: 600;
}

.post-feed__filters {
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
  align-items: center;
}

.post-feed__filters button {
  padding: 0.5rem 1.2rem;
  border-radius: 999px;
  border: 1px solid rgba(124, 58, 237, 0.25);
  background: rgba(124, 58, 237, 0.08);
  color: #4c1d95;
  font-weight: 500;
}

.post-feed__search input {
  padding: 0.6rem 1rem;
  border-radius: 12px;
  border: 1px solid rgba(148, 163, 184, 0.6);
}

.post-feed__list {
  display: grid;
  gap: 1.25rem;
}

article {
  background: #ffffff;
  border-radius: 18px;
  padding: 1.5rem;
  display: grid;
  gap: 0.75rem;
  box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08);
}

article header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

article h2 {
  margin: 0;
  font-size: 1.2rem;
  color: #312e81;
}

article header a {
  color: #4c1d95;
  font-weight: 600;
}

article p {
  margin: 0;
  color: #475569;
}

footer {
  display: flex;
  justify-content: space-between;
  font-size: 0.9rem;
  color: #64748b;
}

footer span {
  margin-right: 0.75rem;
}

@media (max-width: 640px) {
  footer {
    flex-direction: column;
    gap: 0.5rem;
  }
}
</style>
