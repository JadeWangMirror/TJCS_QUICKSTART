<template>
  <div class="post-create-view">
    <div class="content-container">
      
      <!-- 页面标题 -->
      <header class="page-header">
        <div class="header-content">
          <h1>发布交流帖</h1>
          <p>分享你的 Prompt 与 AI 生成艺术，激发社区无限灵感。</p>
        </div>
      </header>

      <!-- 主表单卡片 -->
      <section class="card form-card">
        <form @submit.prevent="handleSubmit" class="form-layout">

          <!-- 1. 标题输入 -->
          <div class="form-group">
            <label class="label">标题 <span class="required">*</span></label>
            <input 
              type="text" 
              class="input-field" 
              placeholder="给你的作品起个引人注目的标题..." 
              v-model="form.title" 
              required 
            />
          </div>

          <!-- 2. 内容输入 -->
          <div class="form-group">
            <label class="label">提示词与思路 <span class="required">*</span></label>
            <textarea 
              rows="6" 
              class="input-field textarea" 
              placeholder="分享你的 Prompt、参数设置或构图思路 (支持 Markdown)..." 
              v-model="form.context" 
              required
            ></textarea>
          </div>

          <!-- 3. 图片上传 (优化版网格布局) -->
          <div class="form-group">
            <label class="label">
              生成结果展示
              <span class="sub-label">({{ imageItems.length }} / {{ maxFiles }})</span>
            </label>
            
            <div class="upload-grid">
              <!-- 已上传图片 -->
              <div 
                v-for="(item, index) in imageItems" 
                :key="item.previewUrl" 
                class="upload-item preview"
                @click.stop.prevent="openPreview(item.previewUrl)"
              >
                <img :src="item.previewUrl" alt="预览图" />
                <div class="overlay">
                  <span class="zoom-icon">🔍</span>
                </div>
                <button class="remove-btn" @click.stop.prevent="removeFile(index)">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M18 6L6 18M6 6l12 12" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </button>
              </div>

              <!-- 上传按钮 -->
              <div 
                v-if="imageItems.length < maxFiles" 
                class="upload-item upload-btn" 
                @dragover.prevent 
                @drop.prevent="handleDrop"
                @click="(($refs.fileInput as any) as HTMLInputElement)?.click()"
              >
                <div class="upload-content">
                  <span class="plus-icon">+</span>
                  <span class="upload-text">点击或拖拽上传</span>
                </div>
                <input 
                  type="file" 
                  multiple 
                  accept="image/*" 
                  ref="fileInput" 
                  class="hidden-input"
                  @change="handleFileSelect" 
                />
              </div>
            </div>
          </div>

          <!-- 4. 标签系统 -->
          <div class="form-group">
            <label class="label">标签 (Tags)</label>
            <div class="tags-wrapper">
              <!-- 输入框 -->
              <input 
                type="text" 
                class="input-field tag-input" 
                placeholder="添加标签 (回车确认，最多5个,至少一个)" 
                v-model="currentTagInput"
                @keydown.enter.prevent="addTag(currentTagInput)" 
                :disabled="form.tags.length >= 5" 
              />
              
              <!-- 推荐标签 -->
              <div class="recommend-tags">
                <span class="rec-label">推荐：</span>
                <span 
                  v-for="(tag, index) in recommendedTags" 
                  :key="index" 
                  class="tag-pill recommend"
                  @click="addTag(tag)"
                >
                  {{ tag }}
                </span>
              </div>

              <!-- 已选标签 -->
              <transition-group name="list" tag="div" class="selected-tags" v-if="form.tags.length">
                <span v-for="tag in form.tags" :key="tag" class="tag-pill selected">
                  #{{ tag }}
                  <span class="remove-tag" @click="removeTag(tag)">×</span>
                </span>
              </transition-group>
            </div>
          </div>

          <!-- 底部操作栏 -->
          <footer class="form-footer">
            <button type="submit" :disabled="isSubmitting" class="btn btn-primary submit-btn">
              <span v-if="isSubmitting" class="loading-spinner"></span>
              {{ isSubmitting ? '正在发布...' : '发布作品' }}
            </button>
          </footer>

        </form>
      </section>

      <!-- 图片预览 Modal -->
      <transition name="fade">
        <div v-if="previewVisible" class="preview-modal" @click.prevent="closePreview">
          <div class="modal-content">
            <img :src="currentPreview" alt="放大预览" />
          </div>
        </div>
      </transition>
      
    </div>
    <CustomToast :message="toast.message.value" :visible="toast.isVisible.value" />
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import { usePostStore } from '@/store/modules/posts';
import type { PostFormPayload } from '@/types/models';
import { useRouter } from 'vue-router';
import { useToast } from '@/composables/useToast';
import CustomToast from '@/components/common/CustomToast.vue';
import { useImageUpload } from '@/hooks/previewAndUploadImage'; 

const postStore = usePostStore();
const router = useRouter();
const toast = useToast();

const form = ref<PostFormPayload>({
  title: '',
  context: '',
  tags: [],
  isShareable: true,
  status: "draft",
  url_list: [],
  files:[] 
});

const {
  imageItems,
  previewVisible,
  currentPreview,
  handleFileSelect,
  handleDrop,
  removeFile,
  openPreview,
  closePreview,
  getFiles,
  maxFiles
} = useImageUpload(9);

const currentTagInput = ref('');
const recommendedTags = ref(['AI绘画', '光影控制', 'Midjourney', 'StableDiffusion', '二次元']);
const isSubmitting = computed(() => postStore.loading);
const fileInput = ref<HTMLInputElement | null>(null);

const addTag = (tag: string) => {
  const trimmedTag = tag.trim().replace(/^#/, '');
  if (trimmedTag && !form.value.tags.includes(trimmedTag) && form.value.tags.length < 5) {
    form.value.tags.push(trimmedTag);
  }
  currentTagInput.value = '';
};

const removeTag = (tagToRemove: string) => {
  form.value.tags = form.value.tags.filter(tag => tag !== tagToRemove);
};

const handleSubmit = async () => {
  if (!form.value.title.trim()) { toast.show('请填写标题'); return; }
  if (!form.value.context.trim()) { toast.show('请填写提示词内容'); return; }
  if(form.value.tags.length==0){ toast.show('请至少选择一个标签'); return; }
  try {
    form.value.files = getFiles(); 
    const result = await postStore.createPost(form.value);

    if (result?.success && result.data) {
      toast.show('发布成功！');
      router.push(`/posts/${result.data.postId}`);
    } else {
      toast.show(`发布失败: ${result?.message || '未知错误'}`);
    }
  } catch (error) {
    if (error instanceof Error && error.message === "User not authenticated.") {
      router.push('/auth/login')
    } else {
      toast.show(`错误: ${error}`);
    }
  }
};
</script>

<style scoped>
/* 
  设计系统：复用 Profile/Home 的变量体系
*/
.post-create-view {
  --primary: #6366f1;
  --primary-hover: #4f46e5;
  --primary-light: rgba(99, 102, 241, 0.1);
  --text-main: #1e293b;
  --text-sub: #64748b;
  --bg-input: #f8fafc;
  --border-color: #e2e8f0;
  --card-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
  --card-shadow-hover: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
  --focus-ring: 0 0 0 3px rgba(99, 102, 241, 0.15);
  
  max-width: 800px;
  margin: 0 auto;
  padding-bottom: 4rem;
  font-family: 'Inter', system-ui, sans-serif;
  color: var(--text-main);
}

/* Header */
.page-header {
  margin-bottom: 2rem;
  text-align: left;
  animation: fadeIn 0.6s ease-out;
}
.page-header h1 {
  font-size: 2rem;
  font-weight: 800;
  margin-bottom: 0.5rem;
  background: linear-gradient(135deg, #1e293b 0%, #475569 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.page-header p {
  color: var(--text-sub);
  font-size: 1rem;
}

/* Card Container */
.card {
  background: #ffffff;
  border-radius: 20px;
  border: 1px solid rgba(255,255,255,0.8);
  box-shadow: var(--card-shadow);
  padding: 2.5rem;
  transition: all 0.3s ease;
  animation: slideUp 0.6s ease-out 0.1s both;
}
.card:hover {
  box-shadow: var(--card-shadow-hover);
}

/* Form Layout */
.form-layout {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.label {
  font-weight: 600;
  font-size: 0.95rem;
  color: var(--text-main);
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.required { color: #ef4444; margin-left: 4px; }
.sub-label { font-weight: 400; color: var(--text-sub); font-size: 0.85rem; }

/* Inputs */
.input-field {
  width: 100%;
  padding: 0.875rem 1rem;
  border-radius: 12px;
  border: 1px solid var(--border-color);
  background: var(--bg-input);
  color: var(--text-main);
  font-size: 1rem;
  transition: all 0.2s;
  box-sizing: border-box;
}
.input-field::placeholder { color: #94a3b8; }
.input-field:focus {
  outline: none;
  background: #fff;
  border-color: var(--primary);
  box-shadow: var(--focus-ring);
}
.textarea { resize: vertical; min-height: 120px; line-height: 1.6; }

/* Image Upload Grid */
.upload-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
  gap: 12px;
}

.upload-item {
  position: relative;
  aspect-ratio: 1;
  border-radius: 12px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.2s;
}

/* Preview Item */
.preview img {
  width: 100%; height: 100%; object-fit: cover;
  transition: transform 0.3s;
}
.preview:hover img { transform: scale(1.05); }
.preview .overlay {
  position: absolute; inset: 0;
  background: rgba(0,0,0,0.3);
  display: flex; align-items: center; justify-content: center;
  opacity: 0; transition: opacity 0.2s;
}
.preview:hover .overlay { opacity: 1; }
.zoom-icon { font-size: 1.2rem; filter: grayscale(1); }

.remove-btn {
  position: absolute; top: 4px; right: 4px;
  width: 20px; height: 20px;
  background: rgba(239, 68, 68, 0.9);
  color: white; border: none; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  cursor: pointer; padding: 0; z-index: 2;
  transition: transform 0.2s;
}
.remove-btn:hover { transform: scale(1.1); background: #ef4444; }
.remove-btn svg { width: 12px; height: 12px; }

/* Upload Button */
.upload-btn {
  border: 2px dashed var(--border-color);
  background: var(--bg-input);
  display: flex; align-items: center; justify-content: center;
}
.upload-btn:hover {
  border-color: var(--primary);
  background: var(--primary-light);
}
.upload-content {
  display: flex; flex-direction: column; align-items: center; gap: 4px;
  color: var(--text-sub);
}
.plus-icon { font-size: 1.8rem; font-weight: 300; line-height: 1; color: var(--primary); }
.upload-text { font-size: 0.75rem; }
.hidden-input { display: none; }

/* Tags System */
.tags-wrapper { display: flex; flex-direction: column; gap: 1rem; }
.recommend-tags { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; font-size: 0.85rem; }
.rec-label { color: var(--text-sub); }

.tag-pill {
  padding: 0.35rem 0.85rem; border-radius: 20px; font-size: 0.85rem;
  display: inline-flex; align-items: center; gap: 6px;
  transition: all 0.2s; cursor: pointer; user-select: none;
}
.tag-pill.recommend {
  background: #f1f5f9; color: var(--text-sub); border: 1px solid transparent;
}
.tag-pill.recommend:hover {
  background: white; border-color: var(--primary); color: var(--primary);
  transform: translateY(-1px);
}
.tag-pill.selected {
  background: var(--primary-light); color: var(--primary); font-weight: 500;
}
.selected-tags { display: flex; flex-wrap: wrap; gap: 8px; }

.remove-tag {
  font-size: 1.1rem; line-height: 0.8; opacity: 0.6;
  transition: opacity 0.2s;
}
.remove-tag:hover { opacity: 1; color: #ef4444; }

/* Footer & Button */
.form-footer { margin-top: 1rem; display: flex; justify-content: flex-end; }
.submit-btn {
  background: linear-gradient(135deg, var(--primary) 0%, var(--primary-hover) 100%);
  color: white; padding: 0.85rem 2.5rem; border: none; border-radius: 12px;
  font-weight: 600; font-size: 1rem; cursor: pointer;
  box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
  transition: all 0.3s;
  display: flex; align-items: center; gap: 8px;
}
.submit-btn:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(99, 102, 241, 0.4);
}
.submit-btn:disabled { opacity: 0.7; cursor: not-allowed; transform: none; }

.loading-spinner {
  width: 16px; height: 16px;
  border: 2px solid rgba(255,255,255,0.3);
  border-top-color: white;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

/* Modal */
.preview-modal {
  position: fixed; inset: 0; z-index: 100;
  background: rgba(0,0,0,0.85); backdrop-filter: blur(4px);
  display: flex; align-items: center; justify-content: center;
  padding: 2rem; cursor: zoom-out;
}
.modal-content img {
  max-width: 100%; max-height: 90vh;
  border-radius: 8px; box-shadow: 0 20px 50px rgba(0,0,0,0.5);
}

/* Animations */
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
@keyframes spin { to { transform: rotate(360deg); } }

.list-enter-active, .list-leave-active { transition: all 0.3s ease; }
.list-enter-from, .list-leave-to { opacity: 0; transform: scale(0.9); }
.fade-enter-active, .fade-leave-active { transition: opacity 0.3s ease; }
.fade-enter-from, .fade-leave-to { opacity: 0; }
</style>
