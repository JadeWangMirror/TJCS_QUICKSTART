<template>
  <section class="latest-page">
    <header class="page-header">
      <h1>我的帖子</h1>
    </header>

    <div class="latest-list" v-if="MyPostStore.feed?.posts?.length">
      <article v-for="(item, index) in MyPostStore.feed.posts" :key="item.id" class="trend-card">
        <div class="rank-badge" :class="`rank-${index + 1}`">#{{ (currentPage - 1) * pageSize + index + 1 }}</div>

        <div class="content-info">
          <h2 class="post-title">{{ item.title }}</h2>
          <p class="post-author">作者: {{ item.author }}</p>

        </div>

        <footer class="post-actions">
          <RouterLink :to="`/posts/${item.id}`" class="btn btn-primary">查看详情</RouterLink>
        </footer>
      </article>
    </div>

    <div v-else class="no-data-message">
      {{ isLoading ? '正在加载我的帖子...' : '请发布后再来看看吧' }}
    </div>

    <div class="pagination-controls">
      <button @click="goToPreviousPage" :disabled="currentPage <= 1" class="pagination-btn">
        <svg fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
          <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
        </svg>
        上一页
      </button>

      <span class="page-info">第 {{ currentPage }} 页 / 共 {{ MyPostStore.feed?.page_count || '?' }} 页</span>

      <button @click="goToNextPage" :disabled="currentPage >= (MyPostStore.feed?.page_count || Infinity)"
        class="pagination-btn">
        下一页
        <svg fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
          <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
        </svg>
      </button>
    </div>
  </section>
</template>

<script lang="ts" setup>
  import { ref, reactive, watch, computed } from 'vue';
  import type { SearchFilters } from '@/types/api';
  import { useRoute, useRouter } from 'vue-router'
  import { useRecommendationStore } from '@/store/modules/recommendation.ts';
  import { usePostStore } from '@/store';
  import DeleteButton from '@/components/fancy/DeleteButton.vue';

  const MyPostStore = useRecommendationStore();
  const route = useRoute();
  const router = useRouter();
  const PostStore = usePostStore();
  const currentPage = computed<number>({
    get() {
      // 尝试从 URL query 获取 'page' 参数，如果不存在或无效，则默认为 1
      const page = parseInt(route.query.page as string);
      return isNaN(page) || page < 1 ? 1 : page;
    },
    // set 方法用于更新 URL
    set(newValue: number) {
      // 调用 router.push 来更新 URL 中的 query 参数，但保持其他参数不变
      router.push({
        name: route.name as string, // 保持当前路由名称
        query: { ...route.query, page: newValue.toString() }
      });
    }
  });
  const pageSize: number = 10;
  const isLoading = ref(false); // 独立管理加载状态

  const filters = reactive<SearchFilters>({
    page: currentPage.value, // 初始值
    pageSize: pageSize,
  });
  async function fetchMyPosts() {
    isLoading.value = true; // 开始加载
    filters.page = currentPage.value;
    try {
      await MyPostStore.fetchFeed("my", filters);
    } catch (error) {
      console.error("获取我的帖子失败:", error);
      // 可以在这里添加错误提示逻辑
    } finally {
      isLoading.value = false; // 加载结束
    }
  }

  watch(
    () => route.query.page,
    (newPageValue) => { // 接收的参数类型为 string | string[] | undefined
      let pageStr: string | undefined;
      if (typeof newPageValue === 'string') {
        pageStr = newPageValue;
      } else if (Array.isArray(newPageValue) && newPageValue.length > 0) {
        // 如果是数组，使用第一个元素（通常页码不会是数组）
        pageStr = newPageValue[0] || undefined;
      }
      const newPageNumber = currentPage.value;
      if (newPageNumber > 0) {
        fetchMyPosts();
      }
    },
    { immediate: true }
  );
  // --- 分页控制函数 ---
  function goToNextPage() {
    const total = MyPostStore.feed?.page_count || Infinity;
    if (currentPage.value < total) {
      currentPage.value++;
    }
  }

  function goToPreviousPage() {
    if (currentPage.value > 1) {
      currentPage.value--;
    }
  }

</script>

<style scoped>
  /* 简化 CSS 样式，您可以根据项目进行调整 */

  .latest-page {
    max-width: 1000px;
    margin: 0 auto;
    padding: 20px;
  }

  .page-header {
    text-align: center;
    margin-bottom: 30px;
    border-bottom: 2px solid #eee;
    padding-bottom: 10px;
  }

  .page-header h1 {
    font-size: 2.2em;
    color: #e34c26;
    /* 热门主题色 */
  }

  .latest-list {
    display: grid;
    gap: 20px;
  }

  .trend-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
    position: relative;
    transition: transform 0.2s;
  }

  .trend-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 10px rgba(0, 0, 0, 0.1);
  }

  .rank-badge {
    position: absolute;
    top: -10px;
    left: -10px;
    background-color: #f7a049;
    /* 默认排名颜色 */
    color: white;
    padding: 5px 10px;
    border-radius: 50%;
    font-weight: bold;
    font-size: 1.1em;
    min-width: 40px;
    text-align: center;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
  }

  .rank-1 {
    background-color: #ff4500;
  }

  /* 冠军 */
  .rank-2 {
    background-color: #ff8c00;
  }

  /* 亚军 */
  .rank-3 {
    background-color: #ffd700;
  }

  /* 季军 */


  .content-info {
    flex-grow: 1;
    margin-right: 20px;
  }

  .post-title {
    font-size: 1.4em;
    color: #333;
    margin-top: 0;
    margin-bottom: 5px;
  }

  .post-author {
    color: #666;
    font-size: 0.9em;
    margin-bottom: 10px;
  }

  .hot-value {
    color: #e34c26;
    font-weight: bold;
  }

  .post-actions {
    display: flex;
    gap: 10px;
  }

  /* 按钮样式复用或自定义 */
  .btn {
    padding: 8px 15px;
    border-radius: 4px;
    text-decoration: none;
    font-weight: 500;
    transition: background-color 0.2s;
    cursor: pointer;
    border: none;
  }

  .btn-primary {
    background-color: #e34c26;
    color: white;
  }

  .btn-primary:hover {
    background-color: #cc4322;
  }

  .btn-secondary {
    background-color: #f0f0f0;
    color: #333;
    border: 1px solid #ddd;
  }

  .btn-secondary:hover {
    background-color: #e0e0e0;
  }

  .no-data-message {
    text-align: center;
    padding: 50px;
    color: #999;
    font-size: 1.1em;
  }

  /* 分页控制样式 */
  .pagination-controls {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 30px;
    gap: 15px;
  }

  .pagination-btn {
    display: flex;
    align-items: center;
    gap: 5px;
    background-color: #f5f5f5;
    color: #333;
    border: 1px solid #ddd;
    padding: 10px 15px;
    border-radius: 6px;
    cursor: pointer;
    transition: background-color 0.2s;
  }

  .pagination-btn:hover:not(:disabled) {
    background-color: #e0e0e0;
  }

  .pagination-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .page-info {
    font-size: 1em;
    color: #666;
  }

  .pagination-btn svg {
    width: 18px;
    height: 18px;
  }
</style>