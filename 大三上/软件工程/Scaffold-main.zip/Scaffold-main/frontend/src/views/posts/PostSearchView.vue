<script setup lang="ts">
import { ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { searchService } from '@/services/search.service'
import { useAuthStore } from '@/store/modules/auth'
import type { SearchPostResult } from '@/types/models'

const route = useRoute()
const router = useRouter()
const authStore = useAuthStore()

const keyword = ref('')
const searchType = ref('title')
const loading = ref(false)
const results = ref<SearchPostResult[]>([])
const totalCount = ref(0)
const hasSearched = ref(false)

const searchTypes = [
  { value: 'title', label: '标题' },
  { value: 'content', label: '内容' },
  { value: 'tag', label: '标签' },
]

const performSearch = async () => {
  if (!keyword.value.trim()) return
  
  loading.value = true
  hasSearched.value = true
  try {
    const userId = authStore.currentUser?.id || 0
    const response = await searchService.searchPosts(userId, keyword.value, searchType.value)
    if (response.success && response.data) {
      results.value = response.data.posts
      totalCount.value = response.data.count
    }
  } catch (error) {
    console.error('Search failed:', error)
  } finally {
    loading.value = false
  }
}

const onSearch = () => {
  router.push({ 
    query: { 
      q: keyword.value,
      type: searchType.value 
    } 
  })
}

// 格式化日期辅助函数
const formatDate = (timestamp: string | number) => {
  return new Date(timestamp).toLocaleDateString('zh-CN', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  })
}

watch(
  () => route.query,
  (newQuery) => {
    if (newQuery.q) {
      keyword.value = newQuery.q as string
      searchType.value = (newQuery.type as string) || 'title'
      performSearch()
    }
  },
  { immediate: true }
)
</script>

<template>
  <div class="search-container">
    <!-- 头部区域 -->
    <header class="page-header">
      <h1>探索交流</h1>
      <p class="subtitle">汇聚想法与灵感，根据关键词快速定位内容。</p>
    </header>

    <!-- 搜索表单区域 -->
    <div class="search-box">
      <form class="search-form" @submit.prevent="onSearch">
        <div class="input-group">
          <!-- 图标 -->
          <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          
          <input 
            v-model="keyword" 
            type="search" 
            class="main-input"
            placeholder="搜索你感兴趣的话题..." 
            required
          />
        </div>
        
        <div class="actions-group">
          <div class="select-wrapper">
            <select v-model="searchType">
              <option v-for="type in searchTypes" :key="type.value" :value="type.value">
                按{{ type.label }}
              </option>
            </select>
            <!-- 下拉箭头图标 -->
            <svg class="chevron-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
          </div>

          <button type="submit" :disabled="loading" class="btn-search">
            <span v-if="loading" class="spinner"></span>
            <span v-else>搜索</span>
          </button>
        </div>
      </form>
    </div>

    <!-- 结果区域 -->
    <section class="results-section">
      <!-- Loading -->
      <div v-if="loading" class="status-state">
        <div class="skeleton-loader"></div>
        <p>正在挖掘精彩内容...</p>
      </div>

      <!-- 结果列表 -->
      <div v-else-if="results.length > 0" class="results-container">
        <div class="results-header">
          <span class="count-badge">找到 {{ totalCount }} 个结果</span>
        </div>
        
        <div class="cards-grid">
          <article v-for="post in results" :key="post.id" class="post-card" @click="router.push(`/posts/${post.id}`)">
            <div class="card-content">
              <div class="card-meta">
                <span class="author">{{ post.author }}</span>
                <span class="dot">·</span>
                <span class="date">{{ formatDate(post.timestamp) }}</span>
              </div>
              
              <h2 class="card-title" v-html="post.title"></h2> <!-- 如果有高亮需求可后续处理 -->
              
              <p class="card-excerpt">{{ post.context }}</p>
              
              <div class="card-footer">
                <div class="tags" v-if="post.tags && post.tags.length">
                  <span v-for="tag in post.tags.slice(0, 3)" :key="tag" class="tag">#{{ tag }}</span>
                </div>
                
                <div class="stats">
                  <span class="stat-item" title="浏览">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                    {{ post.browse_count }}
                  </span>
                  <span class="stat-item" title="点赞">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"/></svg>
                    {{ post.like_count }}
                  </span>
                  <span class="stat-item" title="评论">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
                    {{ post.comment_count }}
                  </span>
                </div>
              </div>
            </div>
          </article>
        </div>
      </div>

      <!-- 空状态 -->
      <div v-else-if="hasSearched && !loading" class="empty-state">
        <div class="empty-icon">🔍</div>
        <h3>未找到相关结果</h3>
        <p>换个关键词或搜索类型试试看吧</p>
      </div>
    </section>
  </div>
</template>

<style scoped>
/* 容器与基础重置 */
.search-container {
  max-width: 1000px;
  margin: 0 auto;
  padding: 2rem 1.5rem;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  color: #334155;
}

/* 头部样式 */
.page-header {
  text-align: center;
  margin-bottom: 2.5rem;
}

.page-header h1 {
  font-size: 2rem;
  font-weight: 800;
  background: linear-gradient(135deg, #6366f1 0%, #a855f7 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  margin: 0 0 0.5rem 0;
}

.subtitle {
  color: #64748b;
  font-size: 1rem;
}

/* 搜索框样式 - 玻璃拟态/悬浮感 */
.search-box {
  background: #ffffff;
  border-radius: 16px;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 10px 15px -3px rgba(0, 0, 0, 0.05);
  padding: 0.75rem;
  margin-bottom: 3rem;
  border: 1px solid rgba(226, 232, 240, 0.8);
}

.search-form {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

/* 响应式：桌面端改为横向排列 */
@media (min-width: 640px) {
  .search-form {
    flex-direction: row;
    align-items: center;
  }
}

.input-group {
  flex: 1;
  display: flex;
  align-items: center;
  padding: 0 0.75rem;
  background: #f8fafc;
  border-radius: 10px;
  border: 1px solid transparent;
  transition: all 0.2s;
}

.input-group:focus-within {
  background: #fff;
  border-color: #818cf8;
  box-shadow: 0 0 0 3px rgba(129, 140, 248, 0.15);
}

.search-icon {
  width: 20px;
  height: 20px;
  color: #94a3b8;
  margin-right: 0.5rem;
}

.main-input {
  width: 100%;
  border: none;
  background: transparent;
  padding: 0.85rem 0;
  font-size: 1rem;
  outline: none;
  color: #1e293b;
}

.actions-group {
  display: flex;
  gap: 0.75rem;
}

/* 自定义下拉框 */
.select-wrapper {
  position: relative;
  min-width: 100px;
}

select {
  appearance: none;
  width: 100%;
  height: 100%;
  padding: 0 2rem 0 1rem;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  font-size: 0.95rem;
  color: #475569;
  cursor: pointer;
  outline: none;
  transition: all 0.2s;
}

select:focus {
  border-color: #818cf8;
}

.chevron-icon {
  position: absolute;
  right: 0.75rem;
  top: 50%;
  transform: translateY(-50%);
  width: 16px;
  height: 16px;
  color: #94a3b8;
  pointer-events: none;
}

.btn-search {
  padding: 0.75rem 2rem;
  background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
  color: white;
  border: none;
  border-radius: 10px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.1s, opacity 0.2s;
  white-space: nowrap;
}

.btn-search:hover {
  opacity: 0.95;
  transform: translateY(-1px);
}

.btn-search:active {
  transform: translateY(0);
}

.btn-search:disabled {
  background: #cbd5e1;
  cursor: not-allowed;
  transform: none;
}

/* 结果区域样式 */
.results-header {
  margin-bottom: 1.5rem;
}

.count-badge {
  font-size: 0.875rem;
  font-weight: 600;
  color: #64748b;
  background: #f1f5f9;
  padding: 0.25rem 0.75rem;
  border-radius: 99px;
}

/* 网格布局 */
.cards-grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: 1.5rem;
}

@media (min-width: 768px) {
  .cards-grid {
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  }
}

/* 卡片样式 */
.post-card {
  background: white;
  border-radius: 16px;
  border: 1px solid #f1f5f9;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  flex-direction: column;
}

.post-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 24px -8px rgba(0, 0, 0, 0.12);
  border-color: #e0e7ff;
}

.card-content {
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  height: 100%;
}

.card-meta {
  font-size: 0.8rem;
  color: #94a3b8;
  margin-bottom: 0.75rem;
  display: flex;
  align-items: center;
}

.dot {
  margin: 0 0.4rem;
}

.card-title {
  font-size: 1.25rem;
  line-height: 1.4;
  margin: 0 0 0.75rem 0;
  color: #1e293b;
  font-weight: 700;
  /* 标题最多显示2行 */
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.card-excerpt {
  color: #64748b;
  font-size: 0.95rem;
  line-height: 1.6;
  margin-bottom: 1.5rem;
  flex-grow: 1;
  /* 摘要最多显示3行 */
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.card-footer {
  margin-top: auto;
  border-top: 1px solid #f1f5f9;
  padding-top: 1rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.tags {
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
}

.tag {
  font-size: 0.75rem;
  color: #8b5cf6;
  background: #f3e8ff;
  padding: 0.2rem 0.5rem;
  border-radius: 6px;
  font-weight: 500;
}

.stats {
  display: flex;
  gap: 0.8rem;
  color: #94a3b8;
  font-size: 0.8rem;
}

.stat-item {
  display: flex;
  align-items: center;
  gap: 0.25rem;
}

/* 状态样式 */
.empty-state, .status-state {
  text-align: center;
  padding: 4rem 1rem;
  color: #64748b;
}

.empty-icon {
  font-size: 3rem;
  margin-bottom: 1rem;
  opacity: 0.5;
}

/* 简单的 Spinner 动画 */
.spinner {
  display: inline-block;
  width: 1rem;
  height: 1rem;
  border: 2px solid rgba(255,255,255,0.3);
  border-radius: 50%;
  border-top-color: #fff;
  animation: spin 1s ease-in-out infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}
</style>
