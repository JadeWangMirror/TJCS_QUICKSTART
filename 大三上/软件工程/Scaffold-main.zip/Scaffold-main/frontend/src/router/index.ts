import { createRouter, createWebHistory, type RouteRecordRaw } from 'vue-router'
import { useAuthStore } from '@/store/modules/auth'

const routes: RouteRecordRaw[] = [
  {
    path: '/',
    name: 'home',
    meta: { layout: 'main', breadcrumb: ['首页'] },
    component: () => import('@/views/home/HomeView.vue'),
  },
  {
    path: '/auth',
    meta: { layout: 'auth', guestOnly: true },
    children: [
      {
        path: 'login',
        name: 'auth.login',
        component: () => import('@/views/auth/LoginView.vue'),
        meta: { title: '登录账号' },
      },
      {
        path: 'register',
        name: 'auth.register',
        component: () => import('@/views/auth/RegisterView.vue'),
        meta: { title: '注册账号' },
      },
      {
        path: 'forgot-password',
        name: 'auth.forgot-password',
        component: () => import('@/views/auth/ForgotPasswordView.vue'),
        meta: { title: '找回密码' },
      },
    ],
  },
  {
    path: '/profile',
    meta: { requiresAuth: true, layout: 'main' },
    children: [
      {
        path: '',
        name: 'profile.overview',
        component: () => import('@/views/account/ProfileOverviewView.vue'),
        meta: { title: '个人资料' },
      },
      {
        path: 'settings',
        name: 'profile.settings',
        component: () => import('@/views/account/ProfileSettingsView.vue'),
        meta: { title: '个人信息设置' },
      },
      {
        path: 'favorites',
        name: 'profile.favorites',
        component: () => import('@/views/posts/FavoritePost.vue'),
        meta: { title: '我的收藏' },
      },
      {
        path: 'follows',
        name: 'profile.follows',
        component: () => import('@/views/account/FollowFeedView.vue'),
        meta: { title: '关注动态' },
      },
      {
        path: 'history',
        name: 'profile.history',
        component: () => import('@/views/account/GenerationArchiveView.vue'),
        meta: { title: '生成历史归档' },
      },
      {
        path: 'mypost',
        name: 'profile.history',
        component: () => import('@/views/posts/MyPost.vue'),
        meta: { title: '我的帖子' },
      },
    ],
  },
  {
    path: '/posts',
    meta: { layout: 'main' },
    children: [
      {
        path: '',
        name: 'posts.index',
        component: () => import('@/views/posts/PostFeedView.vue'),
        meta: { title: '交流帖列表' },
      },
      {
        path: 'new',
        name: 'posts.new',
        component: () => import('@/views/posts/PostCreateView.vue'),
        meta: { title: '发布交流帖', requiresAuth: true },
      },
      {
        path: ':id',
        name: 'posts.detail',
        component: () => import('@/views/posts/PostDetailView.vue'),
        meta: { title: '帖子详情' },
      },
      {
        path: ':id/edit',
        name: 'posts.edit',
        component: () => import('@/views/posts/PostEditView.vue'),
        meta: { title: '编辑交流帖', requiresAuth: true, authorOnly: true },
      },
      {
        path: 'search',
        name: 'posts.search',
        component: () => import('@/views/posts/PostSearchView.vue'),
        meta: { title: '搜索交流帖' },
      },
      {
        path: 'tags',
        name: 'posts.tags',
        component: () => import('@/views/posts/PostTagExploreView.vue'),
        meta: { title: '标签探索' },
      },
      {
        path: 'tags/:tagId',
        name: 'posts.tag-detail',
        component: () => import('@/views/posts/PostTagDetailView.vue'),
        meta: { title: '标签详情' },
      },
      {
        path: 'collections',
        name: 'posts.collections',
        component: () => import('@/views/posts/PostCollectionsView.vue'),
        meta: { title: '收藏列表', requiresAuth: true },
      },
    ],
  },
  {
    path: '/ai',
    meta: { layout: 'main', requiresAuth: true },
    children: [
      {
        path: 'workbench',
        name: 'ai.workbench',
        component: () => import('@/views/ai/AiWorkbenchView.vue'),
        meta: { title: '提示词工作台' },
      },
      {
        path: 'history',
        name: 'ai.history',
        component: () => import('@/views/ai/AiHistoryView.vue'),
        meta: { title: '生成历史' },
      },
      {
        path: 'generate',
        name: 'ai.generate',
        component: () => import('@/views/ai/AiImageGen.vue'),
        meta: { title: '生图工坊' },
      },
      {
        path: 'genhistory',
        name: 'ai.genhistory',
        component: () => import('@/views/ai/AiImageHistory.vue'),
        meta: { title: '生图历史' },
      },
    ],
  },
  {
    path:'/history',
    meta: { layout: 'main' , requiresAuth: true},
    children:[{
      path:"browse",
      name:"browseHistory",
      component:()=>import("@/views/browsehistory/browseHistory.vue"),
      meta:{title:"浏览记录"}
    }]
  },
  {
    path: '/recommendations',
    meta: { layout: 'main' },
    children: [
      {
        path: 'personal',
        name: 'recommendations.personal',
        component: () => import('@/views/recommendation/PersonalizedRecommendView.vue'),
        meta: { title: '个性化推荐', requiresAuth: true },
      },
      {
        path: 'trending',
        name: 'recommendations.trending',
        component: () => import('@/views/recommendation/TrendingView.vue'),
        meta: { title: '热门推荐' },
      },
            {
        path: 'latest',
        name: 'recommendations.latest',
        component: () => import('@/views/recommendation/LatestView.vue'),
        meta: { title: '最新推荐' },
      },
      // {
      //   path: 'tags',
      //   name: 'recommendations.tags',
      //   component: () => import('@/views/recommendation/TagRecommendView.vue'),
      //   meta: { title: '标签推荐' },
      // },
    ],
  },
  {
    path: '/messages',
    name: 'messages.index',
    meta: { layout: 'main', requiresAuth: true },
    component: () => import('@/views/social/MessagesView.vue'),
  },
  {
    path: '/notifications',
    name: 'notifications.index',
    meta: { layout: 'main', requiresAuth: true },
    component: () => import('@/views/social/NotificationsView.vue'),
  },
  {
    path: '/admin',
    meta: { layout: 'admin', requiresAdmin: true },
    children: [
      {
        path: 'dashboard',
        name: 'admin.dashboard',
        component: () => import('@/views/admin/AdminDashboardView.vue'),
        meta: { title: '管理总览' },
      },
      {
        path: 'users',
        name: 'admin.users',
        component: () => import('@/views/admin/AdminUsersView.vue'),
        meta: { title: '用户管理' },
      },
      {
        path: 'content',
        name: 'admin.content',
        component: () => import('@/views/admin/AdminContentReviewView.vue'),
        meta: { title: '内容审核' },
      },
      {
        path: 'tags',
        name: 'admin.tags',
        component: () => import('@/views/admin/AdminTagManagementView.vue'),
        meta: { title: '标签管理' },
      },
      {
        path: 'statistics',
        name: 'admin.statistics',
        component: () => import('@/views/admin/AdminStatisticsView.vue'),
        meta: { title: '数据统计' },
      },
    ],
  },
  {
    path: '/support',
    meta: { layout: 'main' },
    children: [
      {
        path: 'about',
        name: 'support.about',
        component: () => import('@/views/support/AboutView.vue'),
        meta: { title: '关于我们' },
      },
      {
        path: 'guidelines',
        name: 'support.guidelines',
        component: () => import('@/views/support/GuidelinesView.vue'),
        meta: { title: '社区规范' },
      },
      {
        path: 'feedback',
        name: 'support.feedback',
        component: () => import('@/views/support/FeedbackView.vue'),
        meta: { title: '反馈与建议' },
      },
    ],
  },
  {
    path: '/logout',
    name: 'auth.logout',
    meta: { layout: 'main', requiresAuth: true },
    component: () => import('@/views/auth/LogoutView.vue'),
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'not-found',
    meta: { layout: 'main' },
    component: () => import('@/views/system/NotFoundView.vue'),
  },
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
})

// 路由守卫：检查登录状态
router.beforeEach((to, from, next) => {
  const authStore = useAuthStore()
  
  // 检查路由是否需要认证
  const requiresAuth = to.matched.some(record => record.meta.requiresAuth)
  const guestOnly = to.matched.some(record => record.meta.guestOnly)
  
  const isLoggedIn = authStore.isLoggedIn
  
  if (requiresAuth && !isLoggedIn) {
    // 需要登录但未登录，跳转到登录页
    next({
      path: '/auth/login',
      query: { redirect: to.fullPath }
    })
  } else if (guestOnly && isLoggedIn) {
    // 访客页面但已登录，跳转到首页
    next('/')
  } else {
    // 正常导航
    next()
  }
})

export default router
