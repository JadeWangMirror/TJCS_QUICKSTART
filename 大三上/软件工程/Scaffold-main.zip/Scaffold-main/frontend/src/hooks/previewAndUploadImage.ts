// composables/useImageUpload.ts

import { ref, onUnmounted } from 'vue';

// 定义图片项的类型
export interface ImageItem {
  file: File;
  previewUrl: string;
}

/**
 * 图片上传和预览逻辑的组合式函数 (Composable)
 * @param maxFiles 最大允许上传的文件数量，默认为 9
 * @param allowedMimeTypes 允许上传的 MIME 类型，默认为 ['image/*']
 * @returns 包含状态和操作函数的对象
 */
export function useImageUpload(
  maxFiles: number = 9,
  allowedMimeTypes: string[] = ['image/*'],
) {
  // UI 状态：管理图片文件和预览 URL
  const imageItems = ref<ImageItem[]>([]);
  
  // 预览模态框状态
  const previewVisible = ref(false);
  const currentPreview = ref('');

  /**
   * 检查文件是否为允许的类型
   */
  const isFileTypeAllowed = (file: File): boolean => {
    if (allowedMimeTypes.includes('*/*')) return true;

    return allowedMimeTypes.some(mime => {
      if (mime.endsWith('/*')) {
        return file.type.startsWith(mime.slice(0, -2));
      }
      return file.type === mime;
    });
  };

  /**
   * 添加文件到状态
   */
  const addFile = (file: File) => {
    if (!isFileTypeAllowed(file)) {
      alert(`文件类型 ${file.type} 不被允许!`);
      return;
    }
    
    // 检查数量限制
    if (imageItems.value.length >= maxFiles) {
      alert(`最多只能上传 ${maxFiles} 张图片/文件`);
      return;
    }

    const previewUrl = URL.createObjectURL(file);
    imageItems.value.push({ file, previewUrl });
  };

  /**
   * 处理 <input type="file"> 的 change 事件
   */
  const handleFileSelect = (event: Event) => {
    const input = event.target as HTMLInputElement;
    if (!input.files) return;

    for (const file of input.files) {
      addFile(file);
    }
    // 确保同一个文件再次选择时能触发 change 事件
    input.value = '';
  };

  /**
   * 处理拖拽 (Drag and Drop) 事件
   */
  const handleDrop = (event: DragEvent) => {
    if (!event.dataTransfer?.files) return;
    for (const file of event.dataTransfer.files) {
      addFile(file);
    }
  };

  /**
   * 从状态中移除文件并释放内存
   */
  const removeFile = (index: number) => {
    const item = imageItems.value[index];

    // 释放内存
    if (item) {
      URL.revokeObjectURL(item.previewUrl);
    }
    // 从 UI 状态中移除
    imageItems.value.splice(index, 1);
  };

  /**
   * 打开预览模态框
   */
  const openPreview = (src: string) => {
    currentPreview.value = src;
    previewVisible.value = true;
  };

  /**
   * 关闭预览模态框
   */
  const closePreview = () => {
    previewVisible.value = false;
    currentPreview.value = '';
  };
  
  /**
   * 获取文件数组
   */
  const getFiles = (): File[] => {
      return imageItems.value.map(item => item.file);
  };

  /**
   * 清理所有文件和内存
   */
  const clearAllFiles = () => {
     imageItems.value.forEach(item => {
        URL.revokeObjectURL(item.previewUrl);
     });
     imageItems.value = [];
  }


  // 组件卸载时自动清理内存
  onUnmounted(() => {
    clearAllFiles();
  });

  return {
    imageItems,
    previewVisible,
    currentPreview,
    handleFileSelect,
    handleDrop,
    removeFile,
    openPreview,
    closePreview,
    getFiles,
    clearAllFiles,
    // 允许外部组件访问最大文件数
    maxFiles
  };
}