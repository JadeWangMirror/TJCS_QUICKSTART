export function formatDate(timestamp?: number | string): string { 
  if (!timestamp) return '未知时间';

  let date: Date;
  
  // 1. 尝试将输入转换为 Date 对象
  
  // 检查输入是否为日期字符串（包含非数字字符）
  if (typeof timestamp === 'string' && !/^\d+(\.\d+)?$/.test(timestamp.trim())) {
    // 假设这是标准日期字符串格式（如 GMT 格式），直接尝试解析
    date = new Date(timestamp);
  } else {
    // 假设这是时间戳（数字或纯数字字符串）
    
    // a. 清理时间戳：移除小数部分，确保其为整数
    const timestampStr = String(timestamp);
    let cleanTimestampStr = timestampStr.split('.')[0]!; 
    
    const numTimestamp = parseInt(cleanTimestampStr);
    
    if (isNaN(numTimestamp)) {
      return '无效日期';
    }

    // b. 判断时间戳长度（秒级 vs 毫秒级）
    if (cleanTimestampStr.length === 10) {
      date = new Date(numTimestamp * 1000); // 秒级转毫秒
    } else {
      date = new Date(numTimestamp); // 默认为毫秒级
    }
  }

  // 2. 格式化输出 (YYYY年MM月DD日)
  if (isNaN(date.getTime())) {
    // 如果 new Date() 解析失败
    return '无效日期';
  }

  const year = date.getFullYear();
  // 注意：getMonth() 返回 0-11，需要 +1
  const month = date.getMonth() + 1; 
  const day = date.getDate();

  return `${year}年${month}月${day}日`;
}