import { defineStore } from "pinia";
import type {
  ApiPostsListResponse,
  PostHistoryResponse,
} from "@/types/api-response";
import type { SearchFilters, ApiResult } from "@/types/api"; // 导入 ApiResult
import { browseHistoryService } from "@/services/browseHistory.service";
import { useAuthStore } from "./auth";
interface BrowseHistoryState {
  loading: boolean;
  feed: PostHistoryResponse | null; //这里feed返回的就是帖子列表
}

export const useBrowseHistoryStore = defineStore("BrowseHistory", {
  state: (): BrowseHistoryState => ({
    loading: false,
    feed: null,
  }),

  actions: {
    /**
     * 通用获取帖子流的方法，调用 Service 层
     * @param filters 分页和筛选参数
     */
    async fetchBrowseHistory(filters?: SearchFilters) {
      const authStore = useAuthStore();
      let userId = authStore.currentUser?.id;
      if (!userId) {
        throw new Error("User not authenticated.");
      }
      this.loading = true;
      try {
        let response: ApiResult<PostHistoryResponse>;
        response = await browseHistoryService.FetchBrowseHistory(
          userId,
          filters
        );

        if (response.success && response.data) {
          this.feed = response.data;
        }
        return response;
      } catch (error) {
        console.error("store层错误:", error);
        throw error;
      } finally {
        this.loading = false;
      }
    },
    async deleteBrowseHistory(record_id: number) {
      const authStore = useAuthStore();
      const userId = authStore.currentUser?.id;
      if (!userId) {
        throw new Error("User not authenticated.");
      }
      this.loading = true;
      try {
        let response: ApiResult<{ data: null }>;
        response = await browseHistoryService.DeleteBrowseHistory(
          userId,
          record_id
        );
        return response;
      } catch (error) {
        console.error("store层错误:", error);
        throw error;
      } finally {
        this.loading = false;
      }
    },
    async deleteAllBrowseHistory() {
      const authStore = useAuthStore();
      const userId = authStore.currentUser?.id;
      if (!userId) {
        throw new Error("User not authenticated.");
      }
      this.loading = true;
      try {
        let response: ApiResult<{ data: null }>;
        response = await browseHistoryService.DeleteAllBrowseHistory(userId);
        return response;
      } catch (error) {
        console.error("store层错误:", error);
        throw error;
      } finally {
        this.loading = false;
      }
    },
  },
});
