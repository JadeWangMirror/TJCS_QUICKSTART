import { defineStore } from "pinia";
import { postService } from "@/services/post.service";
import { commentService } from "@/services/comment.service";
import type {
  PostSummary,
  CommentFormPayload,
  PostFormPayload,
  PostDetailWithStatus,
} from "@/types/models";
import { useAuthStore } from "./auth";

interface PostState {
  selectedPost: PostDetailWithStatus | null;
  is_liked: boolean | null;
  is_favorited: boolean | null;
  loading: boolean;
  isFetchingDetail: boolean;
  isLikingPost: boolean;
  isFavoritingPost: boolean;
}

export const usePostStore = defineStore("post", {
  state: (): PostState => ({
    selectedPost: null,
    is_liked: null,
    is_favorited: null,
    loading: false,
    isFetchingDetail: false, // 专门用于获取帖子详情
    isLikingPost: false, // 专门用于点赞/取消点赞
    isFavoritingPost: false,
  }),
  actions: {
    async fetchPostDetail(postId: number) {
      this.isFetchingDetail = true; // 开始加载
      const authStore = useAuthStore();
      let userId = authStore.currentUser?.id;
      if (!userId) {
        // 等待 50 毫秒，希望 Pinia 能完成状态恢复
        await new Promise((resolve) => setTimeout(resolve, 10));
        userId = authStore.currentUser?.id;
      }
      const response = await postService.fetchPostDetailAndStatus(postId);
      if (response.success && response.data) {
        this.selectedPost = response.data;
        this.is_liked = response.data.is_liked;
        this.is_favorited = response.data.is_favorited;
      } else {
        // 如果获取失败，最好清除旧数据，或者保持原样，取决于业务需求
        this.selectedPost = null;
      }
      this.isFetchingDetail = false; // 结束加载
      return response;
    },

    async createPost(payload: PostFormPayload) {
      const authStore = useAuthStore();
      const userId = authStore.currentUser?.id;
      if (!userId) {
        throw new Error("User not authenticated.");
      }
      this.loading = true; // 开始加载
      try {
        const result = await postService.createPost(userId, payload);
        return result;
      } finally {
        this.loading = false; // 结束加载
      }
    },
    async createComment(payload: CommentFormPayload) {
      const authStore = useAuthStore();
      const userId = authStore.currentUser?.id;
      if (!userId) {
        throw new Error("User not authenticated.");
      }
      const postId = this.selectedPost?.id;
      if (!postId) {
        throw new Error("User not authenticated.");
      }
      this.loading = true; // 开始加载
      try {
        const result = await commentService.createComment(
          userId,
          postId,
          payload
        );
        return result;
      } finally {
        this.loading = false; // 结束加载
      }
    },
    async deleteComment(commentId: number) {
      const authStore = useAuthStore();
      const userId = authStore.currentUser?.id;
      if (!userId) {
        throw new Error("User not authenticated.");
      }
      try {
        const result = await postService.deletePost(userId, commentId);
        return result;
      } finally {
        this.loading = false; // 结束加载
      }
    },
    async updatePost(postId: number, payload: PostFormPayload) {
      const authStore = useAuthStore();
      const userId = authStore.currentUser?.id;
      if (!userId) {
        throw new Error("User not authenticated.");
      }
      this.loading = true; // 开始加载
      try {
        const result = await postService.updatePost(userId, postId, payload);
        return result;
      } finally {
        this.loading = false; // 结束加载
      }
    },

    async deletePost(postId: number) {
      const authStore = useAuthStore();
      const userId = authStore.currentUser?.id;
      if (!userId) {
        throw new Error("User not authenticated.");
      }
      try {
        const result = await postService.deletePost(userId, postId);
        return result;
      } finally {
        this.loading = false; // 结束加载
      }
    },
    async likePost(postId: number) {
      // 仅在 Store 中有当前帖子的详情数据时才执行状态更新
      if (!this.selectedPost || this.selectedPost.id !== postId) {
        // 可以在这里选择抛出错误，或直接返回 API 结果
        console.warn("Attempted to like a post not currently selected.");
        // 即使没有详情数据，也应该调用 API
      }
      const authStore = useAuthStore();
      const userId = authStore.currentUser?.id;
      if (!userId) {
        throw new Error("User not authenticated.");
      }
      this.isLikingPost = true; // 开始加载
      try {
        const result = await postService.likePost(userId, postId);
        if (
          result.success &&
          this.selectedPost &&
          this.selectedPost.id === postId
        ) {
          this.selectedPost.like_count =
            result.data?.likeCount ?? this.selectedPost.like_count;
          this.selectedPost.is_liked = result.data?.isLike ?? false;
          this.is_liked = result.data?.isLike ?? false;
        }

        return result;
      } finally {
        this.isLikingPost = false;
      }
    },
    async favoritePost(postId: number) {
      if (!this.selectedPost || this.selectedPost.id !== postId) {
        // 可以在这里选择抛出错误，或直接返回 API 结果
        console.warn("Attempted to favorite a post not currently selected.");
        // 即使没有详情数据，也应该调用 API
      }
      const authStore = useAuthStore();
      const userId = authStore.currentUser?.id;
      if (!userId) {
        throw new Error("User not authenticated.");
      }
      this.isFavoritingPost = true; // 开始加载
      try {
        const result = await postService.favoritePost(userId, postId);
        if (
          result.success &&
          this.selectedPost &&
          this.selectedPost.id === postId
        ) {
          this.selectedPost.favorite_count =
            result.data?.favorite_count??0;
          this.selectedPost.is_favorited = result.data?.isFavorited ?? false;
          this.is_favorited = result.data?.isFavorited ?? false;
        }

        return result;
      } finally {
        this.isFavoritingPost= false;
      }
    },
  },
});
