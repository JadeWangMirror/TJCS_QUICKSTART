import { defineStore } from 'pinia'

import type {
  OptimizationRecord,
  OptimizationHistoryResponse,
  OptimizePromptResponse
} from '@/types/ai'
import { httpClient } from '@/utils/httpClients'

interface OptimizeState {
  optimizationHistory: OptimizationRecord[]
  currentOptimization: OptimizationRecord | null
  isLoading: boolean
}

import { useAuthStore } from "@/store/modules/auth";

const normalizeRecord = (record: OptimizePromptResponse): OptimizationRecord => {
  const timestamp =
    record.timestamp ?? record.completed_at ?? new Date().toISOString()

  return {
    ...record,
    timestamp
  }
}

export const useOptimizeStore = defineStore('optimize', {
  state: (): OptimizeState => ({
    optimizationHistory: [],
    currentOptimization: null,
    isLoading: false
  }),

  actions: {
    setLoading(status: boolean) {
      this.isLoading = status
    },
    setOptimizationResult(result: OptimizationRecord | null) {
      this.currentOptimization = result
    },
    setHistory(history: OptimizationRecord[]) {
      this.optimizationHistory = [...history]
    },
    addToHistory(record: OptimizationRecord) {
      this.optimizationHistory.unshift(record)
    },

    async optimizePrompt(prompt: string) {
      this.setLoading(true)
      try {
        const authStore = useAuthStore();
        // 等待用户ID可用
        let retries = 0
        while (!authStore.currentUser?.id && retries < 3) {
          await new Promise(resolve => setTimeout(resolve, 100))
          retries++
        }
        const user_id = authStore.currentUser?.id;
        if (!user_id) {
          throw new Error("User not authenticated.");
        }
        const result = await httpClient<OptimizePromptResponse>('/api/optimize', {
          method: 'POST',
          body: { prompt,
              user_id
           },
          auth: false
        })

        const normalized = normalizeRecord(result)
        this.setOptimizationResult(normalized)
        this.addToHistory(normalized)

        return normalized
      } catch (error) {
        console.error('优化失败:', error)
        throw error
      } finally {
        this.setLoading(false)
      }
    },

    async loadHistory() {
      try {
        const authStore = useAuthStore();
        // 等待用户ID可用
        let retries = 0
        while (!authStore.currentUser?.id && retries < 3) {
          await new Promise(resolve => setTimeout(resolve, 100))
          retries++
        }
        const user_id = authStore.currentUser?.id;
        if (!user_id) {
          throw new Error("User not authenticated.");
        }
        const data = await httpClient<OptimizationHistoryResponse>(`api/user/${user_id}/history/ai`, {
          method: 'GET',
          auth: false
        })
        const records = Array.isArray(data?.records) ? data.records : []
        this.setHistory(records.map((record) => normalizeRecord(record)))
      } catch (error) {
        console.error('加载历史记录失败:', error)
      }
    }
  }
})
