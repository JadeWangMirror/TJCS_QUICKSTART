import { defineStore } from 'pinia'
import { authService, type LoginPayload, type RegisterPayload } from '@/services/auth.service'
import type { AuthTokens } from '@/types/api'
import type { UserSummary } from '@/types/models'
import { setCookie, getCookie, removeCookie } from '@/utils/cookie'
import { userService } from '@/services/user.service'

interface AuthState {
  currentUser: UserSummary | null
  tokens: AuthTokens | null
  loading: boolean
}

// Token 存储键名
const ACCESS_TOKEN_KEY = 'access_token'
const REFRESH_TOKEN_KEY = 'refresh_token'
const TOKENS_STORAGE_KEY = 'auth_tokens' // 用于存储完整的 tokens 对象

export const useAuthStore = defineStore('auth', {
  state: (): AuthState => ({
    currentUser: null,
    tokens: null,
    loading: false,
  }),
  getters: {
    isLoggedIn: (state) => Boolean(state.tokens),
  },
  actions: {
    /**
     * 保存 token 到 localStorage 和 cookie
     * @param tokens - token 对象
     * @param expiresInSeconds - 过期时间（秒），用于设置 cookie 过期时间
     */
    _saveTokens(tokens: AuthTokens, expiresInSeconds?: number) {
      // 保存到 localStorage
      localStorage.setItem(ACCESS_TOKEN_KEY, tokens.accessToken)
      localStorage.setItem(REFRESH_TOKEN_KEY, tokens.refreshToken || '')
      localStorage.setItem(TOKENS_STORAGE_KEY, JSON.stringify(tokens))

      // 根据 expiresInSeconds 计算 cookie 过期天数
      // 如果没有提供，则根据 expiredAt 计算，默认30天
      let cookieDays = 30
      if (expiresInSeconds) {
        cookieDays = Math.ceil(expiresInSeconds / (24 * 60 * 60)) // 转换为天数，向上取整
      } else if (tokens.expiredAt) {
        const expiredAt = new Date(tokens.expiredAt)
        const now = new Date()
        const diffMs = expiredAt.getTime() - now.getTime()
        cookieDays = Math.max(1, Math.ceil(diffMs / (24 * 60 * 60 * 1000))) // 至少1天
      }

      // 保存到 cookie（用于持久化）
      setCookie(ACCESS_TOKEN_KEY, tokens.accessToken, cookieDays)
      if (tokens.refreshToken) {
        setCookie(REFRESH_TOKEN_KEY, tokens.refreshToken, cookieDays)
      }
    },

    /**
     * 从存储中恢复 tokens
     */
    _restoreTokens(): AuthTokens | null {
      // 优先从 localStorage 恢复
      const storedTokens = localStorage.getItem(TOKENS_STORAGE_KEY)
      if (storedTokens) {
        try {
          const tokens = JSON.parse(storedTokens) as AuthTokens
          // 验证 token 是否过期
          if (tokens.expiredAt && new Date(tokens.expiredAt) > new Date()) {
            return tokens
          }
        } catch (e) {
          console.error('Failed to parse stored tokens:', e)
        }
      }

      // 如果 localStorage 没有，尝试从 cookie 恢复
      const accessToken = getCookie(ACCESS_TOKEN_KEY)
      if (accessToken) {
        const refreshToken = getCookie(REFRESH_TOKEN_KEY) || ''
        return {
          accessToken,
          refreshToken,
          expiredAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 默认30天
        }
      }

      return null
    },

    /**
     * 清除所有存储的 token
     */
    _clearTokens() {
      // 清除 localStorage
      localStorage.removeItem(ACCESS_TOKEN_KEY)
      localStorage.removeItem(REFRESH_TOKEN_KEY)
      localStorage.removeItem(TOKENS_STORAGE_KEY)

      // 清除 cookie
      removeCookie(ACCESS_TOKEN_KEY)
      removeCookie(REFRESH_TOKEN_KEY)
    },

    /**
     * 初始化：从存储中恢复登录状态
     * 先同步恢复 token，然后异步获取用户信息
     */
    async initAuth() {
      const tokens = this._restoreTokens()
      if (tokens) {
        // 先同步恢复 token，让 isLoggedIn 立即为 true
        this.tokens = tokens
        
        // 然后异步获取用户信息（不阻塞应用启动）
        // 使用 setTimeout 确保不阻塞路由守卫
        setTimeout(async () => {
          try {
            const result = await userService.getCurrentUserProfile()
            if (result.success && result.user) {
              this.currentUser = result.user
            } else {
              // 如果获取用户信息失败，可能是 token 已过期，清除 token
              console.warn('Failed to restore user info, clearing tokens')
              this.tokens = null
              this._clearTokens()
            }
          } catch (error) {
            // 获取用户信息失败，检查是否是 401（token 过期）
            if (error && typeof error === 'object' && 'status' in error && error.status === 401) {
              // Token 已过期，清除 token
              console.warn('Token expired, clearing tokens')
              this.tokens = null
              this._clearTokens()
            } else {
              // 其他错误，可能是网络问题，暂时保留 token
              console.error('Error restoring user info:', error)
            }
          }
        }, 0)
      }
    },

    async login(payload: LoginPayload) {
      this.loading = true
      try {
        const response = await authService.login(payload)

        if (response.status === 'success') {
          const tokens: AuthTokens = {
            accessToken: response.token,
            refreshToken: '', // 后端暂未返回 refreshToken
            expiredAt: new Date(Date.now() + response.expires_in * 1000).toISOString(),
          }

          // 保存到 store
          this.tokens = tokens

          // 统一保存到 localStorage 和 cookie，传入 expires_in 以正确设置 cookie 过期时间
          this._saveTokens(tokens, response.expires_in)

          // 临时填充 currentUser，页面加载后会通过 /api/user/me 获取真实资料
          this.currentUser = {
            id: Number(response.user_id) || 0,
            name: payload.name,
            introduce: '',
            tag: [],
            created_at: new Date().toISOString(),
            email: payload.name,
            avatarUrl: null,
            followers: 0,
            following: 0,
            role: 'user',
            status: 'active',
          }
        }

        return response
      } finally {
        this.loading = false
      }
    },

    async register(payload: RegisterPayload) {
      this.loading = true
      try {
        return await authService.register(payload)
      } finally {
        this.loading = false
      }
    },

    async logout() {
      try {
        await authService.logout()
      } catch (error) {
        // 即使后端登出失败，也要清除本地状态
        console.error('Logout error:', error)
      } finally {
        // 清除 store 状态
        this.currentUser = null
        this.tokens = null

        // 清除所有存储的 token
        this._clearTokens()
      }
    },
  },
})
