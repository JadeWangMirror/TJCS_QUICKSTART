import { defineStore } from 'pinia'
interface UiState {
  sidebarCollapsed: boolean
  darkMode: boolean
}

export const useUiStore = defineStore('ui', {
  state: (): UiState => ({
    sidebarCollapsed: false,
    darkMode: false,
  }),
  actions: {
    toggleSidebar() {
      this.sidebarCollapsed = !this.sidebarCollapsed
    },
    toggleDarkMode() {
      this.darkMode = !this.darkMode
      document.documentElement.dataset.theme = this.darkMode ? 'dark' : 'light'
    },
  },
})
