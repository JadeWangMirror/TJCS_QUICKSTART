import { defineStore } from "pinia";
import { recommendationService } from "@/services/recommendation.service";
import type { ApiPostsListResponse } from "@/types/api-response";
import type { PaginatedResponse, SearchFilters, ApiResult } from "@/types/api"; // 导入 ApiResult
import type { PostSummary } from "@/types/models";
import { useAuthStore } from "./auth";
import { PostListApi } from "@/api/PostList.api";
//这里原先是考虑可能有靠个性化，流行还有标签筛选的推荐，但是目前后端没有留出接口，暂时不考虑吧
interface RecommendationState {
  loading: boolean;
  feed: ApiPostsListResponse | null; //这里feed返回的就是帖子列表
}

export const useRecommendationStore = defineStore("recommendation", {
  state: (): RecommendationState => ({
    loading: false,
    feed: null,
  }),

  actions: {
    /**
     * 通用获取帖子流的方法，调用 Service 层
     * @param endpoint 帖子流类型
     * @param filters 分页和筛选参数
     */
    async fetchFeed(
      endpoint: "newest" | "hotest" | "recommend" | "my" | "favorite",
      filters?: SearchFilters
    ) {
      this.loading = true;
      try {
        let response: ApiResult<ApiPostsListResponse>;
        // 根据 endpoint 调用 Service 层的具体方法
        if (endpoint === "newest") {
          response = await recommendationService.fetchNewestFeed(
            undefined,
            filters
          );
        } else if (endpoint === "hotest") {
          response = await recommendationService.fetchHottestFeed(
            undefined,
            filters
          );
        } else if (endpoint === "my") {
          const authStore = useAuthStore();
          const userId = authStore.currentUser?.id;
          if (!userId) {
            throw new Error("User not authenticated.");
          }
          response = await recommendationService.fetchMyPosts(userId, filters);
        } else if (endpoint == "favorite") {
          const authStore = useAuthStore();
          const userId = authStore.currentUser?.id;
          if (!userId) {
            throw new Error("User not authenticated.");
          }
          response = await recommendationService.fetchFavoritePosts(
            userId,
            filters
          );
        } else {
          const authStore = useAuthStore();
          const userId = authStore.currentUser?.id;
          if (!userId) {
            throw new Error("User not authenticated.");
          }
          response = await recommendationService.fetchRecommendedFeed(
            userId,
            filters
          );
        }

        if (response.success && response.data) {
          this.feed = response.data;
        }
        return response;
      } catch (error) {
        // 错误通常在 Service 层处理并包装，这里可以做全局错误通知
        console.error("store层错误:", error);
        throw error;
      } finally {
        this.loading = false;
      }
    },
  },
});
