<div align="center">

# [Tongji University Software Engineering] Scaffold

[![Project Website](https://img.shields.io/badge/🌐-Project%20Website-deepgray)](https://github.com/SE-Tales-Cooperate-Code-Branch/Scaffold)

[Yiwei Wang*](https://github.com/JadeWangMirror), [Kuo Li*](https://github.com/Zlatanwic), [Chen Ye*](https://github.com/mikaduu), [Siyuan Xu*](https://github.com/changingxsy), [Baizhou Gao*](https://github.com/gbz666), [Lexin Zhou*](https://github.com/Miraaaacle), [Ke Feng*](https://github.com/fluckyflucky)

School of Computer Science, Tongji University

*These authors contributed equally

</div>

----

## 🔥 Introduction

This project is a group development project for the Software Engineering course in the Department of Computer Science and Technology at Tongji University, for the Fall 2025-2026 semester.

## 🔥 ScaffoldFront

This template should help you get started developing with Vue 3 in Vite.

### Recommended IDE Setup

[VS Code](https://code.visualstudio.com/) + [Vue (Official)](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur).

### Recommended Browser Setup

- Chromium-based browsers (Chrome, Edge, Brave, etc.):
  - [Vue.js devtools](https://chromewebstore.google.com/detail/vuejs-devtools/nhdogjmejiglipccpnnnanhbledajbpd) 
  - [Turn on Custom Object Formatter in Chrome DevTools](http://bit.ly/object-formatters)
- Firefox:
  - [Vue.js devtools](https://addons.mozilla.org/en-US/firefox/addon/vue-js-devtools/)
  - [Turn on Custom Object Formatter in Firefox DevTools](https://fxdx.dev/firefox-devtools-custom-object-formatters/)

### Type Support for `.vue` Imports in TypeScript

TypeScript cannot handle type information for `.vue` imports by default, so we replace the `tsc` CLI with `vue-tsc` for type checking. In editors, we need [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) to make the TypeScript language service aware of `.vue` types.

### Customize Configuration

See [Vite Configuration Reference](https://vite.dev/config/).

### Project Setup

```sh
pnpm install
```

#### Compile and Hot-Reload for Development

```sh
pnpm dev
```

#### Type-Check, Compile and Minify for Production

```sh
pnpm build
```

## 🔥Code Standards

### Frontend

- Pinyin is prohibited
- Use Vite as the build tool, Vue 3 Composition API framework, and TypeScript language to ensure strict typing
- Component names: PascalCase
- Function/variable/constant names: camelCase
- Use RESTful API

### Backend

- Class names: PascalCase
- Function/variable/constant names: camelCase
- Pinyin is prohibited
- Every declaration must have comments. Constructors without parameters can be omitted.

Example:

```java
// Station class
class Station {
    private int stationId; // Station ID
    private String mapURLForStation; // Station map URL
    
    public Station() {
    
    }
    
    // Get map URL
    public getMapURLForStation() {
    
    }
}
```
## 🔥Frontend-Backend Interface API

**Standard**: We uniformly use Restful API (based on HTTP)

---

### 📋 User Management

#### ➕ Add User

**Method**: `POST`  
**URL**: `baseURL/user`  
**Body** (Example):
```JSON
{
    "id": 1,
    "password": "HJB24NAJSH4" // Consider transmitting after hash encryption to avoid plaintext
    // ...other fields
}
```
**Response**:
```json
{
    "code": 204,
    "msg": "Created"
}
```

#### ✏️ Modify User

**Method**: `PUT`  
**URL**: `baseURL/user/{id}`  
**Body** (Example):
```JSON
{
    "password": "HJB24NAJSH4" // Consider transmitting after hash encryption to avoid plaintext
    // ...other fields
}
```
**Response**:
```json
{
    "code": 200,
    "msg": "success"
}
```

## ✏️ To Do List

- [ ] Release the code

