import { fileURLToPath, URL } from "node:url";

import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";
import vueDevTools from "vite-plugin-vue-devtools";
import tailwindcss from "@tailwindcss/vite";

// https://vite.dev/config/
export default defineConfig({
  plugins: [vue(), vueDevTools(), tailwindcss()],
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
  server: {
    // 1. 设置开发服务器端口
    port: 8080, 

    // 2. 配置代理
    proxy: {
      // 匹配所有以 '/api' 开头的请求
      '/api': {
        // 目标后端服务器地址
        target: 'http://ccb.aoinatsu.com',
        changeOrigin: true,
      }
    },
  },
});
